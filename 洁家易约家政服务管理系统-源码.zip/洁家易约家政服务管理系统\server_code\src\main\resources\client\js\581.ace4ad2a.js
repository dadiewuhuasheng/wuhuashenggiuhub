"use strict";
(self["webpackChunkvue3_nf0"] = self["webpackChunkvue3_nf0"] || []).push([[581],{

/***/ 1581:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ formAdd; }
});

// EXTERNAL MODULE: ../../../../../../../node_modules_front/1/node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(4818);
// EXTERNAL MODULE: ../../../../../../../node_modules_front/1/node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(5406);
// EXTERNAL MODULE: ../../../../../../../node_modules_front/1/node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(3870);
// EXTERNAL MODULE: ../../../../../../../node_modules_front/1/node_modules/vue-router/dist/vue-router.esm-bundler.js
var vue_router_esm_bundler = __webpack_require__(1503);
// EXTERNAL MODULE: ../../../../../../../node_modules_front/1/node_modules/vuex/dist/vuex.esm-bundler.js + 5 modules
var vuex_esm_bundler = __webpack_require__(231);
;// CONCATENATED MODULE: ../../../../../../../node_modules_front/1/node_modules/thread-loader/dist/cjs.js!../../../../../../../node_modules_front/1/node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!../../../../../../../node_modules_front/1/node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/pages/yonghu/formAdd.vue?vue&type=script&setup=true&lang=js

const _hoisted_1 = {
  class: "edit_view"
};
const _hoisted_2 = {
  class: "breadcrumb-wrapper",
  style: {
    "width": "100%"
  }
};
const _hoisted_3 = {
  class: "bread_view"
};
const _hoisted_4 = {
  class: "formModel_btn_box"
};



const tableName = 'yonghu';
const formName = '用户';
//基础信息

/* harmony default export */ var formAddvue_type_script_setup_true_lang_js = ({
  __name: 'formAdd',
  setup(__props) {
    const store = (0,vuex_esm_bundler/* useStore */.oR)();
    const user = (0,runtime_core_esm_bundler/* computed */.Fl)(() => store.getters['user/session']);
    const moment = window.moment;
    const context = (0,runtime_core_esm_bundler/* getCurrentInstance */.FN)()?.appContext.config.globalProperties;
    const route = (0,vue_router_esm_bundler/* useRoute */.yj)();
    const router = (0,vue_router_esm_bundler/* useRouter */.tv)();
    //基础信息
    const breadList = (0,reactivity_esm_bundler/* ref */.iH)([{
      name: formName
    }]);
    //获取唯一标识
    const getUUID = () => {
      return new Date().getTime();
    };
    //form表单
    const form = (0,reactivity_esm_bundler/* ref */.iH)({
      yonghuxingming: '',
      nianling: 0,
      lianxifangshi: '',
      zhanghao: '',
      mima: '',
      touxiang: '',
      jiazhengfuwudizhi: ''
    });
    const formRef = (0,reactivity_esm_bundler/* ref */.iH)(null);
    const id = (0,reactivity_esm_bundler/* ref */.iH)(0);
    const type = (0,reactivity_esm_bundler/* ref */.iH)('');
    const disabledForm = (0,reactivity_esm_bundler/* ref */.iH)({
      yonghuxingming: false,
      nianling: false,
      lianxifangshi: false,
      zhanghao: false,
      mima: false,
      touxiang: false,
      jiazhengfuwudizhi: false
    });
    const isAdd = (0,reactivity_esm_bundler/* ref */.iH)(false);
    //表单验证
    const rules = (0,reactivity_esm_bundler/* ref */.iH)({
      yonghuxingming: [{
        required: true,
        message: '请输入',
        trigger: 'blur'
      }],
      nianling: [{
        required: true,
        message: '请输入',
        trigger: 'blur'
      }, {
        validator: context.$toolUtil.validator.intNumber,
        trigger: 'blur'
      }],
      lianxifangshi: [{
        required: true,
        message: '请输入',
        trigger: 'blur'
      }, {
        validator: context.$toolUtil.validator.mobile,
        trigger: 'blur'
      }],
      zhanghao: [{
        required: true,
        message: '请输入',
        trigger: 'blur'
      }],
      mima: [{
        required: true,
        message: '请输入',
        trigger: 'blur'
      }],
      touxiang: [],
      jiazhengfuwudizhi: []
    });
    //头像上传回调
    const touxiangUploadSuccess = e => {
      form.value.touxiang = e;
    };
    //获取info
    const getInfo = () => {
      context?.$http({
        url: `${tableName}/info/${id.value}`,
        method: 'get'
      }).then(res => {
        let reg = new RegExp('../../../file', 'g');
        form.value = res.data.data;
      });
    };
    const crossRow = (0,reactivity_esm_bundler/* ref */.iH)('');
    const crossTable = (0,reactivity_esm_bundler/* ref */.iH)('');
    const crossTips = (0,reactivity_esm_bundler/* ref */.iH)('');
    const crossColumnName = (0,reactivity_esm_bundler/* ref */.iH)('');
    const crossColumnValue = (0,reactivity_esm_bundler/* ref */.iH)('');
    //初始化
    const init = (formId = null, formType = 'add', formNames = '', row = null, table = null, statusColumnName = null, tips = null, statusColumnValue = null) => {
      if (formId) {
        id.value = formId;
        type.value = formType;
      }
      if (formType == 'add') {
        isAdd.value = true;
      } else if (formType == 'info') {
        isAdd.value = false;
        getInfo();
      } else if (formType == 'edit') {
        isAdd.value = true;
        getInfo();
      } else if (formType == 'cross') {
        isAdd.value = true;
        // getInfo()
        for (let x in row) {
          if (x == 'yonghuxingming') {
            form.value.yonghuxingming = row[x];
            disabledForm.value.yonghuxingming = true;
            continue;
          }
          if (x == 'nianling') {
            form.value.nianling = row[x];
            disabledForm.value.nianling = true;
            continue;
          }
          if (x == 'lianxifangshi') {
            form.value.lianxifangshi = row[x];
            disabledForm.value.lianxifangshi = true;
            continue;
          }
          if (x == 'zhanghao') {
            form.value.zhanghao = row[x];
            disabledForm.value.zhanghao = true;
            continue;
          }
          if (x == 'mima') {
            form.value.mima = row[x];
            disabledForm.value.mima = true;
            continue;
          }
          if (x == 'touxiang') {
            form.value.touxiang = row[x];
            disabledForm.value.touxiang = true;
            continue;
          }
          if (x == 'jiazhengfuwudizhi') {
            form.value.jiazhengfuwudizhi = row[x];
            disabledForm.value.jiazhengfuwudizhi = true;
            continue;
          }
        }
        if (row) {
          crossRow.value = row;
        }
        if (table) {
          crossTable.value = table;
        }
        if (tips) {
          crossTips.value = tips;
        }
        if (statusColumnName) {
          crossColumnName.value = statusColumnName;
        }
        if (statusColumnValue) {
          crossColumnValue.value = statusColumnValue;
        }
      }
      context?.$http({
        url: `${context?.$toolUtil.storageGet('frontSessionTable')}/session`,
        method: 'get'
      }).then(res => {
        var json = res.data.data;
        if (localStorage.getItem('autoSave')) {
          localStorage.removeItem('autoSave');
          save();
        }
      });
    };
    //初始化
    //取消
    const backClick = () => {
      history.back();
    };
    //提交
    const save = () => {
      if (form.value.touxiang != null) {
        form.value.touxiang = form.value.touxiang.replace(new RegExp(context?.$config.url, "g"), "");
      }
      var table = crossTable.value;
      var objcross = JSON.parse(JSON.stringify(crossRow.value));
      let crossUserId = '';
      let crossRefId = '';
      let crossOptNum = '';
      formRef.value.validate(async valid => {
        if (valid) {
          if (type.value == 'cross') {
            if (crossColumnName.value != '') {
              if (!crossColumnName.value.startsWith('[')) {
                for (let o in objcross) {
                  if (o == crossColumnName.value) {
                    objcross[o] = crossColumnValue.value;
                  }
                }
                //修改跨表数据
                await changeCrossData(objcross);
              } else {
                crossUserId = context?.$toolUtil.storageGet('userid');
                crossRefId = objcross['id'];
                crossOptNum = crossColumnName.value.replace(/\[/, "").replace(/\]/, "");
              }
            }
          }
          if (crossUserId && crossRefId) {
            //限制用户操作次数
            form.value.crossuserid = crossUserId;
            form.value.crossrefid = crossRefId;
            let params = {
              page: 1,
              limit: 1000,
              crossuserid: form.value.crossuserid,
              crossrefid: form.value.crossrefid
            };
            context?.$http({
              url: `${tableName}/page`,
              method: 'get',
              params: params
            }).then(async res => {
              if (res.data.data.total >= crossOptNum) {
                context?.$toolUtil.message(`${crossTips.value}`, 'error');
                return false;
              } else {
                context?.$http({
                  url: `${tableName}/${!form.value.id ? "save" : "update"}`,
                  method: 'post',
                  data: form.value
                }).then(async res => {
                  context?.$toolUtil.message(`操作成功`, 'success');
                  history.back();
                });
              }
            });
          } else {
            context?.$http({
              url: `${tableName}/${!form.value.id ? "save" : "update"}`,
              method: 'post',
              data: form.value
            }).then(async res => {
              context?.$toolUtil.message(`操作成功`, 'success');
              history.back();
            });
          }
        }
      });
    };
    //修改跨表数据
    const changeCrossData = (row, key) => {
      if (type.value == 'cross') {
        let data = row;
        if (key) {
          //如果有指定key，则只更新key属性
          data = {
            id: row.id
          };
          data[key] = row[key];
        }
        context?.$http({
          url: `${crossTable.value}/update`,
          method: 'post',
          data: data
        }).then(res => {});
      }
    };
    (0,runtime_core_esm_bundler/* onMounted */.bv)(() => {
      type.value = route.query.type ? route.query.type : 'add';
      let row = null;
      let table = null;
      let statusColumnName = null;
      let tips = null;
      let statusColumnValue = null;
      if (type.value == 'cross') {
        row = context?.$toolUtil.storageGet('crossObj') ? JSON.parse(context?.$toolUtil.storageGet('crossObj')) : {};
        table = context?.$toolUtil.storageGet('crossTable');
        statusColumnName = context?.$toolUtil.storageGet('crossStatusColumnName');
        tips = context?.$toolUtil.storageGet('crossTips');
        statusColumnValue = context?.$toolUtil.storageGet('crossStatusColumnValue');
      }
      init(route.query.id ? route.query.id : null, type.value, '', row, table, statusColumnName, tips, statusColumnValue);
    });
    (0,runtime_core_esm_bundler/* onUnmounted */.Ah)(() => {
      Object.keys(localStorage).map(item => {
        if (item.startsWith('cross')) {
          localStorage.removeItem(item);
        }
      });
    });
    return (_ctx, _cache) => {
      const _component_el_breadcrumb_item = (0,runtime_core_esm_bundler/* resolveComponent */.up)("el-breadcrumb-item");
      const _component_el_breadcrumb = (0,runtime_core_esm_bundler/* resolveComponent */.up)("el-breadcrumb");
      const _component_el_input = (0,runtime_core_esm_bundler/* resolveComponent */.up)("el-input");
      const _component_el_form_item = (0,runtime_core_esm_bundler/* resolveComponent */.up)("el-form-item");
      const _component_el_col = (0,runtime_core_esm_bundler/* resolveComponent */.up)("el-col");
      const _component_uploads = (0,runtime_core_esm_bundler/* resolveComponent */.up)("uploads");
      const _component_el_row = (0,runtime_core_esm_bundler/* resolveComponent */.up)("el-row");
      const _component_el_button = (0,runtime_core_esm_bundler/* resolveComponent */.up)("el-button");
      const _component_el_form = (0,runtime_core_esm_bundler/* resolveComponent */.up)("el-form");
      return (0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [(0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_2, [(0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_breadcrumb, {
        separator: "Ξ",
        class: "breadcrumb"
      }, {
        default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_breadcrumb_item, {
          class: "first_breadcrumb",
          to: {
            path: '/'
          }
        }, {
          default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => _cache[6] || (_cache[6] = [(0,runtime_core_esm_bundler/* createTextVNode */.Uk)("首页", -1)])),
          _: 1,
          __: [6]
        }), ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(breadList.value, (item, index) => {
          return (0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_el_breadcrumb_item, {
            class: "second_breadcrumb",
            key: index
          }, {
            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(item.name), 1)]),
            _: 2
          }, 1024);
        }), 128))]),
        _: 1
      })])]), (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_form, {
        ref_key: "formRef",
        ref: formRef,
        model: form.value,
        class: "add_form",
        "label-width": "120px",
        rules: rules.value
      }, {
        default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_row, null, {
          default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_col, {
            span: 12
          }, {
            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_form_item, {
              label: "用户姓名",
              prop: "yonghuxingming"
            }, {
              default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_input, {
                class: "list_inp",
                modelValue: form.value.yonghuxingming,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => form.value.yonghuxingming = $event),
                placeholder: "用户姓名",
                type: "text",
                readonly: !isAdd.value || disabledForm.value.yonghuxingming ? true : false
              }, null, 8, ["modelValue", "readonly"])]),
              _: 1
            })]),
            _: 1
          }), (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_col, {
            span: 12
          }, {
            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_form_item, {
              label: "年龄",
              prop: "nianling"
            }, {
              default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_input, {
                class: "list_inp",
                modelValue: form.value.nianling,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => form.value.nianling = $event),
                modelModifiers: {
                  number: true
                },
                placeholder: "年龄",
                type: "text",
                readonly: !isAdd.value || disabledForm.value.nianling ? true : false
              }, null, 8, ["modelValue", "readonly"])]),
              _: 1
            })]),
            _: 1
          }), (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_col, {
            span: 12
          }, {
            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_form_item, {
              label: "联系方式",
              prop: "lianxifangshi"
            }, {
              default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_input, {
                class: "list_inp",
                modelValue: form.value.lianxifangshi,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => form.value.lianxifangshi = $event),
                placeholder: "联系方式",
                type: "text",
                readonly: !isAdd.value || disabledForm.value.lianxifangshi ? true : false
              }, null, 8, ["modelValue", "readonly"])]),
              _: 1
            })]),
            _: 1
          }), (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_col, {
            span: 12
          }, {
            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_form_item, {
              label: "账号",
              prop: "zhanghao"
            }, {
              default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_input, {
                class: "list_inp",
                modelValue: form.value.zhanghao,
                "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => form.value.zhanghao = $event),
                placeholder: "账号",
                type: "text",
                readonly: !isAdd.value || disabledForm.value.zhanghao ? true : false
              }, null, 8, ["modelValue", "readonly"])]),
              _: 1
            })]),
            _: 1
          }), (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_col, {
            span: 12
          }, {
            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_form_item, {
              label: "密码",
              prop: "mima"
            }, {
              default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_input, {
                class: "list_inp",
                modelValue: form.value.mima,
                "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => form.value.mima = $event),
                placeholder: "密码",
                type: "password",
                readonly: !isAdd.value || disabledForm.value.mima ? true : false
              }, null, 8, ["modelValue", "readonly"])]),
              _: 1
            })]),
            _: 1
          }), (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_col, {
            span: 12
          }, {
            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_form_item, {
              label: "头像",
              prop: "touxiang"
            }, {
              default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_uploads, {
                disabled: !isAdd.value || disabledForm.value.touxiang ? true : false,
                action: "file/upload",
                tip: "请上传头像",
                style: {
                  "width": "100%",
                  "text-align": "left"
                },
                fileUrls: form.value.touxiang ? form.value.touxiang : '',
                onChange: touxiangUploadSuccess
              }, null, 8, ["disabled", "fileUrls"])]),
              _: 1
            })]),
            _: 1
          }), (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_col, {
            span: 12
          }, {
            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_form_item, {
              label: "家政服务地址",
              prop: "jiazhengfuwudizhi"
            }, {
              default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_input, {
                class: "list_inp",
                modelValue: form.value.jiazhengfuwudizhi,
                "onUpdate:modelValue": _cache[5] || (_cache[5] = $event => form.value.jiazhengfuwudizhi = $event),
                placeholder: "家政服务地址",
                type: "text",
                readonly: !isAdd.value || disabledForm.value.jiazhengfuwudizhi ? true : false
              }, null, 8, ["modelValue", "readonly"])]),
              _: 1
            })]),
            _: 1
          })]),
          _: 1
        }), (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_button, {
          class: "formModel_cancel",
          onClick: backClick
        }, {
          default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => _cache[7] || (_cache[7] = [(0,runtime_core_esm_bundler/* createTextVNode */.Uk)("取消", -1)])),
          _: 1,
          __: [7]
        }), (0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_button, {
          class: "formModel_confirm",
          onClick: save,
          type: "success"
        }, {
          default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => _cache[8] || (_cache[8] = [(0,runtime_core_esm_bundler/* createTextVNode */.Uk)(" 保存 ", -1)])),
          _: 1,
          __: [8]
        })])]),
        _: 1
      }, 8, ["model", "rules"])]);
    };
  }
});
;// CONCATENATED MODULE: ./src/views/pages/yonghu/formAdd.vue?vue&type=script&setup=true&lang=js
 
;// CONCATENATED MODULE: ../../../../../../../node_modules_front/1/node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-22.use[0]!../../../../../../../node_modules_front/1/node_modules/css-loader/dist/cjs.js??clonedRuleSet-22.use[1]!../../../../../../../node_modules_front/1/node_modules/vue-loader/dist/stylePostLoader.js!../../../../../../../node_modules_front/1/node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-22.use[2]!../../../../../../../node_modules_front/1/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-22.use[3]!../../../../../../../node_modules_front/1/node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/pages/yonghu/formAdd.vue?vue&type=style&index=0&id=5247d034&lang=scss
// extracted by mini-css-extract-plugin

;// CONCATENATED MODULE: ./src/views/pages/yonghu/formAdd.vue?vue&type=style&index=0&id=5247d034&lang=scss

;// CONCATENATED MODULE: ./src/views/pages/yonghu/formAdd.vue



;

const __exports__ = formAddvue_type_script_setup_true_lang_js;

/* harmony default export */ var formAdd = (__exports__);

/***/ })

}]);
//# sourceMappingURL=581.ace4ad2a.js.map