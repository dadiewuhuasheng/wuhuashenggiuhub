import { createRouter, createWebHashHistory } from 'vue-router'
import index from '../views'
import home from '../views/pages/home.vue'

const routes = [{
		path: '/',
		redirect: '/index/home'
	},
	{
		path: '/index',
		component: index,
		children: [{
			path: 'home',
			component: home
		}
		, {
			path: 'fuwuxinxiList',
			component: ()=>import('@/views/pages/fuwuxinxi/list')
		}, {
			path: 'fuwuxinxiDetail',
			component: ()=>import('@/views/pages/fuwuxinxi/formModel')
		}, {
			path: 'fuwuxinxiAdd',
			component: ()=>import('@/views/pages/fuwuxinxi/formAdd')
		}
		, {
			path: 'fuwuyuyueList',
			component: ()=>import('@/views/pages/fuwuyuyue/list')
		}, {
			path: 'fuwuyuyueDetail',
			component: ()=>import('@/views/pages/fuwuyuyue/formModel')
		}, {
			path: 'fuwuyuyueAdd',
			component: ()=>import('@/views/pages/fuwuyuyue/formAdd')
		}
		, {
			path: 'fuwujiedanList',
			component: ()=>import('@/views/pages/fuwujiedan/list')
		}, {
			path: 'fuwujiedanDetail',
			component: ()=>import('@/views/pages/fuwujiedan/formModel')
		}, {
			path: 'fuwujiedanAdd',
			component: ()=>import('@/views/pages/fuwujiedan/formAdd')
		}
		, {
			path: 'fuwudakaList',
			component: ()=>import('@/views/pages/fuwudaka/list')
		}, {
			path: 'fuwudakaDetail',
			component: ()=>import('@/views/pages/fuwudaka/formModel')
		}, {
			path: 'fuwudakaAdd',
			component: ()=>import('@/views/pages/fuwudaka/formAdd')
		}
		, {
			path: 'fuwujiluList',
			component: ()=>import('@/views/pages/fuwujilu/list')
		}, {
			path: 'fuwujiluDetail',
			component: ()=>import('@/views/pages/fuwujilu/formModel')
		}, {
			path: 'fuwujiluAdd',
			component: ()=>import('@/views/pages/fuwujilu/formAdd')
		}
		, {
			path: 'fuwupingjiaList',
			component: ()=>import('@/views/pages/fuwupingjia/list')
		}, {
			path: 'fuwupingjiaDetail',
			component: ()=>import('@/views/pages/fuwupingjia/formModel')
		}, {
			path: 'fuwupingjiaAdd',
			component: ()=>import('@/views/pages/fuwupingjia/formAdd')
		}
		, {
			path: 'newsList',
			component: ()=>import('@/views/pages/news/list')
		}
		, {
			path: 'yonghuList',
			component: ()=>import('@/views/pages/yonghu/list')
		}, {
			path: 'yonghuDetail',
			component: ()=>import('@/views/pages/yonghu/formModel')
		}, {
			path: 'yonghuAdd',
			component: ()=>import('@/views/pages/yonghu/formAdd')
		}
		, {
			path: 'yonghuCenter',
			component: ()=>import('@/views/pages/yonghu/center')
		}
		, {
			path: 'fuwurenyuanList',
			component: ()=>import('@/views/pages/fuwurenyuan/list')
		}, {
			path: 'fuwurenyuanDetail',
			component: ()=>import('@/views/pages/fuwurenyuan/formModel')
		}, {
			path: 'fuwurenyuanAdd',
			component: ()=>import('@/views/pages/fuwurenyuan/formAdd')
		}
        , {
            path: 'storeupList',
            component: ()=>import('@/views/pages/storeup/list')
        }
		, {
			path: 'syslogList',
			component: ()=>import('@/views/pages/syslog/list')
		}, {
			path: 'syslogDetail',
			component: ()=>import('@/views/pages/syslog/formModel')
		}, {
			path: 'syslogAdd',
			component: ()=>import('@/views/pages/syslog/formAdd')
		}
		]
	},
	{
		path: '/login',
		component: ()=>import('../views/pages/login.vue')
	}
	,{
		path: '/yonghuRegister',
		component: ()=>import('@/views/pages/yonghu/register')
	}
]

const router = createRouter({
  history: createWebHashHistory(process.env.BASE_URL),
  routes
})
// 全局后置钩子，路由跳转后执行
router.afterEach(() => {
    // 滚动到顶部
    window.scrollTo(0, 0)
})

export default router
