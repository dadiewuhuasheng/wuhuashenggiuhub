"use strict";
(self["webpackChunkvue3_nf0"] = self["webpackChunkvue3_nf0"] || []).push([[118],{

/***/ 7118:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ formModel; }
});

// EXTERNAL MODULE: ../../../../../../../node_modules_front/1/node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(4818);
// EXTERNAL MODULE: ../../../../../../../node_modules_front/1/node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(5406);
// EXTERNAL MODULE: ../../../../../../../node_modules_front/1/node_modules/axios/lib/axios.js + 40 modules
var axios = __webpack_require__(362);
// EXTERNAL MODULE: ../../../../../../../node_modules_front/1/node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js
var reactivity_esm_bundler = __webpack_require__(3870);
// EXTERNAL MODULE: ../../../../../../../node_modules_front/1/node_modules/vue-router/dist/vue-router.esm-bundler.js
var vue_router_esm_bundler = __webpack_require__(1503);
// EXTERNAL MODULE: ../../../../../../../node_modules_front/1/node_modules/vuex/dist/vuex.esm-bundler.js + 5 modules
var vuex_esm_bundler = __webpack_require__(231);
;// CONCATENATED MODULE: ../../../../../../../node_modules_front/1/node_modules/thread-loader/dist/cjs.js!../../../../../../../node_modules_front/1/node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!../../../../../../../node_modules_front/1/node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/pages/fuwuxinxi/formModel.vue?vue&type=script&setup=true&lang=js

const _hoisted_1 = {
  class: "detail-page"
};
const _hoisted_2 = {
  class: "breadcrumb-wrapper",
  style: {
    "width": "100%"
  }
};
const _hoisted_3 = {
  class: "bread_view"
};
const _hoisted_4 = {
  class: "back_view"
};
const _hoisted_5 = {
  class: "detail_view"
};
const _hoisted_6 = {
  class: "swiper_view"
};
const _hoisted_7 = ["src"];
const _hoisted_8 = {
  class: "info_view"
};
const _hoisted_9 = {
  class: "title_view"
};
const _hoisted_10 = {
  class: "detail_title"
};
const _hoisted_11 = {
  class: "info_item"
};
const _hoisted_12 = {
  class: "info_text"
};
const _hoisted_13 = {
  class: "info_item"
};
const _hoisted_14 = {
  class: "info_text"
};
const _hoisted_15 = {
  class: "info_item"
};
const _hoisted_16 = {
  class: "info_text"
};
const _hoisted_17 = {
  class: "btn_view"
};




const tableName = 'fuwuxinxi';
const formName = '服务信息';
//基础信息

/* harmony default export */ var formModelvue_type_script_setup_true_lang_js = ({
  __name: 'formModel',
  setup(__props) {
    const moment = window.moment;
    const store = (0,vuex_esm_bundler/* useStore */.oR)();
    const user = (0,runtime_core_esm_bundler/* computed */.Fl)(() => store.getters['user/session']);
    const userAvatar = (0,runtime_core_esm_bundler/* computed */.Fl)(() => store.getters['user/avatar']);
    const context = (0,runtime_core_esm_bundler/* getCurrentInstance */.FN)()?.appContext.config.globalProperties;
    const route = (0,vue_router_esm_bundler/* useRoute */.yj)();
    const router = (0,vue_router_esm_bundler/* useRouter */.tv)();
    const baseUrl = (0,reactivity_esm_bundler/* ref */.iH)(context.$config.url);
    //基础信息
    const breadList = (0,reactivity_esm_bundler/* ref */.iH)([{
      name: formName
    }]);
    //权限验证
    const btnAuth = (e, a) => {
      if (centerType.value) {
        return context?.$toolUtil.isBackAuth(e, a);
      } else {
        return context?.$toolUtil.isAuth(e, a);
      }
    };
    //查看权限验证
    const btnFrontAuth = (e, a) => {
      if (centerType.value) {
        return context?.$toolUtil.isBackAuth(e, a);
      } else {
        return context?.$toolUtil.isFrontAuth(e, a);
      }
    };
    // 返回
    const backClick = () => {
      history.back();
    };
    // 轮播图
    const bannerList = (0,reactivity_esm_bundler/* ref */.iH)([]);
    // 详情
    const title = (0,reactivity_esm_bundler/* ref */.iH)('');
    const detail = (0,reactivity_esm_bundler/* ref */.iH)({});
    const activeName = (0,reactivity_esm_bundler/* ref */.iH)('false');
    const getDetail = () => {
      context?.$http({
        url: `${tableName}/detail/${route.query.id}`,
        method: 'get'
      }).then(res => {
        bannerList.value = res.data.data.tupian ? res.data.data.tupian.split(',') : [];
        title.value = res.data.data.fuwuxiangmu;
        detail.value = res.data.data;
      });
    };
    // 下载文件
    const downClick = file => {
      if (!file) {
        context?.$toolUtil.message('文件不存在', 'error');
      }
      let arr = file.replace(new RegExp('file/', "g"), "");
      axios/* default.get */.Z.get((location.href.split(context?.$config.name).length > 1 ? location.href.split(context?.$config.name)[0] : '') + context?.$config.name + '/file/download?fileName=' + arr, {
        headers: {
          token: context?.$toolUtil.storageGet('frontToken')
        },
        responseType: "blob"
      }).then(({
        data
      }) => {
        const binaryData = [];
        binaryData.push(data);
        const objectUrl = window.URL.createObjectURL(new Blob(binaryData, {
          type: 'application/pdf;chartset=UTF-8'
        }));
        const a = document.createElement('a');
        a.href = objectUrl;
        a.download = arr;
        // a.click()
        // 下面这个写法兼容火狐
        a.dispatchEvent(new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window
        }));
        window.URL.revokeObjectURL(data);
      });
    };
    const approvalSave = async form => {
      context.$http.post(`${tableName}/update`, form).then(res => {
        context.$message.success('审核成功');
        approvalRef.value.approvalVisible = false;
        init();
      });
    };
    // 判断是否从个人中心跳转
    const centerType = (0,reactivity_esm_bundler/* ref */.iH)(false);
    const init = () => {
      if (route.query.centerType) {
        centerType.value = true;
      }
      getDetail();
      // 收藏
      getCollect();
    };
    // 收藏
    const collectType = (0,reactivity_esm_bundler/* ref */.iH)(false);
    const collectInfo = (0,reactivity_esm_bundler/* ref */.iH)({});
    const getCollect = () => {
      if (context?.$toolUtil.storageGet('frontToken')) {
        context?.$http({
          url: 'storeup/list',
          method: 'get',
          params: {
            page: 1,
            limit: 1,
            type: 1,
            refid: route.query.id,
            tablename: tableName,
            userid: context?.$toolUtil.storageGet('userid')
          }
        }).then(res => {
          if (res.data.data.list.length) {
            collectType.value = true;
            collectInfo.value = res.data.data.list[0];
          } else {
            collectType.value = false;
            collectInfo.value = {};
          }
        });
      }
    };
    // 收藏按钮
    const collectClick = type => {
      if (type == 1 && !collectType.value) {
        let params = {
          name: title.value,
          picture: bannerList.value[0],
          refid: detail.value.id,
          type: type,
          tablename: tableName,
          userid: context?.$toolUtil.storageGet('userid')
        };
        context?.$http({
          url: 'storeup/add',
          method: 'post',
          data: params
        }).then(res => {
          detail.value.storeupNumber += 1;
          context?.$http({
            url: `${tableName}/update`,
            method: 'post',
            data: detail.value
          });
          collectType.value = true;
          getCollect();
          context?.$toolUtil.message('收藏成功', 'success');
        });
      } else if (type == -1 && collectType.value) {
        let ids = [];
        ids.push(collectInfo.value.id);
        context?.$http({
          url: 'storeup/delete',
          method: 'post',
          data: ids
        }).then(res => {
          detail.value.storeupNumber -= 1;
          context?.$http({
            url: `${tableName}/update`,
            method: 'post',
            data: detail.value
          });
          collectInfo.value = {};
          collectType.value = false;
          context?.$toolUtil.message('取消成功', 'success');
        });
      }
    };
    //修改
    const editClick = () => {
      router.push(`/index/${tableName}Add?id=${detail.value.id}&&type=edit`);
    };
    //删除
    const delClick = () => {
      ElMessageBox.confirm(`是否删除此${formName}？`, '提示', {
        confirmButtonText: '是',
        cancelButtonText: '否',
        type: 'warning'
      }).then(() => {
        context?.$http({
          url: `${tableName}/delete`,
          method: 'post',
          data: [detail.value.id]
        }).then(res => {
          context?.$toolUtil.message('删除成功', 'success', () => {
            history.back();
          });
        });
      }).catch(_ => {});
    };
    const fuwuyuyueonAcross = async (btnType, crossOptAudit, crossOptPay, statusColumnName, tips, statusColumnValue, type = 1) => {
      if (!context?.$toolUtil.storageGet('frontToken')) {
        context?.$toolUtil.message('请登录后再操作！', 'error');
        return false;
      }
      if (!btnAuth('fuwuxinxi', btnType)) {
        context?.$toolUtil.message('暂无权限操作！', 'error');
        return false;
      }
      context?.$toolUtil.storageSet('crossObj', JSON.stringify(detail.value));
      context?.$toolUtil.storageSet('crossTable', tableName);
      context?.$toolUtil.storageSet('crossStatusColumnName', statusColumnName);
      context?.$toolUtil.storageSet('crossTips', tips);
      context?.$toolUtil.storageSet('crossStatusColumnValue', statusColumnValue);
      if (statusColumnName != '' && !statusColumnName.startsWith("[")) {
        var obj = detail.value;
        for (var o in obj) {
          if (o == statusColumnName && obj[o] == statusColumnValue) {
            context?.$toolUtil.message(tips, 'warning');
            return;
          }
        }
      }
      (0,runtime_core_esm_bundler/* nextTick */.Y3)(() => {
        router.push(`/index/fuwuyuyueAdd?type=cross&&id=${detail.value.id}`);
      });
    };
    (0,runtime_core_esm_bundler/* onMounted */.bv)(() => {
      init();
    });
    return (_ctx, _cache) => {
      const _component_el_breadcrumb_item = (0,runtime_core_esm_bundler/* resolveComponent */.up)("el-breadcrumb-item");
      const _component_el_breadcrumb = (0,runtime_core_esm_bundler/* resolveComponent */.up)("el-breadcrumb");
      const _component_el_button = (0,runtime_core_esm_bundler/* resolveComponent */.up)("el-button");
      const _component_mySwiper = (0,runtime_core_esm_bundler/* resolveComponent */.up)("mySwiper");
      return (0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", _hoisted_1, [(0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_2, [(0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_3, [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_breadcrumb, {
        separator: "Ξ",
        class: "breadcrumb"
      }, {
        default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_breadcrumb_item, {
          class: "first_breadcrumb",
          to: {
            path: '/'
          }
        }, {
          default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => _cache[3] || (_cache[3] = [(0,runtime_core_esm_bundler/* createTextVNode */.Uk)("首页", -1)])),
          _: 1,
          __: [3]
        }), ((0,runtime_core_esm_bundler/* openBlock */.wg)(true), (0,runtime_core_esm_bundler/* createElementBlock */.iD)(runtime_core_esm_bundler/* Fragment */.HY, null, (0,runtime_core_esm_bundler/* renderList */.Ko)(breadList.value, (item, index) => {
          return (0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_el_breadcrumb_item, {
            class: "second_breadcrumb",
            key: index
          }, {
            default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => [(0,runtime_core_esm_bundler/* createTextVNode */.Uk)((0,shared_esm_bundler/* toDisplayString */.zw)(item.name), 1)]),
            _: 2
          }, 1024);
        }), 128))]),
        _: 1
      })]), (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_4, [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_el_button, {
        class: "back_btn",
        onClick: backClick
      }, {
        default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => _cache[4] || (_cache[4] = [(0,runtime_core_esm_bundler/* createTextVNode */.Uk)("返回", -1)])),
        _: 1,
        __: [4]
      })])]), (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_5, [(0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_6, [(0,runtime_core_esm_bundler/* createVNode */.Wm)(_component_mySwiper, {
        data: bannerList.value,
        type: 3,
        loop: true,
        navigation: false,
        pagination: false,
        paginationType: 1,
        scrollbar: true,
        slidesPerView: 1,
        spaceBetween: 20,
        autoHeight: false,
        centeredSlides: false,
        freeMode: false,
        effectType: 2,
        direction: "horizontal",
        autoplay: true,
        slidesPerColumn: 1
      }, {
        default: (0,runtime_core_esm_bundler/* withCtx */.w5)(scope => [(0,runtime_core_esm_bundler/* createElementVNode */._)("img", {
          src: scope.row ? (scope.row.startsWith('http') ? '' : baseUrl.value) + scope.row : ''
        }, null, 8, _hoisted_7)]),
        _: 1
      }, 8, ["data"])]), (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_8, [(0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_9, [(0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_10, [(0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, (0,shared_esm_bundler/* toDisplayString */.zw)(detail.value.fuwuxiangmu), 1)]), !collectType.value ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
        key: 0,
        class: "collect_view",
        onClick: _cache[0] || (_cache[0] = $event => collectClick(1))
      }, _cache[5] || (_cache[5] = [(0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
        class: "iconfont icon-likeline1"
      }, null, -1), (0,runtime_core_esm_bundler/* createElementVNode */._)("span", null, "收藏", -1)]))) : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true), collectType.value ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createElementBlock */.iD)("div", {
        key: 1,
        class: "collect_view",
        onClick: _cache[1] || (_cache[1] = $event => collectClick(-1))
      }, _cache[6] || (_cache[6] = [(0,runtime_core_esm_bundler/* createElementVNode */._)("i", {
        class: "iconfont iconfontActive icon-likeline1"
      }, null, -1), (0,runtime_core_esm_bundler/* createElementVNode */._)("span", {
        class: "textActive"
      }, "取消收藏", -1)]))) : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)]), (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_11, [_cache[7] || (_cache[7] = (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
        class: "info_label"
      }, "服务价格", -1)), (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_12, (0,shared_esm_bundler/* toDisplayString */.zw)(detail.value.fuwujiage), 1)]), (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_13, [_cache[8] || (_cache[8] = (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
        class: "info_label"
      }, "服务描述", -1)), (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_14, (0,shared_esm_bundler/* toDisplayString */.zw)(detail.value.fuwumiaoshu), 1)]), (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_15, [_cache[9] || (_cache[9] = (0,runtime_core_esm_bundler/* createElementVNode */._)("div", {
        class: "info_label"
      }, "收藏数", -1)), (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_16, (0,shared_esm_bundler/* toDisplayString */.zw)(detail.value.storeupNumber), 1)]), (0,runtime_core_esm_bundler/* createElementVNode */._)("div", _hoisted_17, [btnFrontAuth('fuwuxinxi', '服务预约') ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_el_button, {
        key: 0,
        class: "cross_btn",
        onClick: _cache[2] || (_cache[2] = $event => fuwuyuyueonAcross('服务预约', '', '', '[1]', '请勿重复操作')),
        type: "warning"
      }, {
        default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => _cache[10] || (_cache[10] = [(0,runtime_core_esm_bundler/* createTextVNode */.Uk)("服务预约", -1)])),
        _: 1,
        __: [10]
      })) : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true), centerType.value && btnAuth('fuwuxinxi', '修改') ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_el_button, {
        key: 1,
        class: "edit_btn",
        type: "primary",
        onClick: editClick
      }, {
        default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => _cache[11] || (_cache[11] = [(0,runtime_core_esm_bundler/* createTextVNode */.Uk)("修改", -1)])),
        _: 1,
        __: [11]
      })) : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true), centerType.value && btnAuth('fuwuxinxi', '删除') ? ((0,runtime_core_esm_bundler/* openBlock */.wg)(), (0,runtime_core_esm_bundler/* createBlock */.j4)(_component_el_button, {
        key: 2,
        class: "del_btn",
        type: "danger",
        onClick: delClick
      }, {
        default: (0,runtime_core_esm_bundler/* withCtx */.w5)(() => _cache[12] || (_cache[12] = [(0,runtime_core_esm_bundler/* createTextVNode */.Uk)("删除", -1)])),
        _: 1,
        __: [12]
      })) : (0,runtime_core_esm_bundler/* createCommentVNode */.kq)("", true)])])])]);
    };
  }
});
;// CONCATENATED MODULE: ./src/views/pages/fuwuxinxi/formModel.vue?vue&type=script&setup=true&lang=js
 
;// CONCATENATED MODULE: ../../../../../../../node_modules_front/1/node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-22.use[0]!../../../../../../../node_modules_front/1/node_modules/css-loader/dist/cjs.js??clonedRuleSet-22.use[1]!../../../../../../../node_modules_front/1/node_modules/vue-loader/dist/stylePostLoader.js!../../../../../../../node_modules_front/1/node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-22.use[2]!../../../../../../../node_modules_front/1/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-22.use[3]!../../../../../../../node_modules_front/1/node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/views/pages/fuwuxinxi/formModel.vue?vue&type=style&index=0&id=18b3c044&lang=scss&scoped=true
// extracted by mini-css-extract-plugin

;// CONCATENATED MODULE: ./src/views/pages/fuwuxinxi/formModel.vue?vue&type=style&index=0&id=18b3c044&lang=scss&scoped=true

// EXTERNAL MODULE: ../../../../../../../node_modules_front/1/node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(3815);
;// CONCATENATED MODULE: ./src/views/pages/fuwuxinxi/formModel.vue



;


const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.Z)(formModelvue_type_script_setup_true_lang_js, [['__scopeId',"data-v-18b3c044"]])

/* harmony default export */ var formModel = (__exports__);

/***/ })

}]);
//# sourceMappingURL=118.e15746d1.js.map