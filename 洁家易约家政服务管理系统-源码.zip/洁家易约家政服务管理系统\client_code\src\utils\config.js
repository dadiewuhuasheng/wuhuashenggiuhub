const config = {
    get() {
        return {
            url : process.env.VUE_APP_BASE_API_URL + process.env.VUE_APP_BASE_API + '/',
            name: process.env.VUE_APP_BASE_API,
			menuList:[
				{
					name: '服务套餐管理',
					icon: '',
					child:[
						{
							name:'服务信息',
                            url:'/index/fuwuxinxiList'

						},
					]
				},

				{
					name: '家政资讯管理',
					icon: '',
					child:[
						{
							name:'家政资讯',
                            url:'/index/newsList'

						},
					]
				},

			]
        }
    },
    getProjectName(){
        return {
            projectName: `基于Spring Boot的“洁家易约”家政服务管理系统的设计与实现`
        } 
    }
}
export default config
