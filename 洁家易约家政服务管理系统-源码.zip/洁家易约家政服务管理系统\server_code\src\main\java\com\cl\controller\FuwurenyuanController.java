package com.cl.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.*;
import java.lang.*;
import java.math.*;
import java.util.stream.Collectors;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

import com.cl.entity.TokenEntity;
import com.cl.utils.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.cl.annotation.IgnoreAuth;
import com.cl.annotation.SysLog;

import com.cl.entity.FuwurenyuanEntity;
import com.cl.entity.view.FuwurenyuanView;

import com.cl.service.FuwurenyuanService;
import com.cl.service.TokenService;

/**
 * 家政人员
 * 后端接口
 * @author 
 * @email 
 * @date 2026-03-27 11:34:08
 */
@RestController
@RequestMapping("/fuwurenyuan")
public class FuwurenyuanController {
    @Autowired
    private FuwurenyuanService fuwurenyuanService;



	@Autowired
	private TokenService tokenService;

	
	/**
	 * 登录
	 */
	@IgnoreAuth
	@RequestMapping(value = "/login")
	public R login(String username, String password, String captcha, HttpServletRequest request) {
		FuwurenyuanEntity u = fuwurenyuanService.selectOne(new EntityWrapper<FuwurenyuanEntity>().eq("renyuanzhanghao", username));
        if(u!=null && u.getIsLocked().intValue()==1) {
            return R.error("账号已锁定，请联系管理员。");
        }
        if(u==null || !u.getMima().equals(password)) {
        if(u!=null) {
            u.setMaxPasswordWrong(u.getMaxPasswordWrong()+1);
            if(u.getMaxPasswordWrong()>=3) {
                u.setIsLocked(1);
            }
                fuwurenyuanService.updateById(u);
        }
            return R.error("账号或密码不正确");
        }
        if(!"是".equals(u.getSfsh())) return R.error("账号已锁定，请联系管理员审核。");
    		String token = tokenService.generateToken(u.getId(), username,"fuwurenyuan",  "服务人员" );
		return R.ok().put("token", token);
	}


	
	/**
     * 注册
     */
	@IgnoreAuth
    @RequestMapping("/register")
    public R register(@RequestBody FuwurenyuanEntity fuwurenyuan){
    	//ValidatorUtils.validateEntity(fuwurenyuan);
                            FuwurenyuanEntity u = fuwurenyuanService.selectOne(new EntityWrapper<FuwurenyuanEntity>().eq("renyuanzhanghao", fuwurenyuan.getRenyuanzhanghao()));
                                                                                                                                                                                    		if(u!=null) {
			return R.error("注册用户已存在");
		}
		Long uId = new Date().getTime();
		fuwurenyuan.setId(uId);
        fuwurenyuanService.insert(fuwurenyuan);
        return R.ok();
    }

	
	/**
	 * 退出
	 */
	@RequestMapping("/logout")
	public R logout(HttpServletRequest request) {
		request.getSession().invalidate();
		return R.ok("退出成功");
	}
	
	/**
     * 获取用户的session用户信息
     */
    @RequestMapping("/session")
    public R getCurrUser(HttpServletRequest request){
    	Long id = (Long)request.getSession().getAttribute("userId");
        return R.ok().put("data", fuwurenyuanService.selectView(new EntityWrapper<FuwurenyuanEntity>().eq("id", id)));
    }
    
    /**
     * 密码重置
     */
    @IgnoreAuth
	@RequestMapping(value = "/resetPass")
    public R resetPass(String username, HttpServletRequest request){
    	FuwurenyuanEntity u = fuwurenyuanService.selectOne(new EntityWrapper<FuwurenyuanEntity>().eq("renyuanzhanghao", username));
    	if(u==null) {
    		return R.error("账号不存在");
    	}
        u.setMima("123456");
        fuwurenyuanService.updateById(u);
        return R.ok("密码已重置为：123456");
    }






    /**
     * 后台列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params,FuwurenyuanEntity fuwurenyuan,
                                                                                                                                                                                                                    HttpServletRequest request){
                                    EntityWrapper<FuwurenyuanEntity> ew = new EntityWrapper<FuwurenyuanEntity>();
                                                                                                                                                                                                                                                                                                                                                
        
        
        PageUtils page = fuwurenyuanService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, fuwurenyuan), params), params));
        Map<String, String> deSens = new HashMap<>();
                                                                                                                                                                                                                                                                                                                            //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(page,deSens);
        return R.ok().put("data", page);
    }







    /**
     * 前端列表
     */
	@IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params,FuwurenyuanEntity fuwurenyuan,
		HttpServletRequest request){
        EntityWrapper<FuwurenyuanEntity> ew = new EntityWrapper<FuwurenyuanEntity>();

		PageUtils page = fuwurenyuanService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, fuwurenyuan), params), params));
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(page,deSens);
        return R.ok().put("data", page);
    }

	/**
     * 列表
     */
    @RequestMapping("/lists")
    public R list( FuwurenyuanEntity fuwurenyuan){
       	EntityWrapper<FuwurenyuanEntity> ew = new EntityWrapper<FuwurenyuanEntity>();
      	ew.allEq(MPUtil.allEQMapPre( fuwurenyuan, MPUtil.camelToSnake("fuwurenyuan")));
        return R.ok().put("data", fuwurenyuanService.selectListView(ew));
    }

	 /**
     * 查询
     */
    @RequestMapping("/query")
    public R query(FuwurenyuanEntity fuwurenyuan){
        EntityWrapper< FuwurenyuanEntity> ew = new EntityWrapper< FuwurenyuanEntity>();
 		ew.allEq(MPUtil.allEQMapPre( fuwurenyuan, MPUtil.camelToSnake("fuwurenyuan")));
		FuwurenyuanView fuwurenyuanView =  fuwurenyuanService.selectView(ew);
		return R.ok("查询家政人员成功").put("data", fuwurenyuanView);
    }
	
    /**
     * 后端详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id){
        FuwurenyuanEntity fuwurenyuan = fuwurenyuanService.selectById(id);
		fuwurenyuan.setClicktime(new Date());
		fuwurenyuanService.updateById(fuwurenyuan);
		fuwurenyuan = fuwurenyuanService.selectView(new EntityWrapper<FuwurenyuanEntity>().eq("id", id));
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(fuwurenyuan,deSens);
        return R.ok().put("data", fuwurenyuan);
    }

    /**
     * 前端详情
     */
	@IgnoreAuth
    @RequestMapping("/detail/{id}")
    public R detail(@PathVariable("id") Long id){
        FuwurenyuanEntity fuwurenyuan = fuwurenyuanService.selectById(id);
		fuwurenyuan.setClicktime(new Date());
		fuwurenyuanService.updateById(fuwurenyuan);
		fuwurenyuan = fuwurenyuanService.selectView(new EntityWrapper<FuwurenyuanEntity>().eq("id", id));
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(fuwurenyuan,deSens);
        return R.ok().put("data", fuwurenyuan);
    }
    



    /**
     * 后端保存
     */
    @RequestMapping("/save")
    @SysLog("新增家政人员")
    public R save(@RequestBody FuwurenyuanEntity fuwurenyuan, HttpServletRequest request){
        if(fuwurenyuanService.selectCount(new EntityWrapper<FuwurenyuanEntity>().eq("renyuanzhanghao", fuwurenyuan.getRenyuanzhanghao()))>0) {
            return R.error("人员账号已存在");
        }
    	fuwurenyuan.setId(new Date().getTime()+new Double(Math.floor(Math.random()*1000)).longValue());
    	//ValidatorUtils.validateEntity(fuwurenyuan);
        FuwurenyuanEntity u = fuwurenyuanService.selectOne(new EntityWrapper<FuwurenyuanEntity>().eq("renyuanzhanghao", fuwurenyuan.getRenyuanzhanghao()));
		if(u!=null) {
			return R.error("用户已存在");
		}
		fuwurenyuan.setId(new Date().getTime());
        fuwurenyuanService.insert(fuwurenyuan);
        return R.ok().put("data",fuwurenyuan.getId());
    }
    
    /**
     * 前端保存
     */
    @SysLog("新增家政人员")
    @RequestMapping("/add")
    public R add(@RequestBody FuwurenyuanEntity fuwurenyuan, HttpServletRequest request){
        if(fuwurenyuanService.selectCount(new EntityWrapper<FuwurenyuanEntity>().eq("renyuanzhanghao", fuwurenyuan.getRenyuanzhanghao()))>0) {
            return R.error("人员账号已存在");
        }
    	fuwurenyuan.setId(new Date().getTime()+new Double(Math.floor(Math.random()*1000)).longValue());
    	//ValidatorUtils.validateEntity(fuwurenyuan);
        FuwurenyuanEntity u = fuwurenyuanService.selectOne(new EntityWrapper<FuwurenyuanEntity>().eq("renyuanzhanghao", fuwurenyuan.getRenyuanzhanghao()));
		if(u!=null) {
			return R.error("用户已存在");
		}
		fuwurenyuan.setId(new Date().getTime());
        fuwurenyuanService.insert(fuwurenyuan);
        return R.ok();
    }


    /**
     * 修改
     */
    @RequestMapping("/update")
    @Transactional
    @SysLog("修改家政人员")
    public R update(@RequestBody FuwurenyuanEntity fuwurenyuan, HttpServletRequest request){
        //ValidatorUtils.validateEntity(fuwurenyuan);
        fuwurenyuanService.updateById(fuwurenyuan);//全部更新
        if(null!=fuwurenyuan.getRenyuanzhanghao())
        {
            // 修改token
            TokenEntity tokenEntity = new TokenEntity();
            tokenEntity.setUsername(fuwurenyuan.getRenyuanzhanghao());
                            tokenEntity.setUsername(fuwurenyuan.getRenyuanzhanghao());
                        tokenService.update(tokenEntity, new EntityWrapper<TokenEntity>().eq("userid", fuwurenyuan.getId()));
        }
        return R.ok();
    }

    /**
     * 审核
     */
    @RequestMapping("/shBatch")
    @Transactional
    @SysLog("审核家政人员")
    public R update(@RequestBody Long[] ids, @RequestParam String sfsh, @RequestParam String shhf){
        List<FuwurenyuanEntity> list = new ArrayList<FuwurenyuanEntity>();
        for(Long id : ids) {
            FuwurenyuanEntity fuwurenyuan = fuwurenyuanService.selectById(id);
            fuwurenyuan.setSfsh(sfsh);
            fuwurenyuan.setShhf(shhf);
            list.add(fuwurenyuan);
        }
        fuwurenyuanService.updateBatchById(list);
        return R.ok();
    }


    

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @SysLog("删除家政人员")
    public R delete(@RequestBody Long[] ids){
        fuwurenyuanService.deleteBatchIds(Arrays.asList(ids));
        return R.ok();
    }

    	
	/**
     * 前端智能排序
     */
	@IgnoreAuth
    @RequestMapping("/autoSort")
    public R autoSort(@RequestParam Map<String, Object> params,FuwurenyuanEntity fuwurenyuan, HttpServletRequest request,String pre){
        EntityWrapper<FuwurenyuanEntity> ew = new EntityWrapper<FuwurenyuanEntity>();
        Map<String, Object> newMap = new HashMap<String, Object>();
        Map<String, Object> param = new HashMap<String, Object>();
		Iterator<Map.Entry<String, Object>> it = param.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, Object> entry = it.next();
			String key = entry.getKey();
			String newKey = entry.getKey();
			if (pre.endsWith(".")) {
				newMap.put(pre + newKey, entry.getValue());
			} else if (StringUtils.isEmpty(pre)) {
				newMap.put(newKey, entry.getValue());
			} else {
				newMap.put(pre + "." + newKey, entry.getValue());
			}
		}
		params.put("sort", "clicktime");
        params.put("order", "desc");
		PageUtils page = fuwurenyuanService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, fuwurenyuan), params), params));
        return R.ok().put("data", page);
    }








}
