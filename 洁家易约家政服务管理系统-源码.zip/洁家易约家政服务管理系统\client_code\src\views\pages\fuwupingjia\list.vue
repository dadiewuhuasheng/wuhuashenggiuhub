<template>
    <div class="list-page">
        <div class="breadcrumb-wrapper" style="width: 100%;">
            <div class="bread_view">
                <el-breadcrumb separator="Ξ" class="breadcrumb">
                    <el-breadcrumb-item class="first_breadcrumb" :to="{ path: '/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item class="second_breadcrumb" v-for="(item,index) in breadList" :key="index">{{item.name}}</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
            <div class="back_view" v-if="centerType">
                <el-button class="back_btn" @click="backClick">返回</el-button>
            </div>
        </div>
		<div class="list_search">
			<div class="search_view">
				<div class="search_label">
					服务项目：
				</div>
				<div class="search_box">
					<el-input class="search_inp" v-model="searchQuery.fuwuxiangmu" placeholder="服务项目"
						clearable>
					</el-input>
				</div>
			</div>
			<div class="search_btn_view">
				<el-button class="search_btn" @click="searchClick">搜索</el-button>
				<el-button class="add_btn" v-if="btnAuth('fuwupingjia','新增')" @click="addClick">新增</el-button>
			</div>
		</div>



                <div class="table_view">
					<el-table v-loading="listLoading" class="data_table" :data="list" border :row-style="{'cursor':'pointer'}"
						@row-click="tableDetailClick" :stripe='false'>
						<el-table-column :resizable='true' align="center" header-align="center" type="selection" width="55" />
						<el-table-column label="序号" width="120" :resizable='true' align="center" header-align="center">
							<template #default="scope">{{ (listQuery.page-1)*listQuery.limit+scope.$index + 1}}</template>
						</el-table-column>
						<el-table-column label="服务项目" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.fuwuxiangmu}}
							</template>
						</el-table-column>
						<el-table-column label="服务价格" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.fuwujiage}}
							</template>
						</el-table-column>
						<el-table-column label="服务描述" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.fuwumiaoshu}}
							</template>
						</el-table-column>
						<el-table-column label="人员账号" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.renyuanzhanghao}}
							</template>
						</el-table-column>
						<el-table-column label="人员姓名" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.renyuanxingming}}
							</template>
						</el-table-column>
						<el-table-column label="预约日期" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.yuyueriqi}}
							</template>
						</el-table-column>
						<el-table-column label="预约时间段" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.yuyueshijianduan}}
							</template>
						</el-table-column>
						<el-table-column label="预约时间" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.yuyueshijian}}
							</template>
						</el-table-column>
						<el-table-column label="账号" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.zhanghao}}
							</template>
						</el-table-column>
						<el-table-column label="用户姓名" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.yonghuxingming}}
							</template>
						</el-table-column>
						<el-table-column label="服务地点" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.fuwudidian}}
							</template>
						</el-table-column>
						<el-table-column label="完成时间" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.wanchengshijian}}
							</template>
						</el-table-column>
						<el-table-column label="订单编号" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.dingdanbianhao}}
							</template>
						</el-table-column>
						<el-table-column label="评价时间" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.pingjiashijian}}
							</template>
						</el-table-column>
						<el-table-column label="审核回复" v-if="centerType" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								{{scope.row.shhf}}
							</template>
						</el-table-column>
						<el-table-column label="审核状态" v-if="centerType" :resizable='true' align="center" header-align="center">
							<template #default="scope">
								<el-tag type="success" v-if="scope.row.sfsh=='是'">通过</el-tag>
								<el-tag type="danger" v-if="scope.row.sfsh=='否'">未通过</el-tag>
								<el-tag type="warning" v-if="scope.row.sfsh=='待审核'">待审核</el-tag>
							</template>
						</el-table-column>
					</el-table>
                </div>

				<el-pagination
					background
					:layout="layouts.join(',')"
					:total="total"
					:page-size="listQuery.limit"
                    v-model:current-page="listQuery.page"
					prev-text="上一页"
					next-text="下一页"
					:hide-on-single-page="false"
					@size-change="sizeChange"
					@current-change="currentChange"/>


    </div>

    <el-dialog v-model="preViewVisible" :title="'查看大图'" width="40%" destroy-on-close>
        <div style="text-align:center">
            <img :src="preViewUrl" style="max-width: 100%;" alt="">
        </div>
    </el-dialog>
</template>

<script setup>
	import {
		ref,
		getCurrentInstance,
		nextTick,
        computed,
        inject,
	} from 'vue';
    const moment = window.moment
	import {
		useRoute,
		useRouter
	} from 'vue-router';
    import {
        useStore
    } from 'vuex';
    const store = useStore()
    const user = computed(()=>store.getters['user/session'])
	const context = getCurrentInstance()?.appContext.config.globalProperties;
	const router = useRouter()
	const route = useRoute()
    const baseUrl = ref(context.$config.url)
	//基础信息
	const tableName = 'fuwupingjia'
	const formName = '服务评价'
	//基础信息
	const breadList = ref([{
		name: formName
	}])
	const list = ref([])
	const listQuery = ref({
		page: 1,
		limit: 20,
	})
	const total = ref(0)
	const listLoading = ref(false)
	//权限验证
	const btnAuth = (e,a)=>{
		if(centerType.value){
			return context?.$toolUtil.isBackAuth(e,a)
		}else{
			return context?.$toolUtil.isAuth(e,a)
		}
	}
	const addClick = () => {
		router.push('/index/fuwupingjiaAdd')
	}
	//判断是否从个人中心跳转
	const centerType = ref(false)
	//返回
	const backClick = () => {
		router.push(`/index/${context?.$toolUtil.storageGet('frontSessionTable')}Center`)
	}
	//搜索
	const searchQuery = ref({})
	//下拉列表
	const searchClick = async() => {
		listQuery.value.page = 1
		getList()
	}
	//分页
	const layouts = ref(["total","prev","pager","next","sizes"])
	const sizeChange = (size) => {
		listQuery.value.limit = size
		getList()
	}
	const currentChange = (page) => {
		listQuery.value.page = page
		getList()
	}
	//分页
	//列表
	const getList = (obj) => {
		listLoading.value = true
		let params = JSON.parse(JSON.stringify(listQuery.value))
		if(searchQuery.value.fuwuxiangmu&&searchQuery.value.fuwuxiangmu!=''){
			params.fuwuxiangmu = '%' + searchQuery.value.fuwuxiangmu + '%'
		}
		if(!centerType.value){
			params['sfsh'] = '是';
		} 
		context?.$http({
			url: `${tableName}/${centerType.value?'page':'list'}`,
			method: 'get',
			params: params
		}).then(res => {
			listLoading.value = false
			list.value = res.data.data.list
			total.value = Number(res.data.data.total)
		})
	}
	const tableDetailClick = (row) => {
		router.push(`${tableName}Detail?id=` + row.id + (centerType.value?'&&centerType=1':''))
	}
	//下载文件
	const download = (file) =>{
		if(!file){
			context?.$toolUtil.message('文件不存在','error')
		}
		const a = document.createElement('a');
		a.style.display = 'none';
		a.setAttribute('target', '_blank');
		file && a.setAttribute('download', file);
		a.href = context?.$config.url + file;
		document.body.appendChild(a);
		a.click();
		document.body.removeChild(a);
	}
	// 查看大图
	const preViewUrl = ref('')
	const preViewVisible = ref(false)
	const preViewClick = (url) =>{
		preViewUrl.value = url
		preViewVisible.value = true
	}
	const init = async() => {
		if(route.query.centerType){
			centerType.value = true
		}
        if(context.$toolUtil.storageGet('frontToken') && !user.value.id){
            await store.dispatch("user/getSession")
        }
		getList()
	}
	init()
</script>
<style lang="scss" scoped>
</style>