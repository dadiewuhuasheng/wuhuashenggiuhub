package com.cl.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.cl.utils.PageUtils;
import com.cl.utils.Query;


import com.cl.dao.FuwurenyuanDao;
import com.cl.entity.FuwurenyuanEntity;
import com.cl.service.FuwurenyuanService;
import com.cl.entity.view.FuwurenyuanView;

@Service("fuwurenyuanService")
public class FuwurenyuanServiceImpl extends ServiceImpl<FuwurenyuanDao, FuwurenyuanEntity> implements FuwurenyuanService {

    	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<FuwurenyuanEntity> page = this.selectPage(
                new Query<FuwurenyuanEntity>(params).getPage(),
                new EntityWrapper<FuwurenyuanEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<FuwurenyuanEntity> wrapper) {
		  Page<FuwurenyuanView> page =new Query<FuwurenyuanView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
	@Override
	public List<FuwurenyuanView> selectListView(Wrapper<FuwurenyuanEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public FuwurenyuanView selectView(Wrapper<FuwurenyuanEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}
	
	


}
