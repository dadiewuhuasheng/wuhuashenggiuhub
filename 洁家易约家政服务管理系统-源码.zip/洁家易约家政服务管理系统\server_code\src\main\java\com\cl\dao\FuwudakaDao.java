package com.cl.dao;

import com.cl.entity.FuwudakaEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.FuwudakaView;


/**
 * 服务打卡
 * 
 * @author 
 * @email 
 * @date 2026-03-27 11:34:08
 */
public interface FuwudakaDao extends BaseMapper<FuwudakaEntity> {
	
	List<FuwudakaView> selectListView(@Param("ew") Wrapper<FuwudakaEntity> wrapper);

	List<FuwudakaView> selectListView(Pagination page,@Param("ew") Wrapper<FuwudakaEntity> wrapper);
	
	FuwudakaView selectView(@Param("ew") Wrapper<FuwudakaEntity> wrapper);


    List<Map<String, Object>> selectValue(@Param("params") Map<String, Object> params,@Param("ew") Wrapper<FuwudakaEntity> wrapper);

    List<Map<String, Object>> selectTimeStatValue(@Param("params") Map<String, Object> params,@Param("ew") Wrapper<FuwudakaEntity> wrapper);

    List<Map<String, Object>> selectGroup(@Param("params") Map<String, Object> params,@Param("ew") Wrapper<FuwudakaEntity> wrapper);



}
