package com.cl.entity.view;

import com.cl.entity.FuwupingjiaEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.math.BigDecimal;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;

import java.io.Serializable;
import com.cl.utils.EncryptUtil;
 

/**
 * 服务评价
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 * @date 2026-03-27 11:34:08
 */
@TableName("fuwupingjia")
public class FuwupingjiaView  extends FuwupingjiaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public FuwupingjiaView(){
	}
 
 	public FuwupingjiaView(FuwupingjiaEntity fuwupingjiaEntity){
 	try {
			BeanUtils.copyProperties(this, fuwupingjiaEntity);
		} catch (BeansException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}



}
