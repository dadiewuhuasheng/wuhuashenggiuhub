<template>
	<div>
		<div class="center_view edit_form">
			<el-form class="userinfo_form" ref="userinfoFormRef" :model="form">
				<el-row>
					<el-col :span="12">
						<el-form-item label="人员账号" prop="renyuanzhanghao">
							<el-input class="list_inp" v-model="user.renyuanzhanghao" readonly placeholder="人员账号" clearable />
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="人员姓名" prop="renyuanxingming">
							<el-input class="list_inp" v-model="user.renyuanxingming"  placeholder="人员姓名" clearable />
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="年龄" prop="nianling">
							<el-input class="list_inp" v-model="user.nianling"  placeholder="年龄" clearable />
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="性别" prop="xingbie">
							<el-select 
								class="list_sel" 
								v-model="user.xingbie" 
								placeholder="请选择性别"
								>
								<el-option v-for="item in fuwurenyuanxingbieLists" :label="item" :value="item"></el-option>
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="联系电话" prop="lianxidianhua">
							<el-input class="list_inp" v-model="user.lianxidianhua"  placeholder="联系电话" clearable />
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="资质证明" prop="zizhizhengming">
							<uploads
								type="file"
								action="file/upload" 
								tip="请上传资质证明" 
								:limit="3" 
								style="width: 100%;text-align: left;"
								:fileUrls="user.zizhizhengming?user.zizhizhengming:''" 
								@change="fuwurenyuanzizhizhengmingUploadSuccess">
							</uploads>
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="家政服务技能" prop="jiazhengfuwujineng">
							<el-input class="list_inp" v-model="user.jiazhengfuwujineng"  placeholder="家政服务技能" clearable />
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="头像" prop="touxiang">
							<uploads
								action="file/upload" 
								tip="请上传头像"
								style="width: 100%;text-align: left;"
								:fileUrls="user.touxiang?user.touxiang:''" 
								@change="fuwurenyuantouxiangUploadSuccess">
							</uploads>
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="我的排班" prop="wodepaiban">
							<el-input class="list_inp" v-model="user.wodepaiban"  placeholder="我的排班" clearable />
						</el-form-item>
					</el-col>
					<span class="formModel_btn_box">
						<el-button class='confirm_btn' type="primary" @click="onSubmit">保存</el-button>
					</span>
				</el-row>
			</el-form>
		</div>
	</div>
</template>

<script setup>
	import { isNumber,isIntNumer,isEmail,isMobile,isPhone,isURL,checkIdCard } from "@/utils/toolUtil";
	import {
		reactive,
		ref,
		getCurrentInstance,
        computed
	} from 'vue'
	import { useStore } from 'vuex'
	const store = useStore()
	const context = getCurrentInstance()?.appContext.config.globalProperties;
	const tableName = ref('fuwurenyuan')
	const user = ref({})
	const fuwurenyuanxingbieLists = ref([])
	const init = () => {
		fuwurenyuanxingbieLists.value = "男,女".split(',')
	}
	const fuwurenyuanzizhizhengmingUploadSuccess=(fileUrls)=> {
	    user.value.zizhizhengming = fileUrls;
	}
	const fuwurenyuantouxiangUploadSuccess=(fileUrls)=> {
	    user.value.touxiang = fileUrls;
	}
	const onSubmit = () => {
		if((!user.value.renyuanzhanghao)){
			context?.$toolUtil.message(`人员账号不能为空`,'error')
			return false
		}
		if((!user.value.mima)){
			context?.$toolUtil.message(`密码不能为空`,'error')
			return false
		}
		if((!user.value.renyuanxingming)){
			context?.$toolUtil.message(`人员姓名不能为空`,'error')
			return false
		}
		if((user.value.nianling)&&(!context?.$toolUtil.isIntNumer(user.value.nianling))){
			context?.$toolUtil.message(`年龄应输入整数`,'error')
			return false
		}
		if((user.value.lianxidianhua)&&(!context?.$toolUtil.isMobile(user.value.lianxidianhua))){
			context?.$toolUtil.message(`联系电话应输入手机格式`,'error')
			return false
		}
		if(user.value.zizhizhengming!=null){
			user.value.zizhizhengming = user.value.zizhizhengming.replace(new RegExp(context?.$config.url,"g"),"");
		}
		if(user.value.touxiang!=null){
			user.value.touxiang = user.value.touxiang.replace(new RegExp(context?.$config.url,"g"),"");
		}
		if((user.value.maxPasswordWrong)&&(!context?.$toolUtil.isIntNumer(user.value.maxPasswordWrong))){
			context?.$toolUtil.message(`最大密码输错次数应输入整数`,'error')
			return false
		}
		if((user.value.isLocked)&&(!context?.$toolUtil.isIntNumer(user.value.isLocked))){
			context?.$toolUtil.message(`用户锁定状态应输入整数`,'error')
			return false
		}
		store.dispatch('user/update',user.value).then(res=>{
			if(res?.data&&res.data.code==0)context?.$toolUtil.message('修改成功','success')
		})

	}
	const getInfo = () => {
		context?.$http({
			url: `${tableName.value}/session`,
			method: 'get'
		}).then(res => {
			user.value = res.data.data
			init()
		})
	}
	getInfo()
</script>

<style lang="scss" scoped>
	// 表单
	.userinfo_form {
		:deep(.el-form-item) {
			//文件上传样式
			.upload-demo {
				width: 100%;
			}
		}
	}
</style>
