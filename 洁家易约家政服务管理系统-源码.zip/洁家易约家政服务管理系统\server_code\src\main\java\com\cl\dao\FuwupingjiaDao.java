package com.cl.dao;

import com.cl.entity.FuwupingjiaEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.FuwupingjiaView;


/**
 * 服务评价
 * 
 * @author 
 * @email 
 * @date 2026-03-27 11:34:08
 */
public interface FuwupingjiaDao extends BaseMapper<FuwupingjiaEntity> {
	
	List<FuwupingjiaView> selectListView(@Param("ew") Wrapper<FuwupingjiaEntity> wrapper);

	List<FuwupingjiaView> selectListView(Pagination page,@Param("ew") Wrapper<FuwupingjiaEntity> wrapper);
	
	FuwupingjiaView selectView(@Param("ew") Wrapper<FuwupingjiaEntity> wrapper);


}
