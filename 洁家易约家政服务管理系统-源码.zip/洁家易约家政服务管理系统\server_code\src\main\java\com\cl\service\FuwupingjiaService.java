package com.cl.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.cl.utils.PageUtils;
import com.cl.entity.FuwupingjiaEntity;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.FuwupingjiaView;


/**
 * 服务评价
 *
 * @author 
 * @email 
 * @date 2026-03-27 11:34:08
 */
public interface FuwupingjiaService extends IService<FuwupingjiaEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<FuwupingjiaView> selectListView(Wrapper<FuwupingjiaEntity> wrapper);
   	
   	FuwupingjiaView selectView(@Param("ew") Wrapper<FuwupingjiaEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<FuwupingjiaEntity> wrapper);
   	
   
}

