<template>
	<div class="home_view">

		<div class="countList">
			<el-collapse-transition v-if="btnAuth('fuwuyuyue','首页总数')">
				<el-card v-show="countTypeList.closefuwuyuyueCountType" class="count-item">
					<template #header>
						<div class="card_head_title">
							服务预约
						</div>
						<div class="card_head_right">
							<el-icon @click="countTypeClick('hiddenfuwuyuyueCountType')" class="showIcons"
								:class="countTypeList.hiddenfuwuyuyueCountType?'showIcons1':''">
								<ArrowUpBold />
							</el-icon>
							<el-icon @click="countTypeClick('closefuwuyuyueCountType')" class="closeIcons">
								<CloseBold />
							</el-icon>
						</div>
					</template>
					<el-collapse-transition>
						<div class="count_item" v-show="countTypeList.hiddenfuwuyuyueCountType">
							<div class="count_title"><span>服务预约总数</span></div>
							<div class="count_num"><countTo :startVal="0" :endVal="fuwuyuyueCount" :duration="1000"></countTo></div>
						</div>
					</el-collapse-transition>
				</el-card>
			</el-collapse-transition>
			<el-collapse-transition v-if="btnAuth('fuwudaka','首页总数')">
				<el-card v-show="countTypeList.closefuwudakaCountType" class="count-item">
					<template #header>
						<div class="card_head_title">
							服务打卡
						</div>
						<div class="card_head_right">
							<el-icon @click="countTypeClick('hiddenfuwudakaCountType')" class="showIcons"
								:class="countTypeList.hiddenfuwudakaCountType?'showIcons1':''">
								<ArrowUpBold />
							</el-icon>
							<el-icon @click="countTypeClick('closefuwudakaCountType')" class="closeIcons">
								<CloseBold />
							</el-icon>
						</div>
					</template>
					<el-collapse-transition>
						<div class="count_item" v-show="countTypeList.hiddenfuwudakaCountType">
							<div class="count_title"><span>服务打卡总数</span></div>
							<div class="count_num"><countTo :startVal="0" :endVal="fuwudakaCount" :duration="1000"></countTo></div>
						</div>
					</el-collapse-transition>
				</el-card>
			</el-collapse-transition>
			<el-collapse-transition v-if="btnAuth('fuwujilu','首页总数')">
				<el-card v-show="countTypeList.closefuwujiluCountType" class="count-item">
					<template #header>
						<div class="card_head_title">
							服务记录
						</div>
						<div class="card_head_right">
							<el-icon @click="countTypeClick('hiddenfuwujiluCountType')" class="showIcons"
								:class="countTypeList.hiddenfuwujiluCountType?'showIcons1':''">
								<ArrowUpBold />
							</el-icon>
							<el-icon @click="countTypeClick('closefuwujiluCountType')" class="closeIcons">
								<CloseBold />
							</el-icon>
						</div>
					</template>
					<el-collapse-transition>
						<div class="count_item" v-show="countTypeList.hiddenfuwujiluCountType">
							<div class="count_title"><span>服务记录总数</span></div>
							<div class="count_num"><countTo :startVal="0" :endVal="fuwujiluCount" :duration="1000"></countTo></div>
						</div>
					</el-collapse-transition>
				</el-card>
			</el-collapse-transition>
		</div>

		<div class="chartList">
			<el-collapse-transition v-if="btnAuth('fuwuyuyue','首页统计')">
				<el-card v-show="cardTypeList.closefuwuyuyueChartType1" class="chart-item">
					<template #header>
						<div class="card_head_title">
							服务预约
						</div>
						<div class="card_head_right">
							<el-icon @click="cardTypeClick('hiddenfuwuyuyueChartType1')" class="showIcons"
									 :class="cardTypeList.hiddenfuwuyuyueChartType1?'showIcons1':''">
								<ArrowUpBold />
							</el-icon>
							<el-icon @click="cardTypeClick('closefuwuyuyueChartType1')" class="closeIcons">
								<CloseBold />
							</el-icon>
						</div>
					</template>
					<el-collapse-transition>
						<div class="card_item" v-show="cardTypeList.hiddenfuwuyuyueChartType1">
							<div class="chart-title"><span>服务接单</span></div>
							<div id="fuwuyuyuejiedanxiangqingEchart1" class="Echart" style="width: 100%;height: 400px;"></div>
						</div>
					</el-collapse-transition>
				</el-card>
			</el-collapse-transition>
			<el-collapse-transition v-if="btnAuth('fuwudaka','首页统计')">
				<el-card v-show="cardTypeList.closefuwudakaChartType1" class="chart-item">
					<template #header>
						<div class="card_head_title">
							服务打卡
						</div>
						<div class="card_head_right">
							<el-icon @click="cardTypeClick('hiddenfuwudakaChartType1')" class="showIcons"
									 :class="cardTypeList.hiddenfuwudakaChartType1?'showIcons1':''">
								<ArrowUpBold />
							</el-icon>
							<el-icon @click="cardTypeClick('closefuwudakaChartType1')" class="closeIcons">
								<CloseBold />
							</el-icon>
						</div>
					</template>
					<el-collapse-transition>
						<div class="card_item" v-show="cardTypeList.hiddenfuwudakaChartType1">
							<div class="chart-title"><span>服务完成量</span></div>
							<div id="fuwudakafuwuxiangqingEchart1" class="Echart" style="width: 100%;height: 400px;"></div>
						</div>
					</el-collapse-transition>
				</el-card>
			</el-collapse-transition>
			<el-collapse-transition v-if="btnAuth('fuwujilu','首页统计')">
				<el-card v-show="cardTypeList.closefuwujiluChartType1" class="chart-item">
					<template #header>
						<div class="card_head_title">
							服务记录
						</div>
						<div class="card_head_right">
							<el-icon @click="cardTypeClick('hiddenfuwujiluChartType1')" class="showIcons"
									 :class="cardTypeList.hiddenfuwujiluChartType1?'showIcons1':''">
								<ArrowUpBold />
							</el-icon>
							<el-icon @click="cardTypeClick('closefuwujiluChartType1')" class="closeIcons">
								<CloseBold />
							</el-icon>
						</div>
					</template>
					<el-collapse-transition>
						<div class="card_item" v-show="cardTypeList.hiddenfuwujiluChartType1">
							<div class="chart-title"><span>收入金额</span></div>
							<div id="fuwujilufuwujiageEchart1" class="Echart" style="width: 100%;height: 400px;"></div>
						</div>
					</el-collapse-transition>
				</el-card>
			</el-collapse-transition>
		</div>

		<div class="home_news">
			<div class="title">家政资讯</div>
<div class="list">
    <div class="item" v-for="(item,index) in newsList" :key="index"  @click="newsDetailClick(item)">
        <div class="row1">
            <div class="t1">{{item.title}}</div>
            <div class="time">{{moment(item.addtime).format('YYYY-MM-DD')}}</div>
        </div>
        <div class="row2">
            {{item.introduction}}
        </div>
    </div>
</div>
		</div>
		<el-dialog v-model="newsDialog.visible" title="家政资讯" :append-to-body="true" width="60%" class="home_newsDialog">
			<div class="newsTitle" style="text-align: center;font-size: 20px;padding: 0 0 20px;color:#000;font-weight: bold;">{{newsDialog.detail.title}}</div>
			<div class="newImg" v-if="newsDialog.detail.picture">
				<img :src="newsDialog.detail.imgUrl" style="width:100%;height: 100%;object-fit: cover;max-height: 200px;"/>
			</div>
			<div class="newContent">
				<span v-html="newsDialog.detail.content"></span>
			</div>
		</el-dialog>



	</div>
</template>

<script setup>
	import {
		inject,
		nextTick,
		ref,
		getCurrentInstance,
		computed,
		onMounted,
	} from 'vue';
	import {
		useStore
	} from 'vuex';
	const moment = window.moment
	const store = useStore()
	const context = getCurrentInstance()?.appContext.config.globalProperties;
	const projectName = context.$project.projectName
	const user = computed(()=>store.getters['user/session'])
	//权限验证
	const btnAuth = (e,a)=>{
		return context?.$toolUtil.isAuth(e,a)
	}
	const newsList = ref([])
	const newsDialog = ref({
		visible:false,
		detail:{}
	})
	const getNewsList = () => {
		context.$http({
			url: 'news/list',
			method: 'get',
			params: {
				page: 1,
				limit: 6,
				sort: 'id',
				order: 'desc',
			}
		}).then(res => {
			newsList.value = res.data.data.list
			newsList.value.forEach(item => {
				item.imgUrl = context.$config.url + item.picture.split(',')[0]
			})
		})
	}
	const newsDetailClick = (item) => {
		newsDialog.value.detail = item
		newsDialog.value.visible = true
	}
	//获取列表数据
	getNewsList()
	import countTo from '@/components/count-to/vue-countTo.vue';
	const countTypeList = ref({
	})
	const getCountList=()=>{
		countTypeList.value.closefuwuyuyueCountType = true
		countTypeList.value.hiddenfuwuyuyueCountType = true
		if(btnAuth('fuwuyuyue','首页总数')){
			getfuwuyuyueCount()
		}
		countTypeList.value.closefuwudakaCountType = true
		countTypeList.value.hiddenfuwudakaCountType = true
		if(btnAuth('fuwudaka','首页总数')){
			getfuwudakaCount()
		}
		countTypeList.value.closefuwujiluCountType = true
		countTypeList.value.hiddenfuwujiluCountType = true
		if(btnAuth('fuwujilu','首页总数')){
			getfuwujiluCount()
		}
	}
	const fuwuyuyueCount = ref(0)
	const getfuwuyuyueCount = () => {
		context?.$http({
			url:'fuwuyuyue/count',
			method: 'get'
		}).then(res=>{
			fuwuyuyueCount.value = res.data.data
		})
	}
	const fuwudakaCount = ref(0)
	const getfuwudakaCount = () => {
		context?.$http({
			url:'fuwudaka/count',
			method: 'get'
		}).then(res=>{
			fuwudakaCount.value = res.data.data
		})
	}
	const fuwujiluCount = ref(0)
	const getfuwujiluCount = () => {
		context?.$http({
			url:'fuwujilu/count',
			method: 'get'
		}).then(res=>{
			fuwujiluCount.value = res.data.data
		})
	}
	const countTypeClick = (e) => {
		countTypeList.value[e] = !countTypeList.value[e]
	}
	//获取总数
	getCountList()
	const cardTypeClick = (e) =>{
		cardTypeList.value[e] = !cardTypeList.value[e]
		setTimeout(()=>{
			getChartList()
		},1000)
	}
	const cardTypeList = ref({
		closefuwuyuyueChartType1: true,
		hiddenfuwuyuyueChartType1: true,
		closefuwudakaChartType1: true,
		hiddenfuwudakaChartType1: true,
		closefuwujiluChartType1: true,
		hiddenfuwujiluChartType1: true,
	})
	//判断是否有统计图筛选权限
	const changeStatQuery = (arr)=>{
		if(!arr){	//不传限制条件，默认都可见
			return true
		}
		let role = localStorage.getItem('role')
		for(let x in arr){
			if(arr[x] == role) {
				return true
			}
		}
		return false
	}
	import '@/assets/js/echarts-theme'
	const getfuwuyuyueChart1 = () => {
		nextTick(async ()=>{
			var jiedanxiangqingEchart1 = echarts.init(document.getElementById("fuwuyuyuejiedanxiangqingEchart1"),'theme');
			let params = {}
			if(params.conditionColumn) {
				params.conditionColumn += ';' + 'sfsh'
				params.conditionValue += ';' + '是'
			}else {
				params.conditionColumn = 'sfsh'
				params.conditionValue = '是'
			}
			context?.$http({
				url: "fuwuyuyue/group/jiedanxiangqing?order=desc",
				method: "get",
				params
			}).then(obj=>{
				let res = obj.data.data
				let xAxis = [];
				let yAxis = [];
				let dataList = []
				for(let i=0;i<res.length;i++){
				    xAxis.push(res[i].jiedanxiangqing);
				    yAxis.push(parseFloat((res[i].total)));
					dataList.push({
				        value: parseFloat((res[i].total)),
				        name: res[i].jiedanxiangqing				    })
				}
				var option = {};
				option = {
    title:{
        show:false,
        text: '服务接单',
        left: 'center'
    },
    legend: {
        orient: 'horizontal',
        type: 'scroll', // 启用滚动条
        left: 'center',
        padding:[20,0,0,0]
    },
    tooltip: {
        trigger: 'item',
        formatter: '{b} : {c} ({d}%)'
    },
    series: [
        {
            left: '10%',
            type: 'pie',
            radius: '55%',
            center: ['50%', '60%'],
            data: dataList.slice(0,12), 
            emphasis: {
                itemStyle: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }
    ]
}
				jiedanxiangqingEchart1.clear()
				// 使用刚指定的配置项和数据显示图表。
				jiedanxiangqingEchart1.setOption(option);
				//根据窗口的大小变动图表
				jiedanxiangqingEchart1.resize();
			})
		})
	}
	const getfuwudakaChart1 = () => {
		nextTick(async ()=>{
			var fuwuxiangqingEchart1 = echarts.init(document.getElementById("fuwudakafuwuxiangqingEchart1"),'theme');
			let params = {}
			context?.$http({
				url: "fuwudaka/group/fuwuxiangqing?order=desc",
				method: "get",
				params
			}).then(obj=>{
				let res = obj.data.data
				let xAxis = [];
				let yAxis = [];
				let dataList = []
				for(let i=0;i<res.length;i++){
				    xAxis.push(res[i].fuwuxiangqing);
				    yAxis.push(parseFloat((res[i].total)));
					dataList.push({
				        value: parseFloat((res[i].total)),
				        name: res[i].fuwuxiangqing				    })
				}
				var option = {};
				option = {
    title:{
        show:false,
        text: '服务完成量',
        left: 'center'
    },
    legend: {
        orient: 'horizontal',
        type: 'scroll', // 启用滚动条
        left: 'center',
        padding:[20,0,0,0]
    },
    tooltip: {
        trigger: 'item',
        formatter: '{b} : {c} ({d}%)'
    },
    series: [
        {
            left: '10%',
            type: 'pie',
            radius: '55%',
            center: ['50%', '60%'],
            data: dataList.slice(0,12), 
            emphasis: {
                itemStyle: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }
    ]
}
                option.series[0].radius = ['25%', '55%']
				fuwuxiangqingEchart1.clear()
				// 使用刚指定的配置项和数据显示图表。
				fuwuxiangqingEchart1.setOption(option);
				//根据窗口的大小变动图表
				fuwuxiangqingEchart1.resize();
			})
		})
	}
	const getfuwujiluChart1 = () => {
		nextTick(async ()=>{
			var fuwujiageEchart1 = echarts.init(document.getElementById("fuwujilufuwujiageEchart1"),'theme');
			let params = {}
			context?.$http({
				url: `fuwujilu/value/fuwuxiangmu/fuwujiage?order=desc`,
				method: "get",
				params
			}).then(obj=>{
				let res = obj.data.data
				let xAxis = [];
				let yAxis = [];
				let dataList = []
				for(let i=0;i<res.length;i++){
				    xAxis.push(res[i].fuwuxiangmu);
				    yAxis.push(parseFloat((res[i].total)));
					dataList.push({
				        value: parseFloat((res[i].total)),
				        name: res[i].fuwuxiangmu				    })
				}
				var option = {};
				option = {
    title: {
        show:false,
        text: '收入金额',
        left: 'center'
    },
    grid:{
        containLabel:true
    },
    tooltip: {
        trigger: 'item',
        formatter: '{b} : {c}'
    },
    xAxis: {
        data: xAxis.slice(0,12), 
        type: 'category',
        axisLabel: {
        "interval": 0,
        "rotate": 30,
        "width": 120,
        "overflow": "truncate",
        "ellipsis": "..."
        }
    },
    yAxis: {
        type: 'value',
        "minInterval": 1
    },
    series:{
        data: yAxis.slice(0,12), 
        type: 'line'
    }
}
                Object.assign(option.series,{smooth: true})
				fuwujiageEchart1.clear()
				// 使用刚指定的配置项和数据显示图表。
				fuwujiageEchart1.setOption(option);
				//根据窗口的大小变动图表
				fuwujiageEchart1.resize();
			})
		})
	}
	const getChartList = () => {
		if(btnAuth('fuwuyuyue','首页统计')){
			getfuwuyuyueChart1()
		}
		if(btnAuth('fuwudaka','首页统计')){
			getfuwudakaChart1()
		}
		if(btnAuth('fuwujilu','首页统计')){
			getfuwujiluChart1()
		}
	}
	//获取统计图数据
	getChartList()
</script>
<style lang="scss" scoped>
	// 首页盒子
	.home_view {
        background-image: url("http://clfile.zggen.cn/20250728/efa8c4527e0d4b5fa31b9fa123463b16.webp")!important;
	}

	.showIcons {
		transition: transform 0.3s;
		margin-right: 10px;
	}

	.showIcons1 {
		transform: rotate(-180deg);
	}
</style>
<style>
.condition-box {
	display: flex;
	gap: 10px;
	justify-content: center;
}

.condition-box>* {
	max-width: 300px;
}
.home_view .countList {
    display: flex;
    flex-wrap: wrap;
    gap: 30px;
    margin: 30px 0 0;
}

.home_view .count-item {
    min-width: 32%;
    position: relative;
    border-radius: 0;
    background-size: 100% 100%;
    box-shadow: none;
    border: 1px solid #ccc;
    background: linear-gradient(to top, #f2f2f2, #fff);
}

.home_view .el-card__header {
    display: none;
}

.home_view .count_title {
    color: #000;
    order: 1;
}

.home_view .count_num {
    font-size: 30px;
    font-weight: 700;
    line-height: 50px;
    color: var(--theme);
}
.home_view {
    padding: 30px;
}

.home_view .chartList {
    display: flex;
    flex-wrap: wrap;
    gap: 30px;
    margin-top: 60px;
}

.home_view .chart-item {
    flex: 1;
    min-width: 30%;
    border-radius: 0;
    overflow: visible;
    box-shadow: none;
    border: 1px solid #ccc;
}

.home_view .row3 {
    display: flex;
    margin-top: 30px;
    gap: 30px;
}
.home_view .el-carousel img {
    object-fit: cover;
}

.home_view .el-carousel {
    margin-bottom: 20px;
}
.home_view .chart-title {font-size: 22px;font-weight: 700;padding-left: 0px;line-height: 40px;width: 100%;background-size: 100% 100%;height: 44px;margin: 0 auto;text-align: center;position: relative;background: linear-gradient(to top, #f2f2f2, #fff);}

.home_view .count_item {
    display: flex;
    flex-direction: column;
    text-align: left;
}

.home_view .count-item:after {
    background-image: url(http://clfile.zggen.cn/20251108/690261f32b6a455291fb52ad3b5234b5.webp);
    background-size: 100% 100%;
    position: absolute;
    content: '';
    width: 60px;
    height: 100%;
    left: 20px;
    top: 0;
}

.count-item .el-card__body {
    padding-left: 100px;
}

.chart-item .el-card__body {
    padding: 0;
}

/* 后台首页新闻详情图片*/
.home_newsDialog .newImg{
    width: 100%;
    text-align: center;
    margin: 0 0 5px;
}
.home_newsDialog .newImg img{
    width: auto !important;
    height: auto !important;
    object-fit: contain !important;
    max-height: 400px !important;
    max-width: 100%;
}
.home-calendar{
  box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 0px;
  margin: 30px auto 30px;
  color: rgb(102, 102, 102);
  min-width: 480px;
  font-size: inherit;
  background: #fff;
  overflow: hidden;
  height: 600px;
  border: 1px solid #ccc;
  padding: 0;
  border-radius: 0;
  background: #f4f7ed;
}
.home-calendar .header{
  padding: 17px 40px;
  border-color: rgba(126, 96, 16, 0.1);
  flex-wrap: wrap;
  background: var(--theme-light1);
  border-width: 0px 0px 1px;
  display: flex;
  width: 100%;
  border-style: solid;
  justify-content: space-between;
  height: auto;
  background: #fff;
}
.home-calendar .header .btn{
  cursor: pointer;
  border: 0px solid rgb(153, 153, 153);
  padding: 0px 0px 0px 12px;
  align-items: center;
  color: rgb(102, 102, 102);
  border-radius: 4px;
  display: flex;
  width: auto;
  font-size: inherit;
  justify-content: center;
  order: 2;
}
.home-calendar .header .title{
  padding: 0px 10px;
  font-size: 24px;
  align-items: center;
  justify-content: center;
  display: flex;
  color: rgb(51, 51, 51);
}
.home-calendar table{
  width: 100%;
  padding: 0px 0px 20px;
  height: auto;
}
.home-calendar tbody,.home-calendar thead{
  width: 100%;
}
.home-calendar tr{
  width: 100%;
  align-items: center;
  justify-content: center;
  display: flex;
}
.home-calendar th{
  align-items: center;
  flex: 1;
  display: flex;
  line-height: 50px;
  justify-content: center;
}
.home-calendar td{
  cursor: pointer;
  padding: 6px 12px 12px;
  flex: 1;
  display: flex;
  justify-content: center;
  text-align: center;
}

.home-calendar .header .btn.lastYear,.home-calendar .header .btn.nextYear {
    display: none;
}

.home-calendar .btn.lastMonth {
    margin-left: auto;
}

.home-calendar:before {
    content: '日历';
    font-size: 22px;
    color: #555;
    line-height: 44px;
    text-align: center;
    display: block;
    margin: 0 auto;
    background: linear-gradient(to top, #f2f2f2, #fff);
    width: 100%;
}

.home-calendar table {
    background: #f4f7ed;
}

.home-calendar .header .btn .text {
    display: none;
}

.home-calendar .lastMonth .iconfont {
    transform: rotate(180deg);
}

.home-calendar .iconfont {
    font-size: 28px;
    background: #fff;
    border-radius: 50%;
}

.home-calendar td.today {
    background: var(--theme);
    border-radius: 6px;
    color: #fff;
}
.home_news {
    padding: 0 30px 30px;
    background: #fff;
    border-radius: 16px;
    margin-top: 60px;
    padding: 0;
    border: 1px solid #ccc;
    border-radius: 0;
}

.home_news .title {
    font-size: 22px;
    line-height: 60px;
    width: 500px;
    background-size: 100% 100%;
    text-align: center;
    position: relative;
    margin: 0 auto;
    background: linear-gradient(to top, #f2f2f2, #fff);
    width: 100%;
}

.home_news .list {
    overflow: auto;
    /* height: 500px; */
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    flex-wrap: wrap;
    gap: 30px;
    padding: 20px;
}

.home_news .item {
    background: var(--theme-light1);
    /* margin-bottom: 20px; */
    padding: 20px;
    border-radius: 10px;
    flex: 1;
    min-width: 30%;
    cursor: pointer;
}

.home_news .row1 {
    display: flex;
    justify-content: space-between;
}

.home_news .t1 {
    font-size: 18px;
}

.home_news .time {
    font-size: 14px;
    color: #999;
}

.home_news .row2 {
    margin-top: 10px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
}

.home_news .item:hover {
    background: var(--theme);
    color: #fff;
}
</style>