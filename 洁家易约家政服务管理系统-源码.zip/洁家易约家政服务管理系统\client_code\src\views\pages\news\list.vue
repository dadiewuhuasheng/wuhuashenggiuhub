<template>
    <div class="news-page">
        <div class="breadcrumb-wrapper" style="width: 100%;">
            <div class="bread_view">
                <el-breadcrumb separator="Ξ" class="breadcrumb">
                    <el-breadcrumb-item class="first_breadcrumb" :to="{ path: '/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item class="second_breadcrumb" v-for="(item,index) in breadList" :key="index">{{item.name}}</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </div>

        <div class="list_search">
			<div class="search_view">
				<div class="search_label">
					标题：
				</div>
				<div class="search_box">
					<el-input class="search_inp" v-model="searchQuery.title" placeholder="标题" clearable></el-input>
				</div>
			</div>
			<div class="search_btn_view">
				<el-button class="search_btn" type="primary" @click="searchClick">搜索</el-button>
			</div>
		</div>


<div class="list">

	<template v-for="(item,index) in list">
		<div class="item" @click="newsDetail(item.id)">
			<div class="imgbox" v-if="item.imgUrls"><img :src="item.imgUrls[0]" alt=""></div>
			<div class="content">
				<div class="title text-one-row">{{item.title}}</div>
				<div class="intro text-two-row">{{item.introduction}}</div>
				<div class="time">{{moment(item.addtime).format('YYYY-MM-DD')}}</div>
			</div>
		</div>
	</template>

</div>
		<el-pagination
			background
			:layout="layouts.join(',')"
			:total="total"
			:page-size="listQuery.limit"
            v-model:current-page="listQuery.page"
			prev-text="<"
			next-text=">"
			:hide-on-single-page="false"
			@size-change="sizeChange"
			@current-change="currentChange"/>


    </div>
    <formModel ref="formModelRef"></formModel>
</template>

<script setup>
    const moment = window.moment
	import formModel from './formModel'
	import {
		ref,
		nextTick,
        computed,
		getCurrentInstance
	} from 'vue';
	import {
		useRoute,
		useRouter
	} from 'vue-router'
    import {
        useStore
    } from 'vuex';
    const store = useStore()
    const user = computed(()=>store.getters['user/session'])
	const context = getCurrentInstance()?.appContext.config.globalProperties;
    const baseUrl = ref(context.$config.url)
	//基础信息
	const tableName = 'news'
	const formName = '家政资讯'
	const router = useRouter()
	const route = useRoute()
	//基础信息
    const breadList = ref([{
        name: formName
    }])
	//权限验证
	const btnAuth = (e, a) => {
		return context?.$toolUtil.isAuth(e, a)
	}
	const list = ref([])
	const listLoading = ref(false)
	const listQuery = ref({
		page: 1,
		limit: 10,
		sort: 'addtime',
		order: 'desc'
	})
	const searchQuery = ref({})
	//分页
	const layouts = ref(["total","prev","pager","next","sizes"])
	const total = ref(0)
	const sizeChange = (size) => {
		listQuery.value.limit = size
		getList()
	}
	const currentChange = (page) => {
		listQuery.value.page = page
		getList()
	}
	//分页
	const searchClick = () => {
		listQuery.value.page = 1
		getList()
	}
	const getList = () => {
		listLoading.value = true
		let params = JSON.parse(JSON.stringify(listQuery.value))
		if (searchQuery.value.title && searchQuery.value.title != '') {
			params['title'] = `%${searchQuery.value.title}%`
		}
		context?.$http({
			url: `news/list`,
			method: 'get',
			params: params
		}).then(res => {
			listLoading.value = false
			list.value = res.data.data.list
			total.value = res.data.data.total
            list.value.forEach(item=>{
                let urls = item.picture.split(',')
                item.imgUrls = urls.map(url=>{
                    if(url && url.substr(0,4)=='http'){
                        return url
                    }else{
                        return baseUrl.value+url
                    }
                })
            })
		})
	}
	//判断是否从个人中心跳转
	const centerType = ref(false)
	//返回
	const backClick = () => {
		router.push(`/index/${context?.$toolUtil.storageGet('frontSessionTable')}Center`)
	}
	const init = () => {
		if (route.query.centerType) {
			centerType.value = true
		}
		getList()
        nextTick(()=>{
            if(route.query.id){
                newsDetail(route.query.id)
            }
        })
	}
	//定义弹窗
	const formModelRef = ref(null)
	const newsDetail = (id = null) => {
		if (id) {
			formModelRef.value.init(id)
		}
	}
	init()
</script>
<style lang="scss">
.news-page {
    width: 100%;
    padding: 0 7%;
    margin: 20px auto;
    display: flex;
    flex-wrap: wrap;
    align-items: flex-start;
    align-content: flex-start;
}


.news-page .list_search {
    width: 100%;
    display: flex;
    align-items: center;
    padding: 20px 10px 10px;
    justify-content: center;
    background: #fff;
    border-radius: 8px 8px 0 0;
}
.news-page .list_search .search_view {
    display: flex;
    align-items: center;
}
.news-page .search_view .search_label{
    
}
.news-page .search_view .search_box{
    
}
.news-page .search_view .search_box .search_inp{
    
}
.news-page .search_view .search_box .search_inp .el-input__wrapper{
    min-width: 450px;
}
.news-page .search_view .search_box .search_inp .el-input__wrapper .el-input__inner{
    
}
.news-page .list_search .search_btn_view{
    margin: 0 0 0 10px;
}
.news-page .list_search .search_btn_view .search_btn{
    width: auto;
    height: 44px;
    line-height: 44px;
    background:var(--theme);
    padding: 0 20px;
    border: 0;
    color: #fff;
}
.news-page .list_search .search_btn_view .search_btn:hover{
    background: #00B0BE;
}


.news-page .categorys{
    width: 280px;
    height: auto;
    background: #69b839;
    margin: 20px 30px 0px 0;
    padding: 20px; 
    gap:0;
}
.news-page .categorys::before{
    content: "信息分类";
    display: block;
    width: 100%;
    height: 50px;
    line-height: 50px;
    color: #fff;
    text-align: center;
    font-size: 20px;
    border-bottom: 1px solid #b4dc9c;
    margin-bottom: 10px;  
}
.news-page .categorys .category{
    width: 100%;
    color: #fff;
    line-height: 40px;
    border-bottom: 1px dotted #ffffff50;
    border-radius: 0;
}
.news-page .category.categoryActive,.list-page .category:hover {
    color: #ff0;
    cursor: pointer;
}


.news-page .list {
    width: calc(100% + 20px);   
    display: flex;
    flex-wrap: wrap;
    margin: 20px auto 0 -10px;
    flex:1;
}
.news-page .list .item {
    width: calc(100% - 0px);
    background: #fff;
    display: flex;
    flex-wrap: wrap;
    margin: 0 0px 20px;
    padding: 10px;
    border-radius: 4px;
    cursor: pointer;
}
.news-page .list .item .imgbox {
    margin-right: 20px;
}
.news-page .list .item:nth-child(2n) .imgbox {
}

.news-page .list .item .imgbox img {
    width: 110px;
    height: 110px;
    object-fit: cover;
}
.news-page .list .item .content {
    width: 100%;
    padding: 10px;
    flex:1;
}
.news-page .list .item .content .title {
    font-size: 16px;
    line-height: 40px;
    font-weight: 600;
    background: var(--theme30);
    border-left: 8px solid var(--theme);
    padding: 0 12px;
}

.news-page .list .item:hover .content .title {
    color: var(--theme);
    font-weight: 600;
}
.news-page .list .item .content .intro {
    font-size: 14px;
    color: #666;
    margin: 5px 0 0 0;
}
.news-page .list .item:hover .content .intro {
    color: var(--theme);
}
.news-page .list .item .content .time {
    text-align: right;
    font-size: 14px;
    color: #999;
    line-height: 24px;
    margin: 5px 0 0 0;
}
.news-page .list .item:hover .content .time {
    color: var(--theme);
}
.news-page .list .item:nth-child(2n) .content .time{
    text-align: right;
}


.news_hot_view {
    width: 100%;
    margin: 20px 0;
    padding: 0px 0 20px;    
}
.news_hot_view .hot_title {
    width: 100%;
    height: 60px;
    line-height: 60px;
    text-align: center;
}
.news_hot_view .hot_title span{
    font-size: 32px;
    color: #666;
    padding:0px;
    border-bottom: 0px solid #b6010c;
}
.news_hot_view .hot_list {
    width: 100%;
    display: flex;
    margin: 20px 0 0 0;
    gap: 20px;
}
.news_hot_view .hot_list .hot {
    width: 25%;
    padding: 10px;
    background: #fff;
    border-radius: 4px;
}
.news_hot_view .hot_list .hot img {
    width: 100%;
    height: 200px;
    object-fit: cover;
}
.news_hot_view .hot_list .hot .content {
    text-align: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.news_hot_view .hot_list .hot .content .title {
    font-size: 16px;
    color: #000;
    font-weight: 600;
    line-height: 24px;
    text-align: center;
}
.news_hot_view .hot_list .hot .content .intro {
    font-size: 14px;
    color: #666;   
}


.el-pagination {
    width: 100%;
    display: flex;
    justify-content: center;
    padding: 10px;
}
.el-pagination button.is-active,.el-pagination button:hover {
    color: var(--theme);
}
.el-pager li.is-active,.el-pager li:hover {
    color: var(--theme);
}
.el-pagination.is-background .btn-next.is-active, .el-pagination.is-background .btn-prev.is-active, .el-pagination.is-background .el-pager li.is-active {
    background-color: var(--theme);
    color: var(--el-color-white);
}
.el-select__popper.el-popper,.el-select__popper.el-popper .el-popper__arrow:before {
    border: 1px solid var(--theme);
}
.el-select__wrapper.is-focused {
    box-shadow: 0 0 0 1px var(--theme) inset
}
.el-select__wrapper.is-hovering:not(.is-focused) {
    box-shadow: 0 0 0 1px var(--theme) inset
}
.el-select-dropdown__item.is-selected {
    color: var(--theme);
    font-weight: 600;
}


.news_detail .news_detail_title{
    width: 100%;
    text-align: center;
    font-size: 18px;
    font-weight: 600;
}
.news_detail .news_detail_time{
    width: 100%;
    text-align: right;
    margin-bottom: 10px;
}
</style>