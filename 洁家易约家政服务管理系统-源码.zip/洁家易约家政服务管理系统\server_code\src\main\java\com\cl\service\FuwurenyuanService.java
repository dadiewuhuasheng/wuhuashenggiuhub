package com.cl.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.cl.utils.PageUtils;
import com.cl.entity.FuwurenyuanEntity;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.FuwurenyuanView;


/**
 * 家政人员
 *
 * @author 
 * @email 
 * @date 2026-03-27 11:34:08
 */
public interface FuwurenyuanService extends IService<FuwurenyuanEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<FuwurenyuanView> selectListView(Wrapper<FuwurenyuanEntity> wrapper);
   	
   	FuwurenyuanView selectView(@Param("ew") Wrapper<FuwurenyuanEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<FuwurenyuanEntity> wrapper);
   	
   
}

