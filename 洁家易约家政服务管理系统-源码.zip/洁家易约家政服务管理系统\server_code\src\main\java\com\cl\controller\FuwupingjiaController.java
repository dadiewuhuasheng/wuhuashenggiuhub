package com.cl.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.*;
import java.lang.*;
import java.math.*;
import java.util.stream.Collectors;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

import com.cl.utils.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.cl.annotation.IgnoreAuth;
import com.cl.annotation.SysLog;

import com.cl.entity.FuwupingjiaEntity;
import com.cl.entity.view.FuwupingjiaView;

import com.cl.service.FuwupingjiaService;
import com.cl.service.TokenService;

/**
 * 服务评价
 * 后端接口
 * @author 
 * @email 
 * @date 2026-03-27 11:34:08
 */
@RestController
@RequestMapping("/fuwupingjia")
public class FuwupingjiaController {
    @Autowired
    private FuwupingjiaService fuwupingjiaService;









    /**
     * 后台列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params,FuwupingjiaEntity fuwupingjia,
                                                                                                                                                                                                                                                                    HttpServletRequest request){
                    String tableName = request.getSession().getAttribute("tableName").toString();
                                                                                                                                if(tableName.equals("fuwurenyuan")) {
                    fuwupingjia.setRenyuanzhanghao((String)request.getSession().getAttribute("username"));
                                    }
                                                                                                                                                                                                if(tableName.equals("yonghu")) {
                    fuwupingjia.setZhanghao((String)request.getSession().getAttribute("username"));
                                    }
                                                                                                                                                                                                                                                                                                                                                        EntityWrapper<FuwupingjiaEntity> ew = new EntityWrapper<FuwupingjiaEntity>();
                                                                                                                                                                                                                                                                                                                                                                                                                                
        
        
        PageUtils page = fuwupingjiaService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, fuwupingjia), params), params));
        Map<String, String> deSens = new HashMap<>();
                                                                                                                                                                                                                                                                                                                                                                                                            //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(page,deSens);
        return R.ok().put("data", page);
    }







    /**
     * 前端列表
     */
	@IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params,FuwupingjiaEntity fuwupingjia,
		HttpServletRequest request){
        EntityWrapper<FuwupingjiaEntity> ew = new EntityWrapper<FuwupingjiaEntity>();

		PageUtils page = fuwupingjiaService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, fuwupingjia), params), params));
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(page,deSens);
        return R.ok().put("data", page);
    }

	/**
     * 列表
     */
    @RequestMapping("/lists")
    public R list( FuwupingjiaEntity fuwupingjia){
       	EntityWrapper<FuwupingjiaEntity> ew = new EntityWrapper<FuwupingjiaEntity>();
      	ew.allEq(MPUtil.allEQMapPre( fuwupingjia, MPUtil.camelToSnake("fuwupingjia")));
        return R.ok().put("data", fuwupingjiaService.selectListView(ew));
    }

	 /**
     * 查询
     */
    @RequestMapping("/query")
    public R query(FuwupingjiaEntity fuwupingjia){
        EntityWrapper< FuwupingjiaEntity> ew = new EntityWrapper< FuwupingjiaEntity>();
 		ew.allEq(MPUtil.allEQMapPre( fuwupingjia, MPUtil.camelToSnake("fuwupingjia")));
		FuwupingjiaView fuwupingjiaView =  fuwupingjiaService.selectView(ew);
		return R.ok("查询服务评价成功").put("data", fuwupingjiaView);
    }
	
    /**
     * 后端详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id){
        FuwupingjiaEntity fuwupingjia = fuwupingjiaService.selectById(id);
		fuwupingjia = fuwupingjiaService.selectView(new EntityWrapper<FuwupingjiaEntity>().eq("id", id));
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(fuwupingjia,deSens);
        return R.ok().put("data", fuwupingjia);
    }

    /**
     * 前端详情
     */
	@IgnoreAuth
    @RequestMapping("/detail/{id}")
    public R detail(@PathVariable("id") Long id){
        FuwupingjiaEntity fuwupingjia = fuwupingjiaService.selectById(id);
		fuwupingjia = fuwupingjiaService.selectView(new EntityWrapper<FuwupingjiaEntity>().eq("id", id));
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(fuwupingjia,deSens);
        return R.ok().put("data", fuwupingjia);
    }
    



    /**
     * 后端保存
     */
    @RequestMapping("/save")
    @SysLog("新增服务评价")
    public R save(@RequestBody FuwupingjiaEntity fuwupingjia, HttpServletRequest request){
    	//ValidatorUtils.validateEntity(fuwupingjia);
        fuwupingjiaService.insert(fuwupingjia);
        return R.ok().put("data",fuwupingjia.getId());
    }
    
    /**
     * 前端保存
     */
    @SysLog("新增服务评价")
    @RequestMapping("/add")
    public R add(@RequestBody FuwupingjiaEntity fuwupingjia, HttpServletRequest request){
    	//ValidatorUtils.validateEntity(fuwupingjia);
        fuwupingjiaService.insert(fuwupingjia);
        return R.ok();
    }


    /**
     * 修改
     */
    @RequestMapping("/update")
    @Transactional
    @SysLog("修改服务评价")
    public R update(@RequestBody FuwupingjiaEntity fuwupingjia, HttpServletRequest request){
        //ValidatorUtils.validateEntity(fuwupingjia);
        fuwupingjiaService.updateById(fuwupingjia);//全部更新
        return R.ok();
    }

    /**
     * 审核
     */
    @RequestMapping("/shBatch")
    @Transactional
    @SysLog("审核服务评价")
    public R update(@RequestBody Long[] ids, @RequestParam String sfsh, @RequestParam String shhf){
        List<FuwupingjiaEntity> list = new ArrayList<FuwupingjiaEntity>();
        for(Long id : ids) {
            FuwupingjiaEntity fuwupingjia = fuwupingjiaService.selectById(id);
            fuwupingjia.setSfsh(sfsh);
            fuwupingjia.setShhf(shhf);
            list.add(fuwupingjia);
        }
        fuwupingjiaService.updateBatchById(list);
        return R.ok();
    }


    

    /**
     * 删除
     */
    @RequestMapping("/delete")
    @SysLog("删除服务评价")
    public R delete(@RequestBody Long[] ids){
        fuwupingjiaService.deleteBatchIds(Arrays.asList(ids));
        return R.ok();
    }

    	








}
