package com.cl.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.cl.utils.PageUtils;
import com.cl.utils.Query;


import com.cl.dao.FuwudakaDao;
import com.cl.entity.FuwudakaEntity;
import com.cl.service.FuwudakaService;
import com.cl.entity.view.FuwudakaView;

@Service("fuwudakaService")
public class FuwudakaServiceImpl extends ServiceImpl<FuwudakaDao, FuwudakaEntity> implements FuwudakaService {

    	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<FuwudakaEntity> page = this.selectPage(
                new Query<FuwudakaEntity>(params).getPage(),
                new EntityWrapper<FuwudakaEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<FuwudakaEntity> wrapper) {
		  Page<FuwudakaView> page =new Query<FuwudakaView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
	@Override
	public List<FuwudakaView> selectListView(Wrapper<FuwudakaEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public FuwudakaView selectView(Wrapper<FuwudakaEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}
	
	

    @Override
    public List<Map<String, Object>> selectValue(Map<String, Object> params, Wrapper<FuwudakaEntity> wrapper) {
        return baseMapper.selectValue(params, wrapper);
    }

    @Override
    public List<Map<String, Object>> selectTimeStatValue(Map<String, Object> params, Wrapper<FuwudakaEntity> wrapper) {
        return baseMapper.selectTimeStatValue(params, wrapper);
    }

    @Override
    public List<Map<String, Object>> selectGroup(Map<String, Object> params, Wrapper<FuwudakaEntity> wrapper) {
        return baseMapper.selectGroup(params, wrapper);
    }




}
