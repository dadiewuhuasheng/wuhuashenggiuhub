package com.cl.dao;

import com.cl.entity.FuwurenyuanEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.cl.entity.view.FuwurenyuanView;


/**
 * 家政人员
 * 
 * @author 
 * @email 
 * @date 2026-03-27 11:34:08
 */
public interface FuwurenyuanDao extends BaseMapper<FuwurenyuanEntity> {
	
	List<FuwurenyuanView> selectListView(@Param("ew") Wrapper<FuwurenyuanEntity> wrapper);

	List<FuwurenyuanView> selectListView(Pagination page,@Param("ew") Wrapper<FuwurenyuanEntity> wrapper);
	
	FuwurenyuanView selectView(@Param("ew") Wrapper<FuwurenyuanEntity> wrapper);


}
