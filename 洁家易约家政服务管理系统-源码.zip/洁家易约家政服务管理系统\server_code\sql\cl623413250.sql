-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: cl623413250
-- ------------------------------------------------------
-- Server version	5.7.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `cl623413250`
--

/*!40000 DROP DATABASE IF EXISTS `cl623413250`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `cl623413250` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `cl623413250`;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '名称',
  `value` longtext COLLATE utf8mb4_unicode_ci COMMENT '值',
  `url` longtext COLLATE utf8mb4_unicode_ci COMMENT '链接',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='轮播图';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'2026-03-27 03:34:18','swiper1','file/swiperPicture1.jpg',NULL),(2,'2026-03-27 03:34:18','swiper2','file/swiperPicture2.jpg',NULL),(3,'2026-03-27 03:34:18','swiper3','file/swiperPicture3.jpg',NULL);
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fuwudaka`
--

DROP TABLE IF EXISTS `fuwudaka`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuwudaka` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `fuwuxiangmu` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务项目',
  `fuwujiage` double DEFAULT NULL COMMENT '服务价格',
  `fuwumiaoshu` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务描述',
  `renyuanzhanghao` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '人员账号',
  `renyuanxingming` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '人员姓名',
  `yuyueriqi` date DEFAULT NULL COMMENT '预约日期',
  `yuyueshijianduan` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '预约时间段',
  `yuyueshijian` datetime DEFAULT NULL COMMENT '预约时间',
  `zhanghao` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '账号',
  `yonghuxingming` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户姓名',
  `fuwudidian` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务地点',
  `dakashijian` datetime DEFAULT NULL COMMENT '打卡时间',
  `dingdanbianhao` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单编号',
  `fuwuxiangqing` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务详情',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dingdanbianhao` (`dingdanbianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='服务打卡';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fuwudaka`
--

LOCK TABLES `fuwudaka` WRITE;
/*!40000 ALTER TABLE `fuwudaka` DISABLE KEYS */;
INSERT INTO `fuwudaka` VALUES (1,'2026-03-27 03:34:17','老人陪护医疗',400,'术后老人照料用药提醒康复辅助血压监测','119','何雨欣','2026-03-27','8:00-9:00','2026-03-27 11:34:17','119','赵嘉轩','合肥市庐阳区淮河路','2026-03-27 11:34:17','1111111111','已完成'),(2,'2026-03-27 03:34:17','深度保洁',350,'全屋精细擦拭厨卫深度清洁玻璃清洁死角清理','116','蒋欣怡','2026-03-27','15:00-16:00','2026-03-27 11:34:17','116','陈宇泽','长沙市岳麓区岳麓山','2026-03-27 11:34:17','2222222222','已完成'),(3,'2026-03-27 03:34:17','家电清洗油烟机',200,'油烟机拆机清洗滤网风轮清洁机身擦拭','117','林泽阳','2026-03-27','10:00-11:00','2026-03-27 11:34:17','117','胡梓妍','济南市历下区泉城广场','2026-03-27 11:34:17','3333333333','已完成'),(4,'2026-03-27 03:34:17','布艺清洗窗帘',300,'窗帘拆卸清洗烘干安装除螨除尘','123','杨若菲','2026-03-27','17:00-18:00','2026-03-27 11:34:17','123','罗欣怡','福州市鼓楼区东街口','2026-03-27 11:34:17','4444444444','已完成'),(5,'2026-03-27 03:34:17','家庭烹饪宴席',400,'家庭宴席制作特色菜烹饪食材采购摆盘装饰','121','卫泽楷','2026-03-27','13:00-14:00','2026-03-27 11:34:17','121','朱泽宇','郑州市金水区花园路','2026-03-27 11:34:17','5555555555','已完成'),(6,'2026-03-27 03:34:17','布艺清洗地毯',260,'地毯吸尘除螨局部去污整体清洁','114','韩雨桐','2026-03-27','11:00-12:00','2026-03-27 11:34:17','114','刘思怡','长春市朝阳区重庆路','2026-03-27 11:34:17','6666666666','已完成'),(7,'2026-03-27 03:34:17','家电清洗冰箱',150,'冰箱全腔清洁除霜除味密封条清洁','112','冯语涵','2026-03-27','9:00-10:00','2026-03-27 11:34:17','112','吴梦琪','天津市和平区和平路','2026-03-27 11:34:17','7777777777','已完成'),(8,'2026-03-27 03:34:17','满月汗蒸',180,'产后满月发汗祛湿驱寒经络疏通体质调理','115','吴彦辰','2026-03-27','12:00-13:00','2026-03-27 11:34:17','115','徐浩然','成都市锦江区春熙路','2026-03-27 11:34:17','8888888888','已完成'),(9,'2026-03-27 03:34:17','开荒保洁新房',600,'新房全屋清洁建筑垃圾清理玻璃清洁地面擦拭','113','李若曦','2026-03-27','14:00-15:00','2026-03-27 11:34:17','113','黄欣冉','上海市浦东新区张江高科技园区','2026-03-27 11:34:17','9999999999','已完成'),(10,'2026-03-27 03:34:17','家庭烹饪月子餐',180,'产妇月子餐定制营养搭配食材处理餐食制作','118','夏浩然','2026-03-27','16:00-17:00','2026-03-27 11:34:17','118','何一诺','南宁市青秀区民族大道','2026-03-27 11:34:17','11111111110','已完成');
/*!40000 ALTER TABLE `fuwudaka` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fuwujiedan`
--

DROP TABLE IF EXISTS `fuwujiedan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuwujiedan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `yuyueriqi` date DEFAULT NULL COMMENT '预约日期',
  `yuyueshijianduan` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '预约时间段',
  `yuyueshijian` datetime DEFAULT NULL COMMENT '预约时间',
  `zhanghao` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '账号',
  `yonghuxingming` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户姓名',
  `fuwudidian` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '服务地点',
  `fuwuxiangmu` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务项目',
  `fuwujiage` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务价格',
  `fuwumiaoshu` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务描述',
  `renyuanzhanghao` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '人员账号',
  `renyuanxingming` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '人员姓名',
  `jiedanshijian` datetime DEFAULT NULL COMMENT '接单时间',
  `fuwuzhuangtai` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='服务接单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fuwujiedan`
--

LOCK TABLES `fuwujiedan` WRITE;
/*!40000 ALTER TABLE `fuwujiedan` DISABLE KEYS */;
INSERT INTO `fuwujiedan` VALUES (1,'2026-03-27 03:34:17','2026-03-27','8:00-9:00','2026-03-27 11:34:17','119','赵嘉轩','合肥市庐阳区淮河路','老人陪护医疗','400','术后老人照料用药提醒康复辅助血压监测','119','何雨欣','2026-03-27 11:34:17','进行中'),(2,'2026-03-27 03:34:17','2026-03-27','15:00-16:00','2026-03-27 11:34:17','116','陈宇泽','长沙市岳麓区岳麓山','深度保洁','350','全屋精细擦拭厨卫深度清洁玻璃清洁死角清理','116','蒋欣怡','2026-03-27 11:34:17','进行中'),(3,'2026-03-27 03:34:17','2026-03-27','10:00-11:00','2026-03-27 11:34:17','117','胡梓妍','济南市历下区泉城广场','家电清洗油烟机','200','油烟机拆机清洗滤网风轮清洁机身擦拭','117','林泽阳','2026-03-27 11:34:17','进行中'),(4,'2026-03-27 03:34:17','2026-03-27','17:00-18:00','2026-03-27 11:34:17','123','罗欣怡','福州市鼓楼区东街口','布艺清洗窗帘','300','窗帘拆卸清洗烘干安装除螨除尘','123','杨若菲','2026-03-27 11:34:17','进行中'),(5,'2026-03-27 03:34:17','2026-03-27','13:00-14:00','2026-03-27 11:34:17','121','朱泽宇','郑州市金水区花园路','家庭烹饪宴席','400','家庭宴席制作特色菜烹饪食材采购摆盘装饰','121','卫泽楷','2026-03-27 11:34:17','进行中'),(6,'2026-03-27 03:34:17','2026-03-27','11:00-12:00','2026-03-27 11:34:17','114','刘思怡','长春市朝阳区重庆路','布艺清洗地毯','260','地毯吸尘除螨局部去污整体清洁','114','韩雨桐','2026-03-27 11:34:17','进行中'),(7,'2026-03-27 03:34:17','2026-03-27','9:00-10:00','2026-03-27 11:34:17','112','吴梦琪','天津市和平区和平路','家电清洗冰箱','150','冰箱全腔清洁除霜除味密封条清洁','112','冯语涵','2026-03-27 11:34:17','进行中'),(8,'2026-03-27 03:34:17','2026-03-27','12:00-13:00','2026-03-27 11:34:17','115','徐浩然','成都市锦江区春熙路','满月汗蒸','180','产后满月发汗祛湿驱寒经络疏通体质调理','115','吴彦辰','2026-03-27 11:34:17','进行中'),(9,'2026-03-27 03:34:17','2026-03-27','14:00-15:00','2026-03-27 11:34:17','113','黄欣冉','上海市浦东新区张江高科技园区','开荒保洁新房','600','新房全屋清洁建筑垃圾清理玻璃清洁地面擦拭','113','李若曦','2026-03-27 11:34:17','进行中'),(10,'2026-03-27 03:34:17','2026-03-27','16:00-17:00','2026-03-27 11:34:17','118','何一诺','南宁市青秀区民族大道','家庭烹饪月子餐','180','产妇月子餐定制营养搭配食材处理餐食制作','118','夏浩然','2026-03-27 11:34:17','进行中');
/*!40000 ALTER TABLE `fuwujiedan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fuwujilu`
--

DROP TABLE IF EXISTS `fuwujilu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuwujilu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `fuwuxiangmu` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务项目',
  `fuwujiage` double DEFAULT NULL COMMENT '服务价格',
  `fuwumiaoshu` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务描述',
  `renyuanzhanghao` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '人员账号',
  `renyuanxingming` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '人员姓名',
  `yuyueriqi` date DEFAULT NULL COMMENT '预约日期',
  `yuyueshijianduan` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '预约时间段',
  `yuyueshijian` datetime DEFAULT NULL COMMENT '预约时间',
  `zhanghao` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '账号',
  `yonghuxingming` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户姓名',
  `fuwudidian` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务地点',
  `wanchengshijian` datetime DEFAULT NULL COMMENT '完成时间',
  `dingdanbianhao` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单编号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='服务记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fuwujilu`
--

LOCK TABLES `fuwujilu` WRITE;
/*!40000 ALTER TABLE `fuwujilu` DISABLE KEYS */;
INSERT INTO `fuwujilu` VALUES (1,'2026-03-27 03:34:18','老人陪护医疗',400,'术后老人照料用药提醒康复辅助血压监测','119','何雨欣','2026-03-27','8:00-9:00','2026-03-27 11:34:18','119','赵嘉轩','合肥市庐阳区淮河路','2026-03-27 11:34:18','订单编号1'),(2,'2026-03-27 03:34:18','深度保洁',350,'全屋精细擦拭厨卫深度清洁玻璃清洁死角清理','116','蒋欣怡','2026-03-27','15:00-16:00','2026-03-27 11:34:18','116','陈宇泽','长沙市岳麓区岳麓山','2026-03-27 11:34:18','订单编号2'),(3,'2026-03-27 03:34:18','家电清洗油烟机',200,'油烟机拆机清洗滤网风轮清洁机身擦拭','117','林泽阳','2026-03-27','10:00-11:00','2026-03-27 11:34:18','117','胡梓妍','济南市历下区泉城广场','2026-03-27 11:34:18','订单编号3'),(4,'2026-03-27 03:34:18','布艺清洗窗帘',300,'窗帘拆卸清洗烘干安装除螨除尘','123','杨若菲','2026-03-27','17:00-18:00','2026-03-27 11:34:18','123','罗欣怡','福州市鼓楼区东街口','2026-03-27 11:34:18','订单编号4'),(5,'2026-03-27 03:34:18','家庭烹饪宴席',400,'家庭宴席制作特色菜烹饪食材采购摆盘装饰','121','卫泽楷','2026-03-27','13:00-14:00','2026-03-27 11:34:18','121','朱泽宇','郑州市金水区花园路','2026-03-27 11:34:18','订单编号5'),(6,'2026-03-27 03:34:18','布艺清洗地毯',260,'地毯吸尘除螨局部去污整体清洁','114','韩雨桐','2026-03-27','11:00-12:00','2026-03-27 11:34:18','114','刘思怡','长春市朝阳区重庆路','2026-03-27 11:34:18','订单编号6'),(7,'2026-03-27 03:34:18','家电清洗冰箱',150,'冰箱全腔清洁除霜除味密封条清洁','112','冯语涵','2026-03-27','9:00-10:00','2026-03-27 11:34:18','112','吴梦琪','天津市和平区和平路','2026-03-27 11:34:18','订单编号7'),(8,'2026-03-27 03:34:18','满月汗蒸',180,'产后满月发汗祛湿驱寒经络疏通体质调理','115','吴彦辰','2026-03-27','12:00-13:00','2026-03-27 11:34:18','115','徐浩然','成都市锦江区春熙路','2026-03-27 11:34:18','订单编号8'),(9,'2026-03-27 03:34:18','开荒保洁新房',600,'新房全屋清洁建筑垃圾清理玻璃清洁地面擦拭','113','李若曦','2026-03-27','14:00-15:00','2026-03-27 11:34:18','113','黄欣冉','上海市浦东新区张江高科技园区','2026-03-27 11:34:18','订单编号9'),(10,'2026-03-27 03:34:18','家庭烹饪月子餐',180,'产妇月子餐定制营养搭配食材处理餐食制作','118','夏浩然','2026-03-27','16:00-17:00','2026-03-27 11:34:18','118','何一诺','南宁市青秀区民族大道','2026-03-27 11:34:18','订单编号10');
/*!40000 ALTER TABLE `fuwujilu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fuwupingjia`
--

DROP TABLE IF EXISTS `fuwupingjia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuwupingjia` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `fuwuxiangmu` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务项目',
  `fuwujiage` double DEFAULT NULL COMMENT '服务价格',
  `fuwumiaoshu` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务描述',
  `renyuanzhanghao` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '人员账号',
  `renyuanxingming` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '人员姓名',
  `yuyueriqi` date DEFAULT NULL COMMENT '预约日期',
  `yuyueshijianduan` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '预约时间段',
  `yuyueshijian` datetime DEFAULT NULL COMMENT '预约时间',
  `zhanghao` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '账号',
  `yonghuxingming` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户姓名',
  `fuwudidian` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务地点',
  `wanchengshijian` datetime DEFAULT NULL COMMENT '完成时间',
  `dingdanbianhao` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单编号',
  `pingjiashijian` datetime DEFAULT NULL COMMENT '评价时间',
  `pingjianeirong` longtext COLLATE utf8mb4_unicode_ci COMMENT '评价内容',
  `sfsh` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '待审核' COMMENT '是否审核',
  `shhf` longtext COLLATE utf8mb4_unicode_ci COMMENT '回复内容',
  `crossuserid` bigint(20) DEFAULT NULL COMMENT '跨表用户id',
  `crossrefid` bigint(20) DEFAULT NULL COMMENT '跨表主键id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='服务评价';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fuwupingjia`
--

LOCK TABLES `fuwupingjia` WRITE;
/*!40000 ALTER TABLE `fuwupingjia` DISABLE KEYS */;
INSERT INTO `fuwupingjia` VALUES (1,'2026-03-27 03:34:18','老人陪护医疗',400,'术后老人照料用药提醒康复辅助血压监测','119','何雨欣','2026-03-27','8:00-9:00','2026-03-27 11:34:18','119','赵嘉轩','合肥市庐阳区淮河路','2026-03-27 11:34:18','订单编号1','2026-03-27 11:34:18','评价内容1','是','',1,1),(2,'2026-03-27 03:34:18','深度保洁',350,'全屋精细擦拭厨卫深度清洁玻璃清洁死角清理','116','蒋欣怡','2026-03-27','15:00-16:00','2026-03-27 11:34:18','116','陈宇泽','长沙市岳麓区岳麓山','2026-03-27 11:34:18','订单编号2','2026-03-27 11:34:18','评价内容2','是','',2,2),(3,'2026-03-27 03:34:18','家电清洗油烟机',200,'油烟机拆机清洗滤网风轮清洁机身擦拭','117','林泽阳','2026-03-27','10:00-11:00','2026-03-27 11:34:18','117','胡梓妍','济南市历下区泉城广场','2026-03-27 11:34:18','订单编号3','2026-03-27 11:34:18','评价内容3','是','',3,3),(4,'2026-03-27 03:34:18','布艺清洗窗帘',300,'窗帘拆卸清洗烘干安装除螨除尘','123','杨若菲','2026-03-27','17:00-18:00','2026-03-27 11:34:18','123','罗欣怡','福州市鼓楼区东街口','2026-03-27 11:34:18','订单编号4','2026-03-27 11:34:18','评价内容4','是','',4,4),(5,'2026-03-27 03:34:18','家庭烹饪宴席',400,'家庭宴席制作特色菜烹饪食材采购摆盘装饰','121','卫泽楷','2026-03-27','13:00-14:00','2026-03-27 11:34:18','121','朱泽宇','郑州市金水区花园路','2026-03-27 11:34:18','订单编号5','2026-03-27 11:34:18','评价内容5','是','',5,5),(6,'2026-03-27 03:34:18','布艺清洗地毯',260,'地毯吸尘除螨局部去污整体清洁','114','韩雨桐','2026-03-27','11:00-12:00','2026-03-27 11:34:18','114','刘思怡','长春市朝阳区重庆路','2026-03-27 11:34:18','订单编号6','2026-03-27 11:34:18','评价内容6','是','',6,6),(7,'2026-03-27 03:34:18','家电清洗冰箱',150,'冰箱全腔清洁除霜除味密封条清洁','112','冯语涵','2026-03-27','9:00-10:00','2026-03-27 11:34:18','112','吴梦琪','天津市和平区和平路','2026-03-27 11:34:18','订单编号7','2026-03-27 11:34:18','评价内容7','是','',7,7),(8,'2026-03-27 03:34:18','满月汗蒸',180,'产后满月发汗祛湿驱寒经络疏通体质调理','115','吴彦辰','2026-03-27','12:00-13:00','2026-03-27 11:34:18','115','徐浩然','成都市锦江区春熙路','2026-03-27 11:34:18','订单编号8','2026-03-27 11:34:18','评价内容8','是','',8,8),(9,'2026-03-27 03:34:18','开荒保洁新房',600,'新房全屋清洁建筑垃圾清理玻璃清洁地面擦拭','113','李若曦','2026-03-27','14:00-15:00','2026-03-27 11:34:18','113','黄欣冉','上海市浦东新区张江高科技园区','2026-03-27 11:34:18','订单编号9','2026-03-27 11:34:18','评价内容9','是','',9,9),(10,'2026-03-27 03:34:18','家庭烹饪月子餐',180,'产妇月子餐定制营养搭配食材处理餐食制作','118','夏浩然','2026-03-27','16:00-17:00','2026-03-27 11:34:18','118','何一诺','南宁市青秀区民族大道','2026-03-27 11:34:18','订单编号10','2026-03-27 11:34:18','评价内容10','是','',10,10);
/*!40000 ALTER TABLE `fuwupingjia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fuwurenyuan`
--

DROP TABLE IF EXISTS `fuwurenyuan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuwurenyuan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `renyuanzhanghao` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '人员账号',
  `mima` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码',
  `renyuanxingming` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '人员姓名',
  `nianling` int(11) DEFAULT NULL COMMENT '年龄',
  `xingbie` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '性别',
  `lianxidianhua` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '联系电话',
  `zizhizhengming` longtext COLLATE utf8mb4_unicode_ci COMMENT '资质证明',
  `jiazhengfuwujineng` longtext COLLATE utf8mb4_unicode_ci COMMENT '家政服务技能',
  `sfsh` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '待审核' COMMENT '是否审核',
  `shhf` longtext COLLATE utf8mb4_unicode_ci COMMENT '回复内容',
  `touxiang` longtext COLLATE utf8mb4_unicode_ci COMMENT '头像',
  `clicktime` datetime DEFAULT NULL COMMENT '最近点击时间',
  `max_password_wrong` int(11) NOT NULL DEFAULT '3' COMMENT '最大密码输错次数',
  `is_locked` int(11) NOT NULL DEFAULT '0' COMMENT '用户锁定状态',
  `wodepaiban` longtext COLLATE utf8mb4_unicode_ci COMMENT '我的排班',
  PRIMARY KEY (`id`),
  UNIQUE KEY `renyuanzhanghao` (`renyuanzhanghao`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='家政人员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fuwurenyuan`
--

LOCK TABLES `fuwurenyuan` WRITE;
/*!40000 ALTER TABLE `fuwurenyuan` DISABLE KEYS */;
INSERT INTO `fuwurenyuan` VALUES (121,'2026-03-27 03:34:18','119','123456','何雨欣',1,'男','19819881111','','术后老人照料用药提醒康复辅助血压监测','是','','file/fuwurenyuanTouxiang1.jpg','2026-03-27 11:34:18',1,0,'夜班周二至周六2300至0700'),(122,'2026-03-27 03:34:18','116','123456','蒋欣怡',2,'男','19819881112','','全屋精细擦拭厨卫深度清洁玻璃清洁死角清理','是','','file/fuwurenyuanTouxiang2.jpg','2026-03-27 11:34:18',2,0,'夜班周一至周五0000至0800'),(123,'2026-03-27 03:34:18','117','123456','林泽阳',3,'男','19819881113','','油烟机拆机清洗滤网风轮清洁机身擦拭','是','','file/fuwurenyuanTouxiang3.jpg','2026-03-27 11:34:18',3,0,'夜班周一至周五2300至0700'),(124,'2026-03-27 03:34:18','123','123456','杨若菲',4,'男','19819881114','','窗帘拆卸清洗烘干安装除螨除尘','是','','file/fuwurenyuanTouxiang4.jpg','2026-03-27 11:34:18',4,0,'常白班周一至周五0900至1700'),(125,'2026-03-27 03:34:18','121','123456','卫泽楷',5,'男','19819881115','','家庭宴席制作特色菜烹饪食材采购摆盘装饰','是','','file/fuwurenyuanTouxiang5.jpg','2026-03-27 11:34:18',5,0,'早班周二至周六0800至1600'),(126,'2026-03-27 03:34:18','114','123456','韩雨桐',6,'男','19819881116','','地毯吸尘除螨局部去污整体清洁','是','','file/fuwurenyuanTouxiang6.jpg','2026-03-27 11:34:18',6,0,'夜班周三至周日2300至0700'),(127,'2026-03-27 03:34:18','112','123456','冯语涵',7,'男','19819881117','','冰箱全腔清洁除霜除味密封条清洁','是','','file/fuwurenyuanTouxiang7.jpg','2026-03-27 11:34:18',7,0,'中班周一至周五1500至2300'),(128,'2026-03-27 03:34:18','115','123456','吴彦辰',8,'男','19819881118','','产后满月发汗祛湿驱寒经络疏通体质调理','是','','file/fuwurenyuanTouxiang8.jpg','2026-03-27 11:34:18',8,0,'夜班周三至周日0000至0800'),(129,'2026-03-27 03:34:18','113','123456','李若曦',9,'男','19819881119','','新房全屋清洁建筑垃圾清理玻璃清洁地面擦拭','是','','file/fuwurenyuanTouxiang9.jpg','2026-03-27 11:34:18',9,0,'早班周二至周六0700至1500'),(130,'2026-03-27 03:34:18','118','123456','夏浩然',10,'男','198198811110','','产妇月子餐定制营养搭配食材处理餐食制作','是','','file/fuwurenyuanTouxiang10.jpg','2026-03-27 11:34:18',10,0,'中班周一至周五1500至2300');
/*!40000 ALTER TABLE `fuwurenyuan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fuwuxinxi`
--

DROP TABLE IF EXISTS `fuwuxinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuwuxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `fuwuxiangmu` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务项目',
  `fuwujiage` double DEFAULT NULL COMMENT '服务价格',
  `fuwumiaoshu` longtext COLLATE utf8mb4_unicode_ci COMMENT '服务描述',
  `tupian` longtext COLLATE utf8mb4_unicode_ci COMMENT '图片',
  `storeup_number` int(11) DEFAULT '0' COMMENT '收藏数',
  `clicktime` datetime DEFAULT NULL COMMENT '最近点击时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='服务信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fuwuxinxi`
--

LOCK TABLES `fuwuxinxi` WRITE;
/*!40000 ALTER TABLE `fuwuxinxi` DISABLE KEYS */;
INSERT INTO `fuwuxinxi` VALUES (1,'2026-03-27 03:34:17','老人陪护医疗',400,'术后老人照料用药提醒康复辅助血压监测','file/fuwuxinxi_深度除菌1.jpg,file/fuwuxinxi_深度除菌2.jpg,file/fuwuxinxi_深度除菌3.jpg',1,'2026-03-27 11:34:17'),(2,'2026-03-27 03:34:17','深度保洁',350,'全屋精细擦拭厨卫深度清洁玻璃清洁死角清理','file/fuwuxinxi_地板打蜡1.jpg,file/fuwuxinxi_地板打蜡2.jpg,file/fuwuxinxi_地板打蜡3.jpg',2,'2026-03-27 11:34:17'),(3,'2026-03-27 03:34:17','家电清洗油烟机',200,'油烟机拆机清洗滤网风轮清洁机身擦拭','file/fuwuxinxi_沙发洗护1.jpg,file/fuwuxinxi_沙发洗护2.jpg,file/fuwuxinxi_沙发洗护3.jpg',3,'2026-03-27 11:34:17'),(4,'2026-03-27 03:34:17','布艺清洗窗帘',300,'窗帘拆卸清洗烘干安装除螨除尘','file/fuwuxinxi_除尘除螨1.jpg,file/fuwuxinxi_除尘除螨2.jpg,file/fuwuxinxi_除尘除螨3.jpg',5,'2026-03-27 11:37:36'),(5,'2026-03-27 03:34:17','家庭烹饪宴席',400,'家庭宴席制作特色菜烹饪食材采购摆盘装饰','file/fuwuxinxi_月嫂照护1.jpg,file/fuwuxinxi_月嫂照护2.jpg,file/fuwuxinxi_月嫂照护3.jpg',5,'2026-03-27 11:34:17'),(6,'2026-03-27 03:34:17','布艺清洗地毯',260,'地毯吸尘除螨局部去污整体清洁','file/fuwuxinxi_育儿嫂1.jpg,file/fuwuxinxi_育儿嫂2.jpg,file/fuwuxinxi_育儿嫂3.jpg',6,'2026-03-27 11:34:17'),(7,'2026-03-27 03:34:17','家电清洗冰箱',150,'冰箱全腔清洁除霜除味密封条清洁','file/fuwuxinxi_钟点工1.jpg,file/fuwuxinxi_钟点工2.jpg,file/fuwuxinxi_钟点工3.jpg',7,'2026-03-27 11:34:17'),(8,'2026-03-27 03:34:17','满月汗蒸',180,'产后满月发汗祛湿驱寒经络疏通体质调理','file/fuwuxinxi_老人陪护1.jpg,file/fuwuxinxi_老人陪护2.jpg,file/fuwuxinxi_老人陪护3.jpg',8,'2026-03-27 11:34:17'),(9,'2026-03-27 03:34:17','开荒保洁新房',600,'新房全屋清洁建筑垃圾清理玻璃清洁地面擦拭','file/fuwuxinxi_擦窗亮玻1.jpg,file/fuwuxinxi_擦窗亮玻2.jpg,file/fuwuxinxi_擦窗亮玻3.jpg',9,'2026-03-27 11:34:17'),(10,'2026-03-27 03:34:17','家庭烹饪月子餐',180,'产妇月子餐定制营养搭配食材处理餐食制作','file/fuwuxinxi_卫生间消毒1.jpg,file/fuwuxinxi_卫生间消毒2.jpg,file/fuwuxinxi_卫生间消毒3.jpg',10,'2026-03-27 11:34:17');
/*!40000 ALTER TABLE `fuwuxinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fuwuyuyue`
--

DROP TABLE IF EXISTS `fuwuyuyue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fuwuyuyue` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `yuyueriqi` date DEFAULT NULL COMMENT '预约日期',
  `yuyueshijianduan` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '预约时间段',
  `yuyueshijian` datetime DEFAULT NULL COMMENT '预约时间',
  `zhanghao` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '账号',
  `yonghuxingming` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户姓名',
  `fuwudidian` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '服务地点',
  `fuwuxiangmu` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务项目',
  `fuwujiage` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务价格',
  `fuwumiaoshu` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务描述',
  `ispay` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '未支付' COMMENT '是否支付',
  `renyuanzhanghao` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '人员账号',
  `renyuanxingming` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '人员姓名',
  `sfsh` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '待审核' COMMENT '是否审核',
  `shhf` longtext COLLATE utf8mb4_unicode_ci COMMENT '回复内容',
  `jiedanxiangqing` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '接单详情',
  `crossuserid` bigint(20) DEFAULT NULL COMMENT '跨表用户id',
  `crossrefid` bigint(20) DEFAULT NULL COMMENT '跨表主键id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='服务预约';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fuwuyuyue`
--

LOCK TABLES `fuwuyuyue` WRITE;
/*!40000 ALTER TABLE `fuwuyuyue` DISABLE KEYS */;
INSERT INTO `fuwuyuyue` VALUES (1,'2026-03-27 03:34:17','2026-03-27','8:00-9:00','2026-03-27 11:34:17','119','赵嘉轩','合肥市庐阳区淮河路','老人陪护医疗','400','术后老人照料用药提醒康复辅助血压监测','未支付','119','何雨欣','是','','已接单',1,1),(2,'2026-03-27 03:34:17','2026-03-27','15:00-16:00','2026-03-27 11:34:17','116','陈宇泽','长沙市岳麓区岳麓山','深度保洁','350','全屋精细擦拭厨卫深度清洁玻璃清洁死角清理','未支付','116','蒋欣怡','是','','已接单',2,2),(3,'2026-03-27 03:34:17','2026-03-27','10:00-11:00','2026-03-27 11:34:17','117','胡梓妍','济南市历下区泉城广场','家电清洗油烟机','200','油烟机拆机清洗滤网风轮清洁机身擦拭','未支付','117','林泽阳','是','','已接单',3,3),(4,'2026-03-27 03:34:17','2026-03-27','17:00-18:00','2026-03-27 11:34:17','123','罗欣怡','福州市鼓楼区东街口','布艺清洗窗帘','300','窗帘拆卸清洗烘干安装除螨除尘','未支付','123','杨若菲','是','','已接单',4,4),(5,'2026-03-27 03:34:17','2026-03-27','13:00-14:00','2026-03-27 11:34:17','121','朱泽宇','郑州市金水区花园路','家庭烹饪宴席','400','家庭宴席制作特色菜烹饪食材采购摆盘装饰','未支付','121','卫泽楷','是','','已接单',5,5),(6,'2026-03-27 03:34:17','2026-03-27','11:00-12:00','2026-03-27 11:34:17','114','刘思怡','长春市朝阳区重庆路','布艺清洗地毯','260','地毯吸尘除螨局部去污整体清洁','未支付','114','韩雨桐','是','','已接单',6,6),(7,'2026-03-27 03:34:17','2026-03-27','9:00-10:00','2026-03-27 11:34:17','112','吴梦琪','天津市和平区和平路','家电清洗冰箱','150','冰箱全腔清洁除霜除味密封条清洁','未支付','112','冯语涵','是','','已接单',7,7),(8,'2026-03-27 03:34:17','2026-03-27','12:00-13:00','2026-03-27 11:34:17','115','徐浩然','成都市锦江区春熙路','满月汗蒸','180','产后满月发汗祛湿驱寒经络疏通体质调理','未支付','115','吴彦辰','是','','已接单',8,8),(9,'2026-03-27 03:34:17','2026-03-27','14:00-15:00','2026-03-27 11:34:17','113','黄欣冉','上海市浦东新区张江高科技园区','开荒保洁新房','600','新房全屋清洁建筑垃圾清理玻璃清洁地面擦拭','未支付','113','李若曦','是','','已接单',9,9),(10,'2026-03-27 03:34:17','2026-03-27','16:00-17:00','2026-03-27 11:34:17','118','何一诺','南宁市青秀区民族大道','家庭烹饪月子餐','180','产妇月子餐定制营养搭配食材处理餐食制作','未支付','118','夏浩然','是','','已接单',10,10);
/*!40000 ALTER TABLE `fuwuyuyue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `menujson` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '菜单',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='菜单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'2026-03-27 03:34:18','[{\"backMenu\":[{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"appFrontIcon\":\"cuIcon-vip\",\"buttons\":[\"查看\"],\"classname\":\"storeup\",\"menu\":\"我的收藏\",\"menuJump\":\"1\",\"tableName\":\"storeup\"}],\"fontClass\":\"icon-common4\",\"menu\":\"我的收藏管理\",\"unicode\":\"&#xedab;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"审核\",\"支付\",\"服务接单\",\"首页总数\",\"首页统计\",\"接单\"],\"appFrontIcon\":\"cuIcon-shop\",\"buttons\":[\"查看\",\"支付\",\"首页总数\",\"首页统计\",\"服务接单\"],\"classname\":\"fuwuyuyue\",\"menu\":\"服务预约\",\"menuJump\":\"列表\",\"tableName\":\"fuwuyuyue\"}],\"fontClass\":\"icon-common24\",\"menu\":\"服务预约管理\",\"unicode\":\"&#xee07;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"打卡\"],\"appFrontIcon\":\"cuIcon-skin\",\"buttons\":[\"查看\"],\"classname\":\"fuwujiedan\",\"menu\":\"服务接单\",\"menuJump\":\"列表\",\"tableName\":\"fuwujiedan\"}],\"fontClass\":\"icon-common7\",\"menu\":\"服务分配管理\",\"unicode\":\"&#xedb4;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"收入金额\",\"首页总数\",\"首页统计\",\"评价\"],\"appFrontIcon\":\"cuIcon-flashlightopen\",\"buttons\":[\"查看\",\"评价\"],\"classname\":\"fuwujilu\",\"menu\":\"服务记录\",\"menuJump\":\"列表\",\"tableName\":\"fuwujilu\"}],\"fontClass\":\"icon-common15\",\"menu\":\"服务完成管理\",\"unicode\":\"&#xedfc;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"审核\"],\"appFrontIcon\":\"cuIcon-wenzi\",\"buttons\":[\"查看\",\"修改\",\"删除\"],\"classname\":\"fuwupingjia\",\"menu\":\"服务评价\",\"menuJump\":\"列表\",\"tableName\":\"fuwupingjia\"}],\"fontClass\":\"icon-common50\",\"menu\":\"服务评价管理\",\"unicode\":\"&#xef96;\"}],\"frontMenu\":[{\"child\":[{\"appFrontIcon\":\"cuIcon-shop\",\"buttons\":[\"查看\",\"服务预约\"],\"classname\":\"fuwuxinxi\",\"menu\":\"服务信息\",\"menuJump\":\"列表\",\"tableName\":\"fuwuxinxi\"}],\"menu\":\"服务套餐管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-list\",\"buttons\":[\"查看\"],\"classname\":\"news\",\"menu\":\"家政资讯\",\"menuJump\":\"列表\",\"tableName\":\"news\"}],\"menu\":\"家政资讯管理\"}],\"hasBackLogin\":\"否\",\"hasBackRegister\":\"否\",\"hasFrontLogin\":\"是\",\"hasFrontRegister\":\"是\",\"pathName\":\"yonghu\",\"roleName\":\"用户\",\"tableName\":\"yonghu\"},{\"backMenu\":[{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"审核\",\"支付\",\"服务接单\",\"首页总数\",\"首页统计\",\"接单\"],\"appFrontIcon\":\"cuIcon-shop\",\"buttons\":[\"查看\",\"审核\",\"首页总数\",\"首页统计\",\"接单\"],\"classname\":\"fuwuyuyue\",\"menu\":\"服务预约\",\"menuJump\":\"列表\",\"tableName\":\"fuwuyuyue\"}],\"fontClass\":\"icon-common24\",\"menu\":\"服务预约管理\",\"unicode\":\"&#xee07;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"打卡\"],\"appFrontIcon\":\"cuIcon-skin\",\"buttons\":[\"查看\",\"修改\",\"删除\",\"打卡\"],\"classname\":\"fuwujiedan\",\"menu\":\"服务接单\",\"menuJump\":\"列表\",\"tableName\":\"fuwujiedan\"}],\"fontClass\":\"icon-common7\",\"menu\":\"服务分配管理\",\"unicode\":\"&#xedb4;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"服务完成量\",\"首页总数\",\"首页统计\",\"服务完成\"],\"appFrontIcon\":\"cuIcon-camera\",\"buttons\":[\"查看\",\"修改\",\"删除\",\"服务完成量\",\"首页总数\",\"首页统计\",\"服务完成\"],\"classname\":\"fuwudaka\",\"menu\":\"服务打卡\",\"menuJump\":\"列表\",\"tableName\":\"fuwudaka\"}],\"fontClass\":\"icon-common15\",\"menu\":\"服务开始管理\",\"unicode\":\"&#xedfc;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"收入金额\",\"首页总数\",\"首页统计\",\"评价\"],\"appFrontIcon\":\"cuIcon-flashlightopen\",\"buttons\":[\"查看\",\"修改\",\"删除\",\"收入金额\",\"首页总数\",\"首页统计\"],\"classname\":\"fuwujilu\",\"menu\":\"服务记录\",\"menuJump\":\"列表\",\"tableName\":\"fuwujilu\"}],\"fontClass\":\"icon-common15\",\"menu\":\"服务完成管理\",\"unicode\":\"&#xedfc;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"审核\"],\"appFrontIcon\":\"cuIcon-wenzi\",\"buttons\":[\"查看\"],\"classname\":\"fuwupingjia\",\"menu\":\"服务评价\",\"menuJump\":\"列表\",\"tableName\":\"fuwupingjia\"}],\"fontClass\":\"icon-common50\",\"menu\":\"服务评价管理\",\"unicode\":\"&#xef96;\"}],\"frontMenu\":[{\"child\":[{\"appFrontIcon\":\"cuIcon-shop\",\"buttons\":[\"查看\",\"服务预约\"],\"classname\":\"fuwuxinxi\",\"menu\":\"服务信息\",\"menuJump\":\"列表\",\"tableName\":\"fuwuxinxi\"}],\"menu\":\"服务套餐管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-list\",\"buttons\":[\"查看\"],\"classname\":\"news\",\"menu\":\"家政资讯\",\"menuJump\":\"列表\",\"tableName\":\"news\"}],\"menu\":\"家政资讯管理\"}],\"hasBackLogin\":\"是\",\"hasBackRegister\":\"是\",\"hasFrontLogin\":\"否\",\"hasFrontRegister\":\"否\",\"pathName\":\"fuwurenyuan\",\"roleName\":\"家政人员\",\"tableName\":\"fuwurenyuan\"},{\"backMenu\":[{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"appFrontIcon\":\"cuIcon-list\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"classname\":\"config\",\"menu\":\"轮播图\",\"menuJump\":\"列表\",\"tableName\":\"config\"}],\"fontClass\":\"icon-common10\",\"menu\":\"轮播图管理\",\"unicode\":\"&#xedd1;\"},{\"child\":[{\"allButtons\":[\"菜单管理\"],\"appFrontIcon\":\"cuIcon-medal\",\"buttons\":[\"菜单管理\"],\"classname\":\"menu\",\"menu\":\"菜单\",\"menuJump\":\"列表\",\"tableName\":\"menu\"}],\"fontClass\":\"icon-common26\",\"menu\":\"菜单管理\",\"unicode\":\"&#xee2b;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"appFrontIcon\":\"cuIcon-news\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"classname\":\"users\",\"menu\":\"管理员\",\"menuJump\":\"列表\",\"tableName\":\"users\"},{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"appFrontIcon\":\"cuIcon-goodsnew\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"classname\":\"yonghu\",\"menu\":\"用户\",\"menuJump\":\"列表\",\"tableName\":\"yonghu\"},{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"审核\"],\"appFrontIcon\":\"cuIcon-discover\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"审核\"],\"classname\":\"fuwurenyuan\",\"menu\":\"家政人员\",\"menuJump\":\"列表\",\"tableName\":\"fuwurenyuan\"}],\"fontClass\":\"icon-user1\",\"menu\":\"用户管理\",\"unicode\":\"&#xef97;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"appFrontIcon\":\"cuIcon-vipcard\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"classname\":\"news\",\"menu\":\"家政资讯\",\"menuJump\":\"列表\",\"tableName\":\"news\"}],\"fontClass\":\"icon-common11\",\"menu\":\"家政资讯管理\",\"unicode\":\"&#xeded;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"服务预约\"],\"appFrontIcon\":\"cuIcon-skin\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"classname\":\"fuwuxinxi\",\"menu\":\"服务信息\",\"menuJump\":\"列表\",\"tableName\":\"fuwuxinxi\"}],\"fontClass\":\"icon-common15\",\"menu\":\"服务信息管理\",\"unicode\":\"&#xedfc;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"审核\",\"支付\",\"服务接单\",\"首页总数\",\"首页统计\",\"接单\"],\"appFrontIcon\":\"cuIcon-shop\",\"buttons\":[\"查看\",\"服务接单\",\"首页统计\",\"首页总数\",\"修改\",\"删除\"],\"classname\":\"fuwuyuyue\",\"menu\":\"服务预约\",\"menuJump\":\"列表\",\"tableName\":\"fuwuyuyue\"}],\"fontClass\":\"icon-common24\",\"menu\":\"服务预约管理\",\"unicode\":\"&#xee07;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"打卡\"],\"appFrontIcon\":\"cuIcon-skin\",\"buttons\":[\"查看\",\"修改\",\"删除\"],\"classname\":\"fuwujiedan\",\"menu\":\"服务接单\",\"menuJump\":\"列表\",\"tableName\":\"fuwujiedan\"}],\"fontClass\":\"icon-common7\",\"menu\":\"服务分配管理\",\"unicode\":\"&#xedb4;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"服务完成量\",\"首页总数\",\"首页统计\",\"服务完成\"],\"appFrontIcon\":\"cuIcon-camera\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"服务完成量\",\"首页总数\",\"首页统计\"],\"classname\":\"fuwudaka\",\"menu\":\"服务打卡\",\"menuJump\":\"列表\",\"tableName\":\"fuwudaka\"}],\"fontClass\":\"icon-common15\",\"menu\":\"服务开始管理\",\"unicode\":\"&#xedfc;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"收入金额\",\"首页总数\",\"首页统计\",\"评价\"],\"appFrontIcon\":\"cuIcon-flashlightopen\",\"buttons\":[\"查看\",\"修改\",\"删除\",\"收入金额\",\"首页总数\",\"首页统计\"],\"classname\":\"fuwujilu\",\"menu\":\"服务记录\",\"menuJump\":\"列表\",\"tableName\":\"fuwujilu\"}],\"fontClass\":\"icon-common15\",\"menu\":\"服务完成管理\",\"unicode\":\"&#xedfc;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"审核\"],\"appFrontIcon\":\"cuIcon-wenzi\",\"buttons\":[\"查看\",\"修改\",\"删除\",\"审核\"],\"classname\":\"fuwupingjia\",\"menu\":\"服务评价\",\"menuJump\":\"列表\",\"tableName\":\"fuwupingjia\"}],\"fontClass\":\"icon-common50\",\"menu\":\"服务评价管理\",\"unicode\":\"&#xef96;\"},{\"child\":[{\"allButtons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"appFrontIcon\":\"cuIcon-copy\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"classname\":\"syslog\",\"menu\":\"操作日志\",\"menuJump\":\"列表\",\"tableName\":\"syslog\"}],\"fontClass\":\"icon-common35\",\"menu\":\"操作日志管理\",\"unicode\":\"&#xee8c;\"}],\"frontMenu\":[{\"child\":[{\"appFrontIcon\":\"cuIcon-shop\",\"buttons\":[\"查看\",\"服务预约\"],\"classname\":\"fuwuxinxi\",\"menu\":\"服务信息\",\"menuJump\":\"列表\",\"tableName\":\"fuwuxinxi\"}],\"menu\":\"服务套餐管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-list\",\"buttons\":[\"查看\"],\"classname\":\"news\",\"menu\":\"家政资讯\",\"menuJump\":\"列表\",\"tableName\":\"news\"}],\"menu\":\"家政资讯管理\"}],\"hasBackLogin\":\"是\",\"hasBackRegister\":\"否\",\"hasFrontLogin\":\"否\",\"hasFrontRegister\":\"否\",\"pathName\":\"users\",\"roleName\":\"管理员\",\"tableName\":\"users\"}]');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `title` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标题',
  `introduction` longtext COLLATE utf8mb4_unicode_ci COMMENT '简介',
  `picture` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '图片',
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='家政资讯';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (1,'2026-03-27 03:34:18','深度除菌','高温','file/news_深度除菌1.jpg,file/news_深度除菌2.jpg,file/news_深度除菌3.jpg','厨卫'),(2,'2026-03-27 03:34:18','地板打蜡','保养','file/news_地板打蜡1.jpg,file/news_地板打蜡2.jpg,file/news_地板打蜡3.jpg','客厅'),(3,'2026-03-27 03:34:18','沙发洗护','无水','file/news_沙发洗护1.jpg,file/news_沙发洗护2.jpg,file/news_沙发洗护3.jpg','客厅'),(4,'2026-03-27 03:34:18','除尘除螨','除螨','file/news_除尘除螨1.jpg,file/news_除尘除螨2.jpg,file/news_除尘除螨3.jpg','卧室'),(5,'2026-03-27 03:34:18','月嫂照护','育儿','file/news_月嫂照护1.jpg,file/news_月嫂照护2.jpg,file/news_月嫂照护3.jpg','主卧'),(6,'2026-03-27 03:34:18','育儿嫂','游戏','file/news_育儿嫂1.jpg,file/news_育儿嫂2.jpg,file/news_育儿嫂3.jpg','儿童房'),(7,'2026-03-27 03:34:18','钟点工','灵活','file/news_钟点工1.jpg,file/news_钟点工2.jpg,file/news_钟点工3.jpg','客厅'),(8,'2026-03-27 03:34:18','老人陪护','照顾','file/news_老人陪护1.jpg,file/news_老人陪护2.jpg,file/news_老人陪护3.jpg','主卧'),(9,'2026-03-27 03:34:18','擦窗亮玻','无痕','file/news_擦窗亮玻1.jpg,file/news_擦窗亮玻2.jpg,file/news_擦窗亮玻3.jpg','阳台'),(10,'2026-03-27 03:34:18','卫生间消毒','除霉','file/news_卫生间消毒1.jpg,file/news_卫生间消毒2.jpg,file/news_卫生间消毒3.jpg','卫浴');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storeup`
--

DROP TABLE IF EXISTS `storeup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storeup` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `refid` bigint(20) DEFAULT NULL COMMENT 'refid',
  `tablename` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '表名',
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '名称',
  `picture` longtext COLLATE utf8mb4_unicode_ci COMMENT '图片',
  `type` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '1' COMMENT '类型(1:收藏,21:赞,22:踩,31:竞拍参与,41:关注)',
  `inteltype` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '推荐类型',
  `remark` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `userid` bigint(20) NOT NULL COMMENT '用户id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='我的收藏';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storeup`
--

LOCK TABLES `storeup` WRITE;
/*!40000 ALTER TABLE `storeup` DISABLE KEYS */;
INSERT INTO `storeup` VALUES (1,'2026-03-27 03:37:38',4,'fuwuxinxi','布艺清洗窗帘','file/fuwuxinxi_除尘除螨1.jpg','1',NULL,NULL,115);
/*!40000 ALTER TABLE `storeup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `syslog`
--

DROP TABLE IF EXISTS `syslog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `syslog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `username` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `operation` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户操作',
  `method` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '请求方法',
  `params` longtext COLLATE utf8mb4_unicode_ci COMMENT '请求参数',
  `time` bigint(20) DEFAULT NULL COMMENT '请求时长(毫秒)',
  `ip` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ip地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='操作日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `syslog`
--

LOCK TABLES `syslog` WRITE;
/*!40000 ALTER TABLE `syslog` DISABLE KEYS */;
/*!40000 ALTER TABLE `syslog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `userid` bigint(20) NOT NULL COMMENT '用户id',
  `username` varchar(100) NOT NULL COMMENT '用户名',
  `tablename` varchar(100) DEFAULT NULL COMMENT '表名',
  `role` varchar(100) DEFAULT NULL COMMENT '角色',
  `token` varchar(500) NOT NULL COMMENT '密码',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
  `expiratedtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '过期时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='token表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token`
--

LOCK TABLES `token` WRITE;
/*!40000 ALTER TABLE `token` DISABLE KEYS */;
INSERT INTO `token` VALUES (1,115,'121','yonghu','用户','n6gr0lwso7mqw8wr7pqq6n5kqd706s8a','2026-03-27 03:37:33','2026-03-27 04:37:33');
/*!40000 ALTER TABLE `token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `username` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `password` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码',
  `role` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '管理员' COMMENT '角色',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='管理员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'2026-03-27 03:34:18','admin','admin','管理员');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yonghu`
--

DROP TABLE IF EXISTS `yonghu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yonghu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `yonghuxingming` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户姓名',
  `nianling` int(11) NOT NULL COMMENT '年龄',
  `lianxifangshi` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '联系方式',
  `zhanghao` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '账号',
  `mima` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码',
  `touxiang` longtext COLLATE utf8mb4_unicode_ci COMMENT '头像',
  `jiazhengfuwudizhi` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '家政服务地址',
  PRIMARY KEY (`id`),
  UNIQUE KEY `zhanghao` (`zhanghao`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yonghu`
--

LOCK TABLES `yonghu` WRITE;
/*!40000 ALTER TABLE `yonghu` DISABLE KEYS */;
INSERT INTO `yonghu` VALUES (111,'2026-03-27 03:34:18','赵嘉轩',1,'19819881111','119','123456','file/yonghuTouxiang1.jpg','合肥市庐阳区淮河路'),(112,'2026-03-27 03:34:18','陈宇泽',2,'19819881112','116','123456','file/yonghuTouxiang2.jpg','长沙市岳麓区岳麓山'),(113,'2026-03-27 03:34:18','胡梓妍',3,'19819881113','117','123456','file/yonghuTouxiang3.jpg','济南市历下区泉城广场'),(114,'2026-03-27 03:34:18','罗欣怡',4,'19819881114','123','123456','file/yonghuTouxiang4.jpg','福州市鼓楼区东街口'),(115,'2026-03-27 03:34:18','朱泽宇',5,'19819881115','121','123456','file/yonghuTouxiang5.jpg','郑州市金水区花园路'),(116,'2026-03-27 03:34:18','刘思怡',6,'19819881116','114','123456','file/yonghuTouxiang6.jpg','长春市朝阳区重庆路'),(117,'2026-03-27 03:34:18','吴梦琪',7,'19819881117','112','123456','file/yonghuTouxiang7.jpg','天津市和平区和平路'),(118,'2026-03-27 03:34:18','徐浩然',8,'19819881118','115','123456','file/yonghuTouxiang8.jpg','成都市锦江区春熙路'),(119,'2026-03-27 03:34:18','黄欣冉',9,'19819881119','113','123456','file/yonghuTouxiang9.jpg','上海市浦东新区张江高科技园区'),(120,'2026-03-27 03:34:18','何一诺',10,'198198811110','118','123456','file/yonghuTouxiang10.jpg','南宁市青秀区民族大道');
/*!40000 ALTER TABLE `yonghu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-27 13:21:41
