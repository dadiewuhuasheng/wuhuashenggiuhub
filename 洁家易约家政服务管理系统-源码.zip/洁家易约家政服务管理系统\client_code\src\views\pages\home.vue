<template>
    <div class="home_box">

			<!-- 服务信息推荐 -->
            <div class="recomList_view">
<div class="tableName"><span>服务信息推荐</span><div class="more" @click="moreClick('fuwuxinxi')" style="cursor: pointer;"><span>查看更多</span></div></div>
 
<div class="list">
    <div v-for="(item,index) in fuwuxinxiRecomList" @click="detailClick('fuwuxinxi',item.id)" class="item" style="cursor: pointer;">
        <img v-if="item.imgUrls" :src="item.imgUrls[0]" alt="">
        <div class="content">

<div class="title">服务项目：{{item.fuwuxiangmu}}</div>

            <div class="num-row">

<div class="storeupnum">
	<span class="iconfont icon-likeline4"></span>
	<div class="num">{{item.storeupNumber}}</div>
</div>


            </div>
        </div>       
    </div>
</div>

            </div>
			<!-- 家政人员推荐 -->
            <div class="recomList_view">
<div class="tableName"><span>家政人员推荐</span><div class="more" @click="moreClick('fuwurenyuan')" style="cursor: pointer;"><span>查看更多</span></div></div>
 
<div class="list">
    <div v-for="(item,index) in fuwurenyuanRecomList" @click="detailClick('fuwurenyuan',item.id)" class="item" style="cursor: pointer;">
        <img v-if="item.imgUrls" :src="item.imgUrls[0]" alt="">
        <div class="content">

<div class="title">人员姓名：{{item.renyuanxingming}}</div>

            <div class="num-row">



            </div>
        </div>       
    </div>
</div>

            </div>


			<!-- 家政资讯 -->
			<div class="newsList_view">
<div class="list">
    <div class="left">
        <div class="tableName"><span>家政资讯</span></div>
        <template v-for="(item,index) in newsList">
            <div v-if="index<6" class="item" @click="newsDetailClick(item)" style="cursor: pointer;">
                <div class="title text-one-row">{{item.title}}</div>
            </div>
        </template>
    </div>
    
    <div class="right">
        <template v-for="(item,index) in newsList">
            <div v-if="index>5" class="item" @click="newsDetailClick(item)" style="cursor: pointer;">
                <img :src="item.imgUrls[0]" >
            </div>
        </template>
    </div>
    
    <div class="more" @click="moreClick('news')" style="cursor: pointer"><span>查看更多 ></span></div>
</div>

			</div>





    </div>
    <formModel ref="newsFormModelRef"></formModel>
</template>

<script setup>
	import {
		ref,
        computed,
		getCurrentInstance
	} from 'vue';
    const moment = window.moment
	import {
		useRouter
	} from 'vue-router';
    import {
        useStore
    } from 'vuex';
    const store = useStore()
    const user = computed(()=>store.getters['user/session'])
	const context = getCurrentInstance()?.appContext.config.globalProperties;
	const router = useRouter()
    const baseUrl = ref(context.$config.url)
	//服务信息推荐
	const fuwuxinxiRecomList = ref([])
	const getfuwuxinxiRecomList = () => {
		let autoSortUrl = 'fuwuxinxi/autoSort'
		let params = {
			page: 1,
			limit: 4,
		}
		context?.$http({
			url: autoSortUrl,
			method: 'get',
			params: params
		}).then(res => {
			fuwuxinxiRecomList.value = res.data.data.list
			fuwuxinxiRecomList.value.forEach(item=>{
				if(item.tupian!=null){
					item.imgUrls = item.tupian.split(',').map(item=>(isHttp(item)?'':context.$config.url)+item)
				}else{
                    item.imgUrls = []
                }
			})
		})
	}
	//家政人员推荐
	const fuwurenyuanRecomList = ref([])
	const getfuwurenyuanRecomList = () => {
		let autoSortUrl = 'fuwurenyuan/autoSort'
		let params = {
			sfsh: '是',
			page: 1,
			limit: 4,
		}
		context?.$http({
			url: autoSortUrl,
			method: 'get',
			params: params
		}).then(res => {
			fuwurenyuanRecomList.value = res.data.data.list
			fuwurenyuanRecomList.value.forEach(item=>{
				if(item.touxiang!=null){
					item.imgUrls = item.touxiang.split(',').map(item=>(isHttp(item)?'':context.$config.url)+item)
				}else{
                    item.imgUrls = []
                }
			})
		})
	}
	//家政资讯弹窗
	import formModel from './news/formModel'
	const newsFormModelRef = ref(null)
	//家政资讯
	const newsList = ref([])
	const getNewsList = () => {
		context?.$http({
			url: 'news/list',
			method: 'get',
			params:{
				page:1,
				limit: 9,
                sort:'id',
                order:'desc',
			}
		}).then(res=>{
			newsList.value = res.data.data.list
			newsList.value.forEach(item=>{
                let urls = item.picture.split(',')
                item.imgUrls = urls.map(url=>{
                    if(isHttp(url)){
                        return url
                    }else{
                        return baseUrl.value+url
                    }
                })
			})
		})
	}
	const newsDetailClick = (item) => {
		if (item && item.id){
			newsFormModelRef.value.init(item.id)
		}
	}
	//判断图片链接是否带http
	const isHttp = (str) => {
        return str && str.substr(0,4)=='http';
    }
	//跳转详情
	const detailClick = (table,id) => {
		router.push(`/index/${table}Detail?id=${id}`)
	}
	const moreClick = (table) => {
		router.push(`/index/${table}List`)
	}
	const init = () => {
		//服务信息推荐
		getfuwuxinxiRecomList()
		//家政人员推荐
		getfuwurenyuanRecomList()
		//家政资讯
		getNewsList()
	}
	init()
</script>

<style lang="scss">
.home_box {
    width: 100%;
    margin: 0 auto;
    padding: 0;
}
.recomList_view {
    width: 86%;
    margin: 0px auto;
    background: #ececec;
    padding: 20px 0 20px;
    border-top: 5px solid #e0e0e0;
    position: relative;
    order:2;
}
.recomList_view .tableName {
    width: 100%;
    margin: 10px auto 30px;
    text-align: center;
    font-size: 32px;
    letter-spacing: 1px;
    position: relative;
}
.recomList_view .tableName span{
    background: url() no-repeat left center / auto 100%;
    color:#666; 
    padding-left: 0px;
}

.recomList_view .categoryList{
    width: 100%;
    padding-top: 20px;
    padding: 0 100px;
    border-bottom: 5px solid var(--theme);
    clear: both;
    overflow: hidden;
}
.recomList_view .categoryList .item {
    height: 40px;
    line-height: 40px;
    float: left;
    margin-right: 10px;
    padding: 0 20px;
    color: #333;
    font-size: 18px;
    font-weight: 500;
    background-color: #e2e2e2;
    cursor: pointer;
}
.recomList_view .categoryList .item.active{
    background-color: var(--theme);
    color: #fff;
}

.recomList_view .list {
    width: calc(100% + 20px);
    display: flex;
    flex-wrap: wrap;
    margin-top: 30px;
    margin-left: -10px;
    padding: 0 100px;
}

.recomList_view .list .item {
    width: calc(25% - 20px);
    margin: 0 10px 20px;
    padding: 20px;
    border-radius: 0px;
    overflow: hidden;
    background: #fff;
    border-bottom: 5px solid #e0e0e0;
}

.recomList_view .item img {
    width: 100%;
    height: 280px;
    object-fit: cover;
    border-radius: 0
}

.recomList_view .thumbsupnum,.recomList_view  .storeupnum,.recomList_view .clicknum {
    display: flex;
    align-items: center;
    gap: 6px;
}

.recomList_view .el-carousel {
    height: 100%;
}

.recomList_view .el-carousel img {
    height: 100%;
}

.recomList_view .el-carousel__container {
    height: 100%;
}

.recomList_view .item .content {
    width: 100%;
    padding: 10px 0;
    display: flex;
    flex-wrap: wrap;
}
.recomList_view .item .content .title{
    width: 100%; 
    color: #333;
    font-size: 16px;
}
.recomList_view .item:hover .content .title{
    color: #4bb344;
}
.recomList_view .item .content .price {
    width: 100%;
    text-align: left;
    color: #f00;
    font-weight: 600;
    line-height: 1.5;
    margin: 5px 0 0 0;
    order: 5;
}
.recomList_view .item:hover .content .price {
    color: #f00;
}
.recomList_view .item .content .price .number {
    font-size: 16px;
}


.recomList_view .num-row {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-start;
    margin-top: 10px;
    order:8;
}

.recomList_view .thumbsupnum {
    color: var(--theme);
    margin-right: 10px;
}

.recomList_view .storeupnum {
    color: #ff8400;
    margin-right: 10px;
}

.recomList_view .clicknum {
    color: #339933;
    margin-right: 10px;
}

.recomList_view .content .gd {
    width: 100%;
    height: 45px;
    line-height: 45px;
    text-align: center;
    font-size: 16px;
    color: var(--theme);
    border: 1px solid var(--theme50);
    border-radius: 4px;
    margin: 10px 0 0;
    order:11;
}
.recomList_view .content .gd:hover {
    background: var(--theme);
    color: #fff;
}

/* 更多 */
.recomList_view .more {
    width:auto;
    text-align: right;
    display: block;
    float:right;
    margin: 0 100px 0 0;
    position: absolute;
    right: 0;
    top:0;
}
.recomList_view .more span{
    background: #fff;
    padding: 0.6em 1.2em;
    color: #333;
    font-size: 14px;
    display: inline-block;
}
.recomList_view .more span:hover{
}

/* 底部点 */
.recomList_view .swiper-horizontal>.swiper-pagination-bullets,.recomList_view .swiper-pagination-bullets.swiper-pagination-horizontal,
.recomList_view .swiper-pagination-custom,.recomList_view .swiper-pagination-fraction {
    bottom: 0;  
}
.recomList_view .swiper-pagination-bullet {
    width: var(--swiper-pagination-bullet-width,var(--swiper-pagination-bullet-size,12px));
    height: var(--swiper-pagination-bullet-height,var(--swiper-pagination-bullet-size,12px));
}
.newsList_view {
    width: 86%;
    background: #f5f5f5;
    margin: 0px auto;
    padding: 20px 0 40px;
    position: relative;
}
.newsList_view .tableName {
    height: 50px;
    line-height: 50px;
    color: #000;
    text-align: center;
    font-size: 20px;
    border-bottom: 1px solid #b4dc9c;
    margin-bottom: 10px;
}
.newsList_view .tableName span{
}

.newsList_view .list {
    width: 100%;
    padding: 0 100px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}
.newsList_view .list .left{
    width: 280px;
    height: auto;
    background: var(--theme2);
    margin: 0px 30px 5px 0;
    padding: 20px;
  } 
  
.newsList_view .list  .left .item{
      width: 100%;  
}
.newsList_view .list  .left .item .title {
    width: 100%;
    font-size: 14px;
    color: #333;
    line-height: 36px;
    font-weight: 500;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}

.newsList_view .list .right{
    width: calc(100% + 20px);
    display: flex;
    flex: 1;
    margin: 0 0 0 -10px;
}
.newsList_view .list  .right .item{
      width: calc(33.33% - 20px);
      margin: 0 10px;
}
.newsList_view .list  .right .item img{
      width: 100%; 
      height: 320px;
      object-fit: cover;
      border-bottom: 5px solid #e0e0e0;
}

.newsList_view .more {
    width: 100%;
    display: none;
}
.newsList_view .more span{
    color: #b51022;
}
</style>