package com.cl.entity.view;

import com.cl.entity.FuwuxinxiEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.math.BigDecimal;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;

import java.io.Serializable;
import com.cl.utils.EncryptUtil;
 

/**
 * 服务信息
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 * @date 2026-03-27 11:34:07
 */
@TableName("fuwuxinxi")
public class FuwuxinxiView  extends FuwuxinxiEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public FuwuxinxiView(){
	}
 
 	public FuwuxinxiView(FuwuxinxiEntity fuwuxinxiEntity){
 	try {
			BeanUtils.copyProperties(this, fuwuxinxiEntity);
		} catch (BeansException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}



}
