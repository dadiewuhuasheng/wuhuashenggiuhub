import {
	createRouter,
	createWebHashHistory
} from 'vue-router'
import login from '@/views/login.vue'
import index from '@/views/index.vue'
import HomeView from '@/views/HomeView.vue'
export const routes = [{
		path: '/login',
		name: 'login',
        meta: { title: '登录' },
		component: login
	},{
		path: '/',
		name: '首页',
        meta: { title: '首页' },
		component: index,
		children: [{
			path: '/',
			name: 'home',
			component: HomeView,
			meta: {
				affix: true,
                title: '首页'
			}
		}, {
			path: '/updatepassword',
			name: 'updatepassword',
            meta: { title: '修改密码' },
			component: () => import('../views/updatepassword.vue')
		}

		,{
			path: '/usersCenter',
			name: 'usersCenter',
            meta: { title: '管理员个人中心' },
			component: ()=>import('@/views/users/center')
		}
		,{
			path: '/fuwurenyuanCenter',
			name: 'fuwurenyuanCenter',
            meta: { title: '家政人员个人中心' },
			component: ()=>import('@/views/fuwurenyuan/center')
		}
		,{
			path: '/news',
			name: 'news',
            meta: { title: '家政资讯' },
			component: ()=>import('@/views/news/list')
		}
		,{
			path: '/fuwudaka',
			name: 'fuwudaka',
            meta: { title: '服务打卡' },
			component: ()=>import('@/views/fuwudaka/list')
		}
		,{
			path: '/fuwuxinxi',
			name: 'fuwuxinxi',
            meta: { title: '服务信息' },
			component: ()=>import('@/views/fuwuxinxi/list')
		}
		,{
			path: '/syslog',
			name: 'syslog',
            meta: { title: '操作日志' },
			component: ()=>import('@/views/syslog/list')
		}
		,{
			path: '/storeup',
			name: 'storeup',
            meta: { title: '我的收藏' },
			component: ()=>import('@/views/storeup/list')
		}
        ,{
            path: '/menu',
            name: 'menu',
            meta: { title: '菜单权限管理' },
            component: ()=>import('@/views/menu_manage/list')
        }
		,{
			path: '/fuwupingjia',
			name: 'fuwupingjia',
            meta: { title: '服务评价' },
			component: ()=>import('@/views/fuwupingjia/list')
		}
		,{
			path: '/users',
			name: 'users',
            meta: { title: '管理员' },
			component: ()=>import('@/views/users/list')
		}
		,{
			path: '/fuwujilu',
			name: 'fuwujilu',
            meta: { title: '服务记录' },
			component: ()=>import('@/views/fuwujilu/list')
		}
		,{
			path: '/yonghu',
			name: 'yonghu',
            meta: { title: '用户' },
			component: ()=>import('@/views/yonghu/list')
		}
		,{
			path: '/fuwurenyuan',
			name: 'fuwurenyuan',
            meta: { title: '家政人员' },
			component: ()=>import('@/views/fuwurenyuan/list')
		}
		,{
			path: '/fuwuyuyue',
			name: 'fuwuyuyue',
            meta: { title: '服务预约' },
			component: ()=>import('@/views/fuwuyuyue/list')
		}
		,{
			path: '/config',
			name: 'config',
            meta: { title: '轮播图' },
			component: ()=>import('@/views/config/list')
		}
		,{
			path: '/fuwujiedan',
			name: 'fuwujiedan',
            meta: { title: '服务接单' },
			component: ()=>import('@/views/fuwujiedan/list')
		}
		]
	},
	{
		path: '/fuwurenyuanRegister',
		name: 'fuwurenyuanRegister',
        meta: { title: '家政人员注册' },
		component: ()=>import('@/views/fuwurenyuan/register')
	},
]

const router = createRouter({
	history: createWebHashHistory(process.env.BASE_URL),
	routes
})

export default router
