<template>
	<div class="edit_view">
        <div class="breadcrumb-wrapper" style="width: 100%;">
            <div class="bread_view">
                <el-breadcrumb separator="Ξ" class="breadcrumb">
                    <el-breadcrumb-item class="first_breadcrumb" :to="{ path: '/' }">首页</el-breadcrumb-item>
                    <el-breadcrumb-item class="second_breadcrumb" v-for="(item,index) in breadList" :key="index">{{item.name}}</el-breadcrumb-item>
                </el-breadcrumb>
            </div>
        </div>
		<el-form ref="formRef" :model="form" class="add_form" label-width="120px" :rules="rules">
			<el-row>
				<el-col :span="12">
					<el-form-item label="预约日期" prop="yuyueriqi">
						<el-date-picker
							class="list_date"
							v-model="form.yuyueriqi"
							format="YYYY 年 MM 月 DD 日"
							value-format="YYYY-MM-DD"
							type="datetime"
							:readonly="!isAdd||disabledForm.yuyueriqi?true:false"
							placeholder="请选择预约日期"
							style="width: 100%;" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="预约时间段" prop="yuyueshijianduan">
						<el-input class="list_inp"
                                  v-model="form.yuyueshijianduan"
                                  placeholder="预约时间段"
                                  type="text"
							      :readonly="!isAdd||disabledForm.yuyueshijianduan?true:false" />
					</el-form-item>
				</el-col>

				<el-col :span="12">
					<el-form-item label="预约时间" prop="yuyueshijian">
						<el-date-picker
							class="list_date"
							v-model="form.yuyueshijian"
							format="YYYY-MM-DD HH:mm:ss"
							value-format="YYYY-MM-DD HH:mm:ss"
							type="datetime"
							style="width:100%;"
							:readonly="!isAdd||disabledForm.yuyueshijian?true:false"
							placeholder="请选择预约时间" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="账号" prop="zhanghao">
						<el-input class="list_inp"
                                  v-model="form.zhanghao"
                                  placeholder="账号"
                                  type="text"
							      :readonly="!isAdd||disabledForm.zhanghao?true:false" />
					</el-form-item>
				</el-col>

				<el-col :span="12">
					<el-form-item label="用户姓名" prop="yonghuxingming">
						<el-input class="list_inp"
                                  v-model="form.yonghuxingming"
                                  placeholder="用户姓名"
                                  type="text"
							      :readonly="!isAdd||disabledForm.yonghuxingming?true:false" />
					</el-form-item>
				</el-col>

				<el-col :span="12">
					<el-form-item label="服务地点" prop="fuwudidian">
						<el-input class="list_inp"
                                  v-model="form.fuwudidian"
                                  placeholder="服务地点"
                                  type="text"
							      :readonly="!isAdd||disabledForm.fuwudidian?true:false" />
					</el-form-item>
				</el-col>

				<el-col :span="12">
					<el-form-item label="服务项目" prop="fuwuxiangmu">
						<el-input class="list_inp"
                                  v-model="form.fuwuxiangmu"
                                  placeholder="服务项目"
                                  type="text"
							      :readonly="!isAdd||disabledForm.fuwuxiangmu?true:false" />
					</el-form-item>
				</el-col>

				<el-col :span="12">
					<el-form-item label="服务价格" prop="fuwujiage">
						<el-input class="list_inp"
                                  v-model="form.fuwujiage"
                                  placeholder="服务价格"
                                  type="text"
							      :readonly="!isAdd||disabledForm.fuwujiage?true:false" />
					</el-form-item>
				</el-col>

				<el-col :span="12">
					<el-form-item label="服务描述" prop="fuwumiaoshu">
						<el-input class="list_inp"
                                  v-model="form.fuwumiaoshu"
                                  placeholder="服务描述"
                                  type="text"
							      :readonly="!isAdd||disabledForm.fuwumiaoshu?true:false" />
					</el-form-item>
				</el-col>

				<el-col :span="12">
					<el-form-item label="人员账号" prop="renyuanzhanghao">
						<el-input class="list_inp"
                                  v-model="form.renyuanzhanghao"
                                  placeholder="人员账号"
                                  type="text"
							      :readonly="!isAdd||disabledForm.renyuanzhanghao?true:false" />
					</el-form-item>
				</el-col>

				<el-col :span="12">
					<el-form-item label="人员姓名" prop="renyuanxingming">
						<el-input class="list_inp"
                                  v-model="form.renyuanxingming"
                                  placeholder="人员姓名"
                                  type="text"
							      :readonly="!isAdd||disabledForm.renyuanxingming?true:false" />
					</el-form-item>
				</el-col>

				<el-col :span="12">
					<el-form-item label="接单时间" prop="jiedanshijian">
						<el-date-picker
							class="list_date"
							v-model="form.jiedanshijian"
							format="YYYY-MM-DD HH:mm:ss"
							value-format="YYYY-MM-DD HH:mm:ss"
							type="datetime"
							style="width:100%;"
							:readonly="!isAdd||disabledForm.jiedanshijian?true:false"
							placeholder="请选择接单时间" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="服务状态" prop="fuwuzhuangtai">
						<el-select
							class="list_sel"
							:disabled="!isAdd||disabledForm.fuwuzhuangtai?true:false"
							v-model="form.fuwuzhuangtai" 
							placeholder="请选择服务状态"
							style="width:100%;"
							>
							<el-option v-for="(item,index) in fuwuzhuangtaiLists" :label="item"
								:value="item"
								>
							</el-option>
						</el-select>
					</el-form-item>
				</el-col>
			</el-row>
			<div class="formModel_btn_box">
				<el-button class="formModel_cancel" @click="backClick">取消</el-button>
				<el-button class="formModel_confirm"
                           @click="save"
                           type="success"
				>
					保存
				</el-button>
			</div>
		</el-form>
	</div>
</template>
<script setup>
	import {
		ref,
		getCurrentInstance,
		watch,
		onUnmounted,
		onMounted,
		nextTick,
		computed
	} from 'vue';
	import {
		useRoute,
		useRouter
	} from 'vue-router';
    import {
        useStore
    } from 'vuex';
    const store = useStore()
    const user = computed(()=>store.getters['user/session'])
    const moment = window.moment
	const context = getCurrentInstance()?.appContext.config.globalProperties;
	const route = useRoute()
	const router = useRouter()
	//基础信息
	const tableName = 'fuwujiedan'
	const formName = '服务接单'
	//基础信息
	const breadList = ref([{
		name: formName
	}])
	//获取唯一标识
	const getUUID =()=> {
      return new Date().getTime();
    }
	//form表单
	const form = ref({
		yuyueriqi: '',
		yuyueshijianduan: '',
		yuyueshijian: '',
		zhanghao: '',
		yonghuxingming: '',
		fuwudidian: '',
		fuwuxiangmu: '',
		fuwujiage: '',
		fuwumiaoshu: '',
		renyuanzhanghao: '',
		renyuanxingming: '',
		jiedanshijian: '',
		fuwuzhuangtai: '未开始',
	})
	const formRef = ref(null)
	const id = ref(0)
	const type = ref('')
	const disabledForm = ref({
		yuyueriqi : false,
		yuyueshijianduan : false,
		yuyueshijian : false,
		zhanghao : false,
		yonghuxingming : false,
		fuwudidian : false,
		fuwuxiangmu : false,
		fuwujiage : false,
		fuwumiaoshu : false,
		renyuanzhanghao : false,
		renyuanxingming : false,
		jiedanshijian : false,
		fuwuzhuangtai : false,
	})
	const isAdd = ref(false)
	//表单验证
	const rules = ref({
		yuyueriqi: [
		],
		yuyueshijianduan: [
		],
		yuyueshijian: [
		],
		zhanghao: [
		],
		yonghuxingming: [
		],
		fuwudidian: [
			{required: true,message: '请输入',trigger: 'blur'}, 
		],
		fuwuxiangmu: [
		],
		fuwujiage: [
		],
		fuwumiaoshu: [
		],
		renyuanzhanghao: [
		],
		renyuanxingming: [
		],
		jiedanshijian: [
		],
		fuwuzhuangtai: [
		],
	})
	//服务状态列表
	const fuwuzhuangtaiLists = ref([])
	//获取info
	const getInfo = ()=>{
		context?.$http({
			url: `${tableName}/info/${id.value}`,
			method: 'get'
		}).then(res => {
			let reg=new RegExp('../../../file','g')
			form.value = res.data.data
		})
	}
	const crossRow = ref('')
	const crossTable = ref('')
	const crossTips = ref('')
	const crossColumnName = ref('')
	const crossColumnValue = ref('')
	//初始化
	const init = (formId=null,formType='add',formNames='',row=null,table=null,statusColumnName=null,tips=null,statusColumnValue=null) => {
        form.value.yuyueshijian = context?.$toolUtil.getCurDateTime()
        form.value.jiedanshijian = context?.$toolUtil.getCurDateTime()
		if(formId){
			id.value = formId
			type.value = formType
		}
		if(formType == 'add'){
			isAdd.value = true
		}else if(formType == 'info'){
			isAdd.value = false
			getInfo()
		}else if(formType == 'edit'){
			isAdd.value = true
			getInfo()
		}
		else if(formType == 'cross'){
			isAdd.value = true
			// getInfo()
			for(let x in row){
				if(x=='yuyueriqi'){
					form.value.yuyueriqi = row[x];
					disabledForm.value.yuyueriqi = true;
					continue;
				}
				if(x=='yuyueshijianduan'){
					form.value.yuyueshijianduan = row[x];
					disabledForm.value.yuyueshijianduan = true;
					continue;
				}
				if(x=='yuyueshijian'){
					form.value.yuyueshijian = row[x];
					disabledForm.value.yuyueshijian = true;
					continue;
				}
				if(x=='zhanghao'){
					form.value.zhanghao = row[x];
					disabledForm.value.zhanghao = true;
					continue;
				}
				if(x=='yonghuxingming'){
					form.value.yonghuxingming = row[x];
					disabledForm.value.yonghuxingming = true;
					continue;
				}
				if(x=='fuwudidian'){
					form.value.fuwudidian = row[x];
					disabledForm.value.fuwudidian = true;
					continue;
				}
				if(x=='fuwuxiangmu'){
					form.value.fuwuxiangmu = row[x];
					disabledForm.value.fuwuxiangmu = true;
					continue;
				}
				if(x=='fuwujiage'){
					form.value.fuwujiage = row[x];
					disabledForm.value.fuwujiage = true;
					continue;
				}
				if(x=='fuwumiaoshu'){
					form.value.fuwumiaoshu = row[x];
					disabledForm.value.fuwumiaoshu = true;
					continue;
				}
				if(x=='renyuanzhanghao'){
					form.value.renyuanzhanghao = row[x];
					disabledForm.value.renyuanzhanghao = true;
					continue;
				}
				if(x=='renyuanxingming'){
					form.value.renyuanxingming = row[x];
					disabledForm.value.renyuanxingming = true;
					continue;
				}
				if(x=='jiedanshijian'){
					form.value.jiedanshijian = row[x];
					disabledForm.value.jiedanshijian = true;
					continue;
				}
				if(x=='fuwuzhuangtai'){
					form.value.fuwuzhuangtai = row[x];
					disabledForm.value.fuwuzhuangtai = true;
					continue;
				}
			}
			if(row){
				crossRow.value = row
			}
			if(table){
				crossTable.value = table
			}
			if(tips){
				crossTips.value = tips
			}
			if(statusColumnName){
				crossColumnName.value = statusColumnName
			}
			if(statusColumnValue){
				crossColumnValue.value = statusColumnValue
			}
			form.value.fuwuzhuangtai='未开始'
		}
		context?.$http({
			url: `${context?.$toolUtil.storageGet('frontSessionTable')}/session`,
			method: 'get'
		}).then(res => {
			var json = res.data.data
			if(json.hasOwnProperty('zhanghao') && context?.$toolUtil.storageGet("frontSessionTable")!="users"){
				form.value.zhanghao = json.zhanghao
				disabledForm.value.zhanghao = true;
			}
			if(json.hasOwnProperty('yonghuxingming') && context?.$toolUtil.storageGet("frontSessionTable")!="users"){
				form.value.yonghuxingming = json.yonghuxingming
				disabledForm.value.yonghuxingming = true;
			}
			if(json.hasOwnProperty('renyuanzhanghao') && context?.$toolUtil.storageGet("frontSessionTable")!="users"){
				form.value.renyuanzhanghao = json.renyuanzhanghao
				disabledForm.value.renyuanzhanghao = true;
			}
			if(json.hasOwnProperty('renyuanxingming') && context?.$toolUtil.storageGet("frontSessionTable")!="users"){
				form.value.renyuanxingming = json.renyuanxingming
				disabledForm.value.renyuanxingming = true;
			}
			if(context?.$toolUtil.storageGet("frontSessionTable")!="users") {
				disabledForm.value.fuwuzhuangtai = true;
			}
            if (localStorage.getItem('autoSave')) {
                localStorage.removeItem('autoSave')
                save()
            }
		})
		fuwuzhuangtaiLists.value = "进行中,未开始".split(',')
	}
	//初始化
	//取消
	const backClick = () => {
		history.back()
	}
	//提交
	const save=()=>{
		var table = crossTable.value
		var objcross = JSON.parse(JSON.stringify(crossRow.value))
		let crossUserId = ''
		let crossRefId = ''
		let crossOptNum = ''
		formRef.value.validate(async (valid)=>{
			if(valid){
                if(type.value == 'cross'){
                    if(crossColumnName.value!=''){
                        if(!crossColumnName.value.startsWith('[')){
                            for(let o in objcross){
                                if(o == crossColumnName.value){
                                    objcross[o] = crossColumnValue.value
                                }
                            }
                            //修改跨表数据
                            await changeCrossData(objcross)
                        }else{
                            crossUserId = context?.$toolUtil.storageGet('userid')
                            crossRefId = objcross['id']
                            crossOptNum = crossColumnName.value.replace(/\[/,"").replace(/\]/,"")
                        }
                    }
                }
				if(crossUserId&&crossRefId){    //限制用户操作次数
					form.value.crossuserid = crossUserId
					form.value.crossrefid = crossRefId
					let params = {
						page: 1,
						limit: 1000, 
						crossuserid:form.value.crossuserid,
						crossrefid:form.value.crossrefid,
					}
					context?.$http({
						url: `${tableName}/page`,
						method: 'get', 
						params: params 
					}).then(async (res)=>{
						if(res.data.data.total>=crossOptNum){
							context?.$toolUtil.message(`${crossTips.value}`,'error')
							return false
						}else{
							context?.$http({
								url: `${tableName}/${!form.value.id ? "save" : "update"}`,
								method: 'post', 
								data: form.value 
							}).then(async (res)=>{
                                context?.$toolUtil.message(`操作成功`,'success')
                                history.back()
							})
						}
					})
				}else{
					context?.$http({
						url: `${tableName}/${!form.value.id ? "save" : "update"}`,
						method: 'post', 
						data: form.value 
					}).then(async (res)=>{
                        context?.$toolUtil.message(`操作成功`,'success')
                        history.back()
					})
				}
			}
		})
	}
	//修改跨表数据
	const changeCrossData=(row,key)=>{
        if(type.value == 'cross'){
            let data = row
            if(key){	//如果有指定key，则只更新key属性
                data = {
                    id:row.id,
                }
                data[key] = row[key]
            }
            context?.$http({
                url: `${crossTable.value}/update`,
                method: 'post',
                data: data
            }).then(res=>{})
        }
	}
	onMounted(()=>{
		type.value = route.query.type?route.query.type:'add'
		let row = null
		let table = null
		let statusColumnName = null
		let tips = null
		let statusColumnValue = null
		if(type.value == 'cross'){
			row = context?.$toolUtil.storageGet('crossObj')?JSON.parse(context?.$toolUtil.storageGet('crossObj')):{}
			table = context?.$toolUtil.storageGet('crossTable')
			statusColumnName = context?.$toolUtil.storageGet('crossStatusColumnName')
			tips = context?.$toolUtil.storageGet('crossTips')
			statusColumnValue = context?.$toolUtil.storageGet('crossStatusColumnValue')
		}
		init(route.query.id?route.query.id:null, type.value,'', row, table, statusColumnName, tips, statusColumnValue)
	})
    onUnmounted(()=>{
        Object.keys(localStorage).map(item=>{
            if(item.startsWith('cross')){
                localStorage.removeItem(item)
            }
        })
    })
</script>
<style lang="scss" scoped>
</style>
<style lang="scss">
.edit_view {
    width: 100%;
    padding: 0 7%;
    margin: 0 auto;
    position: relative;
    font-size:16px;
    color:#666;
}
.edit_view .add_form{
    width: 100%;
    margin: 30px auto;
    background: #f8f8f8;
    padding: 50px 100px;
    border:0px solid #eee;
    border-radius: 12px;
}
.edit_view .add_form .el-form-item{
    margin: 0px 0px 20px;
    display: flex;
}
.edit_view .add_form .el-form-item .el-form-item__label{
    width: 150px;
    background: none;
    text-align: right;
    display: block;
    font-size: 16px;
    color: rgb(51, 51, 51);
    font-weight: 500;
}
.edit_view .add_form .el-form-item .el-form-item__content{
    display: flex;
    justify-content: flex-start;
    align-items: center;
    flex-wrap: wrap;
    width: calc(100% - 120px);
}
.edit_view .list_inp .el-input__wrapper{
    height: 36px;
}

.edit_view .add_form .el-form-item .el-form-item__content .list_sel{
    line-height: 36px;
    
    box-sizing: border-box;
    width: calc(100% - 120px);
    padding: 0px;
    border-radius: 0px;
    background: rgb(255, 255, 255);
    font-size: 16px;
}

.edit_view .list_date{
    line-height: 36px;
}








</style>