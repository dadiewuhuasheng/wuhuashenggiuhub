<template>
	<div class="register_view">
<div class="form" style="z-index: 1;">
    <div class="projectName">{{projectName}}注册</div>
			<div class="register_form">
				<div class="list_item">
					<div class="list_label">人员账号：</div>
					<el-input class="list_inp"
						 v-model="registerForm.renyuanzhanghao"
						 placeholder="请输入人员账号"
						 type="text"
						/>
				</div>
				<div class="list_item">
					<div class="list_label">密码：</div>
					<el-input class="list_inp"
						 v-model="registerForm.mima"
						 placeholder="请输入密码"
						 type="password"
					     show-password
						 />
				</div>
				<div class="list_item">
					<div class="list_label">确认密码：</div>
					<el-input class="list_inp" v-model="registerForm.mima2" type="password" placeholder="请输入确认密码" show-password />
				</div>
				<div class="list_item">
					<div class="list_label">人员姓名：</div>
					<el-input class="list_inp"
						 v-model="registerForm.renyuanxingming"
						 placeholder="请输入人员姓名"
						 type="text"
						/>
				</div>
				<div class="list_item">
					<div class="list_label">年龄：</div>
					<el-input class="list_inp"
						 v-model="registerForm.nianling"
						 placeholder="请输入年龄"
						 type="text"
						/>
				</div>
				<div class="list_item">
					<div class="list_label">性别：</div>
					<el-select
						class="list_sel"
						v-model="registerForm.xingbie"
						placeholder="请选择性别"
						>
						<el-option v-for="item in fuwurenyuanxingbieLists" :label="item" :value="item"></el-option>
					</el-select>
				</div>
				<div class="list_item">
					<div class="list_label">联系电话：</div>
					<el-input class="list_inp"
						 v-model="registerForm.lianxidianhua"
						 placeholder="请输入联系电话"
						 type="text"
						/>
				</div>
				<div class="list_item">
					<div class="list_label">资质证明：</div>
					<div class="list_file_list">
						<uploads
							type="file"
							action="file/upload"
							tip="请上传资质证明"
							:limit="3"
							:fileUrls="registerForm.zizhizhengming?registerForm.zizhizhengming:''"
							@change="zizhizhengmingUploadSuccess">
						</uploads>
					</div>
				</div>
				<div class="list_item">
					<div class="list_label">头像：</div>
					<div class="list_file_list">
						<uploads
							action="file/upload"
							tip="请上传头像"
							:fileUrls="registerForm.touxiang?registerForm.touxiang:''"
							@change="touxiangUploadSuccess">
						</uploads>
					</div>
				</div>
			</div>

    <div class="back" @click="close">已有账号，直接登录</div>
    <el-button class="register" @click="handleRegister">注册</el-button>
</div>
	</div>
</template>
<script setup>
	import {
		ref,
		getCurrentInstance,
		nextTick,
		onMounted,
	} from 'vue';
	const context = getCurrentInstance()?.appContext.config.globalProperties;
	const projectName = context.$project.projectName
	//获取注册类型
	import { useRoute } from 'vue-router';
	const route = useRoute()
	const tableName = ref('fuwurenyuan')
	
	//公共方法
	const getUUID=()=> {
		return new Date().getTime();
	}
	const registerForm = ref({
        xingbie: '',
	})
	const fuwurenyuanxingbieLists = ref([])
	const init=()=>{
		fuwurenyuanxingbieLists.value = "男,女".split(',')
	}
    const zizhizhengmingUploadSuccess=(fileUrls)=> {
        registerForm.value.zizhizhengming = fileUrls;
    }
    const touxiangUploadSuccess=(fileUrls)=> {
        registerForm.value.touxiang = fileUrls;
    }

	//注册按钮
	const handleRegister = () => {
		let url = tableName.value +"/register";
		if((!registerForm.value.renyuanzhanghao)){
			context?.$toolUtil.message(`人员账号不能为空`,'error')
			return false
		}
		if((!registerForm.value.mima)){
			context?.$toolUtil.message(`密码不能为空`,'error')
			return false
		}
		if(registerForm.value.mima!=registerForm.value.mima2){
			context?.$toolUtil.message('两次密码输入不一致','error')
			return false
		}
		if((!registerForm.value.renyuanxingming)){
			context?.$toolUtil.message(`人员姓名不能为空`,'error')
			return false
		}
		if(registerForm.value.nianling&&(!context?.$toolUtil.isIntNumer(registerForm.value.nianling))){
			context?.$toolUtil.message(`年龄应输入整数`,'error')
			return false
		}
		if(registerForm.value.lianxidianhua&&(!context?.$toolUtil.isMobile(registerForm.value.lianxidianhua))){
			context?.$toolUtil.message(`联系电话应输入手机格式`,'error')
			return false
		}
		if(registerForm.value.zizhizhengming!=null){
			registerForm.value.zizhizhengming = registerForm.value.zizhizhengming.replace(new RegExp(context?.$config.url,"g"),"");
		}
		if(registerForm.value.touxiang!=null){
			registerForm.value.touxiang = registerForm.value.touxiang.replace(new RegExp(context?.$config.url,"g"),"");
		}
		if(registerForm.value.maxPasswordWrong&&(!context?.$toolUtil.isIntNumer(registerForm.value.maxPasswordWrong))){
			context?.$toolUtil.message(`最大密码输错次数应输入整数`,'error')
			return false
		}
		if(registerForm.value.isLocked&&(!context?.$toolUtil.isIntNumer(registerForm.value.isLocked))){
			context?.$toolUtil.message(`用户锁定状态应输入整数`,'error')
			return false
		}
		context?.$http({
			url:url,
			method:'post',
			data:registerForm.value
		}).then(res=>{
			context?.$toolUtil.message('注册成功','success', obj=>{
				context?.$router.push({
					path: "/login"
				});
			})
		})
	}
	//返回登录
	const close = () => {
		context?.$router.push({
			path: "/login"
		});
	}
	init()
	onMounted(()=>{

	})
</script>
<style lang="scss">
	.register_view {
        background-image: url("http://clfile.zggen.cn/20251108/56b49386ef5147b9b1b7b45f64526eb5.webp")!important;
	}
.register_view {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    position: relative;
    overflow: hidden;
    background-size: 70vh 100vh;
    background-repeat: no-repeat;
    background-position: 10% 0;
    background-attachment: fixed;
}
.register_view .box {
    display: flex;
    width: 70vw;
    min-width: 1200px;
    height: auto;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    border-radius: 20px;
    overflow: hidden;
}

.register_view .form {
    text-align: center;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    position: relative;
    width: 600px;
    border-radius: 10px;
    align-items: flex-start;
    margin-right: 10%;
    margin-top: 50px;
    margin-bottom: 50px;
}

.register_view .projectName {
    font-size: 22px;
    font-weight: 700;
    width: 100%;
    text-align: center;
}
.register_view .logo {
    background-image: url(http://clfile.zggen.cn/20250817/c7f4917b88074efa96eed5ca0b734ac4.webp);
    background-size: 100% 100%;
    width: 50px;
    height: 50px;
    margin: 0 auto;
}

.register_view .circle1 {
    position: absolute;
    left: 100px;
    top: 100px;
    background: #daf4dc;
    width: 200px;
    height: 200px;
    border-radius: 50%;
    z-index: 1;
    animation: float 4s ease-in-out infinite;
}

.register_view .circle2 {
    position: absolute;
    right: 100px;
    bottom: 100px;
    background: #EBEFD9;
    width: 300px;
    height: 300px;
    border-radius: 50%;
    z-index: 0;
    animation: float 5s ease-in-out infinite;
}
.register_view .form-circle1 {
    position: absolute;
    right: -34px;
    top: -32px;
    background: #dff6e9;
    width: 140px;
    height: 140px;
    border-radius: 50%;
    z-index: -1;
}

.register_view .form-circle2 {
    position: absolute;
    left: -34px;
    bottom: -32px;
    background: #f7efeb;
    width: 140px;
    height: 140px;
    border-radius: 50%;
    z-index: -1;
}


.register_view .register_form {
    text-align: left;
    display: flex;
    flex-direction: column;
    gap: 20px;
    margin-top: 20px;
    padding: 10px 0;
}

.register_view .list_item {
    display: flex;
    align-items: center;
    color: #000;
    background: #fff;
    padding: 8px 10px;
    border-radius: 6px;
    border: 1px solid #ccc;
}

.register_view .list_label {
    min-width: 100px;
    text-align: center;
}

.register_view .list_code {
    display: flex;
}

.register_view .list_code_item {display: flex;gap: 20px;}

.register_view .register {
    background: var(--theme);
    border: none;
    color: #fff;
    width: 80%;
    margin-top: 10px;
    height: 40px;
    font-size: 18px;
    border-radius: 6px;
}

.register_view .back {
    color: var(--theme);
    border: none;
    background: #fff;
    width: 100%;
    margin-top: 10px;
    line-height: 40px;
    font-size: 18px;
    border-radius: 6px;
    
    cursor: pointer;
}

.register_view .img {
    background: url(http://clfile.zggen.cn/20250817/80398b9b44024bfc8516fe0de27cacf6.webp);
    height: 100%;
    background-size: contain;
    background-repeat: no-repeat;
    background-color: #ebead6;
    flex: 1;
}

.register_view .upload-demo {
    width: 400px;
}

.register_view .el-input__wrapper {
    border: none!important;
    box-shadow: none!important;
}

.register_view .el-select__wrapper {
    border: none;
    box-shadow: none!important;
}

</style>