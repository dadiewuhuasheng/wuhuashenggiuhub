<template>
	<div>
		<el-dialog modal-class="edit_form_modal" class="edit_form" v-model="formVisible" :title="formTitle" width="70%" destroy-on-close :fullscreen='false'>
			<el-form class="formModel_form" ref="formRef" :model="form" :rules="rules">
				<el-row >
					<el-col :span="12">
						<el-form-item label="服务项目" prop="fuwuxiangmu">
							<el-input class="list_inp" v-model="form.fuwuxiangmu" placeholder="服务项目"
                                type="text"
								:readonly="!isAdd||disabledForm.fuwuxiangmu?true:false" />
						</el-form-item>
					</el-col>

					<el-col :span="12">
						<el-form-item label="服务价格" prop="fuwujiage">
							<el-input class="list_inp" v-model.number="form.fuwujiage" placeholder="服务价格"
                                type="number"
                                @mousewheel.native.prevent
								:readonly="!isAdd||disabledForm.fuwujiage?true:false" />
						</el-form-item>
					</el-col>

					<el-col :span="12">
						<el-form-item label="服务描述" prop="fuwumiaoshu">
							<el-input class="list_inp" v-model="form.fuwumiaoshu" placeholder="服务描述"
                                type="text"
								:readonly="!isAdd||disabledForm.fuwumiaoshu?true:false" />
						</el-form-item>
					</el-col>

					<el-col :span="12">
						<el-form-item label="人员账号" prop="renyuanzhanghao">
							<el-input class="list_inp" v-model="form.renyuanzhanghao" placeholder="人员账号"
                                type="text"
								:readonly="!isAdd||disabledForm.renyuanzhanghao?true:false" />
						</el-form-item>
					</el-col>

					<el-col :span="12">
						<el-form-item label="人员姓名" prop="renyuanxingming">
							<el-input class="list_inp" v-model="form.renyuanxingming" placeholder="人员姓名"
                                type="text"
								:readonly="!isAdd||disabledForm.renyuanxingming?true:false" />
						</el-form-item>
					</el-col>

					<el-col :span="12">
						<el-form-item label="预约日期" prop="yuyueriqi">
							<el-date-picker
								class="list_date"
								v-model="form.yuyueriqi"
								format="YYYY 年 MM 月 DD 日"
								value-format="YYYY-MM-DD"
								type="date"
								:readonly="!isAdd||disabledForm.yuyueriqi?true:false"
								placeholder="请选择预约日期" />
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="预约时间段" prop="yuyueshijianduan">
							<el-input class="list_inp" v-model="form.yuyueshijianduan" placeholder="预约时间段"
                                type="text"
								:readonly="!isAdd||disabledForm.yuyueshijianduan?true:false" />
						</el-form-item>
					</el-col>

					<el-col :span="12">
						<el-form-item label="预约时间" prop="yuyueshijian">
							<el-date-picker
								class="list_date"
								v-model="form.yuyueshijian"
								format="YYYY-MM-DD HH:mm:ss"
								value-format="YYYY-MM-DD HH:mm:ss"
								type="datetime"
								:readonly="!isAdd||disabledForm.yuyueshijian?true:false"
								placeholder="请选择预约时间" />
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="账号" prop="zhanghao">
							<el-input class="list_inp" v-model="form.zhanghao" placeholder="账号"
                                type="text"
								:readonly="!isAdd||disabledForm.zhanghao?true:false" />
						</el-form-item>
					</el-col>

					<el-col :span="12">
						<el-form-item label="用户姓名" prop="yonghuxingming">
							<el-input class="list_inp" v-model="form.yonghuxingming" placeholder="用户姓名"
                                type="text"
								:readonly="!isAdd||disabledForm.yonghuxingming?true:false" />
						</el-form-item>
					</el-col>

					<el-col :span="12">
						<el-form-item label="服务地点" prop="fuwudidian">
							<el-input class="list_inp" v-model="form.fuwudidian" placeholder="服务地点"
                                type="text"
								:readonly="!isAdd||disabledForm.fuwudidian?true:false" />
						</el-form-item>
					</el-col>

					<el-col :span="12">
						<el-form-item label="完成时间" prop="wanchengshijian">
							<el-date-picker
								class="list_date"
								v-model="form.wanchengshijian"
								format="YYYY-MM-DD HH:mm:ss"
								value-format="YYYY-MM-DD HH:mm:ss"
								type="datetime"
								:readonly="!isAdd||disabledForm.wanchengshijian?true:false"
								placeholder="请选择完成时间" />
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="订单编号" prop="dingdanbianhao">
							<el-input class="list_inp" v-model="form.dingdanbianhao" placeholder="订单编号"
                                type="text"
								:readonly="!isAdd||disabledForm.dingdanbianhao?true:false" />
						</el-form-item>
					</el-col>

					<el-col :span="12">
						<el-form-item label="评价时间" prop="pingjiashijian">
							<el-date-picker
								class="list_date"
								v-model="form.pingjiashijian"
								format="YYYY-MM-DD HH:mm:ss"
								value-format="YYYY-MM-DD HH:mm:ss"
								type="datetime"
								:readonly="!isAdd||disabledForm.pingjiashijian?true:false"
								placeholder="请选择评价时间" />
						</el-form-item>
					</el-col>
					<el-col :span="24">
						<el-form-item label="评价内容" prop="pingjianeirong">
							<el-input v-model="form.pingjianeirong" placeholder="评价内容" type="textarea"
							:readonly="!isAdd||disabledForm.pingjianeirong?true:false"
							/>
						</el-form-item>
					</el-col>

				</el-row>
			</el-form>
			<template #footer v-if="isAdd||type=='logistics'||type=='reply'">
				<span class="formModel_btn_box">
					<el-button class="cancel_btn" @click="closeClick">取消</el-button>
					<el-button class="confirm_btn" type="primary" @click="save"
						>
						提交
					</el-button>
				</span>
			</template>
		</el-dialog>
	</div>
</template>
<script setup>
	import {
		reactive,
		ref,
		getCurrentInstance,
		nextTick,
		computed,
		defineEmits
	} from 'vue'
    import {
        useStore
    } from 'vuex';
	const moment = window.moment
    const store = useStore()
    const user = computed(()=>store.getters['user/session'])
	const context = getCurrentInstance()?.appContext.config.globalProperties;	
	const emit = defineEmits(['formModelChange'])
    const isAdmin = localStorage.getItem('isAdmin')||context.$toolUtil.storageGet("sessionTable")=='users'
	//基础信息
	const tableName = 'fuwupingjia'
	const formName = '服务评价'
	//基础信息
	//form表单
	const form = ref({})
	const disabledForm = ref({
        fuwuxiangmu : false,
        fuwujiage : false,
        fuwumiaoshu : false,
        renyuanzhanghao : false,
        renyuanxingming : false,
        yuyueriqi : false,
        yuyueshijianduan : false,
        yuyueshijian : false,
        zhanghao : false,
        yonghuxingming : false,
        fuwudidian : false,
        wanchengshijian : false,
        dingdanbianhao : false,
        pingjiashijian : false,
        pingjianeirong : false,
        sfsh : false,
        shhf : false,
        crossuserid : false,
        crossrefid : false,
	})
	const formVisible = ref(false)
	const isAdd = ref(false)
	const formTitle = ref('')
	const rules = ref({
		fuwuxiangmu: [
		],
		fuwujiage: [
			{ validator: context.$toolUtil.validator.number, trigger: 'blur' },
		],
		fuwumiaoshu: [
		],
		renyuanzhanghao: [
		],
		renyuanxingming: [
		],
		yuyueriqi: [
		],
		yuyueshijianduan: [
		],
		yuyueshijian: [
		],
		zhanghao: [
		],
		yonghuxingming: [
		],
		fuwudidian: [
		],
		wanchengshijian: [
		],
		dingdanbianhao: [
		],
		pingjiashijian: [
		],
		pingjianeirong: [
		],
		sfsh: [
		],
		shhf: [
		],
		crossuserid: [
		],
		crossrefid: [
		],
	})
	//表单验证
	
	const formRef = ref(null)
	const id = ref(0)
	const type = ref('')
	//获取唯一标识
	const getUUID =()=> {
      return new Date().getTime();
    }
	//重置
	const resetForm = () => {
		form.value = {
			fuwuxiangmu: '',
			fuwujiage: '',
			fuwumiaoshu: '',
			renyuanzhanghao: '',
			renyuanxingming: '',
			yuyueriqi: '',
			yuyueshijianduan: '',
			yuyueshijian: '',
			zhanghao: '',
			yonghuxingming: '',
			fuwudidian: '',
			wanchengshijian: '',
			dingdanbianhao: '',
			pingjiashijian: '',
			pingjianeirong: '',
			shhf: '',
			crossuserid: '',
			crossrefid: '',

		}
	}
	//获取info
	const getInfo = ()=>{
		context?.$http({
			url: `${tableName}/info/${id.value}`,
			method: 'get'
		}).then(res => {
			let reg=new RegExp('../../../file','g')
			form.value = res.data.data
			formVisible.value = true
		})
	}
	const crossRow = ref('')
	const crossTable = ref('')
	const crossTips = ref('')
	const crossColumnName = ref('')
	const crossColumnValue = ref('')
	//初始化
	const init=(formId=null,formType='add',formNames='',row=null,table=null,statusColumnName=null,tips=null,statusColumnValue=null)=>{
		resetForm()
			form.value.yuyueshijian = context?.$toolUtil.getCurDateTime()
			form.value.wanchengshijian = context?.$toolUtil.getCurDateTime()
			form.value.pingjiashijian = context?.$toolUtil.getCurDateTime()
		if(formId){
			id.value = formId
			type.value = formType
		}
		if(formType == 'add'){
			isAdd.value = true
			formTitle.value = '新增' + formName
			formVisible.value = true
		}else if(formType == 'info'){
			isAdd.value = false
			formTitle.value = '查看' + formName
			getInfo()
		}else if(formType == 'edit'){
			isAdd.value = true
			formTitle.value = '修改' + formName
			getInfo()
		}
		else if(formType == 'cross'){
			isAdd.value = true
			formTitle.value = formNames
			// getInfo()
			for(let x in row){
				if(x=='fuwuxiangmu'){
					form.value.fuwuxiangmu = row[x];
					disabledForm.value.fuwuxiangmu = true;
					continue;
				}
				if(x=='fuwujiage'){
					form.value.fuwujiage = row[x];
					disabledForm.value.fuwujiage = true;
					continue;
				}
				if(x=='fuwumiaoshu'){
					form.value.fuwumiaoshu = row[x];
					disabledForm.value.fuwumiaoshu = true;
					continue;
				}
				if(x=='renyuanzhanghao'){
					form.value.renyuanzhanghao = row[x];
					disabledForm.value.renyuanzhanghao = true;
					continue;
				}
				if(x=='renyuanxingming'){
					form.value.renyuanxingming = row[x];
					disabledForm.value.renyuanxingming = true;
					continue;
				}
				if(x=='yuyueriqi'){
					form.value.yuyueriqi = row[x];
					disabledForm.value.yuyueriqi = true;
					continue;
				}
				if(x=='yuyueshijianduan'){
					form.value.yuyueshijianduan = row[x];
					disabledForm.value.yuyueshijianduan = true;
					continue;
				}
				if(x=='yuyueshijian'){
					form.value.yuyueshijian = row[x];
					disabledForm.value.yuyueshijian = true;
					continue;
				}
				if(x=='zhanghao'){
					form.value.zhanghao = row[x];
					disabledForm.value.zhanghao = true;
					continue;
				}
				if(x=='yonghuxingming'){
					form.value.yonghuxingming = row[x];
					disabledForm.value.yonghuxingming = true;
					continue;
				}
				if(x=='fuwudidian'){
					form.value.fuwudidian = row[x];
					disabledForm.value.fuwudidian = true;
					continue;
				}
				if(x=='wanchengshijian'){
					form.value.wanchengshijian = row[x];
					disabledForm.value.wanchengshijian = true;
					continue;
				}
				if(x=='dingdanbianhao'){
					form.value.dingdanbianhao = row[x];
					disabledForm.value.dingdanbianhao = true;
					continue;
				}
				if(x=='pingjiashijian'){
					form.value.pingjiashijian = row[x];
					disabledForm.value.pingjiashijian = true;
					continue;
				}
				if(x=='pingjianeirong'){
					form.value.pingjianeirong = row[x];
					disabledForm.value.pingjianeirong = true;
					continue;
				}
				if(x=='crossuserid'){
					form.value.crossuserid = row[x];
					disabledForm.value.crossuserid = true;
					continue;
				}
				if(x=='crossrefid'){
					form.value.crossrefid = row[x];
					disabledForm.value.crossrefid = true;
					continue;
				}
			}
			if(row){
				crossRow.value = row
			}
			if(table){
				crossTable.value = table
			}
			if(tips){
				crossTips.value = tips
			}
			if(statusColumnName){
				crossColumnName.value = statusColumnName
			}
			if(statusColumnValue){
				crossColumnValue.value = statusColumnValue
			}
			formVisible.value = true
		}
		context?.$http({
			url: `${context?.$toolUtil.storageGet('sessionTable')}/session`,
			method: 'get'
		}).then(res => {
			var json = res.data.data
			if(json.hasOwnProperty('renyuanzhanghao')&& context?.$toolUtil.storageGet("sessionTable")!="users"){
				form.value.renyuanzhanghao = json.renyuanzhanghao
				disabledForm.value.renyuanzhanghao = true;
			}
			if(json.hasOwnProperty('renyuanxingming')&& context?.$toolUtil.storageGet("sessionTable")!="users"){
				form.value.renyuanxingming = json.renyuanxingming
				disabledForm.value.renyuanxingming = true;
			}
			if(json.hasOwnProperty('zhanghao')&& context?.$toolUtil.storageGet("sessionTable")!="users"){
				form.value.zhanghao = json.zhanghao
				disabledForm.value.zhanghao = true;
			}
			if(json.hasOwnProperty('yonghuxingming')&& context?.$toolUtil.storageGet("sessionTable")!="users"){
				form.value.yonghuxingming = json.yonghuxingming
				disabledForm.value.yonghuxingming = true;
			}
			if(json.hasOwnProperty('fuwudidian')&& context?.$toolUtil.storageGet("sessionTable")!="users"){
				form.value.fuwudidian = json.fuwudidian
				disabledForm.value.fuwudidian = true;
			}
		})
	}
	//初始化
	//声明父级调用
	defineExpose({
		init
	})
	//关闭
	const closeClick = () => {
		formVisible.value = false
	}
	//富文本
	const editorChange = (e,name) =>{
		form.value[name] = e
	}
	//提交
	const save= async ()=>{
		var table = crossTable.value
		var objcross = JSON.parse(JSON.stringify(crossRow.value))
		let crossUserId = ''
		let crossRefId = ''
		let crossOptNum = ''
		formRef.value.validate(async (valid)=>{
			if(valid){
				if(type.value == 'cross'){
					if(crossColumnName.value!=''){
						if(!crossColumnName.value.startsWith('[')){
							for(let o in objcross){
								if(o == crossColumnName.value){
									objcross[o] = crossColumnValue.value
								}
							}
							//修改跨表数据
							await changeCrossData(objcross)
						}else{
							crossUserId = user.value.id
							crossRefId = objcross['id']
							crossOptNum = crossColumnName.value.replace(/\[/,"").replace(/\]/,"")
						}
					}
				}
				if(crossUserId&&crossRefId){
					form.value.crossuserid = crossUserId
					form.value.crossrefid = crossRefId
					let params = {
						page: 1,
						limit: 1000, 
						crossuserid:form.value.crossuserid,
						crossrefid:form.value.crossrefid,
					}
					context?.$http({
						url: `${tableName}/page`,
						method: 'get', 
						params: params 
					}).then(async (res)=>{
						if(res.data.data.total>=crossOptNum){
							context?.$toolUtil.message(`${crossTips.value}`,'error')
							return false
						}else{
							context?.$http({
								url: `${tableName}/${!form.value.id ? "save" : "update"}`,
								method: 'post', 
								data: form.value 
							}).then(async res=>{
								emit('formModelChange')
								context?.$toolUtil.message(`操作成功`,'success')
                                formVisible.value = false
							})
						}
					})
				}else{
					context?.$http({
						url: `${tableName}/${!form.value.id ? "save" : "update"}`,
						method: 'post', 
						data: form.value 
					}).then(async (res)=>{
						emit('formModelChange')
						context?.$toolUtil.message(`操作成功`,'success')
                        formVisible.value = false
					})
				}
			}else{
                context.$message.error('请完善信息')
            }
		})
	}
	//修改跨表数据
	const changeCrossData = async (row,key)=>{
        if(type.value == 'cross'){
			let data = row
			if(key){	//如果有指定key，则只更新key属性
				data = {
					id:row.id,
				}
				data[key] = row[key]
			}
            await context?.$http({
                url: `${crossTable.value}/update`,
                method: 'post',
                data: data
            }).then(res=>{})
        }
	}
</script>
<style lang="scss" scoped>
</style>
