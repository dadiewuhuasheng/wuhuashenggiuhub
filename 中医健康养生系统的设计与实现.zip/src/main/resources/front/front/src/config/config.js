export default {
    baseUrl: 'http://localhost:8080/springboot5m6unc96/',
	name: '/springboot5m6unc96',
    indexNav: [
        {
            name: '养生知识',
            url: '/index/yangshengzhishi'
        },
        {
            name: '中药药材',
            url: '/index/zhongyaoyaocai'
        },
        {
            name: '养生互动',
            url: '/index/forum'
        }, 
        {
            name: '公告信息',
            url: '/index/news'
        },
    ]
}
