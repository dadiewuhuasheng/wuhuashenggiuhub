import VueRouter from 'vue-router'

//引入组件
import Index from '../pages'
import Home from '../pages/home/home'
import Login from '../pages/login/login'
import Register from '../pages/register/register'
import Center from '../pages/center/center'
import Forum from '../pages/forum/list'
import ForumAdd from '../pages/forum/add'
import ForumDetail from '../pages/forum/detail'
import MyForumList from '../pages/forum/myForumList'
import Storeup from '../pages/storeup/list'
import News from '../pages/news/news-list'
import NewsDetail from '../pages/news/news-detail'
import payList from '../pages/pay'

import yonghuList from '../pages/yonghu/list'
import yonghuDetail from '../pages/yonghu/detail'
import yonghuAdd from '../pages/yonghu/add'
import yangshengzhishiList from '../pages/yangshengzhishi/list'
import yangshengzhishiDetail from '../pages/yangshengzhishi/detail'
import yangshengzhishiAdd from '../pages/yangshengzhishi/add'
import zhishifenleiList from '../pages/zhishifenlei/list'
import zhishifenleiDetail from '../pages/zhishifenlei/detail'
import zhishifenleiAdd from '../pages/zhishifenlei/add'
import zhongyaoyaocaiList from '../pages/zhongyaoyaocai/list'
import zhongyaoyaocaiDetail from '../pages/zhongyaoyaocai/detail'
import zhongyaoyaocaiAdd from '../pages/zhongyaoyaocai/add'
import yaocaileibieList from '../pages/yaocaileibie/list'
import yaocaileibieDetail from '../pages/yaocaileibie/detail'
import yaocaileibieAdd from '../pages/yaocaileibie/add'
import jiankangdanganList from '../pages/jiankangdangan/list'
import jiankangdanganDetail from '../pages/jiankangdangan/detail'
import jiankangdanganAdd from '../pages/jiankangdangan/add'
import jiankangfenxiList from '../pages/jiankangfenxi/list'
import jiankangfenxiDetail from '../pages/jiankangfenxi/detail'
import jiankangfenxiAdd from '../pages/jiankangfenxi/add'
import yangshengfanganList from '../pages/yangshengfangan/list'
import yangshengfanganDetail from '../pages/yangshengfangan/detail'
import yangshengfanganAdd from '../pages/yangshengfangan/add'
import newstypeList from '../pages/newstype/list'
import newstypeDetail from '../pages/newstype/detail'
import newstypeAdd from '../pages/newstype/add'
import discussyangshengzhishiList from '../pages/discussyangshengzhishi/list'
import discussyangshengzhishiDetail from '../pages/discussyangshengzhishi/detail'
import discussyangshengzhishiAdd from '../pages/discussyangshengzhishi/add'
import discusszhongyaoyaocaiList from '../pages/discusszhongyaoyaocai/list'
import discusszhongyaoyaocaiDetail from '../pages/discusszhongyaoyaocai/detail'
import discusszhongyaoyaocaiAdd from '../pages/discusszhongyaoyaocai/add'

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
	return originalPush.call(this, location).catch(err => err)
}

//配置路由
export default new VueRouter({
	routes:[
		{
      path: '/',
      redirect: '/index/home'
    },
		{
			path: '/index',
			component: Index,
			children:[
				{
					path: 'home',
					component: Home
				},
				{
					path: 'center',
					component: Center,
				},
				{
					path: 'pay',
					component: payList,
				},
				{
					path: 'forum',
					component: Forum
				},
				{
					path: 'forumAdd',
					component: ForumAdd
				},
				{
					path: 'forumDetail',
					component: ForumDetail
				},
				{
					path: 'myForumList',
					component: MyForumList
				},
				{
					path: 'storeup',
					component: Storeup
				},
				{
					path: 'news',
					component: News
				},
				{
					path: 'newsDetail',
					component: NewsDetail
				},
				{
					path: 'yonghu',
					component: yonghuList
				},
				{
					path: 'yonghuDetail',
					component: yonghuDetail
				},
				{
					path: 'yonghuAdd',
					component: yonghuAdd
				},
				{
					path: 'yangshengzhishi',
					component: yangshengzhishiList
				},
				{
					path: 'yangshengzhishiDetail',
					component: yangshengzhishiDetail
				},
				{
					path: 'yangshengzhishiAdd',
					component: yangshengzhishiAdd
				},
				{
					path: 'zhishifenlei',
					component: zhishifenleiList
				},
				{
					path: 'zhishifenleiDetail',
					component: zhishifenleiDetail
				},
				{
					path: 'zhishifenleiAdd',
					component: zhishifenleiAdd
				},
				{
					path: 'zhongyaoyaocai',
					component: zhongyaoyaocaiList
				},
				{
					path: 'zhongyaoyaocaiDetail',
					component: zhongyaoyaocaiDetail
				},
				{
					path: 'zhongyaoyaocaiAdd',
					component: zhongyaoyaocaiAdd
				},
				{
					path: 'yaocaileibie',
					component: yaocaileibieList
				},
				{
					path: 'yaocaileibieDetail',
					component: yaocaileibieDetail
				},
				{
					path: 'yaocaileibieAdd',
					component: yaocaileibieAdd
				},
				{
					path: 'jiankangdangan',
					component: jiankangdanganList
				},
				{
					path: 'jiankangdanganDetail',
					component: jiankangdanganDetail
				},
				{
					path: 'jiankangdanganAdd',
					component: jiankangdanganAdd
				},
				{
					path: 'jiankangfenxi',
					component: jiankangfenxiList
				},
				{
					path: 'jiankangfenxiDetail',
					component: jiankangfenxiDetail
				},
				{
					path: 'jiankangfenxiAdd',
					component: jiankangfenxiAdd
				},
				{
					path: 'yangshengfangan',
					component: yangshengfanganList
				},
				{
					path: 'yangshengfanganDetail',
					component: yangshengfanganDetail
				},
				{
					path: 'yangshengfanganAdd',
					component: yangshengfanganAdd
				},
				{
					path: 'newstype',
					component: newstypeList
				},
				{
					path: 'newstypeDetail',
					component: newstypeDetail
				},
				{
					path: 'newstypeAdd',
					component: newstypeAdd
				},
				{
					path: 'discussyangshengzhishi',
					component: discussyangshengzhishiList
				},
				{
					path: 'discussyangshengzhishiDetail',
					component: discussyangshengzhishiDetail
				},
				{
					path: 'discussyangshengzhishiAdd',
					component: discussyangshengzhishiAdd
				},
				{
					path: 'discusszhongyaoyaocai',
					component: discusszhongyaoyaocaiList
				},
				{
					path: 'discusszhongyaoyaocaiDetail',
					component: discusszhongyaoyaocaiDetail
				},
				{
					path: 'discusszhongyaoyaocaiAdd',
					component: discusszhongyaoyaocaiAdd
				},
			]
		},
		{
			path: '/login',
			component: Login
		},
		{
			path: '/register',
			component: Register
		},
	]
})
