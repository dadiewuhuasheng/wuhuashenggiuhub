const base = {
    get() {
        return {
            url : "http://localhost:8080/springboot5m6unc96/",
            name: "springboot5m6unc96",
            // 退出到首页链接
            indexUrl: 'http://localhost:8080/springboot5m6unc96/front/dist/index.html'
        };
    },
    getProjectName(){
        return {
            projectName: "中医健康养生系统的设计与实现"
        } 
    }
}
export default base
