<template>
	<div class="addEdit-block" :style='{"padding":"30px","fontSize":"16px","color":"#666","background":"none"}'>
		<el-form
			:style='{"border":"0px solid rgba(254,169,35,.2)","padding":"30px 25%","boxShadow":"0 0px 0px rgba(64, 158, 255, .3)","fontSize":"inherit","borderRadius":"4px","background":"none"}'
			class="add-update-preview"
			ref="ruleForm"
			:model="ruleForm"
			:rules="rules"
			label-width="150px"
		>
			<template >
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' class="input" v-if="type!='info'"  label="药材名称" prop="yaocaimingcheng">
					<el-input v-model="ruleForm.yaocaimingcheng" placeholder="药材名称" clearable  :readonly="ro.yaocaimingcheng"></el-input>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' v-else class="input" label="药材名称" prop="yaocaimingcheng">
					<el-input v-model="ruleForm.yaocaimingcheng" placeholder="药材名称" readonly></el-input>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' class="select" v-if="type!='info'"  label="药材类别" prop="yaocaileibie">
					<el-select :disabled="ro.yaocaileibie" v-model="ruleForm.yaocaileibie" placeholder="请选择药材类别" >
						<el-option
							v-for="(item,index) in yaocaileibieOptions"
							v-bind:key="index"
							:label="item"
							:value="item">
						</el-option>
					</el-select>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' v-else class="input" label="药材类别" prop="yaocaileibie">
					<el-input v-model="ruleForm.yaocaileibie"
						placeholder="药材类别" readonly></el-input>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' class="input" v-if="type!='info'"  label="药性" prop="yaoxing">
					<el-input v-model="ruleForm.yaoxing" placeholder="药性" clearable  :readonly="ro.yaoxing"></el-input>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' v-else class="input" label="药性" prop="yaoxing">
					<el-input v-model="ruleForm.yaoxing" placeholder="药性" readonly></el-input>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' class="input" v-if="type!='info'"  label="来源" prop="laiyuan">
					<el-input v-model="ruleForm.laiyuan" placeholder="来源" clearable  :readonly="ro.laiyuan"></el-input>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' v-else class="input" label="来源" prop="laiyuan">
					<el-input v-model="ruleForm.laiyuan" placeholder="来源" readonly></el-input>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' class="upload" v-if="type!='info' && !ro.yaopintupian" label="药品图片" prop="yaopintupian">
					<file-upload
						tip="点击上传药品图片"
						action="file/upload"
						:limit="3"
						:multiple="true"
						:fileUrls="ruleForm.yaopintupian?ruleForm.yaopintupian:''"
						@change="yaopintupianUploadChange"
					></file-upload>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' class="upload" v-else-if="ruleForm.yaopintupian" label="药品图片" prop="yaopintupian">
					<img v-if="ruleForm.yaopintupian.substring(0,4)=='http'" class="upload-img" style="margin-right:20px;" v-bind:key="index" :src="ruleForm.yaopintupian.split(',')[0]" width="100" height="100">
					<img v-else class="upload-img" style="margin-right:20px;" v-bind:key="index" v-for="(item,index) in ruleForm.yaopintupian.split(',')" :src="$base.url+item" width="100" height="100">
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' class="input" v-if="type!='info'"  label="存储条件" prop="cunchutiaojian">
					<el-input v-model="ruleForm.cunchutiaojian" placeholder="存储条件" clearable  :readonly="ro.cunchutiaojian"></el-input>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' v-else class="input" label="存储条件" prop="cunchutiaojian">
					<el-input v-model="ruleForm.cunchutiaojian" placeholder="存储条件" readonly></el-input>
				</el-form-item>
			</template>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' class="textarea" v-if="type!='info'" label="功能主治" prop="gongnengzhuzhi">
					<el-input
					  style="min-width: 200px; max-width: 600px;"
					  type="textarea"
					  :rows="8"
					  placeholder="功能主治"
					  v-model="ruleForm.gongnengzhuzhi" >
					</el-input>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' v-else-if="ruleForm.gongnengzhuzhi" label="功能主治" prop="gongnengzhuzhi">
					<span :style='{"fontSize":"16px","lineHeight":"40px","color":"inherit","fontWeight":"500","display":"inline-block"}'>{{ruleForm.gongnengzhuzhi}}</span>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' class="textarea" v-if="type!='info'" label="药材功效" prop="yaocaigongxiao">
					<el-input
					  style="min-width: 200px; max-width: 600px;"
					  type="textarea"
					  :rows="8"
					  placeholder="药材功效"
					  v-model="ruleForm.yaocaigongxiao" >
					</el-input>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' v-else-if="ruleForm.yaocaigongxiao" label="药材功效" prop="yaocaigongxiao">
					<span :style='{"fontSize":"16px","lineHeight":"40px","color":"inherit","fontWeight":"500","display":"inline-block"}'>{{ruleForm.yaocaigongxiao}}</span>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' class="textarea" v-if="type!='info'" label="禁忌" prop="jinji">
					<el-input
					  style="min-width: 200px; max-width: 600px;"
					  type="textarea"
					  :rows="8"
					  placeholder="禁忌"
					  v-model="ruleForm.jinji" >
					</el-input>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' v-else-if="ruleForm.jinji" label="禁忌" prop="jinji">
					<span :style='{"fontSize":"16px","lineHeight":"40px","color":"inherit","fontWeight":"500","display":"inline-block"}'>{{ruleForm.jinji}}</span>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' v-if="type!='info'"  label="详细说明" prop="xiangxishuoming">
					<editor 
						style="min-width: 200px; max-width: 600px;"
						v-model="ruleForm.xiangxishuoming" 
						class="editor" 
						action="file/upload">
					</editor>
				</el-form-item>
				<el-form-item :style='{"color":"inherit","margin":"0 0 20px 0","fontSize":"inherit"}' v-else-if="ruleForm.xiangxishuoming" label="详细说明" prop="xiangxishuoming">
                    <span :style='{"fontSize":"16px","lineHeight":"40px","color":"inherit","fontWeight":"500","display":"inline-block"}' v-html="ruleForm.xiangxishuoming"></span>
                </el-form-item>
			<el-form-item :style='{"padding":"0","margin":"30px 0","alignItems":"center","textAlign":"center","display":"flex","width":"100%","fontSize":"48px","justifyContent":"center"}' class="btn">
				<el-button class="btn3"  v-if="type!='info'" type="success" @click="onSubmit">
					<span class="icon iconfont icon-tijiao16" :style='{"color":"inherit","margin":"0 2px","fontSize":"18px"}'></span>
					保存
				</el-button>
				<el-button class="btn4" v-if="type!='info'" type="success" @click="back()">
					<span class="icon iconfont icon-quxiao09" :style='{"color":"inherit","margin":"0 2px","fontSize":"18px"}'></span>
					取消
				</el-button>
				<el-button class="btn5" v-if="type=='info'" type="success" @click="back()">
					<span class="icon iconfont icon-fanhui01" :style='{"color":"inherit","margin":"0 2px","fontSize":"18px"}'></span>
					返程
				</el-button>
			</el-form-item>
		</el-form>
    

  </div>
</template>
<script>
import { 
	isIntNumer,
} from "@/utils/validate";
export default {
	data() {
		var validateIntNumber = (rule, value, callback) => {
			if(!value){
				callback();
			} else if (!isIntNumer(value)) {
				callback(new Error("请输入整数"));
			} else {
				callback();
			}
		};
		return {
			id: '',
			type: '',
			
			
			ro:{
				yaocaimingcheng : false,
				yaocaileibie : false,
				yaoxing : false,
				laiyuan : false,
				gongnengzhuzhi : false,
				yaocaigongxiao : false,
				yaopintupian : false,
				cunchutiaojian : false,
				jinji : false,
				xiangxishuoming : false,
				thumbsupnum : false,
				crazilynum : false,
				clicktime : false,
				clicknum : false,
				discussnum : false,
				storeupnum : false,
			},
			
			
			ruleForm: {
				yaocaimingcheng: '',
				yaocaileibie: '',
				yaoxing: '',
				laiyuan: '',
				gongnengzhuzhi: '',
				yaocaigongxiao: '',
				yaopintupian: '',
				cunchutiaojian: '',
				jinji: '',
				xiangxishuoming: '',
				clicktime: '',
			},
		
			yaocaileibieOptions: [],

			
			rules: {
				yaocaimingcheng: [
					{ required: true, message: '药材名称不能为空', trigger: 'blur' },
				],
				yaocaileibie: [
					{ required: true, message: '药材类别不能为空', trigger: 'blur' },
				],
				yaoxing: [
					{ required: true, message: '药性不能为空', trigger: 'blur' },
				],
				laiyuan: [
				],
				gongnengzhuzhi: [
					{ required: true, message: '功能主治不能为空', trigger: 'blur' },
				],
				yaocaigongxiao: [
				],
				yaopintupian: [
				],
				cunchutiaojian: [
				],
				jinji: [
				],
				xiangxishuoming: [
				],
				thumbsupnum: [
					{ validator: validateIntNumber, trigger: 'blur' },
				],
				crazilynum: [
					{ validator: validateIntNumber, trigger: 'blur' },
				],
				clicktime: [
				],
				clicknum: [
					{ validator: validateIntNumber, trigger: 'blur' },
				],
				discussnum: [
					{ validator: validateIntNumber, trigger: 'blur' },
				],
				storeupnum: [
					{ validator: validateIntNumber, trigger: 'blur' },
				],
			}
		};
	},
	props: ["parent"],
	computed: {



	},
    components: {
    },
	created() {
	},
	methods: {
		
		// 下载
		download(file){
			window.open(`${file}`)
		},
		// 初始化
		init(id,type) {
			if (id) {
				this.id = id;
				this.type = type;
			}
			if(this.type=='info'||this.type=='else'){
				this.info(id);
			}else if(this.type=='logistics'){
				this.logistics=false;
				this.info(id);
			}else if(this.type=='cross'){
				var obj = this.$storage.getObj('crossObj');
				for (var o in obj){
						if(o=='yaocaimingcheng'){
							this.ruleForm.yaocaimingcheng = obj[o];
							this.ro.yaocaimingcheng = true;
							continue;
						}
						if(o=='yaocaileibie'){
							this.ruleForm.yaocaileibie = obj[o];
							this.ro.yaocaileibie = true;
							continue;
						}
						if(o=='yaoxing'){
							this.ruleForm.yaoxing = obj[o];
							this.ro.yaoxing = true;
							continue;
						}
						if(o=='laiyuan'){
							this.ruleForm.laiyuan = obj[o];
							this.ro.laiyuan = true;
							continue;
						}
						if(o=='gongnengzhuzhi'){
							this.ruleForm.gongnengzhuzhi = obj[o];
							this.ro.gongnengzhuzhi = true;
							continue;
						}
						if(o=='yaocaigongxiao'){
							this.ruleForm.yaocaigongxiao = obj[o];
							this.ro.yaocaigongxiao = true;
							continue;
						}
						if(o=='yaopintupian'){
							this.ruleForm.yaopintupian = obj[o];
							this.ro.yaopintupian = true;
							continue;
						}
						if(o=='cunchutiaojian'){
							this.ruleForm.cunchutiaojian = obj[o];
							this.ro.cunchutiaojian = true;
							continue;
						}
						if(o=='jinji'){
							this.ruleForm.jinji = obj[o];
							this.ro.jinji = true;
							continue;
						}
						if(o=='xiangxishuoming'){
							this.ruleForm.xiangxishuoming = obj[o];
							this.ro.xiangxishuoming = true;
							continue;
						}
						if(o=='thumbsupnum'){
							this.ruleForm.thumbsupnum = obj[o];
							this.ro.thumbsupnum = true;
							continue;
						}
						if(o=='crazilynum'){
							this.ruleForm.crazilynum = obj[o];
							this.ro.crazilynum = true;
							continue;
						}
						if(o=='clicktime'){
							this.ruleForm.clicktime = obj[o];
							this.ro.clicktime = true;
							continue;
						}
						if(o=='clicknum'){
							this.ruleForm.clicknum = obj[o];
							this.ro.clicknum = true;
							continue;
						}
						if(o=='discussnum'){
							this.ruleForm.discussnum = obj[o];
							this.ro.discussnum = true;
							continue;
						}
						if(o=='storeupnum'){
							this.ruleForm.storeupnum = obj[o];
							this.ro.storeupnum = true;
							continue;
						}
				}
			}
			// 获取用户信息
			this.$http({
				url: `${this.$storage.get('sessionTable')}/session`,
				method: "get"
			}).then(({ data }) => {
				if (data && data.code === 0) {
					var json = data.data;
				} else {
					this.$message.error(data.msg);
				}
			});
            this.$http({
				url: `option/yaocaileibie/yaocaileibie`,
				method: "get"
            }).then(({ data }) => {
				if (data && data.code === 0) {
					this.yaocaileibieOptions = data.data;
				} else {
					this.$message.error(data.msg);
				}
            });
			
		},
    // 多级联动参数

    info(id) {
      this.$http({
        url: `zhongyaoyaocai/info/${id}`,
        method: "get"
      }).then(({ data }) => {
        if (data && data.code === 0) {
        this.ruleForm = data.data;
        //解决前台上传图片后台不显示的问题
        let reg=new RegExp('../../../upload','g')//g代表全部
        this.ruleForm.xiangxishuoming = this.ruleForm.xiangxishuoming.replace(reg,'../../../springboot5m6unc96/upload');
        } else {
          this.$message.error(data.msg);
        }
      });
    },


    // 提交
    onSubmit() {
	if(this.ruleForm.yaopintupian!=null) {
		this.ruleForm.yaopintupian = this.ruleForm.yaopintupian.replace(new RegExp(this.$base.url,"g"),"");
	}
var objcross = this.$storage.getObj('crossObj');
      //更新跨表属性
       var crossuserid;
       var crossrefid;
       var crossoptnum;
       if(this.type=='cross'){
                var statusColumnName = this.$storage.get('statusColumnName');
                var statusColumnValue = this.$storage.get('statusColumnValue');
                if(statusColumnName!='') {
                        var obj = this.$storage.getObj('crossObj');
                       if(statusColumnName && !statusColumnName.startsWith("[")) {
                               for (var o in obj){
                                 if(o==statusColumnName){
                                   obj[o] = statusColumnValue;
                                 }
                               }
                               var table = this.$storage.get('crossTable');
                             this.$http({
                                 url: `${table}/update`,
                                 method: "post",
                                 data: obj
                               }).then(({ data }) => {});
                       } else {
                               crossuserid=this.$storage.get('userid');
                               crossrefid=obj['id'];
                               crossoptnum=this.$storage.get('statusColumnName');
                               crossoptnum=crossoptnum.replace(/\[/,"").replace(/\]/,"");
                        }
                }
        }
		this.$refs["ruleForm"].validate(valid => {
			if (valid) {
				if(crossrefid && crossuserid) {
					this.ruleForm.crossuserid = crossuserid;
					this.ruleForm.crossrefid = crossrefid;
					let params = { 
						page: 1, 
						limit: 10, 
						crossuserid:this.ruleForm.crossuserid,
						crossrefid:this.ruleForm.crossrefid,
					} 
				this.$http({ 
					url: "zhongyaoyaocai/page", 
					method: "get", 
					params: params 
				}).then(({ 
					data 
				}) => { 
					if (data && data.code === 0) { 
						if(data.data.total>=crossoptnum) {
							this.$message.error(this.$storage.get('tips'));
							return false;
						} else {
							this.$http({
								url: `zhongyaoyaocai/${!this.ruleForm.id ? "save" : "update"}`,
								method: "post",
								data: this.ruleForm
							}).then(({ data }) => {
								if (data && data.code === 0) {
									this.$message({
										message: "操作成功",
										type: "success",
										duration: 1500,
										onClose: () => {
											this.parent.showFlag = true;
											this.parent.addOrUpdateFlag = false;
											this.parent.zhongyaoyaocaiCrossAddOrUpdateFlag = false;
											this.parent.search();
											this.parent.contentStyleChange();
										}
									});
								} else {
									this.$message.error(data.msg);
								}
							});

						}
					} else { 
				} 
			});
		} else {
			this.$http({
				url: `zhongyaoyaocai/${!this.ruleForm.id ? "save" : "update"}`,
				method: "post",
			   data: this.ruleForm
			}).then(({ data }) => {
				if (data && data.code === 0) {
					this.$message({
						message: "操作成功",
						type: "success",
						duration: 1500,
						onClose: () => {
							this.parent.showFlag = true;
							this.parent.addOrUpdateFlag = false;
							this.parent.zhongyaoyaocaiCrossAddOrUpdateFlag = false;
							this.parent.search();
							this.parent.contentStyleChange();
						}
					});
				} else {
					this.$message.error(data.msg);
			   }
			});
		 }
         }
       });
    },
    // 获取uuid
    getUUID () {
      return new Date().getTime();
    },
    // 返回
    back() {
      this.parent.showFlag = true;
      this.parent.addOrUpdateFlag = false;
      this.parent.zhongyaoyaocaiCrossAddOrUpdateFlag = false;
      this.parent.contentStyleChange();
    },
    yaopintupianUploadChange(fileUrls) {
	    this.ruleForm.yaopintupian = fileUrls;
    },
  }
};
</script>
<style lang="scss" scoped>
	.amap-wrapper {
		width: 100%;
		height: 500px;
	}
	
	.search-box {
		position: absolute;
	}
	
	.el-date-editor.el-input {
		width: auto;
	}
	
	.add-update-preview .el-form-item /deep/ .el-form-item__label {
	  	  padding: 0 10px 0 0;
	  	  color: inherit;
	  	  font-weight: 500;
	  	  display: inline-block;
	  	  width: 150px;
	  	  font-size: inherit;
	  	  line-height: 40px;
	  	  text-align: right;
	  	}
	
	.add-update-preview .el-form-item /deep/ .el-form-item__content {
	  margin-left: 150px;
	}
	
	.add-update-preview .el-input /deep/ .el-input__inner {
	  	  border: 1px solid rgba(3, 152, 15, .2);
	  	  border-radius: 4px;
	  	  padding: 0 12px;
	  	  box-shadow: 0 0 0px rgba(64, 158, 255, .5);
	  	  outline: none;
	  	  color: inherit;
	  	  background: none;
	  	  width: 400px;
	  	  font-size: 16px;
	  	  height: 44px;
	  	}
	.add-update-preview .el-input-number /deep/ .el-input__inner {
		text-align: left;
	  	  border: 1px solid rgba(3, 152, 15, .2);
	  	  border-radius: 4px;
	  	  padding: 0 12px;
	  	  box-shadow: 0 0 0px rgba(64, 158, 255, .5);
	  	  outline: none;
	  	  color: inherit;
	  	  background: none;
	  	  width: 400px;
	  	  font-size: 16px;
	  	  height: 44px;
	  	}
	.add-update-preview .el-input-number /deep/ .el-input-number__decrease {
		display: none;
	}
	.add-update-preview .el-input-number /deep/ .el-input-number__increase {
		display: none;
	}
	
	.add-update-preview .el-select /deep/ .el-input__inner {
	  	  border: 1px solid rgba(3, 152, 15, .2);
	  	  border-radius: 4px;
	  	  padding: 0 10px;
	  	  box-shadow: 0 0 0px rgba(64, 158, 255, .5);
	  	  outline: none;
	  	  color: inherit;
	  	  background: none;
	  	  width: 200px;
	  	  font-size: 16px;
	  	  height: 44px;
	  	}
	
	.add-update-preview .el-date-editor /deep/ .el-input__inner {
	  	  border: 1px solid rgba(3, 152, 15, .2);
	  	  border-radius: 4px;
	  	  padding: 0 10px 0 30px;
	  	  box-shadow: 0 0 0px rgba(64, 158, 255, .5);
	  	  outline: none;
	  	  color: inherit;
	  	  background: none;
	  	  width: 200px;
	  	  font-size: 16px;
	  	  height: 44px;
	  	}
	
	.add-update-preview /deep/ .el-upload--picture-card {
		background: transparent;
		border: 0;
		border-radius: 0;
		width: auto;
		height: auto;
		line-height: initial;
		vertical-align: middle;
	}
	
	.add-update-preview /deep/ .upload .upload-img {
	  	  border: 1px solid rgba(3, 152, 15, .2);
	  	  cursor: pointer;
	  	  border-radius: 4px;
	  	  color: inherit;
	  	  background: none;
	  	  object-fit: cover;
	  	  width: 180px;
	  	  font-size: 32px;
	  	  line-height: 90px;
	  	  text-align: center;
	  	  height: 90px;
	  	}
	
	.add-update-preview /deep/ .el-upload-list .el-upload-list__item {
	  	  border: 1px solid rgba(3, 152, 15, .2);
	  	  cursor: pointer;
	  	  border-radius: 4px;
	  	  color: inherit;
	  	  background: none;
	  	  object-fit: cover;
	  	  width: 180px;
	  	  font-size: 32px;
	  	  line-height: 90px;
	  	  text-align: center;
	  	  height: 90px;
	  	}
	
	.add-update-preview /deep/ .el-upload .el-icon-plus {
	  	  border: 1px solid rgba(3, 152, 15, .2);
	  	  cursor: pointer;
	  	  border-radius: 4px;
	  	  color: inherit;
	  	  background: none;
	  	  object-fit: cover;
	  	  width: 180px;
	  	  font-size: 32px;
	  	  line-height: 90px;
	  	  text-align: center;
	  	  height: 90px;
	  	}
	
	.add-update-preview .el-textarea /deep/ .el-textarea__inner {
	  	  border: 1px solid rgba(3, 152, 15, .2);
	  	  border-radius: 4px;
	  	  padding: 12px;
	  	  box-shadow: 0 0 0px rgba(64, 158, 255, .5);
	  	  outline: none;
	  	  color: inherit;
	  	  background: none;
	  	  width: 500px;
	  	  font-size: 16px;
	  	  height: 140px;
	  	}
	
	.add-update-preview .btn .btn1 {
				border: 1px solid rgba(3, 152, 15, .2);
				cursor: pointer;
				padding: 0 20px;
				margin: 0px 4px;
				color: rgba(3, 152, 15, .8);
				display: inline-block;
				font-size: 18px;
				line-height: 24px;
				border-radius: 4px;
				outline: none;
				background: rgba(255,255,255,.0);
				width: auto;
				height: 50px;
			}
	
	.add-update-preview .btn .btn1:hover {
				color: #fff;
				background: rgba(3, 152, 15, .8);
				opacity: 0.8;
			}
	
	.add-update-preview .btn .btn2 {
				border: 1px solid rgba(3, 152, 15, .2);
				cursor: pointer;
				border-radius: 4px;
				padding: 0 20px;
				margin: 0px 4px;
				outline: none;
				color: rgba(3, 152, 15, .8);
				background: none;
				width: auto;
				font-size: 18px;
				line-height: 24px;
				height: 50px;
			}
	
	.add-update-preview .btn .btn2:hover {
				color: #fff;
				background: rgba(3, 152, 15, .8);
				opacity: 0.8;
			}
	
	.add-update-preview .btn .btn3 {
				border: 1px solid rgba(3, 152, 15, .2);
				cursor: pointer;
				border-radius: 4px;
				padding: 0 20px;
				margin: 0px 4px;
				outline: none;
				color: rgba(3, 152, 15, .8);
				background: rgba(255,255,255,.0);
				width: auto;
				font-size: 18px;
				line-height: 24px;
				height: 50px;
			}
	
	.add-update-preview .btn .btn3:hover {
				color: #fff;
				background: rgba(3, 152, 15, .8);
				opacity: 0.8;
			}
	
	.add-update-preview .btn .btn4 {
				border: 1px solid rgba(3, 152, 15, .2);
				cursor: pointer;
				border-radius: 4px;
				padding: 0 20px;
				margin: 0px 4px;
				outline: none;
				color: rgba(3, 152, 15, .8);
				background: rgba(255,255,255,.0);
				width: auto;
				font-size: 18px;
				line-height: 24px;
				height: 50px;
			}
	
	.add-update-preview .btn .btn4:hover {
				color: #fff;
				background: rgba(3, 152, 15, .8);
				opacity: 0.8;
			}
	
	.add-update-preview .btn .btn5 {
				border: 1px solid rgba(3, 152, 15, .2);
				cursor: pointer;
				border-radius: 4px;
				padding: 0 20px;
				margin: 4px;
				outline: none;
				color: rgba(3, 152, 15, .8);
				background: rgba(255,255,255,.0);
				width: auto;
				font-size: 18px;
				line-height: 24px;
				height: 50px;
			}
	
	.add-update-preview .btn .btn5:hover {
				color: #fff;
				background: rgba(3, 152, 15, .8);
				opacity: 0.8;
			}
</style>
