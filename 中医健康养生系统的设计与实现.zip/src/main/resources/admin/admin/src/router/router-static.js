import Vue from 'vue';
//配置路由
import VueRouter from 'vue-router'
Vue.use(VueRouter);
//1.创建组件
import Index from '@/views/index'
import Home from '@/views/home'
import Login from '@/views/login'
import NotFound from '@/views/404'
import UpdatePassword from '@/views/update-password'
import pay from '@/views/pay'
import register from '@/views/register'
import center from '@/views/center'
    import news from '@/views/modules/news/list'
    import jiankangdangan from '@/views/modules/jiankangdangan/list'
    import discusszhongyaoyaocai from '@/views/modules/discusszhongyaoyaocai/list'
    import discussyangshengzhishi from '@/views/modules/discussyangshengzhishi/list'
    import yaocaileibie from '@/views/modules/yaocaileibie/list'
    import forum from '@/views/modules/forum/list'
    import zhishifenlei from '@/views/modules/zhishifenlei/list'
    import yangshengzhishi from '@/views/modules/yangshengzhishi/list'
    import yonghu from '@/views/modules/yonghu/list'
    import jiankangfenxi from '@/views/modules/jiankangfenxi/list'
    import zhongyaoyaocai from '@/views/modules/zhongyaoyaocai/list'
    import yangshengfangan from '@/views/modules/yangshengfangan/list'
    import config from '@/views/modules/config/list'
    import newstype from '@/views/modules/newstype/list'


//2.配置路由   注意：名字
export const routes = [{
    path: '/',
    name: '系统首页',
    component: Index,
    children: [{
      // 这里不设置值，是把main作为默认页面
      path: '/',
      name: '系统首页',
      component: Home,
      meta: {icon:'', title:'center', affix: true}
    }, {
      path: '/updatePassword',
      name: '修改密码',
      component: UpdatePassword,
      meta: {icon:'', title:'updatePassword'}
    }, {
      path: '/pay',
      name: '支付',
      component: pay,
      meta: {icon:'', title:'pay'}
    }, {
      path: '/center',
      name: '个人信息',
      component: center,
      meta: {icon:'', title:'center'}
    }
      ,{
	path: '/news',
        name: '公告信息',
        component: news
      }
      ,{
	path: '/jiankangdangan',
        name: '健康档案',
        component: jiankangdangan
      }
      ,{
	path: '/discusszhongyaoyaocai',
        name: '中药药材评论',
        component: discusszhongyaoyaocai
      }
      ,{
	path: '/discussyangshengzhishi',
        name: '养生知识评论',
        component: discussyangshengzhishi
      }
      ,{
	path: '/yaocaileibie',
        name: '药材类别',
        component: yaocaileibie
      }
      ,{
	path: '/forum',
        name: '养生互动',
        component: forum
      }
      ,{
	path: '/zhishifenlei',
        name: '知识分类',
        component: zhishifenlei
      }
      ,{
	path: '/yangshengzhishi',
        name: '养生知识',
        component: yangshengzhishi
      }
      ,{
	path: '/yonghu',
        name: '用户',
        component: yonghu
      }
      ,{
	path: '/jiankangfenxi',
        name: '健康分析',
        component: jiankangfenxi
      }
      ,{
	path: '/zhongyaoyaocai',
        name: '中药药材',
        component: zhongyaoyaocai
      }
      ,{
	path: '/yangshengfangan',
        name: '养生方案',
        component: yangshengfangan
      }
      ,{
	path: '/config',
        name: '轮播图管理',
        component: config
      }
      ,{
	path: '/newstype',
        name: '公告信息分类',
        component: newstype
      }
    ]
  },
  {
    path: '/login',
    name: 'login',
    component: Login,
    meta: {icon:'', title:'login'}
  },
  {
    path: '/register',
    name: 'register',
    component: register,
    meta: {icon:'', title:'register'}
  },
  {
    path: '*',
    component: NotFound
  }
]
//3.实例化VueRouter  注意：名字
const router = new VueRouter({
  mode: 'hash',
  /*hash模式改为history*/
  routes // （缩写）相当于 routes: routes
})
const originalPush = VueRouter.prototype.push
//修改原型对象中的push方法
VueRouter.prototype.push = function push(location) {
   return originalPush.call(this, location).catch(err => err)
}
export default router;
