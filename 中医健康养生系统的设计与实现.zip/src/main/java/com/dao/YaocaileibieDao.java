package com.dao;

import com.entity.YaocaileibieEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.YaocaileibieVO;
import com.entity.view.YaocaileibieView;


/**
 * 药材类别
 * 
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
public interface YaocaileibieDao extends BaseMapper<YaocaileibieEntity> {
	
	List<YaocaileibieVO> selectListVO(@Param("ew") Wrapper<YaocaileibieEntity> wrapper);
	
	YaocaileibieVO selectVO(@Param("ew") Wrapper<YaocaileibieEntity> wrapper);
	
	List<YaocaileibieView> selectListView(@Param("ew") Wrapper<YaocaileibieEntity> wrapper);

	List<YaocaileibieView> selectListView(Pagination page,@Param("ew") Wrapper<YaocaileibieEntity> wrapper);

	
	YaocaileibieView selectView(@Param("ew") Wrapper<YaocaileibieEntity> wrapper);
	

}
