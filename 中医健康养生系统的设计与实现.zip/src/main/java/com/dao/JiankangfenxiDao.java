package com.dao;

import com.entity.JiankangfenxiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.JiankangfenxiVO;
import com.entity.view.JiankangfenxiView;


/**
 * 健康分析
 * 
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
public interface JiankangfenxiDao extends BaseMapper<JiankangfenxiEntity> {
	
	List<JiankangfenxiVO> selectListVO(@Param("ew") Wrapper<JiankangfenxiEntity> wrapper);
	
	JiankangfenxiVO selectVO(@Param("ew") Wrapper<JiankangfenxiEntity> wrapper);
	
	List<JiankangfenxiView> selectListView(@Param("ew") Wrapper<JiankangfenxiEntity> wrapper);

	List<JiankangfenxiView> selectListView(Pagination page,@Param("ew") Wrapper<JiankangfenxiEntity> wrapper);

	
	JiankangfenxiView selectView(@Param("ew") Wrapper<JiankangfenxiEntity> wrapper);
	

}
