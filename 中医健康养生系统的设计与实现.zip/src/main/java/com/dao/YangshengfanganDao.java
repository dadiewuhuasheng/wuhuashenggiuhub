package com.dao;

import com.entity.YangshengfanganEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.YangshengfanganVO;
import com.entity.view.YangshengfanganView;


/**
 * 养生方案
 * 
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
public interface YangshengfanganDao extends BaseMapper<YangshengfanganEntity> {
	
	List<YangshengfanganVO> selectListVO(@Param("ew") Wrapper<YangshengfanganEntity> wrapper);
	
	YangshengfanganVO selectVO(@Param("ew") Wrapper<YangshengfanganEntity> wrapper);
	
	List<YangshengfanganView> selectListView(@Param("ew") Wrapper<YangshengfanganEntity> wrapper);

	List<YangshengfanganView> selectListView(Pagination page,@Param("ew") Wrapper<YangshengfanganEntity> wrapper);

	
	YangshengfanganView selectView(@Param("ew") Wrapper<YangshengfanganEntity> wrapper);
	

}
