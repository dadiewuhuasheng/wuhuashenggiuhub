package com.dao;

import com.entity.DiscusszhongyaoyaocaiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.DiscusszhongyaoyaocaiVO;
import com.entity.view.DiscusszhongyaoyaocaiView;


/**
 * 中药药材评论表
 * 
 * @author 
 * @email 
 * @date 2024-04-20 14:25:50
 */
public interface DiscusszhongyaoyaocaiDao extends BaseMapper<DiscusszhongyaoyaocaiEntity> {
	
	List<DiscusszhongyaoyaocaiVO> selectListVO(@Param("ew") Wrapper<DiscusszhongyaoyaocaiEntity> wrapper);
	
	DiscusszhongyaoyaocaiVO selectVO(@Param("ew") Wrapper<DiscusszhongyaoyaocaiEntity> wrapper);
	
	List<DiscusszhongyaoyaocaiView> selectListView(@Param("ew") Wrapper<DiscusszhongyaoyaocaiEntity> wrapper);

	List<DiscusszhongyaoyaocaiView> selectListView(Pagination page,@Param("ew") Wrapper<DiscusszhongyaoyaocaiEntity> wrapper);

	
	DiscusszhongyaoyaocaiView selectView(@Param("ew") Wrapper<DiscusszhongyaoyaocaiEntity> wrapper);
	

}
