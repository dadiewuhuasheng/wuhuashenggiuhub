package com.dao;

import com.entity.ZhongyaoyaocaiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.ZhongyaoyaocaiVO;
import com.entity.view.ZhongyaoyaocaiView;


/**
 * 中药药材
 * 
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
public interface ZhongyaoyaocaiDao extends BaseMapper<ZhongyaoyaocaiEntity> {
	
	List<ZhongyaoyaocaiVO> selectListVO(@Param("ew") Wrapper<ZhongyaoyaocaiEntity> wrapper);
	
	ZhongyaoyaocaiVO selectVO(@Param("ew") Wrapper<ZhongyaoyaocaiEntity> wrapper);
	
	List<ZhongyaoyaocaiView> selectListView(@Param("ew") Wrapper<ZhongyaoyaocaiEntity> wrapper);

	List<ZhongyaoyaocaiView> selectListView(Pagination page,@Param("ew") Wrapper<ZhongyaoyaocaiEntity> wrapper);

	
	ZhongyaoyaocaiView selectView(@Param("ew") Wrapper<ZhongyaoyaocaiEntity> wrapper);
	

}
