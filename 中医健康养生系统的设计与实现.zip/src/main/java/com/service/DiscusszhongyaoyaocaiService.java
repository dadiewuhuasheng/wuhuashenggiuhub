package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.DiscusszhongyaoyaocaiEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.DiscusszhongyaoyaocaiVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.DiscusszhongyaoyaocaiView;


/**
 * 中药药材评论表
 *
 * @author 
 * @email 
 * @date 2024-04-20 14:25:50
 */
public interface DiscusszhongyaoyaocaiService extends IService<DiscusszhongyaoyaocaiEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<DiscusszhongyaoyaocaiVO> selectListVO(Wrapper<DiscusszhongyaoyaocaiEntity> wrapper);
   	
   	DiscusszhongyaoyaocaiVO selectVO(@Param("ew") Wrapper<DiscusszhongyaoyaocaiEntity> wrapper);
   	
   	List<DiscusszhongyaoyaocaiView> selectListView(Wrapper<DiscusszhongyaoyaocaiEntity> wrapper);
   	
   	DiscusszhongyaoyaocaiView selectView(@Param("ew") Wrapper<DiscusszhongyaoyaocaiEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<DiscusszhongyaoyaocaiEntity> wrapper);

   	

}

