package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.YaocaileibieEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.YaocaileibieVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.YaocaileibieView;


/**
 * 药材类别
 *
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
public interface YaocaileibieService extends IService<YaocaileibieEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<YaocaileibieVO> selectListVO(Wrapper<YaocaileibieEntity> wrapper);
   	
   	YaocaileibieVO selectVO(@Param("ew") Wrapper<YaocaileibieEntity> wrapper);
   	
   	List<YaocaileibieView> selectListView(Wrapper<YaocaileibieEntity> wrapper);
   	
   	YaocaileibieView selectView(@Param("ew") Wrapper<YaocaileibieEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<YaocaileibieEntity> wrapper);

   	

}

