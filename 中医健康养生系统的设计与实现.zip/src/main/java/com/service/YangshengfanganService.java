package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.YangshengfanganEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.YangshengfanganVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.YangshengfanganView;


/**
 * 养生方案
 *
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
public interface YangshengfanganService extends IService<YangshengfanganEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<YangshengfanganVO> selectListVO(Wrapper<YangshengfanganEntity> wrapper);
   	
   	YangshengfanganVO selectVO(@Param("ew") Wrapper<YangshengfanganEntity> wrapper);
   	
   	List<YangshengfanganView> selectListView(Wrapper<YangshengfanganEntity> wrapper);
   	
   	YangshengfanganView selectView(@Param("ew") Wrapper<YangshengfanganEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<YangshengfanganEntity> wrapper);

   	

}

