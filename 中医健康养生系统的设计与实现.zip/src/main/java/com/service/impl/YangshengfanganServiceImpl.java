package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.YangshengfanganDao;
import com.entity.YangshengfanganEntity;
import com.service.YangshengfanganService;
import com.entity.vo.YangshengfanganVO;
import com.entity.view.YangshengfanganView;

@Service("yangshengfanganService")
public class YangshengfanganServiceImpl extends ServiceImpl<YangshengfanganDao, YangshengfanganEntity> implements YangshengfanganService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<YangshengfanganEntity> page = this.selectPage(
                new Query<YangshengfanganEntity>(params).getPage(),
                new EntityWrapper<YangshengfanganEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<YangshengfanganEntity> wrapper) {
		  Page<YangshengfanganView> page =new Query<YangshengfanganView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}

    
    @Override
	public List<YangshengfanganVO> selectListVO(Wrapper<YangshengfanganEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public YangshengfanganVO selectVO(Wrapper<YangshengfanganEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<YangshengfanganView> selectListView(Wrapper<YangshengfanganEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public YangshengfanganView selectView(Wrapper<YangshengfanganEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
