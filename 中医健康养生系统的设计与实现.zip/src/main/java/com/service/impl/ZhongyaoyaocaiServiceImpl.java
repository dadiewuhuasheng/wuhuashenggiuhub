package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.ZhongyaoyaocaiDao;
import com.entity.ZhongyaoyaocaiEntity;
import com.service.ZhongyaoyaocaiService;
import com.entity.vo.ZhongyaoyaocaiVO;
import com.entity.view.ZhongyaoyaocaiView;

@Service("zhongyaoyaocaiService")
public class ZhongyaoyaocaiServiceImpl extends ServiceImpl<ZhongyaoyaocaiDao, ZhongyaoyaocaiEntity> implements ZhongyaoyaocaiService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ZhongyaoyaocaiEntity> page = this.selectPage(
                new Query<ZhongyaoyaocaiEntity>(params).getPage(),
                new EntityWrapper<ZhongyaoyaocaiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ZhongyaoyaocaiEntity> wrapper) {
		  Page<ZhongyaoyaocaiView> page =new Query<ZhongyaoyaocaiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}

    
    @Override
	public List<ZhongyaoyaocaiVO> selectListVO(Wrapper<ZhongyaoyaocaiEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public ZhongyaoyaocaiVO selectVO(Wrapper<ZhongyaoyaocaiEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<ZhongyaoyaocaiView> selectListView(Wrapper<ZhongyaoyaocaiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ZhongyaoyaocaiView selectView(Wrapper<ZhongyaoyaocaiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
