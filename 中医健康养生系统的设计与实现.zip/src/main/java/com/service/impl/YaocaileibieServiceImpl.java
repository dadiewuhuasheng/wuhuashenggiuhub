package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.YaocaileibieDao;
import com.entity.YaocaileibieEntity;
import com.service.YaocaileibieService;
import com.entity.vo.YaocaileibieVO;
import com.entity.view.YaocaileibieView;

@Service("yaocaileibieService")
public class YaocaileibieServiceImpl extends ServiceImpl<YaocaileibieDao, YaocaileibieEntity> implements YaocaileibieService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<YaocaileibieEntity> page = this.selectPage(
                new Query<YaocaileibieEntity>(params).getPage(),
                new EntityWrapper<YaocaileibieEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<YaocaileibieEntity> wrapper) {
		  Page<YaocaileibieView> page =new Query<YaocaileibieView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}

    
    @Override
	public List<YaocaileibieVO> selectListVO(Wrapper<YaocaileibieEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public YaocaileibieVO selectVO(Wrapper<YaocaileibieEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<YaocaileibieView> selectListView(Wrapper<YaocaileibieEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public YaocaileibieView selectView(Wrapper<YaocaileibieEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
