package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.DiscusszhongyaoyaocaiDao;
import com.entity.DiscusszhongyaoyaocaiEntity;
import com.service.DiscusszhongyaoyaocaiService;
import com.entity.vo.DiscusszhongyaoyaocaiVO;
import com.entity.view.DiscusszhongyaoyaocaiView;

@Service("discusszhongyaoyaocaiService")
public class DiscusszhongyaoyaocaiServiceImpl extends ServiceImpl<DiscusszhongyaoyaocaiDao, DiscusszhongyaoyaocaiEntity> implements DiscusszhongyaoyaocaiService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<DiscusszhongyaoyaocaiEntity> page = this.selectPage(
                new Query<DiscusszhongyaoyaocaiEntity>(params).getPage(),
                new EntityWrapper<DiscusszhongyaoyaocaiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<DiscusszhongyaoyaocaiEntity> wrapper) {
		  Page<DiscusszhongyaoyaocaiView> page =new Query<DiscusszhongyaoyaocaiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}

    
    @Override
	public List<DiscusszhongyaoyaocaiVO> selectListVO(Wrapper<DiscusszhongyaoyaocaiEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public DiscusszhongyaoyaocaiVO selectVO(Wrapper<DiscusszhongyaoyaocaiEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<DiscusszhongyaoyaocaiView> selectListView(Wrapper<DiscusszhongyaoyaocaiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public DiscusszhongyaoyaocaiView selectView(Wrapper<DiscusszhongyaoyaocaiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
