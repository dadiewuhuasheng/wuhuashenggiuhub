package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.JiankangfenxiEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.JiankangfenxiVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.JiankangfenxiView;


/**
 * 健康分析
 *
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
public interface JiankangfenxiService extends IService<JiankangfenxiEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<JiankangfenxiVO> selectListVO(Wrapper<JiankangfenxiEntity> wrapper);
   	
   	JiankangfenxiVO selectVO(@Param("ew") Wrapper<JiankangfenxiEntity> wrapper);
   	
   	List<JiankangfenxiView> selectListView(Wrapper<JiankangfenxiEntity> wrapper);
   	
   	JiankangfenxiView selectView(@Param("ew") Wrapper<JiankangfenxiEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<JiankangfenxiEntity> wrapper);

   	

}

