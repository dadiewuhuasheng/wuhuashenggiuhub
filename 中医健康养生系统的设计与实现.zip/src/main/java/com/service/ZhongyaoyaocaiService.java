package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ZhongyaoyaocaiEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ZhongyaoyaocaiVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ZhongyaoyaocaiView;


/**
 * 中药药材
 *
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
public interface ZhongyaoyaocaiService extends IService<ZhongyaoyaocaiEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ZhongyaoyaocaiVO> selectListVO(Wrapper<ZhongyaoyaocaiEntity> wrapper);
   	
   	ZhongyaoyaocaiVO selectVO(@Param("ew") Wrapper<ZhongyaoyaocaiEntity> wrapper);
   	
   	List<ZhongyaoyaocaiView> selectListView(Wrapper<ZhongyaoyaocaiEntity> wrapper);
   	
   	ZhongyaoyaocaiView selectView(@Param("ew") Wrapper<ZhongyaoyaocaiEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ZhongyaoyaocaiEntity> wrapper);

   	

}

