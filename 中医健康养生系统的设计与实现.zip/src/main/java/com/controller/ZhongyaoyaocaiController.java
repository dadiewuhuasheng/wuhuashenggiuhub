package com.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import com.utils.ValidatorUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.annotation.IgnoreAuth;

import com.entity.ZhongyaoyaocaiEntity;
import com.entity.view.ZhongyaoyaocaiView;

import com.service.ZhongyaoyaocaiService;
import com.service.TokenService;
import com.utils.PageUtils;
import com.utils.R;
import com.utils.MPUtil;
import com.utils.MapUtils;
import com.utils.CommonUtil;
import java.io.IOException;
import com.service.StoreupService;
import com.entity.StoreupEntity;

/**
 * 中药药材
 * 后端接口
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
@RestController
@RequestMapping("/zhongyaoyaocai")
public class ZhongyaoyaocaiController {
    @Autowired
    private ZhongyaoyaocaiService zhongyaoyaocaiService;

    @Autowired
    private StoreupService storeupService;



    



    /**
     * 后台列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params,ZhongyaoyaocaiEntity zhongyaoyaocai,
		HttpServletRequest request){
        EntityWrapper<ZhongyaoyaocaiEntity> ew = new EntityWrapper<ZhongyaoyaocaiEntity>();

		PageUtils page = zhongyaoyaocaiService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, zhongyaoyaocai), params), params));

        return R.ok().put("data", page);
    }
    
    /**
     * 前台列表
     */
	@IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params,ZhongyaoyaocaiEntity zhongyaoyaocai, 
		HttpServletRequest request){
        EntityWrapper<ZhongyaoyaocaiEntity> ew = new EntityWrapper<ZhongyaoyaocaiEntity>();

		PageUtils page = zhongyaoyaocaiService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, zhongyaoyaocai), params), params));
        return R.ok().put("data", page);
    }



	/**
     * 列表
     */
    @RequestMapping("/lists")
    public R list( ZhongyaoyaocaiEntity zhongyaoyaocai){
       	EntityWrapper<ZhongyaoyaocaiEntity> ew = new EntityWrapper<ZhongyaoyaocaiEntity>();
      	ew.allEq(MPUtil.allEQMapPre( zhongyaoyaocai, "zhongyaoyaocai")); 
        return R.ok().put("data", zhongyaoyaocaiService.selectListView(ew));
    }

	 /**
     * 查询
     */
    @RequestMapping("/query")
    public R query(ZhongyaoyaocaiEntity zhongyaoyaocai){
        EntityWrapper< ZhongyaoyaocaiEntity> ew = new EntityWrapper< ZhongyaoyaocaiEntity>();
 		ew.allEq(MPUtil.allEQMapPre( zhongyaoyaocai, "zhongyaoyaocai")); 
		ZhongyaoyaocaiView zhongyaoyaocaiView =  zhongyaoyaocaiService.selectView(ew);
		return R.ok("查询中药药材成功").put("data", zhongyaoyaocaiView);
    }
	
    /**
     * 后台详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id){
        ZhongyaoyaocaiEntity zhongyaoyaocai = zhongyaoyaocaiService.selectById(id);
		zhongyaoyaocai.setClicknum(zhongyaoyaocai.getClicknum()+1);
		zhongyaoyaocai.setClicktime(new Date());
		zhongyaoyaocaiService.updateById(zhongyaoyaocai);
        zhongyaoyaocai = zhongyaoyaocaiService.selectView(new EntityWrapper<ZhongyaoyaocaiEntity>().eq("id", id));
        return R.ok().put("data", zhongyaoyaocai);
    }

    /**
     * 前台详情
     */
	@IgnoreAuth
    @RequestMapping("/detail/{id}")
    public R detail(@PathVariable("id") Long id){
        ZhongyaoyaocaiEntity zhongyaoyaocai = zhongyaoyaocaiService.selectById(id);
		zhongyaoyaocai.setClicknum(zhongyaoyaocai.getClicknum()+1);
		zhongyaoyaocai.setClicktime(new Date());
		zhongyaoyaocaiService.updateById(zhongyaoyaocai);
        zhongyaoyaocai = zhongyaoyaocaiService.selectView(new EntityWrapper<ZhongyaoyaocaiEntity>().eq("id", id));
        return R.ok().put("data", zhongyaoyaocai);
    }
    


    /**
     * 赞或踩
     */
    @RequestMapping("/thumbsup/{id}")
    public R vote(@PathVariable("id") String id,String type){
        ZhongyaoyaocaiEntity zhongyaoyaocai = zhongyaoyaocaiService.selectById(id);
        if(type.equals("1")) {
        	zhongyaoyaocai.setThumbsupnum(zhongyaoyaocai.getThumbsupnum()+1);
        } else {
        	zhongyaoyaocai.setCrazilynum(zhongyaoyaocai.getCrazilynum()+1);
        }
        zhongyaoyaocaiService.updateById(zhongyaoyaocai);
        return R.ok("投票成功");
    }

    /**
     * 后台保存
     */
    @RequestMapping("/save")
    public R save(@RequestBody ZhongyaoyaocaiEntity zhongyaoyaocai, HttpServletRequest request){
    	//ValidatorUtils.validateEntity(zhongyaoyaocai);
        zhongyaoyaocaiService.insert(zhongyaoyaocai);
        return R.ok();
    }
    
    /**
     * 前台保存
     */
    @RequestMapping("/add")
    public R add(@RequestBody ZhongyaoyaocaiEntity zhongyaoyaocai, HttpServletRequest request){
    	//ValidatorUtils.validateEntity(zhongyaoyaocai);
        zhongyaoyaocaiService.insert(zhongyaoyaocai);
        return R.ok();
    }





    /**
     * 修改
     */
    @RequestMapping("/update")
    @Transactional
    public R update(@RequestBody ZhongyaoyaocaiEntity zhongyaoyaocai, HttpServletRequest request){
        //ValidatorUtils.validateEntity(zhongyaoyaocai);
        zhongyaoyaocaiService.updateById(zhongyaoyaocai);//全部更新
        return R.ok();
    }



    

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Long[] ids){
        zhongyaoyaocaiService.deleteBatchIds(Arrays.asList(ids));
        return R.ok();
    }
    
	
	/**
     * 前台智能排序
     */
	@IgnoreAuth
    @RequestMapping("/autoSort")
    public R autoSort(@RequestParam Map<String, Object> params,ZhongyaoyaocaiEntity zhongyaoyaocai, HttpServletRequest request,String pre){
        EntityWrapper<ZhongyaoyaocaiEntity> ew = new EntityWrapper<ZhongyaoyaocaiEntity>();
        Map<String, Object> newMap = new HashMap<String, Object>();
        Map<String, Object> param = new HashMap<String, Object>();
		Iterator<Map.Entry<String, Object>> it = param.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, Object> entry = it.next();
			String key = entry.getKey();
			String newKey = entry.getKey();
			if (pre.endsWith(".")) {
				newMap.put(pre + newKey, entry.getValue());
			} else if (StringUtils.isEmpty(pre)) {
				newMap.put(newKey, entry.getValue());
			} else {
				newMap.put(pre + "." + newKey, entry.getValue());
			}
		}
		params.put("sort", "clicknum");
        params.put("order", "desc");
		PageUtils page = zhongyaoyaocaiService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, zhongyaoyaocai), params), params));
        return R.ok().put("data", page);
    }


    /**
     * 协同算法（按收藏推荐）
     */
    @RequestMapping("/autoSort2")
    public R autoSort2(@RequestParam Map<String, Object> params,ZhongyaoyaocaiEntity zhongyaoyaocai, HttpServletRequest request){
        String userId = request.getSession().getAttribute("userId").toString();
        String inteltypeColumn = "yaocaileibie";
        List<StoreupEntity> storeups = storeupService.selectList(new EntityWrapper<StoreupEntity>().eq("type", 1).eq("userid", userId).eq("tablename", "zhongyaoyaocai").orderBy("addtime", false));
        List<String> inteltypes = new ArrayList<String>();
        Integer limit = params.get("limit")==null?10:Integer.parseInt(params.get("limit").toString());
        List<ZhongyaoyaocaiEntity> zhongyaoyaocaiList = new ArrayList<ZhongyaoyaocaiEntity>();
        //去重
        if(storeups!=null && storeups.size()>0) {
            for(StoreupEntity s : storeups) {
                zhongyaoyaocaiList.addAll(zhongyaoyaocaiService.selectList(new EntityWrapper<ZhongyaoyaocaiEntity>().eq(inteltypeColumn, s.getInteltype())));
            }
        }
        EntityWrapper<ZhongyaoyaocaiEntity> ew = new EntityWrapper<ZhongyaoyaocaiEntity>();
        params.put("sort", "id");
        params.put("order", "desc");
        PageUtils page = zhongyaoyaocaiService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, zhongyaoyaocai), params), params));
        List<ZhongyaoyaocaiEntity> pageList = (List<ZhongyaoyaocaiEntity>)page.getList();
        if(zhongyaoyaocaiList.size()<limit) {
            int toAddNum = (limit-zhongyaoyaocaiList.size())<=pageList.size()?(limit-zhongyaoyaocaiList.size()):pageList.size();
            for(ZhongyaoyaocaiEntity o1 : pageList) {
                boolean addFlag = true;
                for(ZhongyaoyaocaiEntity o2 : zhongyaoyaocaiList) {
                    if(o1.getId().intValue()==o2.getId().intValue()) {
                        addFlag = false;
                        break;
                    }
                }
                if(addFlag) {
                    zhongyaoyaocaiList.add(o1);
                    if(--toAddNum==0) break;
                }
            }
        } else if(zhongyaoyaocaiList.size()>limit) {
            zhongyaoyaocaiList = zhongyaoyaocaiList.subList(0, limit);
        }
        page.setList(zhongyaoyaocaiList);
        return R.ok().put("data", page);
    }








}
