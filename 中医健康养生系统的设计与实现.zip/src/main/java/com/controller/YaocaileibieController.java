package com.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import com.utils.ValidatorUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.annotation.IgnoreAuth;

import com.entity.YaocaileibieEntity;
import com.entity.view.YaocaileibieView;

import com.service.YaocaileibieService;
import com.service.TokenService;
import com.utils.PageUtils;
import com.utils.R;
import com.utils.MPUtil;
import com.utils.MapUtils;
import com.utils.CommonUtil;
import java.io.IOException;

/**
 * 药材类别
 * 后端接口
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
@RestController
@RequestMapping("/yaocaileibie")
public class YaocaileibieController {
    @Autowired
    private YaocaileibieService yaocaileibieService;




    



    /**
     * 后台列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params,YaocaileibieEntity yaocaileibie,
		HttpServletRequest request){
        EntityWrapper<YaocaileibieEntity> ew = new EntityWrapper<YaocaileibieEntity>();

		PageUtils page = yaocaileibieService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, yaocaileibie), params), params));

        return R.ok().put("data", page);
    }
    
    /**
     * 前台列表
     */
	@IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params,YaocaileibieEntity yaocaileibie, 
		HttpServletRequest request){
        EntityWrapper<YaocaileibieEntity> ew = new EntityWrapper<YaocaileibieEntity>();

		PageUtils page = yaocaileibieService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, yaocaileibie), params), params));
        return R.ok().put("data", page);
    }



	/**
     * 列表
     */
    @RequestMapping("/lists")
    public R list( YaocaileibieEntity yaocaileibie){
       	EntityWrapper<YaocaileibieEntity> ew = new EntityWrapper<YaocaileibieEntity>();
      	ew.allEq(MPUtil.allEQMapPre( yaocaileibie, "yaocaileibie")); 
        return R.ok().put("data", yaocaileibieService.selectListView(ew));
    }

	 /**
     * 查询
     */
    @RequestMapping("/query")
    public R query(YaocaileibieEntity yaocaileibie){
        EntityWrapper< YaocaileibieEntity> ew = new EntityWrapper< YaocaileibieEntity>();
 		ew.allEq(MPUtil.allEQMapPre( yaocaileibie, "yaocaileibie")); 
		YaocaileibieView yaocaileibieView =  yaocaileibieService.selectView(ew);
		return R.ok("查询药材类别成功").put("data", yaocaileibieView);
    }
	
    /**
     * 后台详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id){
        YaocaileibieEntity yaocaileibie = yaocaileibieService.selectById(id);
        return R.ok().put("data", yaocaileibie);
    }

    /**
     * 前台详情
     */
	@IgnoreAuth
    @RequestMapping("/detail/{id}")
    public R detail(@PathVariable("id") Long id){
        YaocaileibieEntity yaocaileibie = yaocaileibieService.selectById(id);
        return R.ok().put("data", yaocaileibie);
    }
    



    /**
     * 后台保存
     */
    @RequestMapping("/save")
    public R save(@RequestBody YaocaileibieEntity yaocaileibie, HttpServletRequest request){
    	//ValidatorUtils.validateEntity(yaocaileibie);
        yaocaileibieService.insert(yaocaileibie);
        return R.ok();
    }
    
    /**
     * 前台保存
     */
    @RequestMapping("/add")
    public R add(@RequestBody YaocaileibieEntity yaocaileibie, HttpServletRequest request){
    	//ValidatorUtils.validateEntity(yaocaileibie);
        yaocaileibieService.insert(yaocaileibie);
        return R.ok();
    }





    /**
     * 修改
     */
    @RequestMapping("/update")
    @Transactional
    public R update(@RequestBody YaocaileibieEntity yaocaileibie, HttpServletRequest request){
        //ValidatorUtils.validateEntity(yaocaileibie);
        yaocaileibieService.updateById(yaocaileibie);//全部更新
        return R.ok();
    }



    

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Long[] ids){
        yaocaileibieService.deleteBatchIds(Arrays.asList(ids));
        return R.ok();
    }
    
	










}
