package com.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import com.utils.ValidatorUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.annotation.IgnoreAuth;

import com.entity.YangshengfanganEntity;
import com.entity.view.YangshengfanganView;

import com.service.YangshengfanganService;
import com.service.TokenService;
import com.utils.PageUtils;
import com.utils.R;
import com.utils.MPUtil;
import com.utils.MapUtils;
import com.utils.CommonUtil;
import java.io.IOException;

/**
 * 养生方案
 * 后端接口
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
@RestController
@RequestMapping("/yangshengfangan")
public class YangshengfanganController {
    @Autowired
    private YangshengfanganService yangshengfanganService;




    



    /**
     * 后台列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params,YangshengfanganEntity yangshengfangan,
		HttpServletRequest request){
		String tableName = request.getSession().getAttribute("tableName").toString();
		if(tableName.equals("yonghu")) {
			yangshengfangan.setYonghuzhanghao((String)request.getSession().getAttribute("username"));
		}
        EntityWrapper<YangshengfanganEntity> ew = new EntityWrapper<YangshengfanganEntity>();

		PageUtils page = yangshengfanganService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, yangshengfangan), params), params));

        return R.ok().put("data", page);
    }
    
    /**
     * 前台列表
     */
	@IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params,YangshengfanganEntity yangshengfangan, 
		HttpServletRequest request){
        EntityWrapper<YangshengfanganEntity> ew = new EntityWrapper<YangshengfanganEntity>();

		PageUtils page = yangshengfanganService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, yangshengfangan), params), params));
        return R.ok().put("data", page);
    }



	/**
     * 列表
     */
    @RequestMapping("/lists")
    public R list( YangshengfanganEntity yangshengfangan){
       	EntityWrapper<YangshengfanganEntity> ew = new EntityWrapper<YangshengfanganEntity>();
      	ew.allEq(MPUtil.allEQMapPre( yangshengfangan, "yangshengfangan")); 
        return R.ok().put("data", yangshengfanganService.selectListView(ew));
    }

	 /**
     * 查询
     */
    @RequestMapping("/query")
    public R query(YangshengfanganEntity yangshengfangan){
        EntityWrapper< YangshengfanganEntity> ew = new EntityWrapper< YangshengfanganEntity>();
 		ew.allEq(MPUtil.allEQMapPre( yangshengfangan, "yangshengfangan")); 
		YangshengfanganView yangshengfanganView =  yangshengfanganService.selectView(ew);
		return R.ok("查询养生方案成功").put("data", yangshengfanganView);
    }
	
    /**
     * 后台详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id){
        YangshengfanganEntity yangshengfangan = yangshengfanganService.selectById(id);
        return R.ok().put("data", yangshengfangan);
    }

    /**
     * 前台详情
     */
	@IgnoreAuth
    @RequestMapping("/detail/{id}")
    public R detail(@PathVariable("id") Long id){
        YangshengfanganEntity yangshengfangan = yangshengfanganService.selectById(id);
        return R.ok().put("data", yangshengfangan);
    }
    



    /**
     * 后台保存
     */
    @RequestMapping("/save")
    public R save(@RequestBody YangshengfanganEntity yangshengfangan, HttpServletRequest request){
    	//ValidatorUtils.validateEntity(yangshengfangan);
        yangshengfanganService.insert(yangshengfangan);
        return R.ok();
    }
    
    /**
     * 前台保存
     */
    @RequestMapping("/add")
    public R add(@RequestBody YangshengfanganEntity yangshengfangan, HttpServletRequest request){
    	//ValidatorUtils.validateEntity(yangshengfangan);
        yangshengfanganService.insert(yangshengfangan);
        return R.ok();
    }





    /**
     * 修改
     */
    @RequestMapping("/update")
    @Transactional
    public R update(@RequestBody YangshengfanganEntity yangshengfangan, HttpServletRequest request){
        //ValidatorUtils.validateEntity(yangshengfangan);
        yangshengfanganService.updateById(yangshengfangan);//全部更新
        return R.ok();
    }



    

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Long[] ids){
        yangshengfanganService.deleteBatchIds(Arrays.asList(ids));
        return R.ok();
    }
    
	










}
