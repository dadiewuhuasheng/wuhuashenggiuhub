package com.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import com.utils.ValidatorUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.annotation.IgnoreAuth;

import com.entity.YangshengzhishiEntity;
import com.entity.view.YangshengzhishiView;

import com.service.YangshengzhishiService;
import com.service.TokenService;
import com.utils.PageUtils;
import com.utils.R;
import com.utils.MPUtil;
import com.utils.MapUtils;
import com.utils.CommonUtil;
import java.io.IOException;
import com.service.StoreupService;
import com.entity.StoreupEntity;

/**
 * 养生知识
 * 后端接口
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
@RestController
@RequestMapping("/yangshengzhishi")
public class YangshengzhishiController {
    @Autowired
    private YangshengzhishiService yangshengzhishiService;

    @Autowired
    private StoreupService storeupService;



    



    /**
     * 后台列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params,YangshengzhishiEntity yangshengzhishi,
		HttpServletRequest request){
        EntityWrapper<YangshengzhishiEntity> ew = new EntityWrapper<YangshengzhishiEntity>();

		PageUtils page = yangshengzhishiService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, yangshengzhishi), params), params));

        return R.ok().put("data", page);
    }
    
    /**
     * 前台列表
     */
	@IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params,YangshengzhishiEntity yangshengzhishi, 
		HttpServletRequest request){
        EntityWrapper<YangshengzhishiEntity> ew = new EntityWrapper<YangshengzhishiEntity>();

		PageUtils page = yangshengzhishiService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, yangshengzhishi), params), params));
        return R.ok().put("data", page);
    }



	/**
     * 列表
     */
    @RequestMapping("/lists")
    public R list( YangshengzhishiEntity yangshengzhishi){
       	EntityWrapper<YangshengzhishiEntity> ew = new EntityWrapper<YangshengzhishiEntity>();
      	ew.allEq(MPUtil.allEQMapPre( yangshengzhishi, "yangshengzhishi")); 
        return R.ok().put("data", yangshengzhishiService.selectListView(ew));
    }

	 /**
     * 查询
     */
    @RequestMapping("/query")
    public R query(YangshengzhishiEntity yangshengzhishi){
        EntityWrapper< YangshengzhishiEntity> ew = new EntityWrapper< YangshengzhishiEntity>();
 		ew.allEq(MPUtil.allEQMapPre( yangshengzhishi, "yangshengzhishi")); 
		YangshengzhishiView yangshengzhishiView =  yangshengzhishiService.selectView(ew);
		return R.ok("查询养生知识成功").put("data", yangshengzhishiView);
    }
	
    /**
     * 后台详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id){
        YangshengzhishiEntity yangshengzhishi = yangshengzhishiService.selectById(id);
        return R.ok().put("data", yangshengzhishi);
    }

    /**
     * 前台详情
     */
	@IgnoreAuth
    @RequestMapping("/detail/{id}")
    public R detail(@PathVariable("id") Long id){
        YangshengzhishiEntity yangshengzhishi = yangshengzhishiService.selectById(id);
        return R.ok().put("data", yangshengzhishi);
    }
    


    /**
     * 赞或踩
     */
    @RequestMapping("/thumbsup/{id}")
    public R vote(@PathVariable("id") String id,String type){
        YangshengzhishiEntity yangshengzhishi = yangshengzhishiService.selectById(id);
        if(type.equals("1")) {
        	yangshengzhishi.setThumbsupnum(yangshengzhishi.getThumbsupnum()+1);
        } else {
        	yangshengzhishi.setCrazilynum(yangshengzhishi.getCrazilynum()+1);
        }
        yangshengzhishiService.updateById(yangshengzhishi);
        return R.ok("投票成功");
    }

    /**
     * 后台保存
     */
    @RequestMapping("/save")
    public R save(@RequestBody YangshengzhishiEntity yangshengzhishi, HttpServletRequest request){
    	//ValidatorUtils.validateEntity(yangshengzhishi);
        yangshengzhishiService.insert(yangshengzhishi);
        return R.ok();
    }
    
    /**
     * 前台保存
     */
    @RequestMapping("/add")
    public R add(@RequestBody YangshengzhishiEntity yangshengzhishi, HttpServletRequest request){
    	//ValidatorUtils.validateEntity(yangshengzhishi);
        yangshengzhishiService.insert(yangshengzhishi);
        return R.ok();
    }





    /**
     * 修改
     */
    @RequestMapping("/update")
    @Transactional
    public R update(@RequestBody YangshengzhishiEntity yangshengzhishi, HttpServletRequest request){
        //ValidatorUtils.validateEntity(yangshengzhishi);
        yangshengzhishiService.updateById(yangshengzhishi);//全部更新
        return R.ok();
    }



    

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Long[] ids){
        yangshengzhishiService.deleteBatchIds(Arrays.asList(ids));
        return R.ok();
    }
    
	










}
