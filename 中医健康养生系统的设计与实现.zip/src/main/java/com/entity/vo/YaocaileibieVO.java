package com.entity.vo;

import com.entity.YaocaileibieEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 药材类别
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
public class YaocaileibieVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 				
}
