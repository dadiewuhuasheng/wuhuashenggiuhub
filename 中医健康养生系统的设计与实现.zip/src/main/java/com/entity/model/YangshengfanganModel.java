package com.entity.model;

import com.entity.YangshengfanganEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 养生方案
 * 接收传参的实体类  
 *（实际开发中配合移动端接口开发手动去掉些没用的字段， 后端一般用entity就够用了） 
 * 取自ModelAndView 的model名称
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
public class YangshengfanganModel  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 用户账号
	 */
	
	private String yonghuzhanghao;
		
	/**
	 * 用户姓名
	 */
	
	private String yonghuxingming;
		
	/**
	 * 头像
	 */
	
	private String touxiang;
		
	/**
	 * 推荐原因
	 */
	
	private String tuijianyuanyin;
		
	/**
	 * 方案内容
	 */
	
	private String fanganneirong;
		
	/**
	 * 药材名称
	 */
	
	private String yaocaimingcheng;
		
	/**
	 * 药材类别
	 */
	
	private String allyaocaileibie;
		
	/**
	 * 用量
	 */
	
	private String yongliang;
		
	/**
	 * 使用方法
	 */
	
	private String shiyongfangfa;
		
	/**
	 * 方案时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date fanganshijian;
				
	
	/**
	 * 设置：用户账号
	 */
	 
	public void setYonghuzhanghao(String yonghuzhanghao) {
		this.yonghuzhanghao = yonghuzhanghao;
	}
	
	/**
	 * 获取：用户账号
	 */
	public String getYonghuzhanghao() {
		return yonghuzhanghao;
	}
				
	
	/**
	 * 设置：用户姓名
	 */
	 
	public void setYonghuxingming(String yonghuxingming) {
		this.yonghuxingming = yonghuxingming;
	}
	
	/**
	 * 获取：用户姓名
	 */
	public String getYonghuxingming() {
		return yonghuxingming;
	}
				
	
	/**
	 * 设置：头像
	 */
	 
	public void setTouxiang(String touxiang) {
		this.touxiang = touxiang;
	}
	
	/**
	 * 获取：头像
	 */
	public String getTouxiang() {
		return touxiang;
	}
				
	
	/**
	 * 设置：推荐原因
	 */
	 
	public void setTuijianyuanyin(String tuijianyuanyin) {
		this.tuijianyuanyin = tuijianyuanyin;
	}
	
	/**
	 * 获取：推荐原因
	 */
	public String getTuijianyuanyin() {
		return tuijianyuanyin;
	}
				
	
	/**
	 * 设置：方案内容
	 */
	 
	public void setFanganneirong(String fanganneirong) {
		this.fanganneirong = fanganneirong;
	}
	
	/**
	 * 获取：方案内容
	 */
	public String getFanganneirong() {
		return fanganneirong;
	}
				
	
	/**
	 * 设置：药材名称
	 */
	 
	public void setYaocaimingcheng(String yaocaimingcheng) {
		this.yaocaimingcheng = yaocaimingcheng;
	}
	
	/**
	 * 获取：药材名称
	 */
	public String getYaocaimingcheng() {
		return yaocaimingcheng;
	}
				
	
	/**
	 * 设置：药材类别
	 */
	 
	public void setAllyaocaileibie(String allyaocaileibie) {
		this.allyaocaileibie = allyaocaileibie;
	}
	
	/**
	 * 获取：药材类别
	 */
	public String getAllyaocaileibie() {
		return allyaocaileibie;
	}
				
	
	/**
	 * 设置：用量
	 */
	 
	public void setYongliang(String yongliang) {
		this.yongliang = yongliang;
	}
	
	/**
	 * 获取：用量
	 */
	public String getYongliang() {
		return yongliang;
	}
				
	
	/**
	 * 设置：使用方法
	 */
	 
	public void setShiyongfangfa(String shiyongfangfa) {
		this.shiyongfangfa = shiyongfangfa;
	}
	
	/**
	 * 获取：使用方法
	 */
	public String getShiyongfangfa() {
		return shiyongfangfa;
	}
				
	
	/**
	 * 设置：方案时间
	 */
	 
	public void setFanganshijian(Date fanganshijian) {
		this.fanganshijian = fanganshijian;
	}
	
	/**
	 * 获取：方案时间
	 */
	public Date getFanganshijian() {
		return fanganshijian;
	}
			
}
