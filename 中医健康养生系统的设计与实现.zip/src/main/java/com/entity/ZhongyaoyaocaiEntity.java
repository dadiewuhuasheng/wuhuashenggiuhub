package com.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.lang.reflect.InvocationTargetException;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.beanutils.BeanUtils;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.baomidou.mybatisplus.enums.IdType;


/**
 * 中药药材
 * 数据库通用操作实体类（普通增删改查）
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
@TableName("zhongyaoyaocai")
public class ZhongyaoyaocaiEntity<T> implements Serializable {
	private static final long serialVersionUID = 1L;


	public ZhongyaoyaocaiEntity() {
		
	}
	
	public ZhongyaoyaocaiEntity(T t) {
		try {
			BeanUtils.copyProperties(this, t);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 主键id
	 */
    @TableId(type = IdType.AUTO)
    private Long id;
	/**
	 * 药材名称
	 */
					
	private String yaocaimingcheng;
	
	/**
	 * 药材类别
	 */
					
	private String yaocaileibie;
	
	/**
	 * 药性
	 */
					
	private String yaoxing;
	
	/**
	 * 来源
	 */
					
	private String laiyuan;
	
	/**
	 * 功能主治
	 */
					
	private String gongnengzhuzhi;
	
	/**
	 * 药材功效
	 */
					
	private String yaocaigongxiao;
	
	/**
	 * 药品图片
	 */
					
	private String yaopintupian;
	
	/**
	 * 存储条件
	 */
					
	private String cunchutiaojian;
	
	/**
	 * 禁忌
	 */
					
	private String jinji;
	
	/**
	 * 详细说明
	 */
					
	private String xiangxishuoming;
	
	/**
	 * 赞
	 */
					
	private Integer thumbsupnum;
	
	/**
	 * 踩
	 */
					
	private Integer crazilynum;
	
	/**
	 * 最近点击时间
	 */
				
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 		
	private Date clicktime;
	
	/**
	 * 点击次数
	 */
					
	private Integer clicknum;
	
	/**
	 * 评论数
	 */
					
	private Integer discussnum;
	
	/**
	 * 收藏数
	 */
					
	private Integer storeupnum;
	
	
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat
	private Date addtime;

	public Date getAddtime() {
		return addtime;
	}
	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 设置：药材名称
	 */
	public void setYaocaimingcheng(String yaocaimingcheng) {
		this.yaocaimingcheng = yaocaimingcheng;
	}
	/**
	 * 获取：药材名称
	 */
	public String getYaocaimingcheng() {
		return yaocaimingcheng;
	}
	/**
	 * 设置：药材类别
	 */
	public void setYaocaileibie(String yaocaileibie) {
		this.yaocaileibie = yaocaileibie;
	}
	/**
	 * 获取：药材类别
	 */
	public String getYaocaileibie() {
		return yaocaileibie;
	}
	/**
	 * 设置：药性
	 */
	public void setYaoxing(String yaoxing) {
		this.yaoxing = yaoxing;
	}
	/**
	 * 获取：药性
	 */
	public String getYaoxing() {
		return yaoxing;
	}
	/**
	 * 设置：来源
	 */
	public void setLaiyuan(String laiyuan) {
		this.laiyuan = laiyuan;
	}
	/**
	 * 获取：来源
	 */
	public String getLaiyuan() {
		return laiyuan;
	}
	/**
	 * 设置：功能主治
	 */
	public void setGongnengzhuzhi(String gongnengzhuzhi) {
		this.gongnengzhuzhi = gongnengzhuzhi;
	}
	/**
	 * 获取：功能主治
	 */
	public String getGongnengzhuzhi() {
		return gongnengzhuzhi;
	}
	/**
	 * 设置：药材功效
	 */
	public void setYaocaigongxiao(String yaocaigongxiao) {
		this.yaocaigongxiao = yaocaigongxiao;
	}
	/**
	 * 获取：药材功效
	 */
	public String getYaocaigongxiao() {
		return yaocaigongxiao;
	}
	/**
	 * 设置：药品图片
	 */
	public void setYaopintupian(String yaopintupian) {
		this.yaopintupian = yaopintupian;
	}
	/**
	 * 获取：药品图片
	 */
	public String getYaopintupian() {
		return yaopintupian;
	}
	/**
	 * 设置：存储条件
	 */
	public void setCunchutiaojian(String cunchutiaojian) {
		this.cunchutiaojian = cunchutiaojian;
	}
	/**
	 * 获取：存储条件
	 */
	public String getCunchutiaojian() {
		return cunchutiaojian;
	}
	/**
	 * 设置：禁忌
	 */
	public void setJinji(String jinji) {
		this.jinji = jinji;
	}
	/**
	 * 获取：禁忌
	 */
	public String getJinji() {
		return jinji;
	}
	/**
	 * 设置：详细说明
	 */
	public void setXiangxishuoming(String xiangxishuoming) {
		this.xiangxishuoming = xiangxishuoming;
	}
	/**
	 * 获取：详细说明
	 */
	public String getXiangxishuoming() {
		return xiangxishuoming;
	}
	/**
	 * 设置：赞
	 */
	public void setThumbsupnum(Integer thumbsupnum) {
		this.thumbsupnum = thumbsupnum;
	}
	/**
	 * 获取：赞
	 */
	public Integer getThumbsupnum() {
		return thumbsupnum;
	}
	/**
	 * 设置：踩
	 */
	public void setCrazilynum(Integer crazilynum) {
		this.crazilynum = crazilynum;
	}
	/**
	 * 获取：踩
	 */
	public Integer getCrazilynum() {
		return crazilynum;
	}
	/**
	 * 设置：最近点击时间
	 */
	public void setClicktime(Date clicktime) {
		this.clicktime = clicktime;
	}
	/**
	 * 获取：最近点击时间
	 */
	public Date getClicktime() {
		return clicktime;
	}
	/**
	 * 设置：点击次数
	 */
	public void setClicknum(Integer clicknum) {
		this.clicknum = clicknum;
	}
	/**
	 * 获取：点击次数
	 */
	public Integer getClicknum() {
		return clicknum;
	}
	/**
	 * 设置：评论数
	 */
	public void setDiscussnum(Integer discussnum) {
		this.discussnum = discussnum;
	}
	/**
	 * 获取：评论数
	 */
	public Integer getDiscussnum() {
		return discussnum;
	}
	/**
	 * 设置：收藏数
	 */
	public void setStoreupnum(Integer storeupnum) {
		this.storeupnum = storeupnum;
	}
	/**
	 * 获取：收藏数
	 */
	public Integer getStoreupnum() {
		return storeupnum;
	}

}
