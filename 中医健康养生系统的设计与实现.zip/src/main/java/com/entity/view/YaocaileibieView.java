package com.entity.view;

import com.entity.YaocaileibieEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import org.apache.commons.beanutils.BeanUtils;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;

import java.io.Serializable;
import com.utils.EncryptUtil;
 

/**
 * 药材类别
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 * @date 2024-04-20 14:25:49
 */
@TableName("yaocaileibie")
public class YaocaileibieView  extends YaocaileibieEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public YaocaileibieView(){
	}
 
 	public YaocaileibieView(YaocaileibieEntity yaocaileibieEntity){
 	try {
			BeanUtils.copyProperties(this, yaocaileibieEntity);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}


}
