package com.entity.view;

import com.entity.DiscusszhongyaoyaocaiEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import org.apache.commons.beanutils.BeanUtils;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;

import java.io.Serializable;
import com.utils.EncryptUtil;
 

/**
 * 中药药材评论表
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 * @date 2024-04-20 14:25:50
 */
@TableName("discusszhongyaoyaocai")
public class DiscusszhongyaoyaocaiView  extends DiscusszhongyaoyaocaiEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public DiscusszhongyaoyaocaiView(){
	}
 
 	public DiscusszhongyaoyaocaiView(DiscusszhongyaoyaocaiEntity discusszhongyaoyaocaiEntity){
 	try {
			BeanUtils.copyProperties(this, discusszhongyaoyaocaiEntity);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}


}
