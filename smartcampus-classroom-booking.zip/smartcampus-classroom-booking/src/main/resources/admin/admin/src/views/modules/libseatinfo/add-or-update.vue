<template>
	<div class="addEdit-block" :style='{"padding":"30px"}' style="width: 100%;">
		<el-form
			:style='{"padding":"30px","boxShadow":"0 0px 0px #999","borderRadius":"6px","background":"url(http://codegen.caihongy.cn/20221014/5e767dc0afa649ec9fbc71f9da086ab3.jpg)"}'
			class="add-update-preview"
			ref="ruleForm"
			:model="ruleForm"
			:rules="rules"
			label-width="80px"
		>
			<template >
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="input" v-if="type!='info'"  label="座位名称" prop="libseatmingcheng">
					<el-input v-model="ruleForm.libseatmingcheng" placeholder="座位名称" clearable  :readonly="ro.libseatmingcheng"></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-else class="input" label="座位名称" prop="libseatmingcheng">
					<el-input v-model="ruleForm.libseatmingcheng" placeholder="座位名称" readonly></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="select" v-if="type!='info'"  label="教室类型" prop="libseattype">
					<el-select :disabled="ro.libseattype" v-model="ruleForm.libseattype" placeholder="请选择教室类型" >
						<el-option
							v-for="(item,index) in libseattypeOptions"
							v-bind:key="index"
							:label="item"
							:value="item">
						</el-option>
					</el-select>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-else class="input" label="教室类型" prop="libseattype">
					<el-input v-model="ruleForm.libseattype"
						placeholder="教室类型" readonly></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="upload" v-if="type!='info' && !ro.libseatpicture" label="座位封面" prop="libseatpicture">
					<file-upload
						tip="点击上传座位封面"
						action="file/upload"
						:limit="3"
						:multiple="true"
						:fileUrls="ruleForm.libseatpicture?ruleForm.libseatpicture:''"
						@change="libseatpictureUploadChange"
					></file-upload>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="upload" v-else-if="ruleForm.libseatpicture" label="座位封面" prop="libseatpicture">
					<img v-if="ruleForm.libseatpicture.substring(0,4)=='http'" class="upload-img" style="margin-right:20px;" v-bind:key="index" :src="ruleForm.libseatpicture.split(',')[0]" width="100" height="100">
					<img v-else class="upload-img" style="margin-right:20px;" v-bind:key="index" v-for="(item,index) in ruleForm.libseatpicture.split(',')" :src="$base.url+item" width="100" height="100">
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="input" v-if="type!='info'"  label="座位票数" prop="libseatpiaoshu">
					<el-input v-model="ruleForm.libseatpiaoshu" placeholder="座位票数" clearable  :readonly="ro.libseatpiaoshu"></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-else class="input" label="座位票数" prop="libseatpiaoshu">
					<el-input v-model="ruleForm.libseatpiaoshu" placeholder="座位票数" readonly></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="upload" v-if="type!='info'&& !ro.libseatpianduan" label="座位片段" prop="libseatpianduan">
					<file-upload
						tip="点击上传座位片段"
						action="file/upload"
						:limit="1"
						:multiple="true"
						:fileUrls="ruleForm.libseatpianduan?ruleForm.libseatpianduan:''"
						@change="libseatpianduanUploadChange"
					></file-upload>
				</el-form-item> 
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-else-if="ruleForm.libseatpianduan" label="座位片段" prop="libseatpianduan">
					<el-button :style='{"border":"1px solid #128f90","cursor":"pointer","padding":"0 24px","margin":"0 20px 0 0","outline":"none","color":"rgba(255, 255, 255, 1)","borderRadius":"4px","background":"-webkit-linear-gradient(top,#2fc1c2,#037f80)","width":"auto","lineHeight":"40px","fontSize":"14px","height":"40px"}' type="text" size="small" @click="download($base.url+ruleForm.libseatpianduan)">预览</el-button>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-else-if="!ruleForm.libseatpianduan" label="座位片段" prop="libseatpianduan">
					<el-button :style='{"border":"1px solid #128f90","cursor":"pointer","padding":"0 24px","margin":"0 20px 0 0","outline":"none","color":"rgba(255, 255, 255, 1)","borderRadius":"4px","background":"-webkit-linear-gradient(top,#2fc1c2,#037f80)","width":"auto","lineHeight":"40px","fontSize":"14px","height":"40px"}' type="text" size="small">无</el-button>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="input" v-if="type!='info'"  label="座位区域" prop="libseataddress">
					<el-input v-model="ruleForm.libseataddress" placeholder="座位区域" clearable  :readonly="ro.libseataddress"></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-else class="input" label="座位区域" prop="libseataddress">
					<el-input v-model="ruleForm.libseataddress" placeholder="座位区域" readonly></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="input" v-if="type!='info'"  label="场次" prop="changci">
					<el-input v-model="ruleForm.changci" placeholder="场次" clearable  :readonly="ro.changci"></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-else class="input" label="场次" prop="changci">
					<el-input v-model="ruleForm.changci" placeholder="场次" readonly></el-input>
				</el-form-item>
				<!-- <el-form-item :style='{"margin":"0 0 20px 0"}' class="input" v-if="type!='info'"  label="座位语言" prop="libseatyuyan">
					<el-input v-model="ruleForm.libseatyuyan" placeholder="座位语言" clearable  :readonly="ro.libseatyuyan"></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-else class="input" label="座位语言" prop="libseatyuyan">
					<el-input v-model="ruleForm.libseatyuyan" placeholder="座位语言" readonly></el-input>
				</el-form-item> -->
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="input" v-if="type!='info'"  label="主办方" prop="daoyan">
					<el-input v-model="ruleForm.daoyan" placeholder="主办方" clearable  :readonly="ro.daoyan"></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-else class="input" label="主办方" prop="daoyan">
					<el-input v-model="ruleForm.daoyan" placeholder="主办方" readonly></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="date" v-if="type!='info'" label="座位时间" prop="shangyingtime">
					<el-date-picker
						format="yyyy 年 MM 月 dd 日"
						value-format="yyyy-MM-dd"
						v-model="ruleForm.shangyingtime"
						type="date"
						:readonly="ro.shangyingtime"
						placeholder="座位时间"
					></el-date-picker> 
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="input" v-else-if="ruleForm.shangyingtime" label="座位时间" prop="shangyingtime">
					<el-input v-model="ruleForm.shangyingtime" placeholder="座位时间" readonly></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="input" v-if="type!='info'"  label="价格" prop="price">
					<el-input v-model="ruleForm.price" placeholder="价格" clearable  :readonly="ro.price"></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-else class="input" label="价格" prop="price">
					<el-input v-model="ruleForm.price" placeholder="价格" readonly></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="input" v-if="type!='info'"  label="座位总数" prop="number">
					<el-input v-model="ruleForm.number" placeholder="座位总数" clearable  :readonly="ro.number"></el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-else class="input" label="座位总数" prop="number">
					<el-input v-model="ruleForm.number" placeholder="座位总数" readonly></el-input>
				</el-form-item>
			</template>
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="textarea" v-if="type!='info'" label="参赛选手" prop="zhuyan">
					<el-input
					  style="min-width: 200px; max-width: 600px;"
					  type="textarea"
					  :rows="8"
					  placeholder="参赛选手"
					  v-model="ruleForm.zhuyan" >
					</el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-else-if="ruleForm.zhuyan" label="参赛选手" prop="zhuyan">
					<span :style='{"fontSize":"14px","lineHeight":"40px","color":"#00a9aa","fontWeight":"500","display":"inline-block"}'>{{ruleForm.zhuyan}}</span>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' class="textarea" v-if="type!='info'" label="已选座位[用,号隔开]" prop="selected">
					<el-input
					  style="min-width: 200px; max-width: 600px;"
					  type="textarea"
					  :rows="8"
					  placeholder="已选座位[用,号隔开]"
					  v-model="ruleForm.selected" >
					</el-input>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-else-if="ruleForm.selected" label="已选座位[用,号隔开]" prop="selected">
					<span :style='{"fontSize":"14px","lineHeight":"40px","color":"#00a9aa","fontWeight":"500","display":"inline-block"}'>{{ruleForm.selected}}</span>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-if="type!='info'"  label="座位简介" prop="libseatintro">
					<editor 
						style="min-width: 200px; max-width: 600px;"
						v-model="ruleForm.libseatintro"
						class="editor" 
						action="file/upload">
					</editor>
				</el-form-item>
				<el-form-item :style='{"margin":"0 0 20px 0"}' v-else-if="ruleForm.libseatintro" label="座位简介" prop="libseatintro">
                    <span :style='{"fontSize":"14px","lineHeight":"40px","color":"#00a9aa","fontWeight":"500","display":"inline-block"}' v-html="ruleForm.libseatintro"></span>
                </el-form-item>
			<el-form-item :style='{"padding":"0","margin":"0"}' class="btn">
				<el-button :style='{"border":"1px solid #5e9808","cursor":"pointer","padding":"0","margin":"0 20px 0 0","outline":"none","color":"rgba(255, 255, 255, 1)","borderRadius":"4px","background":"-webkit-linear-gradient(top,#96d148,#4a7f06)","width":"128px","lineHeight":"40px","fontSize":"14px","height":"40px"}'  v-if="type!='info'" type="primary" class="btn-success" @click="onSubmit">提交</el-button>
				<el-button :style='{"border":"1px solid #ccc","cursor":"pointer","padding":"0","margin":"0","outline":"none","color":"#5b8020","borderRadius":"4px","background":"-webkit-linear-gradient(top,#fff,#ccc)","width":"128px","lineHeight":"40px","fontSize":"14px","height":"40px"}' v-if="type!='info'" class="btn-close" @click="back()">取消</el-button>
				<el-button :style='{"border":"1px solid #ccc","cursor":"pointer","padding":"0","margin":"0","outline":"none","color":"#5b8020","borderRadius":"4px","background":"-webkit-linear-gradient(top,#fff,#ccc)","width":"128px","lineHeight":"40px","fontSize":"14px","height":"40px"}' v-if="type=='info'" class="btn-close" @click="back()">返回</el-button>
			</el-form-item>
		</el-form>
    

  </div>
</template>
<script>
// 数字，邮件，手机，url，身份证校验
import { isNumber,isIntNumer,isEmail,isPhone, isMobile,isURL,checkIdCard } from "@/utils/validate";
export default {
	data() {
		let self = this
		var validateIdCard = (rule, value, callback) => {
			if(!value){
				callback();
			} else if (!checkIdCard(value)) {
				callback(new Error("请输入正确的身份证号码"));
			} else {
				callback();
			}
		};
		var validateUrl = (rule, value, callback) => {
			if(!value){
				callback();
			} else if (!isURL(value)) {
				callback(new Error("请输入正确的URL地址"));
			} else {
				callback();
			}
		};
		var validateMobile = (rule, value, callback) => {
			if(!value){
				callback();
			} else if (!isMobile(value)) {
				callback(new Error("请输入正确的手机号码"));
			} else {
				callback();
			}
		};
		var validatePhone = (rule, value, callback) => {
			if(!value){
				callback();
			} else if (!isPhone(value)) {
				callback(new Error("请输入正确的电话号码"));
			} else {
				callback();
			}
		};
		var validateEmail = (rule, value, callback) => {
			if(!value){
				callback();
			} else if (!isEmail(value)) {
				callback(new Error("请输入正确的邮箱地址"));
			} else {
				callback();
			}
		};
		var validateNumber = (rule, value, callback) => {
			if(!value){
				callback();
			} else if (!isNumber(value)) {
				callback(new Error("请输入数字"));
			} else {
				callback();
			}
		};
		var validateIntNumber = (rule, value, callback) => {
			if(!value){
				callback();
			} else if (!isIntNumer(value)) {
				callback(new Error("请输入整数"));
			} else {
				callback();
			}
		};
		return {
			id: '',
			type: '',
			
			
			ro:{
				libseatmingcheng : false,
				libseattype : false,
				libseatpicture : false,
				libseatpiaoshu : false,
				libseatpianduan : false,
				libseataddress : false,
				changci : false,
				libseatyuyan : false,
				daoyan : false,
				zhuyan : false,
				libseatintro : false,
				shangyingtime : false,
				thumbsupnum : false,
				crazilynum : false,
				clicktime : false,
				clicknum : false,
				price : false,
				number : false,
				selected : false,
			},
			
			
			ruleForm: {
				libseatmingcheng: '',
				libseattype: '',
				libseatpicture: '',
				libseatpiaoshu: '',
				libseatpianduan: '',
				libseataddress: '',
				changci: '',
				libseatyuyan: '',
				daoyan: '',
				zhuyan: '',
				libseatintro: '',
				shangyingtime: '',
				clicktime: '',
				price: '',
				number: '',
				selected: '',
			},
		
			libseattypeOptions: [],
			
			rules: {
				libseatmingcheng: [
				],
				libseattype: [
				],
				libseatpicture: [
				],
				libseatpiaoshu: [
					{ validator: validateIntNumber, trigger: 'blur' },
				],
				libseatpianduan: [
				],
				libseataddress: [
				],
				changci: [
				],
				libseatyuyan: [
				],
				daoyan: [
				],
				zhuyan: [
				],
				libseatintro: [
				],
				shangyingtime: [
				],
				thumbsupnum: [
					{ validator: validateIntNumber, trigger: 'blur' },
				],
				crazilynum: [
					{ validator: validateIntNumber, trigger: 'blur' },
				],
				clicktime: [
				],
				clicknum: [
					{ validator: validateIntNumber, trigger: 'blur' },
				],
				price: [
					{ required: true, message: '价格不能为空', trigger: 'blur' },
					{ validator: validateNumber, trigger: 'blur' },
				],
				number: [
					{ validator: validateIntNumber, trigger: 'blur' },
				],
				selected: [
				],
			}
		};
	},
	props: ["parent"],
	computed: {



	},
    components: {
    },
	created() {
	},
	methods: {
		
		// 下载
		download(file){
			window.open(`${file}`)
		},
		// 初始化
		init(id,type) {
			if (id) {
				this.id = id;
				this.type = type;
			}
			if(this.type=='info'||this.type=='else'){
				this.info(id);
			}else if(this.type=='logistics'){
				this.logistics=false;
				this.info(id);
			}else if(this.type=='cross'){
				var obj = this.$storage.getObj('crossObj');
				for (var o in obj){
						if(o=='libseatmingcheng'){
							this.ruleForm.libseatmingcheng = obj[o];
							this.ro.libseatmingcheng = true;
							continue;
						}
						if(o=='libseattype'){
							this.ruleForm.libseattype = obj[o];
							this.ro.libseattype = true;
							continue;
						}
						if(o=='libseatpicture'){
							this.ruleForm.libseatpicture = obj[o];
							this.ro.libseatpicture = true;
							continue;
						}
						if(o=='libseatpiaoshu'){
							this.ruleForm.libseatpiaoshu = obj[o];
							this.ro.libseatpiaoshu = true;
							continue;
						}
						if(o=='libseatpianduan'){
							this.ruleForm.libseatpianduan = obj[o];
							this.ro.libseatpianduan = true;
							continue;
						}
						if(o=='libseataddress'){
							this.ruleForm.libseataddress = obj[o];
							this.ro.libseataddress = true;
							continue;
						}
						if(o=='changci'){
							this.ruleForm.changci = obj[o];
							this.ro.changci = true;
							continue;
						}
						if(o=='libseatyuyan'){
							this.ruleForm.libseatyuyan = obj[o];
							this.ro.libseatyuyan = true;
							continue;
						}
						if(o=='daoyan'){
							this.ruleForm.daoyan = obj[o];
							this.ro.daoyan = true;
							continue;
						}
						if(o=='zhuyan'){
							this.ruleForm.zhuyan = obj[o];
							this.ro.zhuyan = true;
							continue;
						}
						if(o=='libseatintro'){
							this.ruleForm.libseatintro = obj[o];
							this.ro.libseatintro = true;
							continue;
						}
						if(o=='shangyingtime'){
							this.ruleForm.shangyingtime = obj[o];
							this.ro.shangyingtime = true;
							continue;
						}
						if(o=='thumbsupnum'){
							this.ruleForm.thumbsupnum = obj[o];
							this.ro.thumbsupnum = true;
							continue;
						}
						if(o=='crazilynum'){
							this.ruleForm.crazilynum = obj[o];
							this.ro.crazilynum = true;
							continue;
						}
						if(o=='clicktime'){
							this.ruleForm.clicktime = obj[o];
							this.ro.clicktime = true;
							continue;
						}
						if(o=='clicknum'){
							this.ruleForm.clicknum = obj[o];
							this.ro.clicknum = true;
							continue;
						}
						if(o=='price'){
							this.ruleForm.price = obj[o];
							this.ro.price = true;
							continue;
						}
						if(o=='number'){
							this.ruleForm.number = obj[o];
							this.ro.number = true;
							continue;
						}
						if(o=='selected'){
							this.ruleForm.selected = obj[o];
							this.ro.selected = true;
							continue;
						}
				}
				



















			}
			
			
			// 获取用户信息
			this.$http({
				url: `${this.$storage.get('sessionTable')}/session`,
				method: "get"
			}).then(({ data }) => {
				if (data && data.code === 0) {
					
					var json = data.data;
				} else {
					this.$message.error(data.msg);
				}
			});
			
            this.$http({
				url: `option/libseattype/libseattype`,
				method: "get"
            }).then(({ data }) => {
				if (data && data.code === 0) {
					this.libseattypeOptions = data.data;
				} else {
					this.$message.error(data.msg);
				}
            });
			
		},
    // 多级联动参数

    info(id) {
      this.$http({
        url: `libseatinfo/info/${id}`,
        method: "get"
      }).then(({ data }) => {
        if (data && data.code === 0) {
        this.ruleForm = data.data;
        //解决前台上传图片后台不显示的问题
        let reg=new RegExp('../../../upload','g')//g代表全部
        this.ruleForm.libseatintro = this.ruleForm.libseatintro.replace(reg,'../../../smartcampusclassressys/upload');
        } else {
          this.$message.error(data.msg);
        }
      });
    },


    // 提交
    onSubmit() {






	if(this.ruleForm.libseatpicture!=null) {
		this.ruleForm.libseatpicture = this.ruleForm.libseatpicture.replace(new RegExp(this.$base.url,"g"),"");
	}




	if(this.ruleForm.libseatpianduan!=null) {
		this.ruleForm.libseatpianduan = this.ruleForm.libseatpianduan.replace(new RegExp(this.$base.url,"g"),"");
	}





























var objcross = this.$storage.getObj('crossObj');

      //更新跨表属性
       var crossuserid;
       var crossrefid;
       var crossoptnum;
       if(this.type=='cross'){
                var statusColumnName = this.$storage.get('statusColumnName');
                var statusColumnValue = this.$storage.get('statusColumnValue');
                if(statusColumnName!='') {
                        var obj = this.$storage.getObj('crossObj');
                       if(statusColumnName && !statusColumnName.startsWith("[")) {
                               for (var o in obj){
                                 if(o==statusColumnName){
                                   obj[o] = statusColumnValue;
                                 }
                               }
                               var table = this.$storage.get('crossTable');
                             this.$http({
                                 url: `${table}/update`,
                                 method: "post",
                                 data: obj
                               }).then(({ data }) => {});
                       } else {
                               crossuserid=this.$storage.get('userid');
                               crossrefid=obj['id'];
                               crossoptnum=this.$storage.get('statusColumnName');
                               crossoptnum=crossoptnum.replace(/\[/,"").replace(/\]/,"");
                        }
                }
        }
       this.$refs["ruleForm"].validate(valid => {
         if (valid) {
		 if(crossrefid && crossuserid) {
			 this.ruleForm.crossuserid = crossuserid;
			 this.ruleForm.crossrefid = crossrefid;
			let params = { 
				page: 1, 
				limit: 10, 
				crossuserid:this.ruleForm.crossuserid,
				crossrefid:this.ruleForm.crossrefid,
			} 
			this.$http({ 
				url: "libseatinfo/page",
				method: "get", 
				params: params 
			}).then(({ 
				data 
			}) => { 
				if (data && data.code === 0) { 
				       if(data.data.total>=crossoptnum) {
					     this.$message.error(this.$storage.get('tips'));
					       return false;
				       } else {
					 this.$http({
					   url: `libseatinfo/${!this.ruleForm.id ? "save" : "update"}`,
					   method: "post",
					   data: this.ruleForm
					 }).then(({ data }) => {
					   if (data && data.code === 0) {
					     this.$message({
					       message: "操作成功",
					       type: "success",
					       duration: 1500,
					       onClose: () => {
						 this.parent.showFlag = true;
						 this.parent.addOrUpdateFlag = false;
						 this.parent.libseatinfoCrossAddOrUpdateFlag = false;
						 this.parent.search();
						 this.parent.contentStyleChange();
					       }
					     });
					   } else {
					     this.$message.error(data.msg);
					   }
					 });

				       }
				} else { 
				} 
			});
		 } else {
			 this.$http({
			   url: `libseatinfo/${!this.ruleForm.id ? "save" : "update"}`,
			   method: "post",
			   data: this.ruleForm
			 }).then(({ data }) => {
			   if (data && data.code === 0) {
			     this.$message({
			       message: "操作成功",
			       type: "success",
			       duration: 1500,
			       onClose: () => {
				 this.parent.showFlag = true;
				 this.parent.addOrUpdateFlag = false;
				 this.parent.libseatinfoCrossAddOrUpdateFlag = false;
				 this.parent.search();
				 this.parent.contentStyleChange();
			       }
			     });
			   } else {
			     this.$message.error(data.msg);
			   }
			 });
		 }
         }
       });
    },
    // 获取uuid
    getUUID () {
      return new Date().getTime();
    },
    // 返回
    back() {
      this.parent.showFlag = true;
      this.parent.addOrUpdateFlag = false;
      this.parent.libseatinfoCrossAddOrUpdateFlag = false;
      this.parent.contentStyleChange();
    },
    libseatpictureUploadChange(fileUrls) {
	    this.ruleForm.libseatpicture = fileUrls;
    },
    libseatpianduanUploadChange(fileUrls) {
	    this.ruleForm.libseatpianduan = fileUrls;
    },
  }
};
</script>
<style lang="scss" scoped>
	.amap-wrapper {
		width: 100%;
		height: 500px;
	}
	
	.search-box {
		position: absolute;
	}
	
	.el-date-editor.el-input {
		width: auto;
	}
	
	.add-update-preview .el-form-item ::v-deep .el-form-item__label {
	  	  padding: 0 10px 0 0;
	  	  text-shadow: 0 1px 10px #fff;
	  	  color: #699620;
	  	  width: 80px;
	  	  font-size: 14px;
	  	  line-height: 40px;
	  	  text-align: right;
	  	}
	
	.add-update-preview .el-form-item ::v-deep .el-form-item__content {
	  margin-left: 80px;
	}
	
	.add-update-preview .el-input ::v-deep .el-input__inner {
	  	  border: 0;
	  	  border-radius: 4px;
	  	  padding: 0 12px;
	  	  box-shadow: 0 0 1px #4b681d;
	  	  outline: none;
	  	  color: #00a9aa;
	  	  width: 400px;
	  	  font-size: 14px;
	  	  height: 40px;
	  	}
	
	.add-update-preview .el-select ::v-deep .el-input__inner {
	  	  border: 0;
	  	  border-radius: 4px;
	  	  padding: 0 10px;
	  	  box-shadow: 0 0 1px #4b681d;
	  	  outline: none;
	  	  color: #00a9aa;
	  	  width: 200px;
	  	  font-size: 14px;
	  	  height: 40px;
	  	}
	
	.add-update-preview .el-date-editor ::v-deep .el-input__inner {
	  	  border: 0;
	  	  border-radius: 4px;
	  	  padding: 0 10px 0 30px;
	  	  box-shadow: 0 0 1px #4b681d;
	  	  outline: none;
	  	  color: #00a9aa;
	  	  width: 200px;
	  	  font-size: 14px;
	  	  height: 40px;
	  	}
	
	.add-update-preview ::v-deep .el-upload--picture-card {
		background: transparent;
		border: 0;
		border-radius: 0;
		width: auto;
		height: auto;
		line-height: initial;
		vertical-align: middle;
	}
	
	.add-update-preview ::v-deep .upload .upload-img {
	  	  border: 1px dashed #fff;
	  	  cursor: pointer;
	  	  border-radius: 6px;
	  	  color: #fff;
	  	  width: 200px;
	  	  font-size: 32px;
	  	  line-height: 100px;
	  	  text-align: center;
	  	  height: 100px;
	  	}
	
	.add-update-preview ::v-deep .el-upload-list .el-upload-list__item {
	  	  border: 1px dashed #fff;
	  	  cursor: pointer;
	  	  border-radius: 6px;
	  	  color: #fff;
	  	  width: 200px;
	  	  font-size: 32px;
	  	  line-height: 100px;
	  	  text-align: center;
	  	  height: 100px;
	  	}
	
	.add-update-preview ::v-deep .el-upload .el-icon-plus {
	  	  border: 1px dashed #fff;
	  	  cursor: pointer;
	  	  border-radius: 6px;
	  	  color: #fff;
	  	  width: 200px;
	  	  font-size: 32px;
	  	  line-height: 100px;
	  	  text-align: center;
	  	  height: 100px;
	  	}
	
	.add-update-preview .el-textarea ::v-deep .el-textarea__inner {
	  	  border: 0;
	  	  border-radius: 4px;
	  	  padding: 12px;
	  	  box-shadow: 0 0 1px #4b681d;
	  	  outline: none;
	  	  color: #00a9aa;
	  	  width: 400px;
	  	  font-size: 14px;
	  	  height: auto;
	  	}
</style>
