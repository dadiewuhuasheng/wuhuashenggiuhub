<template>
  <div class="addOrUpdate-container">
    <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="120px" class="demo-ruleForm">
      <el-form-item label="用户ID" prop="userId">
        <el-input v-model="ruleForm.userId" placeholder="用户ID" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="通知内容" prop="message">
        <el-input type="textarea" :rows="6" v-model="ruleForm.message" placeholder="通知内容" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="通知类型" prop="type">
        <el-input v-model="ruleForm.type" placeholder="通知类型" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="关联预约ID" prop="relatedReservationId">
        <el-input v-model="ruleForm.relatedReservationId" placeholder="关联预约ID" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="预约类型" prop="reservationType">
        <el-input v-model="ruleForm.reservationType" placeholder="预约类型" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="已读状态" prop="isRead">
        <el-tag v-if="ruleForm.isRead === 0" type="warning">未读</el-tag>
        <el-tag v-else type="success">已读</el-tag>
      </el-form-item>
      <el-form-item label="创建时间" prop="addtime">
        <el-input v-model="ruleForm.addtime" placeholder="创建时间" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button @click="back()">返回</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      ruleForm: {
        id: '',
        userId: '',
        message: '',
        type: '',
        relatedReservationId: '',
        reservationType: '',
        isRead: 0,
        addtime: ''
      },
      rules: {}
    };
  },
  props: ["parent"],
  computed: {},
  methods: {
    init(id, type) {
      if (id) {
        this.getInfo(id);
      }
    },
    // 获取信息
    getInfo(id) {
      this.$http({
        url: `notification/info/${id}`,
        method: "get"
      }).then(({ data }) => {
        if (data && data.code === 0) {
          this.ruleForm = data.data;
        }
      });
    },
    // 返回
    back() {
      this.parent.showFlag = true;
      this.parent.addOrUpdateFlag = false;
      this.parent.search();
    }
  }
};
</script>
<style lang="scss" scoped>
.addOrUpdate-container {
  padding: 30px;
  .el-input, .el-textarea {
    width: 80%;
  }
}
</style>
