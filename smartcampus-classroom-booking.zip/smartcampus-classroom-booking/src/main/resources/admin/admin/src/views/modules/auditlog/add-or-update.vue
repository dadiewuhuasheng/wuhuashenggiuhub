<template>
  <div class="addOrUpdate-container">
    <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="120px" class="demo-ruleForm">
      <el-form-item label="用户ID" prop="userId">
        <el-input v-model="ruleForm.userId" placeholder="用户ID" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="操作类型" prop="actionType">
        <el-tag v-if="ruleForm.actionType === 'CREATE'" type="success">创建</el-tag>
        <el-tag v-else-if="ruleForm.actionType === 'UPDATE'" type="primary">修改</el-tag>
        <el-tag v-else-if="ruleForm.actionType === 'CANCEL'" type="warning">取消</el-tag>
        <el-tag v-else-if="ruleForm.actionType === 'DELETE'" type="danger">删除</el-tag>
        <el-tag v-else type="info">{{ruleForm.actionType}}</el-tag>
      </el-form-item>
      <el-form-item label="资源类型" prop="resourceType">
        <el-input v-model="resourceTypeText" placeholder="资源类型" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="资源ID" prop="resourceId">
        <el-input v-model="ruleForm.resourceId" placeholder="资源ID" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="操作详情" prop="details">
        <el-input type="textarea" :rows="8" v-model="ruleForm.details" placeholder="操作详情" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="操作时间" prop="timestamp">
        <el-input v-model="ruleForm.timestamp" placeholder="操作时间" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button @click="back()">返回</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      ruleForm: {
        id: '',
        userId: '',
        actionType: '',
        resourceType: '',
        resourceId: '',
        details: '',
        timestamp: ''
      },
      rules: {}
    };
  },
  props: ["parent"],
  computed: {
    resourceTypeText() {
      if (this.ruleForm.resourceType === 'SEAT_RESERVATION') {
        return '座位预约';
      } else if (this.ruleForm.resourceType === 'CLASSROOM_RESERVATION') {
        return '教室预约';
      } else {
        return this.ruleForm.resourceType;
      }
    }
  },
  methods: {
    init(id, type) {
      if (id) {
        this.getInfo(id);
      }
    },
    // 获取信息
    getInfo(id) {
      this.$http({
        url: `auditlog/info/${id}`,
        method: "get"
      }).then(({ data }) => {
        if (data && data.code === 0) {
          this.ruleForm = data.data;
        }
      });
    },
    // 返回
    back() {
      this.parent.showFlag = true;
      this.parent.addOrUpdateFlag = false;
      this.parent.search();
    }
  }
};
</script>
<style lang="scss" scoped>
.addOrUpdate-container {
  padding: 30px;
  .el-input, .el-textarea {
    width: 80%;
  }
}
</style>
