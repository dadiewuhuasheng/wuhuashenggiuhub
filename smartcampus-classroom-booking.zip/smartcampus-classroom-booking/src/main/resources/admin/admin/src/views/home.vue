<template>
    <div class="content" :style='{ "padding": "30px" }'>
        <div class="text"
            :style='{ "margin": "50px auto", "fontSize": "30px", "color": "#00a9aa", "textAlign": "center", "fontWeight": "bold" }'>
            欢迎使用 {{ this.$project.projectName }}</div>
        <div style="width: 100%; display: flex; justify-content: space-around;">
            <el-card style="width: 50%;" v-if="isAuth('xueshengpingjia', '修改') || true">
                <div id="kaoqinChart1" style="width:100%;height:400px;"></div>
            </el-card>
            <el-card style="width: 50%;" v-if="isAuth('xueshengpingjia', '修改') || true">
                <div id="monthAmountChart" style="width:100%;height:400px;"></div>
            </el-card>
        </div>
    </div>
</template>
<script>
//0
import router from '@/router/router-static'
import * as echarts from 'echarts'
export default {
    data() {
        return {
        };
    },
    mounted() {
        this.init();
        this.kaoqinChat1();
        this.monthAmountChart();
    },
    methods: {
        init() {
            if (this.$storage.get('Token')) {
                this.$http({
                    url: `${this.$storage.get('sessionTable')}/session`,
                    method: "get"
                }).then(({ data }) => {
                    if (data && data.code != 0) {
                        router.push({ name: 'login' })
                    }
                });
            } else {
                router.push({ name: 'login' })
            }
        },
        kaoqinChat1() {
            this.$nextTick(() => {

                var kaoqinChart1 = echarts.init(document.getElementById("kaoqinChart1"), 'roma');
                this.$http({
                    url: "orders/ordergroup",
                    method: "get",
                }).then(({ data }) => {
                    if (data && data.code === 0) {
                        let res = data.data;
                        let xAxis = [];
                        let yAxis1 = [];
                        let yAxis2 = [];
                        let yAxis3 = [];
                        let yAxis4 = [];
                        let yAxis5 = [];

                        let pArray = []
                        for (let i = 0; i < res.length; i++) {
                            xAxis.push(res[i].goodname);
                            yAxis1.push(parseFloat((res[i].p1)));
                            yAxis2.push(parseFloat((res[i].p2)));
                            yAxis3.push(parseFloat((res[i].p3)));
                            yAxis4.push(parseFloat((res[i].p4)));
                            yAxis5.push(parseFloat((res[i].p5)));

                            pArray.push({
                                name: res[i].goodname
                            })
                        }
                        var option = {};
                        option = {
                            title: {
                                text: '预约统计',
                                left: 'center'
                            },
                            legend: {
                                data: [
                                    '未支付预约',
                                    '已取消预约',
                                    '已使用预约',
                                    '已预约预约',
                                    '已完成预约',

                                ],
                                left: 'center',
                                bottom: 10,
                            },
                            tooltip: {
                                trigger: 'axis'
                            },
                            xAxis: {
                                type: 'category',
                                data: xAxis
                            },
                            yAxis: {
                                type: 'value'
                            },
                            series: [
                                {
                                    name: '未支付预约',
                                    data: yAxis1,
                                    type: 'bar'
                                },
                                {
                                    name: '已取消预约',
                                    data: yAxis2,
                                    type: 'bar'
                                },
                                {
                                    name: '已使用预约',
                                    data: yAxis3,
                                    type: 'bar'
                                },
                                {
                                    name: '已预约预约',
                                    data: yAxis4,
                                    type: 'bar'
                                },
                                {
                                    name: '已完成预约',
                                    data: yAxis5,
                                    type: 'bar'
                                },

                            ],
                        };
                        // 使用刚指定的配置项和数据显示图表。
                        kaoqinChart1.setOption(option);
                        //根据窗口的大小变动图表
                        window.onresize = function () {
                            kaoqinChart1.resize();
                        };
                    }
                });
            })
        },

        monthAmountChart() {

            this.$nextTick(() => {
                var monthAmountChart = echarts.init(document.getElementById("monthAmountChart"), 'macarons');
                this.$http({
                    url: `orders/value/addtime/total/月`,
                    method: "get"
                }).then(({ data }) => {
                    if (data && data.code === 0) {
                        let res = data.data;
                        let xAxis = [];
                        let yAxis = [];
                        let pArray = []
                        for (let i = 0; i < res.length; i++) {
                            xAxis.push(res[i].addtime);
                            yAxis.push(parseFloat((res[i].total)).toFixed(2));
                            pArray.push({
                                value: parseFloat((res[i].total)),
                                name: res[i].addtime
                            })
                            var option = {};
                            option = {
                                tooltip: {
                                    trigger: 'item',
                                    formatter: '{b} : {c}'
                                },
                                title: {
                                    text: '月预约量',
                                    left: 'center'
                                },
                                xAxis: {
                                    type: 'category',
                                    data: xAxis
                                },
                                yAxis: {
                                    type: 'value'
                                },
                                series: [{
                                    data: yAxis,
                                    type: 'line'
                                }]
                            };
                            // 使用刚指定的配置项和数据显示图表。
                            monthAmountChart.setOption(option);
                            //根据窗口的大小变动图表
                            window.onresize = function () {
                                monthAmountChart.resize();
                            };
                        }
                    }
                });
            })
        },
    }
};
</script>
<style lang="scss" scoped>
.cardView {
    display: flex;
    flex-wrap: wrap;
    width: 100%;

    .cards {
        display: flex;
        align-items: center;
        width: 100%;
        margin-bottom: 10px;
        justify-content: center;

        .card {
            width: calc(25% - 20px);
            margin: 0 10px;

            ::v-deep.el-card__body {
                padding: 0;
            }
        }
    }
}
</style>