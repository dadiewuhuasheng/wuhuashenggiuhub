const base = {
    get() {
        return {
            url : "http://localhost:8080/smartcampusclassressys/",
            name: "smartcampusclassressys",
            // 退出到首页链接
            indexUrl: 'http://localhost:8080/smartcampusclassressys/front/dist/index.html'
        };
    },
    getProjectName(){
        return {
            projectName: "智能化校园教室预约管理系统"
        } 
    }
}
export default base
