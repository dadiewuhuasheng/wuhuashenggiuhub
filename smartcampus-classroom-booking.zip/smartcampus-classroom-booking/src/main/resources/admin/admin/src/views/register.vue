<template>
	<div>
		<div class="container" :style='{"minHeight":"100vh","alignItems":"center","background":"url(../assets/img/bg.jpg)","display":"flex","width":"100%","backgroundSize":"cover","backgroundPosition":"center center","backgroundRepeat":"no-repeat","justifyContent":"center"}'>
			<el-form v-if="pageFlag=='register'" :style='{"padding":"20px 0px 25px 370px","boxShadow":"0 1px 6px rgba(64, 158, 255, .8)","margin":"0","borderRadius":"30px","background":"url(http://codegen.caihongy.cn/20221015/19eb61a4cfe24ad989ed1b95e48e237c.jpg) #fff no-repeat 0px 0px","width":"980px","backgroundSize":"40% 100%","position":"relative","height":"auto"}' ref="rgsForm" class="rgs-form" :model="rgsForm">
				<div v-if="true" :style='{"margin":"0 0 10px 0","color":"#d9f0ff","top":"-90px","textAlign":"center","width":"100%","lineHeight":"40px","fontSize":"40px","position":"absolute","right":"40px"}' class="title">智能化校园教室预约管理系统注册</div>
				<el-form-item :style='{"width":"80%","padding":"0","margin":"0 auto 4px","height":"auto"}' class="list-item" v-if="tableName=='users'">
					<div v-if="false" :style='{"width":"64px","lineHeight":"44px","fontSize":"14px","color":"rgba(64, 158, 255, 1)"}' class="lable">用户账号</div>
					<el-input  v-model="ruleForm.username"  autocomplete="off" placeholder="用户账号"  type="text"  />
				</el-form-item>
				<el-form-item :style='{"width":"80%","padding":"0","margin":"0 auto 4px","height":"auto"}' class="list-item" v-if="tableName=='users'">
					<div v-if="false" :style='{"width":"64px","lineHeight":"44px","fontSize":"14px","color":"rgba(64, 158, 255, 1)"}' class="lable">密码</div>
					<el-input  v-model="ruleForm.password"  autocomplete="off" placeholder="密码"  type="password"  />
				</el-form-item>
				<el-form-item :style='{"width":"80%","padding":"0","margin":"0 auto 4px","height":"auto"}' class="list-item" v-if="tableName=='users'">
					<div v-if="false" :style='{"width":"64px","lineHeight":"44px","fontSize":"14px","color":"rgba(64, 158, 255, 1)"}' class="lable">确认密码</div>
					<el-input  v-model="ruleForm.password2" autocomplete="off" placeholder="确认密码" type="password" />
				</el-form-item>
				<el-form-item :style='{"width":"80%","padding":"0","margin":"0 auto 4px","height":"auto"}' class="list-item" v-if="tableName=='users'">
					<div v-if="false" :style='{"width":"64px","lineHeight":"44px","fontSize":"14px","color":"rgba(64, 158, 255, 1)"}' class="lable">用户姓名</div>
					<el-input  v-model="ruleForm.nickname"  autocomplete="off" placeholder="用户姓名"  type="text"  />
				</el-form-item>
				<el-form-item :style='{"width":"80%","padding":"0","margin":"0 auto 4px","height":"auto"}' class="list-item" v-if="tableName=='users'">
					<div v-if="false" :style='{"width":"64px","lineHeight":"44px","fontSize":"14px","color":"rgba(64, 158, 255, 1)"}' class="lable">性别</div>
                    <el-select v-model="ruleForm.gender" placeholder="请选择性别" >
                        <el-option
                            v-for="(item,index) in usersgenderOptions"
                            v-bind:key="index"
                            :label="item"
                            :value="item">
                        </el-option>
                    </el-select>
				</el-form-item>
				<el-form-item :style='{"width":"80%","padding":"0","margin":"0 auto 4px","height":"auto"}' class="list-item" v-if="tableName=='users'">
					<div v-if="false" :style='{"width":"64px","lineHeight":"44px","fontSize":"14px","color":"rgba(64, 158, 255, 1)"}' class="lable">头像</div>
                    <file-upload
                        tip="点击上传头像"
                        action="file/upload"
                        :limit="3"
                        :multiple="true"
                        :fileUrls="ruleForm.avatar?ruleForm.avatar:''"
                        @change="usersavatarUploadChange"
                    ></file-upload>
				</el-form-item>
				<el-form-item :style='{"width":"80%","padding":"0","margin":"0 auto 4px","height":"auto"}' class="list-item" v-if="tableName=='users'">
					<div v-if="false" :style='{"width":"64px","lineHeight":"44px","fontSize":"14px","color":"rgba(64, 158, 255, 1)"}' class="lable">用户电话</div>
					<el-input  v-model="ruleForm.telephone"  autocomplete="off" placeholder="用户电话"  type="text"  />
				</el-form-item>
				<button :style='{"border":"0","cursor":"pointer","padding":"0 10px","margin":"5px auto 5px","outline":"none","color":"#fff","borderRadius":"12px","background":"-webkit-linear-gradient(top,#00cecf,#008a8b)","display":"block","width":"80%","fontSize":"16px","height":"36px"}' type="button" class="r-btn" @click="login()">注册</button>
				<div :style='{"cursor":"pointer","padding":"0 10%","color":"rgba(159, 159, 159, 1)","display":"inline-block","lineHeight":"1","fontSize":"12px","textDecoration":"underline"}' class="r-login" @click="close()">已有账号，直接登录</div>
			</el-form>
			
		</div>
	</div>
</template>

<script>

export default {
	data() {
		return {
			ruleForm: {
                gender: '',
			},

            pageFlag : '',
			tableName:"",
			rules: {},
            usersgenderOptions: [],
		};
	},
	mounted(){
        this.pageFlag = this.$storage.get("pageFlag");
		let table = this.$storage.get("loginTable");
		this.tableName = table;
        this.usersgenderOptions = "男,女".split(',')
	},
	created() {
    
	},
	destroyed() {
		  	},
	methods: {
		// 获取uuid
		getUUID () {
			return new Date().getTime();
		},
		close(){
			this.$router.push({ path: "/login" });
		},
        usersavatarUploadChange(fileUrls) {
            this.ruleForm.avatar = fileUrls;
        },

        // 多级联动参数


		// 注册
		login() {
			var url=this.tableName+"/register";
					if((!this.ruleForm.username) && `users` == this.tableName){
						this.$message.error(`用户账号不能为空`);
						return
					}
					
					
					
					
					
					
					
					
					
					
					if((!this.ruleForm.password) && `users` == this.tableName){
						this.$message.error(`密码不能为空`);
						return
					}
					
					
					
					
					
					
					
					
					
					
					if((this.ruleForm.password!=this.ruleForm.password2) && `users` == this.tableName){
						this.$message.error(`两次密码输入不一致`);
						return
					}
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
            if(this.ruleForm.avatar!=null) {
                this.ruleForm.avatar = this.ruleForm.avatar.replace(new RegExp(this.$base.url,"g"),"");
            }
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					if(`users` == this.tableName && this.ruleForm.telephone&&(!this.$validate.isMobile(this.ruleForm.telephone))){
						this.$message.error(`用户电话应输入手机格式`);
						return
					}
					
					
					
					
					
					
					
					
					if(`users` == this.tableName && this.ruleForm.money&&(!this.$validate.isNumber(this.ruleForm.money))){
						this.$message.error(`余额应输入数字`);
						return
					}
					
					
					
					
					
					
				
			
			this.$http({
				url: url,
				method: "post",
				data:this.ruleForm
			}).then(({ data }) => {
				if (data && data.code === 0) {
					this.$message({
						message: "注册成功",
						type: "success",
						duration: 1500,
						onClose: () => {
							this.$router.replace({ path: "/login" });
						}
					});
				} else {
					this.$message.error(data.msg);
				}
			});
		}
	}
};
</script>

<style lang="scss" scoped>
	.container {
	  position: relative;
	  background: url(../assets/img/bg.jpg);

		.el-date-editor.el-input {
		  width: 100%;
		}
		
		.rgs-form .el-input ::v-deep .el-input__inner {
						border: 1px solid #00b4b5;
						border-radius: 12px;
						padding: 0 10px;
						margin: 0;
						color: #aaa;
						width: 100%;
						font-size: 14px;
						height: 36px;
					}
		
		.rgs-form .el-select ::v-deep .el-input__inner {
						border: 1px solid #00b4b5;
						border-radius: 12px;
						padding: 0 10px;
						box-shadow: 0 0 0px rgba(64, 158, 255, .5);
						outline: none;
						color: #aaa;
						width: 288px;
						font-size: 14px;
						height: 36px;
					}
		
		.rgs-form .el-date-editor ::v-deep .el-input__inner {
						border: 1px solid #00b4b5;
						border-radius: 12px;
						padding: 0 10px 0 30px;
						box-shadow: 0 0 0px rgba(64, 158, 255, .5);
						outline: none;
						color: #aaa;
						width: 288px;
						font-size: 14px;
						height: 36px;
					}
		
		.rgs-form .el-date-editor ::v-deep .el-input__inner {
						border: 1px solid #00b4b5;
						border-radius: 12px;
						padding: 0 10px 0 30px;
						box-shadow: 0 0 0px rgba(64, 158, 255, .5);
						outline: none;
						color: #aaa;
						width: 288px;
						font-size: 14px;
						height: 36px;
					}
		
		.rgs-form ::v-deep .el-upload--picture-card {
			background: transparent;
			border: 0;
			border-radius: 0;
			width: auto;
			height: auto;
			line-height: initial;
			vertical-align: middle;
		}
		
		.rgs-form ::v-deep .upload .upload-img {
		  		  border: 1px dashed #00b4b5;
		  		  cursor: pointer;
		  		  border-radius: 12px;
		  		  color: #00b4b5;
		  		  width: 160px;
		  		  font-size: 32px;
		  		  line-height: 80px;
		  		  text-align: center;
		  		  height: 80px;
		  		}
		
		.rgs-form ::v-deep .el-upload-list .el-upload-list__item {
		  		  border: 1px dashed #00b4b5;
		  		  cursor: pointer;
		  		  border-radius: 12px;
		  		  color: #00b4b5;
		  		  width: 160px;
		  		  font-size: 32px;
		  		  line-height: 80px;
		  		  text-align: center;
		  		  height: 80px;
		  		}
		
		.rgs-form ::v-deep .el-upload .el-icon-plus {
		  		  border: 1px dashed #00b4b5;
		  		  cursor: pointer;
		  		  border-radius: 12px;
		  		  color: #00b4b5;
		  		  width: 160px;
		  		  font-size: 32px;
		  		  line-height: 80px;
		  		  text-align: center;
		  		  height: 80px;
		  		}
	}
</style>
