<template>
  <div class="addOrUpdate-container">
    <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="120px" class="demo-ruleForm">
      <el-form-item label="教室名称" prop="classroomName">
        <el-input v-model="ruleForm.classroomName" placeholder="教室名称" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="预约人" prop="username">
        <el-input v-model="ruleForm.username" placeholder="预约人" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="开始时间" prop="startTime">
        <el-date-picker
          v-model="ruleForm.startTime"
          type="datetime"
          placeholder="选择开始时间"
          value-format="yyyy-MM-dd HH:mm:ss"
          :disabled="true">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="结束时间" prop="endTime">
        <el-date-picker
          v-model="ruleForm.endTime"
          type="datetime"
          placeholder="选择结束时间"
          value-format="yyyy-MM-dd HH:mm:ss"
          :disabled="true">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="预约目的" prop="purpose">
        <el-input type="textarea" v-model="ruleForm.purpose" placeholder="预约目的" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="状态" prop="status">
        <el-input v-model="ruleForm.status" placeholder="状态" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="预约时间" prop="addtime">
        <el-input v-model="ruleForm.addtime" placeholder="预约时间" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button @click="back()">返回</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      ruleForm: {
        id: '',
        classroomId: '',
        classroomName: '',
        userId: '',
        username: '',
        startTime: '',
        endTime: '',
        purpose: '',
        status: '',
        addtime: ''
      },
      rules: {}
    };
  },
  props: ["parent"],
  computed: {},
  methods: {
    init(id, type) {
      if (id) {
        this.getInfo(id);
      }
    },
    // 获取信息
    getInfo(id) {
      this.$http({
        url: `classroomreservation/info/${id}`,
        method: "get"
      }).then(({ data }) => {
        if (data && data.code === 0) {
          this.ruleForm = data.data;
        }
      });
    },
    // 返回
    back() {
      this.parent.showFlag = true;
      this.parent.addOrUpdateFlag = false;
      this.parent.search();
    }
  }
};
</script>
<style lang="scss" scoped>
.addOrUpdate-container {
  padding: 30px;
  .el-input, .el-textarea {
    width: 80%;
  }
  .el-date-editor {
    width: 80%;
  }
}
</style>
