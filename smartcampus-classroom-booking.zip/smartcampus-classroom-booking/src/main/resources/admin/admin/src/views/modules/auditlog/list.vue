<template>
	<div class="main-content" :style='{"padding":"30px"}'>
		<!-- 列表页 -->
		<template v-if="showFlag">
			<el-form class="center-form-pv" :style='{"margin":"0 0 20px"}' :inline="true" :model="searchForm">
				<el-row :style='{"display":"block"}' >
					<div :style='{"margin":"0 10px 0 0","display":"inline-block"}'>
						<label :style='{"margin":"0 10px 0 0","color":"#333","display":"inline-block","lineHeight":"40px","fontSize":"14px","fontWeight":"500","height":"40px"}' class="item-label">用户ID</label>
						<el-input v-model="searchForm.userId" placeholder="用户ID" clearable></el-input>
					</div>
					<div :style='{"margin":"0 10px 0 0","display":"inline-block"}'>
						<label :style='{"margin":"0 10px 0 0","color":"#333","display":"inline-block","lineHeight":"40px","fontSize":"14px","fontWeight":"500","height":"40px"}' class="item-label">操作类型</label>
						<el-select v-model="searchForm.actionType" placeholder="请选择操作类型" clearable>
							<el-option label="创建" value="CREATE"></el-option>
							<el-option label="修改" value="UPDATE"></el-option>
							<el-option label="取消" value="CANCEL"></el-option>
							<el-option label="删除" value="DELETE"></el-option>
						</el-select>
					</div>
					<div :style='{"margin":"0 10px 0 0","display":"inline-block"}'>
						<label :style='{"margin":"0 10px 0 0","color":"#333","display":"inline-block","lineHeight":"40px","fontSize":"14px","fontWeight":"500","height":"40px"}' class="item-label">资源类型</label>
						<el-select v-model="searchForm.resourceType" placeholder="请选择资源类型" clearable>
							<el-option label="座位预约" value="SEAT_RESERVATION"></el-option>
							<el-option label="教室预约" value="CLASSROOM_RESERVATION"></el-option>
						</el-select>
					</div>
					<div :style='{"margin":"0 10px 0 0","display":"inline-block"}'>
						<label :style='{"margin":"0 10px 0 0","color":"#333","display":"inline-block","lineHeight":"40px","fontSize":"14px","fontWeight":"500","height":"40px"}' class="item-label">开始日期</label>
						<el-date-picker
							v-model="searchForm.startDate"
							type="date"
							placeholder="选择开始日期"
							value-format="yyyy-MM-dd">
						</el-date-picker>
					</div>
					<div :style='{"margin":"0 10px 0 0","display":"inline-block"}'>
						<label :style='{"margin":"0 10px 0 0","color":"#333","display":"inline-block","lineHeight":"40px","fontSize":"14px","fontWeight":"500","height":"40px"}' class="item-label">结束日期</label>
						<el-date-picker
							v-model="searchForm.endDate"
							type="date"
							placeholder="选择结束日期"
							value-format="yyyy-MM-dd">
						</el-date-picker>
					</div>
					<el-button :style='{"border":"0","cursor":"pointer","padding":"0 24px","outline":"none","color":"#fff","borderRadius":"4px","background":"#00a9aa","width":"auto","fontSize":"14px","height":"40px"}' type="success" @click="search()">查询</el-button>
				</el-row>

				<el-row :style='{"margin":"20px 0","display":"flex"}'>
					<download-excel v-if="isAuth('auditlog','导出')" class="export-excel-wrapper" :data="dataList" :fields="json_fields" name="审计日志.xls">
						<el-button :style='{"border":"0","cursor":"pointer","padding":"0 24px","margin":"0 10px 0 0","outline":"none","color":"#fff","borderRadius":"4px","background":"rgba(255, 128, 0, 1)","width":"auto","fontSize":"14px","height":"40px"}' type="danger">导出</el-button>
					</download-excel>
				</el-row>
			</el-form>
			
			<el-table class="tables"
				:stripe='false'
				:style='{"padding":"0","borderColor":"#eee","borderRadius":"10px","borderWidth":"1px 0 0 1px","background":"#fff","width":"100%","borderStyle":"solid"}' 
				v-if="isAuth('auditlog','查看')"
				:data="dataList"
				v-loading="dataListLoading">
				<el-table-column :resizable='true' :sortable='true' label="索引" type="index" width="50" />
				<el-table-column :resizable='true' :sortable='true' prop="userId" label="用户ID" width="100">
					<template slot-scope="scope">
						{{scope.row.userId}}
					</template>
				</el-table-column>
				<el-table-column :resizable='true' :sortable='true' prop="actionType" label="操作类型" width="100">
					<template slot-scope="scope">
						<el-tag v-if="scope.row.actionType === 'CREATE'" type="success">创建</el-tag>
						<el-tag v-else-if="scope.row.actionType === 'UPDATE'" type="primary">修改</el-tag>
						<el-tag v-else-if="scope.row.actionType === 'CANCEL'" type="warning">取消</el-tag>
						<el-tag v-else-if="scope.row.actionType === 'DELETE'" type="danger">删除</el-tag>
						<el-tag v-else type="info">{{scope.row.actionType}}</el-tag>
					</template>
				</el-table-column>
				<el-table-column :resizable='true' :sortable='true' prop="resourceType" label="资源类型" width="150">
					<template slot-scope="scope">
						<span v-if="scope.row.resourceType === 'SEAT_RESERVATION'">座位预约</span>
						<span v-else-if="scope.row.resourceType === 'CLASSROOM_RESERVATION'">教室预约</span>
						<span v-else>{{scope.row.resourceType}}</span>
					</template>
				</el-table-column>
				<el-table-column :resizable='true' :sortable='true' prop="resourceId" label="资源ID" width="100">
					<template slot-scope="scope">
						{{scope.row.resourceId}}
					</template>
				</el-table-column>
				<el-table-column :resizable='true' :sortable='true' prop="details" label="操作详情" min-width="300">
					<template slot-scope="scope">
						<el-tooltip :content="scope.row.details" placement="top">
							<div class="text-ellipsis">{{scope.row.details}}</div>
						</el-tooltip>
					</template>
				</el-table-column>
				<el-table-column :resizable='true' :sortable='true' prop="timestamp" label="操作时间" width="180">
					<template slot-scope="scope">
						{{scope.row.timestamp}}
					</template>
				</el-table-column>
				<el-table-column width="200" label="操作">
					<template slot-scope="scope">
						<el-button :style='{"border":"1px solid #3ca512","cursor":"pointer","padding":"0 10px 0 24px","margin":"3px 6px 3px 0","outline":"none","color":"#fff","borderRadius":"4px","background":"url(http://codegen.caihongy.cn/20221011/ca1c191554d24b108bc94f4a2046d636.png) #41b314 no-repeat 5px 8px","width":"auto","fontSize":"12px","height":"32px"}' v-if="isAuth('auditlog','查看')" type="success" size="mini" @click="addOrUpdateHandler(scope.row.id,'info')">详情</el-button>
					</template>
				</el-table-column>
			</el-table>
			<el-pagination
				@size-change="sizeChangeHandle"
				@current-change="currentChangeHandle"
				:current-page="pageIndex"
				background
				:page-sizes="[10, 20, 30, 50]"
				:page-size="pageSize"
				:layout="layouts.join()"
				:total="totalPage"
				prev-text="<"
				next-text=">"
				:hide-on-single-page="true"
				:style='{"width":"100%","padding":"0","margin":"20px 0 0","whiteSpace":"nowrap","color":"#eee","fontWeight":"500"}'
			></el-pagination>
		</template>
		
		<!-- 添加/修改页面 -->
		<add-or-update v-if="addOrUpdateFlag" :parent="this" ref="addOrUpdate"></add-or-update>
	</div>
</template>

<script>
import AddOrUpdate from "./add-or-update";
export default {
  data() {
    return {
      searchForm: {
        userId: "",
        actionType: "",
        resourceType: "",
        startDate: "",
        endDate: ""
      },
      dataList: [],
      pageIndex: 1,
      pageSize: 10,
      totalPage: 0,
      dataListLoading: false,
      showFlag: true,
      addOrUpdateFlag:false,
      layouts: ["total","prev","pager","next","sizes","jumper"],
      json_fields: {
        "用户ID": "userId",
        "操作类型": "actionType",
        "资源类型": "resourceType",
        "资源ID": "resourceId",
        "操作详情": "details",
        "操作时间": "timestamp"
      }
    };
  },
  created() {
    this.init();
    this.getDataList();
    this.contentStyleChange()
  },
  components: {
    AddOrUpdate,
  },
  methods: {
    contentStyleChange() {
      this.contentPageStyleChange()
    },
    contentPageStyleChange(){
      let arr = []
    },
    init () {
    },
    search() {
      this.pageIndex = 1;
      this.getDataList();
    },
    // 获取数据列表
    getDataList() {
      this.dataListLoading = true;
      let params = {
        page: this.pageIndex,
        limit: this.pageSize,
        sort: 'id',
        order: 'desc',
      }
      if(this.searchForm.userId!='' && this.searchForm.userId!=undefined){
        params['userId'] = this.searchForm.userId
      }
      if(this.searchForm.actionType!='' && this.searchForm.actionType!=undefined){
        params['actionType'] = this.searchForm.actionType
      }
      if(this.searchForm.resourceType!='' && this.searchForm.resourceType!=undefined){
        params['resourceType'] = this.searchForm.resourceType
      }
      if(this.searchForm.startDate!='' && this.searchForm.startDate!=undefined){
        params['startDate'] = this.searchForm.startDate
      }
      if(this.searchForm.endDate!='' && this.searchForm.endDate!=undefined){
        params['endDate'] = this.searchForm.endDate
      }
      this.$http({
        url: "auditlog/page",
        method: "get",
        params: params
      }).then(({ data }) => {
        if (data && data.code === 0) {
          this.dataList = data.data.list;
          this.totalPage = data.data.total;
        } else {
          this.dataList = [];
          this.totalPage = 0;
        }
        this.dataListLoading = false;
      });
    },
    // 每页数
    sizeChangeHandle(val) {
      this.pageSize = val;
      this.pageIndex = 1;
      this.getDataList();
    },
    // 当前页
    currentChangeHandle(val) {
      this.pageIndex = val;
      this.getDataList();
    },
    // 添加/修改
    addOrUpdateHandler(id,type) {
      this.showFlag = false;
      this.addOrUpdateFlag = true;
      if(type!='info'){
        type = 'else';
      }
      this.$nextTick(() => {
        this.$refs.addOrUpdate.init(id,type);
      });
    }
  }
};
</script>
<style lang="scss" scoped>
	@import "@/assets/styles/admin-table.scss";
	.text-ellipsis {
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		max-width: 300px;
	}
</style>
