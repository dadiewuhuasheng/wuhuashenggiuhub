const menu = {
  list() {
    return [
      {
        backMenu: [
          {
            child: [
              {
                appFrontIcon: "cuIcon-rank",
                buttons: ["新增", "查看", "修改", "删除"],
                menu: "用户",
                menuJump: "列表",
                tableName: "users",
              },
            ],
            menu: "用户管理",
          },
          {
            child: [
              {
                appFrontIcon: "cuIcon-pay",
                buttons: ["新增", "查看", "修改", "删除"],
                menu: "资讯类型",
                menuJump: "列表",
                tableName: "noticetype",
              },
            ],
            menu: "资讯类型管理",
          },
          {
            child: [
              {
                appFrontIcon: "cuIcon-attentionfavor",
                buttons: ["新增", "查看", "修改", "删除", "查看评论"],
                menu: "教室资讯",
                menuJump: "列表",
                tableName: "librarynotice",
              },
            ],
            menu: "教室资讯管理",
          },
          {
            child: [
              {
                appFrontIcon: "cuIcon-camera",
                buttons: ["新增", "查看", "修改", "删除"],
                menu: "教室类型",
                menuJump: "列表",
                tableName: "libseattype",
              },
            ],
            menu: "教室类型管理",
          },
          {
            child: [
              {
                appFrontIcon: "cuIcon-link",
                buttons: ["新增", "查看", "修改", "删除", "查看评论"],
                menu: "教室信息",
                menuJump: "列表",
                tableName: "libseatinfo",
              },
            ],
            menu: "教室信息管理",
          },
          {
            child: [
              {
                appFrontIcon: "cuIcon-service",
                buttons: ["查看", "回复"],
                menu: "在线咨询",
                tableName: "chat",
              },
            ],
            menu: "在线咨询管理",
          },
          {
            child: [
              {
                appFrontIcon: "cuIcon-news",
                buttons: ["新增", "查看", "修改", "删除"],
                menu: "公告信息",
                tableName: "news",
              },
              {
                appFrontIcon: "cuIcon-pay",
                buttons: ["查看", "修改"],
                menu: "关于我们",
                tableName: "aboutus",
              },
              {
                appFrontIcon: "cuIcon-goodsnew",
                buttons: ["查看", "修改"],
                menu: "系统简介",
                tableName: "systemintro",
              },
              {
                appFrontIcon: "cuIcon-pay",
                buttons: ["新增", "查看", "修改", "删除"],
                menu: "轮播图管理",
                tableName: "config",
              },
            ],
            menu: "系统管理",
          },
          {
            child: [
              {
                appFrontIcon: "cuIcon-pic",
                buttons: ["查看", "删除"],
                menu: "未支付预约",
                tableName: "orders/未支付",
              },
              {
                appFrontIcon: "cuIcon-skin",
                buttons: ["查看", "删除"],
                menu: "已取消预约",
                tableName: "orders/已取消",
              },
              {
                appFrontIcon: "cuIcon-phone",
                buttons: ["查看", "删除"],
                menu: "已使用预约",
                tableName: "orders/已使用",
              },
              {
                appFrontIcon: "cuIcon-full",
                buttons: [
                  "查看",
                  "删除",
                  "日销量",
                  "月销量",
                  "日预约量",
                  "月预约量",
                  "年预约量",
                  "年销量",
                ],
                menu: "已预约预约",
                tableName: "orders/已预约",
              },
              {
                appFrontIcon: "cuIcon-form",
                buttons: [
                  "查看",
                  "删除",
                  "日销量",
                  "月销量",
                  "日预约量",
                  "月预约量",
                  "年预约量",
                  "年销量",
                ],
                menu: "已完成预约",
                tableName: "orders/已完成",
              },
            ],
            menu: "预约管理",
          },
          {
            child: [
              {
                appFrontIcon: "cuIcon-calendar",
                buttons: ["查看", "删除", "取消", "导出"],
                menu: "教室预约管理",
                menuJump: "列表",
                tableName: "classroomreservation",
              },
            ],
            menu: "教室预约管理",
          },
          {
            child: [
              {
                appFrontIcon: "cuIcon-notice",
                buttons: ["查看", "删除", "标记已读", "导出"],
                menu: "通知管理",
                menuJump: "列表",
                tableName: "notification",
              },
            ],
            menu: "通知管理",
          },
          {
            child: [
              {
                appFrontIcon: "cuIcon-list",
                buttons: ["查看", "导出"],
                menu: "审计日志",
                menuJump: "列表",
                tableName: "auditlog",
              },
            ],
            menu: "审计日志",
          },
        ],
        frontMenu: [
          {
            child: [
              {
                appFrontIcon: "cuIcon-goodsnew",
                buttons: ["查看"],
                menu: "教室资讯列表",
                menuJump: "列表",
                tableName: "librarynotice",
              },
            ],
            menu: "教室资讯模块",
          },
          {
            child: [
              {
                appFrontIcon: "cuIcon-form",
                buttons: ["查看"],
                menu: "教室信息列表",
                menuJump: "列表",
                tableName: "libseatinfo",
              },
            ],
            menu: "教室信息模块",
          },
        ],
        hasBackLogin: "是",
        hasBackRegister: "否",
        hasFrontLogin: "否",
        hasFrontRegister: "否",
        roleName: "管理员",
        tableName: "admin",
      },
      {
        backMenu: [],
        frontMenu: [
          {
            child: [
              {
                appFrontIcon: "cuIcon-goodsnew",
                buttons: ["查看"],
                menu: "教室资讯列表",
                menuJump: "列表",
                tableName: "librarynotice",
              },
            ],
            menu: "教室资讯模块",
          },
          {
            child: [
              {
                appFrontIcon: "cuIcon-form",
                buttons: ["查看"],
                menu: "教室信息列表",
                menuJump: "列表",
                tableName: "libseatinfo",
              },
            ],
            menu: "教室信息模块",
          },
        ],
        hasBackLogin: "否",
        hasBackRegister: "否",
        hasFrontLogin: "是",
        hasFrontRegister: "是",
        roleName: "用户",
        tableName: "users",
      },
    ];
  },
};
export default menu;
