import Vue from 'vue';
//配置路由
import VueRouter from 'vue-router'
Vue.use(VueRouter);
//1.创建组件
import Index from '@/views/index'
import Home from '@/views/home'
import Login from '@/views/login'
import NotFound from '@/views/404'
import UpdatePassword from '@/views/update-password'
import pay from '@/views/pay'
import register from '@/views/register'
import center from '@/views/center'
    import news from '@/views/modules/news/list'
    import libseatinfo from '@/views/modules/libseatinfo/list'
    import aboutus from '@/views/modules/aboutus/list'
    import discusslibrarynotice from '@/views/modules/discusslibrarynotice/list'
    import libseattype from '@/views/modules/libseattype/list'
    import discusslibseatinfo from '@/views/modules/discusslibseatinfo/list'
    import systemintro from '@/views/modules/systemintro/list'
    import librarynotice from '@/views/modules/librarynotice/list'
    import users from '@/views/modules/users/list'
    import chat from '@/views/modules/chat/list'
    import orders from '@/views/modules/orders/list'
    import noticetype from '@/views/modules/noticetype/list'
    import config from '@/views/modules/config/list'
    import classroomreservation from '@/views/modules/classroomreservation/list'
    import notification from '@/views/modules/notification/list'
    import auditlog from '@/views/modules/auditlog/list'


//2.配置路由   注意：名字
const routes = [{
    path: '/index',
    name: '系统首页',
    component: Index,
    children: [{
      // 这里不设置值，是把main作为默认页面
      path: '/',
      name: '系统首页',
      component: Home,
      meta: {icon:'', title:'center'}
    }, {
      path: '/updatePassword',
      name: '修改密码',
      component: UpdatePassword,
      meta: {icon:'', title:'updatePassword'}
    }, {
      path: '/pay',
      name: '支付',
      component: pay,
      meta: {icon:'', title:'pay'}
    }, {
      path: '/center',
      name: '个人信息',
      component: center,
      meta: {icon:'', title:'center'}
    }
      ,{
	path: '/news',
        name: '公告信息',
        component: news
      }
      ,{
	path: '/libseatinfo',
        name: '教室信息',
        component: libseatinfo
      }
      ,{
	path: '/aboutus',
        name: '关于我们',
        component: aboutus
      }
      ,{
	path: '/discusslibrarynotice',
        name: '教室资讯评论',
        component: discusslibrarynotice
      }
      ,{
	path: '/libseattype',
        name: '教室类型',
        component: libseattype
      }
      ,{
	path: '/discusslibseatinfo',
        name: '教室信息评论',
        component: discusslibseatinfo
      }
      ,{
	path: '/systemintro',
        name: '系统简介',
        component: systemintro
      }
      ,{
	path: '/librarynotice',
        name: '教室资讯',
        component: librarynotice
      }
      ,{
	path: '/users',
        name: '用户',
        component: users
      }
      ,{
	path: '/chat',
        name: '在线咨询',
        component: chat
      }
      ,{
        path: '/orders/:status',
        name: '预约管理',
        component: orders
      }
      ,{
	path: '/noticetype',
        name: '教室类型',
        component: noticetype
      }
      ,{
	path: '/config',
        name: '轮播图管理',
        component: config
      }
      ,{
	path: '/classroomreservation',
        name: '教室预约管理',
        component: classroomreservation
      }
      ,{
	path: '/notification',
        name: '通知管理',
        component: notification
      }
      ,{
	path: '/auditlog',
        name: '审计日志',
        component: auditlog
      }
    ]
  },
  {
    path: '/login',
    name: 'login',
    component: Login,
    meta: {icon:'', title:'login'}
  },
  {
    path: '/register',
    name: 'register',
    component: register,
    meta: {icon:'', title:'register'}
  },
  {
    path: '/',
    name: '系统首页',
    redirect: '/index'
  }, /*默认跳转路由*/
  {
    path: '*',
    component: NotFound
  }
]
//3.实例化VueRouter  注意：名字
const router = new VueRouter({
  mode: 'hash',
  /*hash模式改为history*/
  routes // （缩写）相当于 routes: routes
})
const originalPush = VueRouter.prototype.push
//修改原型对象中的push方法
VueRouter.prototype.push = function push(location) {
   return originalPush.call(this, location).catch(err => err)
}
export default router;
