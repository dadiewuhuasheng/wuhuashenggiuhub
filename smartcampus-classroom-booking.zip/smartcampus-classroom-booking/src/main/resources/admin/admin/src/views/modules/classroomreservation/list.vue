<template>
	<div class="main-content" :style='{"padding":"30px"}'>
		<!-- 列表页 -->
		<template v-if="showFlag">
			<el-form class="center-form-pv" :style='{"margin":"0 0 20px"}' :inline="true" :model="searchForm">
				<el-row :style='{"display":"block"}' >
					<div :style='{"margin":"0 10px 0 0","display":"inline-block"}'>
						<label :style='{"margin":"0 10px 0 0","color":"#333","display":"inline-block","lineHeight":"40px","fontSize":"14px","fontWeight":"500","height":"40px"}' class="item-label">教室名称</label>
						<el-input v-model="searchForm.classroomName" placeholder="教室名称" clearable></el-input>
					</div>
					<div :style='{"margin":"0 10px 0 0","display":"inline-block"}'>
						<label :style='{"margin":"0 10px 0 0","color":"#333","display":"inline-block","lineHeight":"40px","fontSize":"14px","fontWeight":"500","height":"40px"}' class="item-label">预约人</label>
						<el-input v-model="searchForm.username" placeholder="预约人" clearable></el-input>
					</div>
					<div :style='{"margin":"0 10px 0 0","display":"inline-block"}'>
						<label :style='{"margin":"0 10px 0 0","color":"#333","display":"inline-block","lineHeight":"40px","fontSize":"14px","fontWeight":"500","height":"40px"}' class="item-label">状态</label>
						<el-select v-model="searchForm.status" placeholder="请选择状态" clearable>
							<el-option label="已预约" value="已预约"></el-option>
							<el-option label="已取消" value="已取消"></el-option>
							<el-option label="已完成" value="已完成"></el-option>
						</el-select>
					</div>
					<el-button :style='{"border":"0","cursor":"pointer","padding":"0 24px","outline":"none","color":"#fff","borderRadius":"4px","background":"#00a9aa","width":"auto","fontSize":"14px","height":"40px"}' type="success" @click="search()">查询</el-button>
				</el-row>

				<el-row :style='{"margin":"20px 0","display":"flex"}'>
					<el-button :style='{"border":"0","cursor":"pointer","padding":"0 24px","margin":"0 10px 0 0","outline":"none","color":"#fff","borderRadius":"4px","background":"rgba(255, 0, 0, 1)","width":"auto","fontSize":"14px","height":"40px"}' v-if="isAuth('classroomreservation','删除')" :disabled="dataListSelections.length <= 0" type="danger" @click="deleteHandler()">删除</el-button>
					
					<download-excel v-if="isAuth('classroomreservation','导出')" class="export-excel-wrapper" :data="dataList" :fields="json_fields" name="教室预约.xls">
						<el-button :style='{"border":"0","cursor":"pointer","padding":"0 24px","margin":"0 10px 0 0","outline":"none","color":"#fff","borderRadius":"4px","background":"rgba(255, 128, 0, 1)","width":"auto","fontSize":"14px","height":"40px"}' type="danger">导出</el-button>
					</download-excel>
				</el-row>
			</el-form>
			
			<el-table class="tables"
				:stripe='false'
				:style='{"padding":"0","borderColor":"#eee","borderRadius":"10px","borderWidth":"1px 0 0 1px","background":"#fff","width":"100%","borderStyle":"solid"}' 
				v-if="isAuth('classroomreservation','查看')"
				:data="dataList"
				v-loading="dataListLoading"
			@selection-change="selectionChangeHandler">
				<el-table-column :resizable='true' type="selection" align="center" width="50"></el-table-column>
				<el-table-column :resizable='true' :sortable='true' label="索引" type="index" width="50" />
				<el-table-column :resizable='true' :sortable='true' prop="classroomName" label="教室名称">
					<template slot-scope="scope">
						{{scope.row.classroomName}}
					</template>
				</el-table-column>
				<el-table-column :resizable='true' :sortable='true' prop="username" label="预约人">
					<template slot-scope="scope">
						{{scope.row.username}}
					</template>
				</el-table-column>
				<el-table-column :resizable='true' :sortable='true' prop="startTime" label="开始时间">
					<template slot-scope="scope">
						{{scope.row.startTime}}
					</template>
				</el-table-column>
				<el-table-column :resizable='true' :sortable='true' prop="endTime" label="结束时间">
					<template slot-scope="scope">
						{{scope.row.endTime}}
					</template>
				</el-table-column>
				<el-table-column :resizable='true' :sortable='true' prop="purpose" label="预约目的">
					<template slot-scope="scope">
						{{scope.row.purpose}}
					</template>
				</el-table-column>
				<el-table-column :resizable='true' :sortable='true' prop="status" label="状态">
					<template slot-scope="scope">
						<el-tag v-if="scope.row.status === '已预约'" type="success">{{scope.row.status}}</el-tag>
						<el-tag v-else-if="scope.row.status === '已取消'" type="info">{{scope.row.status}}</el-tag>
						<el-tag v-else type="warning">{{scope.row.status}}</el-tag>
					</template>
				</el-table-column>
				<el-table-column :resizable='true' :sortable='true' prop="addtime" label="预约时间">
					<template slot-scope="scope">
						{{scope.row.addtime}}
					</template>
				</el-table-column>
				<el-table-column width="300" label="操作">
					<template slot-scope="scope">
						<el-button :style='{"border":"1px solid #3ca512","cursor":"pointer","padding":"0 10px 0 24px","margin":"3px 6px 3px 0","outline":"none","color":"#fff","borderRadius":"4px","background":"url(http://codegen.caihongy.cn/20221011/ca1c191554d24b108bc94f4a2046d636.png) #41b314 no-repeat 5px 8px","width":"auto","fontSize":"12px","height":"32px"}' v-if="isAuth('classroomreservation','查看')" type="success" size="mini" @click="addOrUpdateHandler(scope.row.id,'info')">详情</el-button>
						
						<el-button :style='{"border":"1px solid #00a0f0","cursor":"pointer","padding":"0 10px 0 24px","margin":"3px 6px 3px 0","outline":"none","color":"#fff","borderRadius":"4px","background":"url(http://codegen.caihongy.cn/20221011/161eb7a46f5d4cd19d68a1386174d662.png) #00aaff no-repeat 5px 8px","width":"auto","fontSize":"12px","height":"32px"}' v-if="isAuth('classroomreservation','取消') && scope.row.status === '已预约'" type="warning" size="mini" @click="cancelHandler(scope.row.id)">取消预约</el-button>
						
						<el-button :style='{"border":"0","cursor":"pointer","padding":"0 10px 0 24px","margin":"3px 6px 3px 0","outline":"none","color":"#fff","borderRadius":"4px","background":"url(http://codegen.caihongy.cn/20221011/68bd264a8e4341c6aa5409f871d590d0.png) #d9534f no-repeat 5px 8px","width":"auto","fontSize":"12px","height":"32px"}' v-if="isAuth('classroomreservation','删除')" type="danger" size="mini" @click="deleteHandler(scope.row.id)">删除</el-button>
					</template>
				</el-table-column>
			</el-table>
			<el-pagination
				@size-change="sizeChangeHandle"
				@current-change="currentChangeHandle"
				:current-page="pageIndex"
				background
				:page-sizes="[10, 20, 30, 50]"
				:page-size="pageSize"
				:layout="layouts.join()"
				:total="totalPage"
				prev-text="<"
				next-text=">"
				:hide-on-single-page="true"
				:style='{"width":"100%","padding":"0","margin":"20px 0 0","whiteSpace":"nowrap","color":"#eee","fontWeight":"500"}'
			></el-pagination>
		</template>
		
		<!-- 添加/修改页面 -->
		<add-or-update v-if="addOrUpdateFlag" :parent="this" ref="addOrUpdate"></add-or-update>
	</div>
</template>

<script>
import AddOrUpdate from "./add-or-update";
export default {
  data() {
    return {
      searchForm: {
        classroomName: "",
        username: "",
        status: ""
      },
      dataList: [],
      pageIndex: 1,
      pageSize: 10,
      totalPage: 0,
      dataListLoading: false,
      dataListSelections: [],
      showFlag: true,
      addOrUpdateFlag:false,
      layouts: ["total","prev","pager","next","sizes","jumper"],
      json_fields: {
        "教室名称": "classroomName",
        "预约人": "username",
        "开始时间": "startTime",
        "结束时间": "endTime",
        "预约目的": "purpose",
        "状态": "status",
        "预约时间": "addtime"
      }
    };
  },
  created() {
    this.init();
    this.getDataList();
    this.contentStyleChange()
  },
  components: {
    AddOrUpdate,
  },
  methods: {
    contentStyleChange() {
      this.contentPageStyleChange()
    },
    contentPageStyleChange(){
      let arr = []
    },
    init () {
    },
    search() {
      this.pageIndex = 1;
      this.getDataList();
    },
    // 获取数据列表
    getDataList() {
      this.dataListLoading = true;
      let params = {
        page: this.pageIndex,
        limit: this.pageSize,
        sort: 'id',
        order: 'desc',
      }
      if(this.searchForm.classroomName!='' && this.searchForm.classroomName!=undefined){
        params['classroomName'] = '%' + this.searchForm.classroomName + '%'
      }
      if(this.searchForm.username!='' && this.searchForm.username!=undefined){
        params['username'] = '%' + this.searchForm.username + '%'
      }
      if(this.searchForm.status!='' && this.searchForm.status!=undefined){
        params['status'] = this.searchForm.status
      }
      this.$http({
        url: "classroomreservation/page",
        method: "get",
        params: params
      }).then(({ data }) => {
        if (data && data.code === 0) {
          this.dataList = data.data.list;
          this.totalPage = data.data.total;
        } else {
          this.dataList = [];
          this.totalPage = 0;
        }
        this.dataListLoading = false;
      });
    },
    // 每页数
    sizeChangeHandle(val) {
      this.pageSize = val;
      this.pageIndex = 1;
      this.getDataList();
    },
    // 当前页
    currentChangeHandle(val) {
      this.pageIndex = val;
      this.getDataList();
    },
    // 多选
    selectionChangeHandler(val) {
      this.dataListSelections = val;
    },
    // 添加/修改
    addOrUpdateHandler(id,type) {
      this.showFlag = false;
      this.addOrUpdateFlag = true;
      if(type!='info'){
        type = 'else';
      }
      this.$nextTick(() => {
        this.$refs.addOrUpdate.init(id,type);
      });
    },
    // 取消预约
    cancelHandler(id) {
      this.$confirm(`确定要取消该教室预约吗?`, "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(() => {
        this.$http({
          url: `classroomreservation/cancel/${id}`,
          method: "post"
        }).then(({ data }) => {
          if (data && data.code === 0) {
            this.$message({
              message: "取消成功",
              type: "success",
              duration: 1500,
              onClose: () => {
                this.search();
              }
            });
          } else {
            this.$message.error(data.msg);
          }
        });
      });
    },
    // 删除
    deleteHandler(id) {
      var ids = id
        ? [Number(id)]
        : this.dataListSelections.map(item => {
            return Number(item.id);
          });
      this.$confirm(`确定进行[${id ? "删除" : "批量删除"}]操作?`, "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(() => {
        this.$http({
          url: "classroomreservation/delete",
          method: "post",
          data: ids
        }).then(({ data }) => {
          if (data && data.code === 0) {
            this.$message({
              message: "操作成功",
              type: "success",
              duration: 1500,
              onClose: () => {
                this.search();
              }
            });
          } else {
            this.$message.error(data.msg);
          }
        });
      });
    }
  }
};
</script>
<style lang="scss" scoped>
	@import "@/assets/styles/admin-table.scss";
</style>
