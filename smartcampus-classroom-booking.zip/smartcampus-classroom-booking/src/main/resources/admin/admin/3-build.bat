cnpm run build
