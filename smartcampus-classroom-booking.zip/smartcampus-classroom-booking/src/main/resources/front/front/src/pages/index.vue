<template>
	<div class="main-containers">
		<div class="top-container">
			<img v-if='true' class="logo-img" src='http://codegen.caihongy.cn/20201114/7856ba26477849ea828f481fa2773a95.jpg'>
			<div class="system-title">智能化校园教室预约管理系统</div>
			<div class="user-operations">
				<Notification v-if="Token" class="notification-component-wrapper" />
				<div v-if="false" class="contact-info">0753-1234567</div>
				<div v-if="Token" class="username">{{username}}</div>
				<el-button v-if="!Token" @click="toLogin()" class="login-btn">登录/注册</el-button>
                <el-button v-if="Token" @click="logout" class="logout-btn">退出</el-button>
			</div>
		</div>
		
		<div class="body-containers">
			<div class="menu-preview">
				<el-menu class="el-menu-horizontal-demo" :default-active="activeIndex" :unique-opened="true" mode="horizontal" :router="true" @select="handleSelect">
					<el-image v-if="false" class="menu-logo" src="http://codegen.caihongy.cn/20201114/7856ba26477849ea828f481fa2773a95.jpg" fit="cover"></el-image>
					<el-menu-item v-for="(menu, index) in menuList" :index="index + ''" :key="index" :route="menu.url">
						<i v-if="false" :class="iconArr[index]" class="menu-icon"></i>
						<span class="menu-text">{{menu.name}}</span>
					</el-menu-item>
					<el-menu-item @click="goChat">
						<i v-if="false" class="el-icon-service menu-icon"></i>
						<span class="menu-text">在线咨询</span>
					</el-menu-item>
					<el-menu-item :index="menuList.length + 2 + ''" v-if="Token && notAdmin" @click="goMenu('/index/center')">
						<i v-if="false" class="el-icon-user menu-icon"></i>
						<span class="menu-text">个人中心</span>
					</el-menu-item>
				</el-menu>
			</div>
			
			<div class="banner-preview">
				<el-carousel class="carousel-container" trigger="click" indicator-position="inside" arrow="always" type="default" direction="horizontal" height="550px" :autoplay="true" :interval="5000" :loop="true">
					<el-carousel-item class="carousel-item" v-for="item in carouselList" :key="item.id">
						<el-image class="carousel-img" :src="baseUrl + item.value" fit="cover" @mouseenter="handleImgHover($event)" @mouseleave="handleImgLeave($event)"></el-image>
					</el-carousel-item>
				</el-carousel>
			</div>
			
			<router-view></router-view>
			
			<div class="bottom-preview">
			    <img class="footer-logo" src="http://codegen.caihongy.cn/20201114/7856ba26477849ea828f481fa2773a95.jpg" >
			    <div class="copyright">智能化校园教室预约管理系统 © 2025</div>
			    <div class="service-hours">服务时间: 每日 8:00-22:00</div>
			    <div class="contact-phone">联系电话: 0753-1234567</div>
			</div>
		</div>
		
        <el-dialog title="在线咨询" :visible.sync="chatFormVisible" width="600px" :before-close="chatClose" class="chat-dialog">
            <div class="chat-content">
                <div :class="{'right-content': item.reply == '' || item.reply == null, 'left-content': item.ask == '' || item.ask == null}"
                    v-for="item in chatList" :key="item.id" class="chat-message">
                    <el-tag :type="(item.ask == '' || item.ask == null) ? 'info' : 'primary'" class="message-tag">
                        {{(item.ask == '' || item.ask == null) ? item.reply : item.ask}}
                    </el-tag>
                </div>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-input v-model="form.ask" placeholder="请输入您的问题..." class="chat-input">
                </el-input>
                <el-button type="primary" @click="addChat" class="send-btn">
                    <i class="el-icon-document"></i>发送
                </el-button>
            </div>
        </el-dialog>
	</div>
</template>

<script>
import Vue from 'vue'
import Notification from '../components/Notification.vue'

export default {
    components: {
        Notification
    },
    data() {
		return {
            activeIndex: '0',
			roleMenus: [],
			baseUrl: '',
			carouselList: [],
			menuList: [],
			chatFormVisible: false,
			chatList: [],
			form: {
				ask: '',
				userid: localStorage.getItem('userid')
			},
			Token: localStorage.getItem('Token'),
            username: localStorage.getItem('username'),
            notAdmin: localStorage.getItem('sessionTable')!='"admin"',
			timer: '',
			iconArr: [
				'el-icon-star-off',
				'el-icon-goods',
				'el-icon-warning',
				'el-icon-question',
				'el-icon-info',
				'el-icon-help',
				'el-icon-picture-outline-round',
				'el-icon-camera-solid',
				'el-icon-video-camera-solid',
				'el-icon-video-camera',
				'el-icon-bell',
				'el-icon-s-cooperation',
				'el-icon-s-order',
				'el-icon-s-platform',
				'el-icon-s-operation',
				'el-icon-s-promotion',
				'el-icon-s-release',
				'el-icon-s-ticket',
				'el-icon-s-management',
				'el-icon-s-open',
				'el-icon-s-shop',
				'el-icon-s-marketing',
				'el-icon-s-flag',
				'el-icon-s-comment',
				'el-icon-s-finance',
				'el-icon-s-claim',
				'el-icon-s-opportunity',
				'el-icon-s-data',
				'el-icon-s-check'
			],	
		}
    },
    created() {
		this.baseUrl = this.$config.baseUrl;
		this.menuList = this.$config.indexNav;
		this.getCarousel();
        if(localStorage.getItem('Token') && localStorage.getItem('Token')!=null) {
            this.saveChathelper('主人，我是您的智能助手小搏，请问有什么可以帮您！');
            this.getChatList();
        }
    },
    mounted() {
        this.activeIndex = localStorage.getItem('keyPath') || '0';
        // 添加滚动时顶部导航栏样式变化效果
        window.addEventListener('scroll', this.handleScroll);
    },
    beforeDestroy() {
        window.removeEventListener('scroll', this.handleScroll);
    },
    watch: {
        $route(newValue) {
            let that = this
            let url = window.location.href
            let arr = url.split('#')
            for (let x in this.menuList) {
                if (newValue.path == this.menuList[x].url) {
                    this.activeIndex = x
                }
            }
            this.Token = localStorage.getItem('Token')
        },
    },
    methods: {
        handleSelect(keyPath) {
            if (keyPath) {
                localStorage.setItem('keyPath', keyPath)
            }
        },
		toLogin() {
		  this.$router.push('/login');
		},
        logout() {
            localStorage.clear();
            Vue.http.headers.common['Token'] = "";
            this.$router.push('/index/home');
            this.activeIndex = '0'
            localStorage.setItem('keyPath', this.activeIndex)
            this.Token = ''
            this.$forceUpdate()
            this.$message({
                message: '登出成功',
                type: 'success',
                duration: 1000,
            });
        },
		getCarousel() {
			this.$http.get('config/list', {params: { page: 1, limit: 3 }}).then(res => {
				if (res.data.code == 0) {
					this.carouselList = res.data.data.list;
				}
			});
		},
		goBackend() {
			window.open(`${this.$config.baseUrl}admin/dist/index.html`, "_blank");
		},
		getChatList() {
			this.$http.get('chat/list', {params: { userid: localStorage.getItem('userid'), sort: 'addtime', order: 'asc',limit: 1000 }}).then(res => {
				if (res.data.code == 0) {
					this.chatList = res.data.data.list;
                    let div = document.getElementsByClassName('chat-content')[0]
                    setTimeout(() => {
                        if (div)
                            div.scrollTop = div.scrollHeight
                    }, 0)
				}
			});
		},
		addChat() {
			this.$http.post('chat/add', this.form).then(res => {
				if (res.data.code == 0) {
					this.form.ask = '';
					this.getChatList();
				}
			});
		},
		chatClose() {
			clearInterval(this.timer);
			this.chatFormVisible = false;
		},
		goChat() {
            if(!localStorage.getItem('Token')) {
                this.toLogin();
                return;
            }
			this.chatFormVisible = true;
			this.timer = setInterval(this.getChatList, 2000);
		},
		goMenu(path) {
            if (!localStorage.getItem('Token')) {
                this.toLogin();
            } else {
                this.$router.push(path);
            }
        },
        // 处理滚动事件，改变顶部导航样式
        handleScroll() {
            const topContainer = document.querySelector('.top-container');
            if (window.scrollY > 50) {
                topContainer.style.height = '100px';
                topContainer.style.boxShadow = '0 4px 15px rgba(52, 152, 219, 0.2)';
            } else {
                topContainer.style.height = '152px';
                topContainer.style.boxShadow = '0 2px 15px rgba(52, 152, 219, 0.15)';
            }
        },
        // 轮播图图片悬停效果
        handleImgHover(event) {
            event.currentTarget.style.transform = 'scale(1.02)';
        },
        handleImgLeave(event) {
            event.currentTarget.style.transform = 'scale(1)';
        },
        // 保存聊天助手欢迎语
        saveChathelper(content) {
            this.$http.post('chat/add', {
                ask: content,
                userid: localStorage.getItem('userid')
            }).then(res => {
                if (res.data.code == 0) {
                    this.getChatList();
                }
            });
        }
    }
}
</script>

<style scoped>
/* 基础样式 */
.main-containers {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* 顶部容器样式 */
.top-container {
    box-shadow: 0 2px 15px rgba(52, 152, 219, 0.15);
    padding: 0px;
    align-items: center;
    display: flex;
    justify-content: space-between;
    overflow: hidden;
    top: 0;
    left: 0;
    background: linear-gradient(135deg, #e6f2ff 0%, #d1e7fe 100%);
    width: 100%;
    position: relative;
    height: 152px;
    z-index: 1002;
    transition: all 0.3s ease;
}

.logo-img {
    width: 0px;
    object-fit: cover;
    border-radius: 100%;
    display: block;
    height: 0px;
}

.system-title {
    margin: 0 auto;
    overflow: hidden;
    color: #2980b9;
    text-align: center;
    left: 20%;
    background: none;
    width: 60%;
    font-size: 30px;
    line-height: 74px;
    position: absolute;
    height: 64px;
    font-weight: 600;
    text-shadow: 0 1px 2px rgba(255,255,255,0.8);
}

.user-operations {
    padding-right: 20px;
    display: flex;
    align-items: center;
    gap: 15px;
}

.notification-component-wrapper {
    margin-right: 5px;
}

.contact-info {
    color: #3498db;
    font-size: 16px;
    display: inline-block;
}

.username {
    color: #2980b9;
    font-size: 16px;
    display: inline-block;
    margin-right: 10px;
}

.login-btn {
    padding: 0 12px;
    margin: 0 0 0 10px;
    color: #fff;
    border-radius: 20px;
    background: #3498db;
    display: inline-block;
    font-size: 14px;
    line-height: 32px;
    height: 32px;
    border: none;
    transition: all 0.3s ease;
    box-shadow: 0 2px 5px rgba(52, 152, 219, 0.2);
}

.logout-btn {
    padding: 0 12px;
    margin: 0 50px 0 10px;
    color: #2980b9;
    border-radius: 20px;
    background: #e6f2ff;
    display: inline-block;
    font-size: 14px;
    line-height: 32px;
    height: 32px;
    border: 1px solid #b8daff;
    transition: all 0.3s ease;
}

/* 主体容器样式 */
.body-containers {
    padding: 0;
    margin: 0;
    position: relative;
    background: #f8fcff;
}

/* 菜单预览样式 */
.menu-preview {
    padding: 0;
    border-color: #e6f2ff;
    margin: 10px 0px 2px;
    background: none;
    border-width: 0;
    width: 100%;
    border-style: solid;
    height: auto;
}

.el-menu-horizontal-demo {
    border: 0;
    padding: 0;
    list-style: none;
    margin: 0;
    flex-wrap: wrap;
    background: #fff;
    display: flex;
    position: relative;
    justify-content: center;
    box-shadow: 0 2px 10px rgba(52, 152, 219, 0.05);
}

.menu-logo {
    width: 44px;
    margin: 8px 10px 8px 0;
    object-fit: cover;
    border-radius: 100%;
    float: left;
    height: 44px;
}

.el-menu-item {
    cursor: pointer;
    border: 0;
    padding: 0 25px !important;
    color: #2980b9 !important;
    background: #fff !important;
    font-weight: 500;
    display: flex;
    font-size: 16px !important;
    line-height: 66px !important;
    align-items: center;
    position: relative;
    height: 66px !important;
    transition: all 0.3s ease !important;
}

.el-menu-item:hover {
    cursor: pointer;
    padding: 0 25px !important;
    color: #1e6091 !important;
    background: #e6f2ff !important;
    font-size: 16px !important;
    line-height: 66px !important;
    height: 66px !important;
    transform: translateY(-2px) !important;
}

.el-menu-item.is-active {
    cursor: pointer;
    border: 0;
    padding: 0 25px !important;
    color: #1e6091 !important;
    background: #e6f2ff !important;
    font-size: 16px !important;
    line-height: 66px !important;
    height: 66px !important;
    font-weight: 600;
    position: relative;
}

.el-menu-item.is-active::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 80%;
    height: 3px;
    background: #3498db;
    border-radius: 3px 3px 0 0;
}

.menu-icon {
    padding: 0 10px;
    margin: 0;
    color: inherit;
    width: 14px;
    line-height: 60px;
    font-size: 14px;
    height: 60px;
}

.menu-text {
    color: inherit;
    font-size: 16px;
}

/* 轮播图样式 */
.banner-preview {
    width: 100%;
    height: auto;
    padding: 20px 0;
    box-sizing: border-box;
}

.carousel-container {
    width: 90%;
    margin: 0 auto;
    height: 100%;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(52, 152, 219, 0.1);
}

.carousel-item {
    border-radius: 0;
    width: 100%;
    height: 100%;
}

.carousel-img {
    object-fit: cover;
    width: 100%;
    height: 100%;
    transition: transform 0.5s ease;
}

/* 轮播图箭头和指示器样式 */
::v-deep .el-carousel__indicator button {
    width: 0;
    height: 0;
    display: none;
}

::v-deep .el-carousel__container .el-carousel__arrow--left {
    background: rgba(255,255,255,0.8);
    width: 45px;
    font-size: 16px;
    height: 45px;
    border-radius: 50%;
    color: #3498db;
    transition: all 0.3s ease;
    opacity: 0.7;
}

::v-deep .el-carousel__container .el-carousel__arrow--left:hover {
    background: #fff;
    opacity: 1;
    transform: scale(1.1);
}

::v-deep .el-carousel__container .el-carousel__arrow--right {
    background: rgba(255,255,255,0.8);
    width: 45px;
    font-size: 16px;
    height: 45px;
    border-radius: 50%;
    color: #3498db;
    transition: all 0.3s ease;
    opacity: 0.7;
}

::v-deep .el-carousel__container .el-carousel__arrow--right:hover {
    background: #fff;
    opacity: 1;
    transform: scale(1.1);
}

::v-deep .el-carousel__indicators {
    z-index: 2;
    bottom: 20px;
    top: auto;
    width: 100%;
    position: absolute;
    list-style: none;
    text-align: center;
}

::v-deep .el-carousel__indicators li {
    border-radius: 5px;
    padding: 0;
    margin: 0 6px;
    background: rgba(255,255,255,0.5);
    display: inline-block;
    width: 10px;
    opacity: 0.7;
    transition: 0.3s;
    height: 10px;
}

::v-deep .el-carousel__indicators li:hover {
    padding: 0;
    margin: 0 6px;
    background: #fff;
    display: inline-block;
    width: 24px;
    opacity: 1;
    height: 10px;
}

::v-deep .el-carousel__indicators li.is-active {
    padding: 0;
    margin: 0 6px;
    background: #3498db;
    display: inline-block;
    width: 24px;
    opacity: 1;
    height: 10px;
}

/* 底部样式 */
.bottom-preview {
    min-height: 200px;
    padding: 20px 0;
    border-color: #3498db;
    align-items: center;
    background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
    flex-direction: column;
    border-width: 0 0 0;
    display: flex;
    width: 100%;
    border-style: solid;
    justify-content: center;
    color: #fff;
    margin-top: 50px;
}

.footer-logo {
    width: 44px;
    object-fit: cover;
    border-radius: 100%;
    display: none;
    height: 44px;
}

.copyright {
    margin: 10px 0 0;
    font-size: 14px;
    line-height: 28px;
    color: rgba(255,255,255,0.9);
}

.service-hours {
    margin: 5px 0 0;
    font-size: 14px;
    line-height: 28px;
    color: rgba(255,255,255,0.8);
}

.contact-phone {
    margin: 5px 0 0;
    font-size: 14px;
    line-height: 28px;
    color: rgba(255,255,255,0.8);
}

/* 聊天对话框样式 */
.chat-dialog {
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 5px 25px rgba(52, 152, 219, 0.2);
}

.chat-content {
    background: #f8fcff;
    padding: 15px;
    box-sizing: border-box;
    overflow-y: scroll;
    max-height: 40vh;
    min-height: 40vh;
    border-radius: 5px;
}

.chat-message {
    margin: 8px 0;
    animation: fadeIn 0.3s ease-in-out;
}

.left-content {
    width: 100%;
    text-align: left;
}

.right-content {
    width: 100%;
    text-align: right;
}

.message-tag {
    margin: 5px 0;
    max-width: 70%;
    padding: 8px 12px;
    line-height: 1.5;
    border-radius: 10px;
}

.dialog-footer {
    display: flex;
    align-items: center;
}

.chat-input {
    width: calc(100% - 80px);
    float: left;
    border-radius: 20px;
    border-color: #b8daff;
}

.send-btn {
    border-radius: 20px;
    width: 60px;
    height: 40px;
    padding: 0;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
    margin: 0 10px 0 10px;
}

/* 按钮悬停效果 */
::v-deep .el-button--primary:hover {
    background-color: #2980b9 !important;
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(52, 152, 219, 0.3) !important;
}

/* 对话框标题样式 */
::v-deep .el-dialog__title {
    color: #2980b9;
    font-weight: 600;
    font-size: 18px;
}

/* 动画效果 */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* 菜单滚动条样式 */
.menu-preview .el-scrollbar {
    height: 100%;
}

.menu-preview .el-scrollbar ::v-deep .scrollbar-wrapper {
    overflow-x: hidden;
}
</style>
