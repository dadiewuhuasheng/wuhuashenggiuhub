<template>
  <div class="center-preview">
    <div class="title">{{ title }}</div>

    <el-tabs tab-position="left" class="tabs-container" @tab-click="handleClick">
      <el-tab-pane label="个人中心">
        <el-form class="center-preview-pv" ref="sessionForm" :model="sessionForm" :rules="rules" label-width="120px">
          <el-form-item v-if="userTableName == 'users'" label="用户账号" prop="username" class="form-item">
            <el-input v-model="sessionForm.username" placeholder="用户账号" readonly></el-input>
          </el-form-item>
          <el-form-item v-if="userTableName == 'users'" label="密码" prop="password" class="form-item">
            <el-input type="password" v-model="sessionForm.password" placeholder="密码"></el-input>
          </el-form-item>
          <el-form-item v-if="userTableName == 'users'" label="用户姓名" prop="nickname" class="form-item">
            <el-input v-model="sessionForm.nickname" placeholder="用户姓名"></el-input>
          </el-form-item>
          <el-form-item v-if="userTableName == 'users'" label="性别" class="form-item">
            <el-select v-model="sessionForm.gender" placeholder="请选择性别">
              <el-option v-for="(item, index) in dynamicProp.gender" :key="index" :label="item" :value="item"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item v-if="userTableName == 'users'" label="头像" class="form-item">
            <el-upload class="avatar-uploader" :action="uploadUrl" :headers="headers" :show-file-list="false"
              :on-success="usersavatarHandleAvatarSuccess">
              <img v-if="sessionForm.avatar" :src="baseUrl + sessionForm.avatar" class="avatar">
              <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </el-form-item>
          <el-form-item v-if="userTableName == 'users'" label="用户电话" prop="telephone" class="form-item">
            <el-input v-model="sessionForm.telephone" placeholder="用户电话"></el-input>
          </el-form-item>
          <el-form-item class="balance form-item" v-if="userTableName == 'users'" label="余额">
            <div class="balance-container">
              <el-input v-model="sessionForm.money" placeholder="余额" readonly></el-input>
              <div @click="dialogFormVisibleMoney = true" class="recharge-btn">点我充值</div>
            </div>
          </el-form-item>
          <el-form-item class="button-group">
            <el-button class="update-btn" type="primary" @click="onSubmit('sessionForm')">更新信息</el-button>
            <el-button class="logout-btn" type="danger" @click="logout">退出登录</el-button>
          </el-form-item>
        </el-form>

        <el-dialog title="用户充值" :visible.sync="dialogFormVisibleMoney" width="726px" center>
          <el-form :model="chongzhiForm">
            <el-form-item label="充值金额" label-width="120px">
              <el-input type="number" v-model="chongzhiForm.money" autocomplete="off" placeholder="充值金额"></el-input>
            </el-form-item>
            <el-form-item label-width="120px">
              <el-radio-group v-model="chongzhiForm.radio">
                <el-radio style="margin-bottom: 30px" label="微信支付">
                  <el-image style="width: 60px; height: 60px;vertical-align: middle;"
                    :src="require('@/assets/weixin.png')" fit="fill"></el-image>
                  <span style="display: inline-block;margin-left: 10px">微信支付</span>
                </el-radio>
                <el-radio label="支付宝支付">
                  <el-image style="width: 60px; height: 60px;vertical-align: middle;"
                    :src="require('@/assets/zhifubao.png')" fit="fill"></el-image>
                  <span style="display: inline-block;margin-left: 10px">支付宝支付</span>
                </el-radio>
                <el-radio label="中国建设银行支付">
                  <el-image style="width: 120px; height: 60px;vertical-align: middle;"
                    :src="require('@/assets/jianshe.png')" fit="fill"></el-image>
                </el-radio>
                <el-radio label="中国农业银行支付">
                  <el-image style="width: 126px; height: 60px;vertical-align: middle;"
                    :src="require('@/assets/nongye.png')" fit="fill"></el-image>
                </el-radio>
                <el-radio label="中国银行支付">
                  <el-image style="width: 140px; height: 60px;vertical-align: middle;"
                    :src="require('@/assets/zhongguo.png')" fit="fill"></el-image>
                </el-radio>
                <el-radio label="交通银行支付">
                  <el-image style="width: 120px; height: 60px;vertical-align: middle;"
                    :src="require('@/assets/jiaotong.png')" fit="fill"></el-image>
                </el-radio>
              </el-radio-group>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisibleMoney = false">取 消</el-button>
            <el-button type="primary" @click="chongzhi">确认充值</el-button>
          </div>
        </el-dialog>
        <el-dialog title="会员购买" :visible.sync="dialogFormVisibleVip" width="726px" center>
          <el-form :model="chongzhiForm">
            <el-form-item label="会员卡" label-width="120px">
              <el-input readonly autocomplete="off" value="￥199/年"></el-input>
            </el-form-item>
            <el-form-item label-width="120px">
              <el-radio-group v-model="chongzhiForm.radio">
                <el-radio style="margin-bottom: 30px" label="微信支付">
                  <el-image style="width: 60px; height: 60px;vertical-align: middle;"
                    :src="require('@/assets/weixin.png')" fit="fill"></el-image>
                  <span style="display: inline-block;margin-left: 10px">微信支付</span>
                </el-radio>
                <el-radio label="支付宝支付">
                  <el-image style="width: 60px; height: 60px;vertical-align: middle;"
                    :src="require('@/assets/zhifubao.png')" fit="fill"></el-image>
                  <span style="display: inline-block;margin-left: 10px">支付宝支付</span>
                </el-radio>
                <el-radio label="中国建设银行支付">
                  <el-image style="width: 120px; height: 60px;vertical-align: middle;"
                    :src="require('@/assets/jianshe.png')" fit="fill"></el-image>
                </el-radio>
                <el-radio label="中国农业银行支付">
                  <el-image style="width: 126px; height: 60px;vertical-align: middle;"
                    :src="require('@/assets/nongye.png')" fit="fill"></el-image>
                </el-radio>
                <el-radio label="中国银行支付">
                  <el-image style="width: 140px; height: 60px;vertical-align: middle;"
                    :src="require('@/assets/zhongguo.png')" fit="fill"></el-image>
                </el-radio>
                <el-radio label="交通银行支付">
                  <el-image style="width: 120px; height: 60px;vertical-align: middle;"
                    :src="require('@/assets/jiaotong.png')" fit="fill"></el-image>
                </el-radio>
              </el-radio-group>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisibleVip = false">取 消</el-button>
            <el-button type="primary" @click="chongzhivip">确认支付</el-button>
          </div>
        </el-dialog>
      </el-tab-pane>
      <el-tab-pane label="我的预约">
        <div class="my-reservations-section">
          <h3 class="section-title">座位预约</h3>
          <div class="reservation-list" v-if="seatReservations.length > 0">
            <el-table
              :data="seatReservations"
              style="width: 100%"
              stripe
              :header-cell-style="{background:'#f5f7fa',color:'#606266'}">
              <el-table-column prop="libseatmingcheng" label="座位名称" width="180"></el-table-column>
              <el-table-column prop="startTime" label="开始时间" width="180">
                <template slot-scope="scope">
                  {{ formatTime(scope.row.startTime) }}
                </template>
              </el-table-column>
              <el-table-column prop="endTime" label="结束时间" width="180">
                <template slot-scope="scope">
                  {{ formatTime(scope.row.endTime) }}
                </template>
              </el-table-column>
              <el-table-column prop="status" label="状态" width="120">
                <template slot-scope="scope">
                  <el-tag :type="getOrderStatusType(scope.row.status)" size="small">
                    {{ scope.row.status }}
                  </el-tag>
                </template>
              </el-table-column>
              <el-table-column prop="addtime" label="预约时间" width="180">
                <template slot-scope="scope">
                  {{ formatTime(scope.row.addtime) }}
                </template>
              </el-table-column>
              <el-table-column label="操作" width="150" fixed="right">
                <template slot-scope="scope">
                  <el-button
                    v-if="scope.row.status === '未支付'"
                    type="success"
                    size="mini"
                    @click="paySeatReservation(scope.row)">
                    支付
                  </el-button>
                  <el-button
                    v-if="scope.row.status === '未支付'"
                    type="danger"
                    size="mini"
                    @click="cancelSeatReservation(scope.row)">
                    取消
                  </el-button>
                  <el-button
                    v-if="scope.row.status === '已预约'"
                    type="info"
                    size="mini"
                    @click="viewSeatDetails(scope.row)">
                    详情
                  </el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div v-else class="empty-state">
            <i class="el-icon-document"></i>
            <p>暂无座位预约记录</p>
          </div>

          <h3 class="section-title" style="margin-top: 30px;">教室预约</h3>
          <div class="reservation-list" v-if="classroomReservations.length > 0">
            <el-table
              :data="classroomReservations"
              style="width: 100%"
              stripe
              :header-cell-style="{background:'#f5f7fa',color:'#606266'}">
              <el-table-column prop="classroomName" label="教室名称" width="180"></el-table-column>
              <el-table-column prop="startTime" label="开始时间" width="180">
                <template slot-scope="scope">
                  {{ formatTime(scope.row.startTime) }}
                </template>
              </el-table-column>
              <el-table-column prop="endTime" label="结束时间" width="180">
                <template slot-scope="scope">
                  {{ formatTime(scope.row.endTime) }}
                </template>
              </el-table-column>
              <el-table-column prop="purpose" label="使用目的" show-overflow-tooltip></el-table-column>
              <el-table-column prop="status" label="状态" width="120">
                <template slot-scope="scope">
                  <el-tag :type="getStatusType(scope.row.status)" size="small">
                    {{ getStatusText(scope.row.status) }}
                  </el-tag>
                </template>
              </el-table-column>
              <el-table-column prop="addtime" label="预约时间" width="180">
                <template slot-scope="scope">
                  {{ formatTime(scope.row.addtime) }}
                </template>
              </el-table-column>
              <el-table-column label="操作" width="150" fixed="right">
                <template slot-scope="scope">
                  <el-button
                    v-if="scope.row.status === 'pending' || scope.row.status === 'approved'"
                    type="danger"
                    size="mini"
                    @click="cancelClassroomReservation(scope.row)">
                    取消
                  </el-button>
                  <el-button
                    type="info"
                    size="mini"
                    @click="viewClassroomDetails(scope.row)">
                    详情
                  </el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div v-else class="empty-state">
            <i class="el-icon-document"></i>
            <p>暂无教室预约记录</p>
            <el-button type="primary" size="small" @click="goToClassroomReservation">去预约教室</el-button>
          </div>
        </div>

        <!-- 教室预约详情对话框 -->
        <el-dialog title="教室预约详情" :visible.sync="classroomDetailDialogVisible" width="600px">
          <div v-if="currentClassroomReservation" class="detail-content">
            <div class="detail-item">
              <span class="detail-label">教室名称：</span>
              <span class="detail-value">{{ currentClassroomReservation.classroomName }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">开始时间：</span>
              <span class="detail-value">{{ formatTime(currentClassroomReservation.startTime) }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">结束时间：</span>
              <span class="detail-value">{{ formatTime(currentClassroomReservation.endTime) }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">使用目的：</span>
              <span class="detail-value">{{ currentClassroomReservation.purpose }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">预约状态：</span>
              <el-tag :type="getStatusType(currentClassroomReservation.status)" size="small">
                {{ getStatusText(currentClassroomReservation.status) }}
              </el-tag>
            </div>
            <div class="detail-item">
              <span class="detail-label">预约时间：</span>
              <span class="detail-value">{{ formatTime(currentClassroomReservation.addtime) }}</span>
            </div>
          </div>
          <div slot="footer" class="dialog-footer">
            <el-button @click="classroomDetailDialogVisible = false">关闭</el-button>
          </div>
        </el-dialog>

        <!-- 座位预约详情对话框 -->
        <el-dialog title="座位预约详情" :visible.sync="seatDetailDialogVisible" width="600px">
          <div v-if="currentSeatReservation" class="detail-content">
            <div class="detail-item">
              <span class="detail-label">座位名称：</span>
              <span class="detail-value">{{ currentSeatReservation.goodname }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">开始时间：</span>
              <span class="detail-value">{{ currentSeatReservation.startTime || '-' }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">结束时间：</span>
              <span class="detail-value">{{ currentSeatReservation.endTime || '-' }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">预约状态：</span>
              <el-tag :type="getOrderStatusType(currentSeatReservation.status)" size="small">
                {{ currentSeatReservation.status }}
              </el-tag>
            </div>
            <div class="detail-item">
              <span class="detail-label">总价：</span>
              <span class="detail-value">￥{{ currentSeatReservation.total }}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">预约时间：</span>
              <span class="detail-value">{{ currentSeatReservation.addtime }}</span>
            </div>
          </div>
          <div slot="footer" class="dialog-footer">
            <el-button @click="seatDetailDialogVisible = false">关闭</el-button>
          </div>
        </el-dialog>
      </el-tab-pane>
      <el-tab-pane label="收藏"></el-tab-pane>
    </el-tabs>
  </div>
</template>
  
<script>
import config from '@/config/config'
import Vue from 'vue'
export default {
  //数据集合
  data() {
    return {
      title: '个人中心',
      baseUrl: config.baseUrl,
      sessionForm: {},
      rules: {},
      chongzhiForm: {
        money: '',
        radio: ''
      },
      disabled: false,
      dialogFormVisibleMoney: false,
      dialogFormVisibleVip: false,
      uploadUrl: config.baseUrl + 'file/upload',
      imageUrl: '',
      headers: { Token: localStorage.getItem('Token') },
      userTableName: localStorage.getItem('UserTableName'),
      dynamicProp: {},
      seatReservations: [],
      classroomReservations: [],
      classroomDetailDialogVisible: false,
      currentClassroomReservation: null,
      seatDetailDialogVisible: false,
      currentSeatReservation: null
    }
  },
  created() {
    if ('users' == this.userTableName) {
      this.$set(this.sessionForm, 'username', null);
    }
    if ('users' == this.userTableName) {
      this.$set(this.sessionForm, 'password', null);
    }
    if ('users' == this.userTableName) {
      this.$set(this.sessionForm, 'nickname', null);
    }
    if ('users' == this.userTableName) {
      this.$set(this.sessionForm, 'gender', null);
    }
    if ('users' == this.userTableName) {
      this.$set(this.sessionForm, 'avatar', null);
    }
    if ('users' == this.userTableName) {
      this.$set(this.sessionForm, 'telephone', null);
    }
    if ('users' == this.userTableName) {
      this.$set(this.sessionForm, 'money', null);
    }

    if ('users' == this.userTableName) {
      this.$set(this.rules, 'username', [{ required: true, message: '请输入用户账号', trigger: 'blur' }]);
    }
    if ('users' == this.userTableName) {
      this.$set(this.rules, 'password', [{ required: true, message: '请输入密码', trigger: 'blur' }]);
    }
    if ('users' == this.userTableName) {
      this.$set(this.rules, 'telephone', [{ required: false, validator: this.$validate.isMobile, trigger: 'blur' }]);
    }
    if ('users' == this.userTableName) {
      this.$set(this.rules, 'money', [{ required: false, validator: this.$validate.isNumber, trigger: 'blur' }]);
    }

    this.init();
    this.getSession();
  },
  //方法集合
  methods: {
    init() {
      if ('users' == this.userTableName) {
        this.dynamicProp.gender = '男,女'.split(',');
      }
    },
    getSession() {
      this.$http.get(this.userTableName + '/session', { emulateJSON: true }).then(res => {
        if (res.data.code == 0) {
          this.sessionForm = res.data.data;
          localStorage.setItem('userid', res.data.data.id);
          if (res.data.data.vip) {
            localStorage.setItem('vip', res.data.data.vip);
          }
          if (res.data.data.avatar) {
            localStorage.setItem('headportrait', res.data.data.avatar);
          } else if (res.data.data.headportrait) {
            localStorage.setItem('headportrait', res.data.data.headportrait);
          }
        }
      });
    },
    onSubmit(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$http.post(this.userTableName + '/update', this.sessionForm).then(res => {
            if (res.data.code == 0) {
              this.$message({
                message: '更新成功',
                type: 'success',
                duration: 1500
              });
            }
          });
        } else {
          return false;
        }
      });
    },
    usersavatarHandleAvatarSuccess(res, file) {
      if (res.code == 0) {
        if ('users' == this.userTableName) {
          this.sessionForm.avatar = 'upload/' + res.file;
        }
      }
    },
    chongzhi() {
      if (this.chongzhiForm.money == '') {
        this.$message({
          message: '请输入充值金额',
          type: 'error',
          duration: 1500
        });
        return;
      }
      if (this.chongzhiForm.money <= 0) {
        this.$message({
          message: '请输入正确的充值金额',
          type: 'error',
          duration: 1500
        });
        return;
      }
      if (this.chongzhiForm.radio == '') {
        this.$message({
          message: '请选择充值方式',
          type: 'error',
          duration: 1500
        });
        return;
      }
      this.sessionForm.money = parseInt(this.sessionForm.money) + parseInt(this.chongzhiForm.money);
      this.$http.post(this.userTableName + '/update', this.sessionForm).then(res => {
        if (res.data.code == 0) {
          this.$message({
            message: '充值成功',
            type: 'success',
            duration: 1500,
            onClose: () => {
              this.dialogFormVisibleMoney = false;
            }
          });
        }
      });
    },
    chongzhivip() {
      this.chongzhiForm.money == 199;
      if (this.chongzhiForm.radio == '') {
        this.$message({
          message: '请选择支付方式',
          type: 'error',
          duration: 1500
        });
        return;
      }
      if (this.sessionForm.vip == '是') {
        this.$message({
          message: '您已是我们的尊贵会员。',
          type: 'success',
          duration: 1500
        });
        return;
      }

      this.sessionForm.vip = "是"
      this.$http.post(this.userTableName + '/update', this.sessionForm).then(res => {
        if (res.data.code == 0) {
          this.$message({
            message: '会员购买成功',
            type: 'success',
            duration: 1500,
            onClose: () => {
              localStorage.setItem('vip', this.sessionForm.vip);
              this.dialogFormVisibleVip = false;
            }
          });
        }
      });
    },
    handleClick(tab, event) {
      switch (event.target.outerText) {
        case '个人中心':
          tab.$router.push('/index/center');
          break;
        case '我的预约':
          this.loadReservations();
          break;
        case '收藏':
          localStorage.setItem('storeupType', 1);
          tab.$router.push('/index/storeup');
          break;
      }

      this.title = event.target.outerText;
    },
    logout() {
      localStorage.clear();
      Vue.http.headers.common['Token'] = "";
      this.$router.push('/index/home');
      this.activeIndex = '0'
      localStorage.setItem('keyPath', this.activeIndex)
      this.$forceUpdate()
      this.$message({
        message: '登出成功',
        type: 'success',
        duration: 1500,
      });
    },
    loadReservations() {
      // 加载座位预约
      this.$http({
        url: 'orders/list',
        method: 'get',
        params: {
          page: 1,
          limit: 100,
          userid: localStorage.getItem('userid')
        }
      }).then(({data}) => {
        if (data && data.code === 0) {
          this.seatReservations = data.data.list || [];
        }
      }).catch(() => {
        this.seatReservations = [];
      });

      // 加载教室预约
      this.$http({
        url: 'classroomreservation/my-reservations',
        method: 'get',
        params: {
          page: 1,
          limit: 100
        }
      }).then(({data}) => {
        if (data && data.code === 0) {
          this.classroomReservations = data.data.list || [];
        }
      }).catch(() => {
        this.classroomReservations = [];
      });
    },
    formatTime(time) {
      if (!time) return '-';
      return time.replace('T', ' ').substring(0, 19);
    },
    getStatusType(status) {
      const typeMap = {
        'pending': 'warning',
        'approved': 'success',
        'cancelled': 'info',
        'rejected': 'danger'
      };
      return typeMap[status] || 'info';
    },
    getStatusText(status) {
      const textMap = {
        'pending': '待审批',
        'approved': '已批准',
        'cancelled': '已取消',
        'rejected': '已拒绝'
      };
      return textMap[status] || status;
    },
    getOrderStatusType(status) {
      const typeMap = {
        '已支付': 'success',
        '未支付': 'warning',
        '已完成': 'info',
        '已取消': 'danger'
      };
      return typeMap[status] || 'info';
    },
    cancelClassroomReservation(reservation) {
      this.$confirm('确定要取消这个教室预约吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$http({
          url: `classroomreservation/cancel/${reservation.id}`,
          method: 'post'
        }).then(({data}) => {
          if (data && data.code === 0) {
            this.$message.success('取消成功');
            this.loadReservations();
          } else {
            this.$message.error(data.msg || '取消失败');
          }
        }).catch(() => {
          this.$message.error('取消失败，请重试');
        });
      }).catch(() => {});
    },
    viewClassroomDetails(reservation) {
      this.currentClassroomReservation = reservation;
      this.classroomDetailDialogVisible = true;
    },
    goToClassroomReservation() {
      this.$router.push('/index/classroom-reservation');
    },
    paySeatReservation(item) {
      this.$confirm(`确定支付该预约吗？`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$http.get(item.tablename + '/info/' + item.goodid, {}).then(res => {
          let data = res.data.data;
          let table = localStorage.getItem('UserTableName');
          this.$http.get(table + '/session', {}).then(res2 => {
            let user = res2.data.data;
            if (Number(user.money) < Number(item.total)) {
              this.$message.error('余额不足，请先充值');
              return;
            }
            if (data.jf) {
              user.jf = Number(user.jf) + Number(data.jf * item.buynumber);
            }
            user.money = user.money - item.total;
            this.$http.post(table + '/update', user).then(res3 => {
              item.status = '已预约';
              this.$http.post('orders/update', item).then(res4 => {
                this.$message.success('支付成功');
                this.loadReservations();
              });
            });
          });
        });
      }).catch(() => {});
    },
    cancelSeatReservation(item) {
      this.$confirm(`确定取消该预约吗？`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        item.status = '已取消';
        this.$http.post('orders/update', item).then(res => {
          if (res.data.code === 0) {
            this.$message.success('取消成功');
            this.loadReservations();
          } else {
            this.$message.error(res.data.msg || '取消失败');
          }
        }).catch(() => {
          this.$message.error('取消失败，请重试');
        });
      }).catch(() => {});
    },
    viewSeatDetails(item) {
      this.currentSeatReservation = item;
      this.seatDetailDialogVisible = true;
    }
  }
}
</script>
  
<style rel="stylesheet/scss" lang="scss" scoped>


.center-preview {
  padding: 20px 10% 40px;
  margin: 0px auto;
  flex-wrap: wrap;
  background: #f9fbfd;
  display: flex;
  width: 100%;
  position: relative;
  justify-content: space-between;
  animation: fadeIn 0.6s ease-in-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.title {
  margin: 10px 0;
  color: #fff;
  text-align: center;
  background: #6aa8e6;
  width: 100%;
  font-size: 20px;
  line-height: 54px;
  border-radius: 6px;
  letter-spacing: 1px;
  box-shadow: 0 2px 5px rgba(106, 168, 230, 0.2);
}

.tabs-container {
  align-items: center;
  flex-wrap: wrap;
  background: #fff;
  display: flex;
  width: 100%;
  position: relative;
  justify-content: center;
  margin-top: 20px;
  border-radius: 6px;
  box-shadow: 0 2px 10px rgba(106, 168, 230, 0.1);

}

.center-preview .el-tabs ::v-deep .el-tabs__header {
  background: #f0f7ff;
  display: flex;
  width: 100%;
  border-color: #d1e3f5;
  border-width: 0 1px 0 0;
  justify-content: center;
  position: relative;
  border-style: solid;
  min-width: 1200px;
  height: 60px;
}

.center-preview .el-tabs ::v-deep .el-tabs__header .el-tabs__item {
  padding: 0 20px;
  color: #556677;
  background: transparent;
  font-weight: 500;
  display: inline-block;
  font-size: 15px;
  border-color: #6aa8e6;
  border-width: 0 0 3px;
  line-height: 60px;
  border-style: solid;
  text-align: center;
  height: 60px;
  margin: 0 5px;
  transition: all 0.3s ease;
}

.center-preview .el-tabs ::v-deep .el-tabs__header .el-tabs__item:hover {
  padding: 0 20px;
  background: rgba(106, 168, 230, 0.1);
  color: #4a90e2;
  font-weight: 500;
  font-size: 15px;
  line-height: 60px;
  position: relative;
  text-align: center;
  height: 60px;
}

.center-preview .el-tabs ::v-deep .el-tabs__header .el-tabs__item.is-active {
  padding: 0 20px;
  background: transparent;
  color: #4a90e2;
  font-weight: 600;
  font-size: 15px;
  line-height: 60px;
  position: relative;
  text-align: center;
  height: 60px;
  border-color: #4a90e2;
}

.center-preview .el-tabs ::v-deep .el-tabs__content .el-tab-pane {
  padding: 30px 50px;
  background: #fff;
  flex: 1;
  position: relative;
  min-width: 1200px;
}

.center-preview-pv {
  width: 100%;
}

.form-item {
  border: 1px solid #d1e3f5;
  padding: 15px;
  margin: 0 0 15px;
  background: #f9fbfd;
  border-radius: 6px;
  transition: all 0.3s ease;
}

.form-item:hover {
  box-shadow: 0 2px 8px rgba(106, 168, 230, 0.1);
  border-color: #b8d4f0;
}

.center-preview-pv .el-form-item ::v-deep .el-form-item__label {
  padding: 0 10px 0 0;
  color: #556677;
  font-weight: 500;
  width: 120px;
  font-size: 14px;
  line-height: 40px;
  text-align: right;
}

.center-preview-pv .el-form-item .el-form-item__content {
  margin-left: 120px;
}

.center-preview-pv .el-input ::v-deep .el-input__inner {
  border: 1px solid #b8d4f0;
  border-radius: 4px;
  padding: 0 12px;
  outline: none;
  color: #34495e;
  background: #fff;
  width: 400px;
  font-size: 14px;
  height: 40px;
  transition: all 0.3s ease;
}

.center-preview-pv .el-input ::v-deep .el-input__inner:focus {
  border-color: #6aa8e6;
  box-shadow: 0 0 0 2px rgba(106, 168, 230, 0.2);
}

.center-preview-pv .el-select ::v-deep .el-input__inner {
  border: 1px solid #b8d4f0;
  border-radius: 4px;
  padding: 0 12px;
  outline: none;
  color: #34495e;
  background: #fff;
  width: 400px;
  font-size: 14px;
  height: 40px;
  transition: all 0.3s ease;
}

.center-preview-pv .el-select ::v-deep .el-input__inner:focus {
  border-color: #6aa8e6;
  box-shadow: 0 0 0 2px rgba(106, 168, 230, 0.2);
}

.center-preview-pv .el-date-editor ::v-deep .el-input__inner {
  border: 1px solid #b8d4f0;
  border-radius: 4px;
  padding: 0 10px 0 30px;
  outline: none;
  color: #34495e;
  background: #fff;
  width: 200px;
  font-size: 14px;
  height: 40px;
}

.avatar-uploader {
  transition: all 0.3s ease;
}

.avatar-uploader:hover {
  transform: scale(1.02);
}

::v-deep .avatar-uploader-icon {
  border: 1px solid #b8d4f0;
  cursor: pointer;
  border-radius: 6px;
  color: #6aa8e6;
  background: #f0f7ff;
  width: 100px;
  font-size: 32px;
  line-height: 100px;
  text-align: center;
  height: 100px;
  transition: all 0.3s ease;
}

::v-deep .avatar-uploader-icon:hover {
  background: #e6f0fa;
  border-color: #6aa8e6;
}

.avatar {
  border: 1px solid #b8d4f0;
  cursor: pointer;
  border-radius: 6px;
  color: #666;
  background: #f0f7ff;
  width: 100px;
  font-size: 32px;
  line-height: 100px;
  height: 100px;
  object-fit: cover;
  transition: all 0.3s ease;
}

.avatar:hover {
  transform: scale(1.05);
  box-shadow: 0 3px 10px rgba(106, 168, 230, 0.2);
}

.balance-container {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
}

.center-preview-pv .el-form-item.balance ::v-deep .el-input__inner {
  border: 1px solid #b8d4f0;
  border-radius: 4px;
  padding: 0 12px;
  outline: none;
  color: #34495e;
  background: #fff;
  display: inline-block;
  width: 200px;
  font-size: 14px;
  height: 40px;
}

.recharge-btn {
  border: 0;
  cursor: pointer;
  padding: 0 15px;
  margin: 0 20px 0 0;
  color: rgba(255, 255, 255, 1);
  display: inline-block;
  outline: none;
  border-radius: 4px;
  background: #6aa8e6;
  width: auto;
  line-height: 40px;
  font-size: 14px;
  height: 40px;
  transition: all 0.3s ease;
}

.recharge-btn:hover {
  background: #4a90e2;
  transform: translateY(-2px);
  box-shadow: 0 3px 8px rgba(106, 168, 230, 0.3);
}

.button-group {
  padding: 15px 0;
  margin: 10px 0 0;
  text-align: center;
}

.update-btn {
  border: 0;
  cursor: pointer;
  padding: 0;
  margin: 0 20px 0 0;
  border-color: #6aa8e6;
  color: #fff;
  outline: none;
  border-radius: 4px;
  background: #6aa8e6;
  border-width: 0;
  width: 128px;
  font-size: 14px;
  height: 40px;
  transition: all 0.3s ease;
}

.update-btn:hover {
  background: #4a90e2;
  transform: translateY(-2px);
  box-shadow: 0 3px 8px rgba(106, 168, 230, 0.3);
}

.logout-btn {
  cursor: pointer;
  padding: 0;
  margin: 0;
  border-color: #e74c3c;
  color: #fff;
  outline: none;
  border-radius: 4px;
  background: #e74c3c;
  border-width: 0;
  width: 128px;
  font-size: 14px;
  height: 40px;
  transition: all 0.3s ease;
}

.logout-btn:hover {
  background: #c0392b;
  transform: translateY(-2px);
  box-shadow: 0 3px 8px rgba(231, 76, 60, 0.3);
}

.el-dialog ::v-deep .el-dialog__header {
  background: #f0f7ff;
  padding: 15px 20px;
  border-bottom: 1px solid #e6f0fa;
}

.el-dialog ::v-deep .el-dialog__title {
  color: #2c3e50;
  font-weight: 600;
}

.el-dialog ::v-deep .el-dialog__footer {
  padding: 15px 20px;
  border-top: 1px solid #e6f0fa;
}

.dialog-footer .el-button {
  transition: all 0.3s ease;
}

.dialog-footer .el-button--primary {
  background-color: #6aa8e6;
  border-color: #6aa8e6;
}

.dialog-footer .el-button--primary:hover {
  background-color: #4a90e2;
  border-color: #4a90e2;
}

.my-reservations-section {
  padding: 20px;
}

.section-title {
  font-size: 18px;
  font-weight: 600;
  color: #2c3e50;
  margin-bottom: 15px;
  padding-bottom: 10px;
  border-bottom: 2px solid #6aa8e6;
}

.reservation-list {
  margin-bottom: 30px;
}

.empty-state {
  text-align: center;
  padding: 40px 20px;
  color: #909399;
}

.empty-state i {
  font-size: 48px;
  color: #c0c4cc;
  margin-bottom: 15px;
}

.empty-state p {
  font-size: 14px;
  margin-bottom: 15px;
}

.detail-content {
  padding: 10px 0;
}

.detail-item {
  padding: 12px 0;
  border-bottom: 1px solid #f0f0f0;
  display: flex;
  align-items: flex-start;
}

.detail-item:last-child {
  border-bottom: none;
}

.detail-label {
  width: 100px;
  color: #909399;
  font-weight: 500;
  flex-shrink: 0;
}

.detail-value {
  flex: 1;
  color: #606266;
  word-break: break-all;
}

.my-reservations-section ::v-deep .el-table {
  border-radius: 6px;
  overflow: hidden;
}

.my-reservations-section ::v-deep .el-table th {
  font-weight: 600;
}

.my-reservations-section ::v-deep .el-table .el-button--mini {
  padding: 5px 10px;
  border-radius: 4px;
}


</style>
  