/**
 * 表单验证工具类
 */
class Validator {
  /**
   * 验证时间范围
   * @param {String|Date} startTime - 开始时间
   * @param {String|Date} endTime - 结束时间
   * @returns {Object} { valid: Boolean, message: String }
   */
  static validateTimeRange(startTime, endTime) {
    if (!startTime || !endTime) {
      return {
        valid: false,
        message: '请选择开始时间和结束时间'
      }
    }

    const start = new Date(startTime)
    const end = new Date(endTime)
    const now = new Date()

    // 检查时间是否有效
    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      return {
        valid: false,
        message: '时间格式不正确'
      }
    }

    // 检查开始时间是否在过去
    if (start < now) {
      return {
        valid: false,
        message: '开始时间不能早于当前时间'
      }
    }

    // 检查结束时间是否晚于开始时间
    if (end <= start) {
      return {
        valid: false,
        message: '结束时间必须晚于开始时间'
      }
    }

    // 检查时间跨度是否合理（不超过24小时）
    const duration = (end - start) / (1000 * 60 * 60) // 小时
    if (duration > 24) {
      return {
        valid: false,
        message: '预约时长不能超过24小时'
      }
    }

    // 检查最小时长（至少30分钟）
    if (duration < 0.5) {
      return {
        valid: false,
        message: '预约时长至少为30分钟'
      }
    }

    return {
      valid: true,
      message: ''
    }
  }

  /**
   * 验证必填字段
   * @param {Any} value - 字段值
   * @param {String} fieldName - 字段名称
   * @returns {Object} { valid: Boolean, message: String }
   */
  static validateRequired(value, fieldName = '此字段') {
    if (value === null || value === undefined || value === '') {
      return {
        valid: false,
        message: `${fieldName}不能为空`
      }
    }

    if (typeof value === 'string' && value.trim() === '') {
      return {
        valid: false,
        message: `${fieldName}不能为空`
      }
    }

    return {
      valid: true,
      message: ''
    }
  }

  /**
   * 验证字符串长度
   * @param {String} value - 字符串值
   * @param {Number} min - 最小长度
   * @param {Number} max - 最大长度
   * @param {String} fieldName - 字段名称
   * @returns {Object} { valid: Boolean, message: String }
   */
  static validateLength(value, min, max, fieldName = '此字段') {
    if (!value) {
      return {
        valid: false,
        message: `${fieldName}不能为空`
      }
    }

    const length = value.length

    if (length < min) {
      return {
        valid: false,
        message: `${fieldName}长度不能少于${min}个字符`
      }
    }

    if (length > max) {
      return {
        valid: false,
        message: `${fieldName}长度不能超过${max}个字符`
      }
    }

    return {
      valid: true,
      message: ''
    }
  }

  /**
   * 验证角色
   * @param {String} role - 角色值
   * @returns {Object} { valid: Boolean, message: String }
   */
  static validateRole(role) {
    const validRoles = ['student', 'teacher']
    
    if (!role) {
      return {
        valid: false,
        message: '请选择角色'
      }
    }

    if (!validRoles.includes(role)) {
      return {
        valid: false,
        message: '角色选择无效'
      }
    }

    return {
      valid: true,
      message: ''
    }
  }

  /**
   * 验证用户名
   * @param {String} username - 用户名
   * @returns {Object} { valid: Boolean, message: String }
   */
  static validateUsername(username) {
    if (!username) {
      return {
        valid: false,
        message: '请输入用户名'
      }
    }

    if (username.length < 3 || username.length > 20) {
      return {
        valid: false,
        message: '用户名长度应在3-20个字符之间'
      }
    }

    // 只允许字母、数字、下划线
    const pattern = /^[a-zA-Z0-9_]+$/
    if (!pattern.test(username)) {
      return {
        valid: false,
        message: '用户名只能包含字母、数字和下划线'
      }
    }

    return {
      valid: true,
      message: ''
    }
  }

  /**
   * 验证密码
   * @param {String} password - 密码
   * @returns {Object} { valid: Boolean, message: String }
   */
  static validatePassword(password) {
    if (!password) {
      return {
        valid: false,
        message: '请输入密码'
      }
    }

    if (password.length < 6) {
      return {
        valid: false,
        message: '密码长度不能少于6个字符'
      }
    }

    if (password.length > 20) {
      return {
        valid: false,
        message: '密码长度不能超过20个字符'
      }
    }

    return {
      valid: true,
      message: ''
    }
  }

  /**
   * 验证手机号
   * @param {String} phone - 手机号
   * @returns {Object} { valid: Boolean, message: String }
   */
  static validatePhone(phone) {
    if (!phone) {
      return {
        valid: false,
        message: '请输入手机号'
      }
    }

    const pattern = /^1[3-9]\d{9}$/
    if (!pattern.test(phone)) {
      return {
        valid: false,
        message: '请输入有效的手机号'
      }
    }

    return {
      valid: true,
      message: ''
    }
  }

  /**
   * 验证邮箱
   * @param {String} email - 邮箱
   * @returns {Object} { valid: Boolean, message: String }
   */
  static validateEmail(email) {
    if (!email) {
      return {
        valid: false,
        message: '请输入邮箱'
      }
    }

    const pattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/
    if (!pattern.test(email)) {
      return {
        valid: false,
        message: '请输入有效的邮箱地址'
      }
    }

    return {
      valid: true,
      message: ''
    }
  }

  /**
   * 批量验证
   * @param {Array} validations - 验证数组 [{ validator: Function, args: Array }]
   * @returns {Object} { valid: Boolean, message: String }
   */
  static validateAll(validations) {
    for (const validation of validations) {
      const { validator, args } = validation
      const result = validator(...args)
      
      if (!result.valid) {
        return result
      }
    }

    return {
      valid: true,
      message: ''
    }
  }
}

export default Validator
