export default {
    baseUrl: 'http://localhost:8080/smartcampusclassressys/',
    indexNav: [
        {
            name: '首页',
            url: '/index/home'
        },
        {
            name: '教室资讯',
            url: '/index/librarynotice'
        },
      
        {
            name: '教室信息',
            url: '/index/classroom-reservation'
        },
          {
            name: '座位信息',
            url: '/index/libseatinfo'
        },
       
        {
            name: '公告信息',
            url: '/index/news'
        },
    ]
}
