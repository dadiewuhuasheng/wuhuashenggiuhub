<template>
	<div>
		<div class="breadcrumb-preview">
			<el-breadcrumb :separator="'Ξ'" class="breadcrumb-content">
				<el-breadcrumb-item>首页</el-breadcrumb-item>
				<el-breadcrumb-item v-for="(item, index) in breadcrumbItem" :key="index">{{item.name}}</el-breadcrumb-item>
			</el-breadcrumb>
		</div>
		<div class="search-container">
			<el-form :inline="true" :model="formSearch" class="search-form">
				<div class="section-btn">
					<el-form-item>
					  <el-input v-model="title" placeholder="标题"></el-input>
					</el-form-item>
				  <el-button type="primary" @click="getNewsList(1)"><i class="el-icon-search"></i>查询</el-button>
				</div>
			</el-form>
		</div>
		
		<div class="news-preview">				
			<div class="list7 index-pv1">
				<div v-for="item in newsList" :key="item.id" @click="toNewsDetail(item)" class="list-item animation-box">
					<div class="title">{{item.title}}</div>
					<div class="introduction">{{item.introduction}}</div>
					<div class="time">{{item.addtime}}</div>
					<div class="tags">新闻动态</div>
				</div>
			</div>
					
			<el-pagination
			  background
			  class="pagination"
			  :pager-count="7"
			  :page-size="pageSize"
			  :page-sizes="pageSizes"
			  prev-text="<"
			  next-text=">"
			  :hide-on-single-page="true"
			  :layout='["total","prev","pager","next","sizes","jumper"].join()'
			  :total="total"
			  @current-change="curChange"
			  @prev-click="prevClick"
			  @next-click="nextClick"
			></el-pagination>
		</div>
	</div>
	</template>
	
	<script>
	  export default {
		//数据集合
		data() {
		  return {
			baseUrl: this.$config.baseUrl,
			breadcrumbItem: [
			  {
				name: '公告信息'
			  }
			],
			newsList: [],
			total: 1,
			pageSize: 10,pageSizes: [10,20,30,50],
			totalPage: 1,
			layouts: '',
			title: '',
		  }
		},
		created() {
			this.getNewsList(1);
		},
		//方法集合
		methods: {
		  getNewsList(page) {
			let params = {page, limit: this.pageSize,sort:'addtime',order:'desc'};
			let searchWhere = {};
			if(this.title != '') searchWhere.title = '%' + this.title + '%';
			this.$http.get('news/list', {params: Object.assign(params, searchWhere)}).then(res => {
			  if (res.data.code == 0) {
				this.newsList = res.data.data.list;
				this.total = res.data.data.total;
				this.pageSize = res.data.data.pageSize;this.pageSizes = [this.pageSize, this.pageSize*2, this.pageSize*3, this.pageSize*5];
				this.totalPage = res.data.data.totalPage;
			  }
			});
		  },
		  curChange(page) {
			this.getNewsList(page);
		  },
		  prevClick(page) {
			this.getNewsList(page);
		  },
		  nextClick(page) {
			this.getNewsList(page);
		  },
		  toNewsDetail(item) {
			this.$router.push({path: '/index/newsDetail', query: {detailObj: JSON.stringify(item)}});
		  }
		}
	  }
	</script>
	
	<style rel="stylesheet/scss" lang="scss" scoped>
		// 基础样式
		.breadcrumb-preview {
		  padding: 0 20px;
		  margin: 10px auto;
		  background: #6aa8e6;
		  display: flex;
		  width: 100%;
		  justify-content: space-between;
		  height: 40px;
		}
		
		.breadcrumb-content {
		  font-size: 14px;
		  line-height: 40px;
		  color: #fff;
		}
		
		// 搜索区域样式
		.search-container {
		  padding: 0 20px;
		  margin: 10px auto;
		  background: #e6f0fa;
		  display: flex;
		  width: 100%;
		  justify-content: space-between;
		  height: 60px;
		  align-items: center;
		}
		
		.search-form {
		  justify-content: center;
		  display: flex;
		  width: 100%;
		}
		
		.section-btn {
		  display: flex;
		  align-items: center;
		  gap: 10px;
		}
		
		.el-input__inner {
		  border-color: #b8d4f0;
		  transition: all 0.3s ease;
		}
		
		.el-input__inner:focus {
		  border-color: #6aa8e6;
		  box-shadow: 0 0 0 2px rgba(106, 168, 230, 0.2);
		}
		
		.el-button--primary {
		  background-color: #4a90e2;
		  border-color: #4a90e2;
		  transition: all 0.3s ease;
		}
		
		.el-button--primary:hover {
		  background-color: #3a80d2;
		  border-color: #3a80d2;
		}
		
		// 新闻列表样式
		.news-preview {
		  width: 100%;
		  padding: 20px 7% 0;
		  margin: 0 auto;
		  position: relative;
		  background: #f9fbfd;
		}
		
		.list7 {
		  width: 100%;
		  display: flex;
		  flex-wrap: wrap;
		  background: none;
		  justify-content: space-between;
		  height: auto;
		  gap: 2%;
		}
		
		.list-item {
		  border: 1px solid #d1e3f5;
		  padding: 15px;
		  box-shadow: 0 3px 10px rgba(106, 168, 230, 0.1);
		  margin: 0 0 25px;
		  background: #fff;
		  width: 49%;
		  position: relative;
		  height: auto;
		  border-radius: 6px;
		  cursor: pointer;
		}
		
		.title {
		  padding: 0 10px 10px;
		  border-color: #d1e3f5;
		  white-space: nowrap;
		  overflow: hidden;
		  color: #2c3e50;
		  background: none;
		  border-width: 0 0 1px;
		  line-height: 32px;
		  font-size: 16px;
		  text-overflow: ellipsis;
		  border-style: solid;
		  font-weight: 600;
		}
		
		.introduction {
		  margin: 10px 0 0;
		  overflow: hidden;
		  color: #556677;
		  line-height: 24px;
		  font-size: 14px;
		  text-indent: 2em;
		  height: 72px;
		}
		
		.time {
		  line-height: 32px;
		  font-size: 12px;
		  position: absolute;
		  right: 20px;
		  color: #95b1ce;
		  top: 15px;
		}
		
		.tags {
		  padding: 3px 10px;
		  font-size: 12px;
		  line-height: 18px;
		  color: #fff;
		  background: #6aa8e6;
		  display: inline-block;
		  position: absolute;
		  bottom: 15px;
		  right: 15px;
		  border-radius: 3px;
		}
		
		// 动画效果
		.index-pv1 .animation-box {
		  transform: translate3d(0px, 0px, 0px);
		  z-index: initial;
		  transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
		}
		
		.index-pv1 .animation-box:hover {
		  transform: translate3d(0px, -5px, 0px);
		  box-shadow: 0 10px 20px rgba(106, 168, 230, 0.15);
		  z-index: 1;
		}
		
		// 分页样式
		.pagination {
		  padding: 20px 7% 20px;
		  margin: 0;
		  white-space: nowrap;
		  color: #333;
		  text-align: center;
		  background: #f0f7ff;
		  width: 100%;
		  font-weight: 500;
		}
		
		.el-pagination ::v-deep .el-pagination__total {
		  margin: 0 10px 0 0;
		  color: #556677;
		  font-weight: 400;
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  height: 28px;
		}
		
		.el-pagination ::v-deep .btn-prev,
		.el-pagination ::v-deep .btn-next {
		  border: 1px solid #d1e3f5;
		  border-radius: 4px;
		  padding: 0;
		  margin: 0 5px;
		  color: #6aa8e6;
		  background: #ffffff;
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  min-width: 35px;
		  height: 28px;
		  transition: all 0.3s ease;
		}
		
		.el-pagination ::v-deep .btn-prev:hover,
		.el-pagination ::v-deep .btn-next:hover {
		  background-color: #f0f7ff;
		  border-color: #6aa8e6;
		}
		
		.el-pagination ::v-deep .btn-prev:disabled,
		.el-pagination ::v-deep .btn-next:disabled {
		  border: 1px solid #e1e8ed;
		  cursor: not-allowed;
		  color: #c0cddf;
		  background: #ffffff;
		}
		
		.el-pagination ::v-deep .el-pager {
		  padding: 0;
		  margin: 0;
		  display: inline-block;
		  vertical-align: top;
		}
		
		.el-pagination ::v-deep .el-pager .number {
		  cursor: pointer;
		  padding: 0 4px;
		  margin: 0 5px;
		  color: #556677;
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  border-radius: 4px;
		  background: #ffffff;
		  text-align: center;
		  min-width: 30px;
		  height: 28px;
		  border: 1px solid #d1e3f5;
		  transition: all 0.3s ease;
		}
		
		.el-pagination ::v-deep .el-pager .number:hover {
		  background: #f0f7ff;
		  color: #4a90e2;
		  border-color: #6aa8e6;
		}
		
		.el-pagination ::v-deep .el-pager .number.active {
		  cursor: default;
		  color: #FFF;
		  background: #4a90e2;
		  border-color: #4a90e2;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes {
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  height: 28px;
		  color: #556677;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes .el-input {
		  margin: 0 5px;
		  width: 100px;
		  position: relative;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes .el-input .el-input__inner {
		  border: 1px solid #d1e3f5;
		  cursor: pointer;
		  padding: 0 25px 0 8px;
		  color: #556677;
		  font-size: 13px;
		  line-height: 28px;
		  border-radius: 4px;
		  background: #FFF;
		  width: 100%;
		  text-align: center;
		  height: 28px;
		}
		
		.el-pagination ::v-deep .el-pagination__jump {
		  margin: 0 0 0 24px;
		  color: #556677;
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  height: 28px;
		}
		
		.el-pagination ::v-deep .el-pagination__jump .el-input {
		  border-radius: 4px;
		  padding: 0 2px;
		  margin: 0 2px;
		  display: inline-block;
		  width: 50px;
		  font-size: 14px;
		  line-height: 18px;
		  position: relative;
		  text-align: center;
		  height: 28px;
		}
		
		// 文本截断样式
		.hide1 {
		  text-overflow: ellipsis;
		  display: -webkit-box;
		  -webkit-line-clamp: 1;
		  -webkit-box-orient: vertical;
		  overflow:hidden;
		  text-overflow:ellipsis;
		}
		.hide2 {
		  text-overflow: ellipsis;
		  display: -webkit-box;
		  -webkit-line-clamp: 2;
		  -webkit-box-orient: vertical;
		  overflow:hidden;
		  text-overflow:ellipsis;
		}
		.hide3 {
		  text-overflow: ellipsis;
		  display: -webkit-box;
		  -webkit-line-clamp: 3;
		  -webkit-box-orient: vertical;
		  overflow:hidden;
		  text-overflow:ellipsis;
		}
	</style>
	