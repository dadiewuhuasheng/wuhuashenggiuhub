<template>
	<div>
		<div class="breadcrumb-preview">
			<el-breadcrumb :separator="'Ξ'">
				<el-breadcrumb-item>首页</el-breadcrumb-item>
				<el-breadcrumb-item v-for="(item, index) in breadcrumbItem" :key="index">{{item.name}}</el-breadcrumb-item>
			</el-breadcrumb>
		</div>
		
		<div class="detail-preview">
			<div class="attr">
				<el-carousel trigger="click" indicator-position="inside" arrow="always" type="default" direction="horizontal" height="400px" :autoplay="true" :interval="5000" :loop="true">
					<el-carousel-item v-for="item in detailBanner" :key="item.id">
						<el-image v-if="item.substr(0,4)=='http'" :src="item" fit="cover" class="image"></el-image>
						<el-image v-else :src="baseUrl + item" fit="cover" class="image"></el-image>
					</el-carousel-item>
				</el-carousel>
		
				<div class="zancai">
					<div v-if="!isThumbsupnum && !isCrazilynum" class="zan" @click="thumbsupOrCrazily(21)">
						<i class="iconfont icon-dianzan"></i>
						<span>赞一下({{detail.thumbsupnum}})</span>
					</div>
					<div v-if="!isThumbsupnum && !isCrazilynum" class="cai" @click="thumbsupOrCrazily(22)">
						<i class="iconfont icon-iconfontzan"></i>
						<span>踩一下({{detail.crazilynum}})</span>
					</div>
					<div v-if="isThumbsupnum" class="zan" @click="cancelThumbsupOrCrazily(21)">
						<i class="iconfont icon-dianzan"></i>
						<span>取消赞({{detail.thumbsupnum}})</span>
					</div>
					<div v-if="isCrazilynum" class="cai" @click="cancelThumbsupOrCrazily(22)">
						<i class="iconfont icon-iconfontzan"></i>
						<span>取消踩({{detail.crazilynum}})</span>
					</div>
				</div>
				
				<div class="info">
					<div class="item title-item">
						<div>
						{{detail.libseatmingcheng}}
						</div>
						<div @click="storeup(1)" v-show="!isStoreup" class="storeup-btn"><i class="el-icon-star-off"></i><span>点我收藏</span></div>
						<div @click="storeup(-1)" v-show="isStoreup" class="storeup-btn active"><i class="el-icon-star-on"></i><span>取消收藏</span></div>
					</div>
	
					<div class="item" v-if="detail.price">
						<div class="lable">价格</div>
						<div class="value price-value"><span>￥</span>{{detail.price}}</div>
					</div>
					<div class="item" v-if="detail.jf">
						<div class="lable">积分</div>
						<div class="value score-value">{{detail.jf}}</div>
					</div>
					<div class="item">
						<div class="lable">座位类型</div>
						<div class="value">{{detail.libseattype}}</div>
					</div>
	
					<div class="item">
						<div class="lable">座位区域</div>
						<div class="value">{{detail.libseataddress}}</div>
					</div>
					
					<div class="item">
						<div class="lable">点击次数</div>
						<div class="value">{{detail.clicknum}}</div>
					</div>
					<div class="item">
						<div class="lable">座位总数</div>
						<div class="value">{{detail.number}}</div>
					</div>
					<div class="btn-group">
						<el-button type="warning" size="small" @click="showTimeDialog" class="book-btn">立即预订</el-button>
					</div>
				</div>
				
			</div>
			
			<!-- 时间选择对话框 -->
			<el-dialog title="选择预约时间" :visible.sync="timeDialogVisible" width="500px">
				<el-form :model="timeForm" :rules="timeRules" ref="timeForm" label-width="100px">
					<el-form-item label="开始时间" prop="startTime">
						<el-date-picker
							v-model="timeForm.startTime"
							type="datetime"
							placeholder="选择开始时间"
							format="yyyy-MM-dd HH:mm:ss"
							value-format="yyyy-MM-dd HH:mm:ss"
							:picker-options="startTimeOptions"
							style="width: 100%;">
						</el-date-picker>
					</el-form-item>
					<el-form-item label="结束时间" prop="endTime">
						<el-date-picker
							v-model="timeForm.endTime"
							type="datetime"
							placeholder="选择结束时间"
							format="yyyy-MM-dd HH:mm:ss"
							value-format="yyyy-MM-dd HH:mm:ss"
							:picker-options="endTimeOptions"
							style="width: 100%;">
						</el-date-picker>
					</el-form-item>
				</el-form>
				<div slot="footer" class="dialog-footer">
					<el-button @click="timeDialogVisible = false">取消</el-button>
					<el-button type="primary" @click="confirmTimeAndBook">确定预订</el-button>
				</div>
			</el-dialog>
			
			
			<el-tabs class="detail" v-model="activeName" type="border-card">
				<el-tab-pane label="座位简介" name="first">
					<div v-html="detail.libseatintro" class="intro-content"></div>
				</el-tab-pane>
				<el-tab-pane label="评论" name="second">
					<el-form class="add comment" :model="form" :rules="rules" ref="form">
						<el-form-item class="comment-item" label="评论" prop="content">
							<el-input type="textarea" :rows="5" v-model="form.content" placeholder="请输入内容"></el-input>
						</el-form-item>
						<el-form-item class="comment-btn">
							<el-button type="primary" @click="submitForm('form')" class="submit-btn">立即提交</el-button>
							<el-button @click="resetForm('form')" class="reset-btn">重置</el-button>
						</el-form-item>
					</el-form>
					
					<div v-if="infoList.length" class="comment-list">
						<div class="comment-item" v-for="item in infoList" :key="item.id">
							<div class="user">
								<el-image v-if="item.avatarurl" :size="50" :src="baseUrl + item.avatarurl" class="avatar"></el-image>
								<el-image v-if="!item.avatarurl" :size="50" :src="require('@/assets/avatar.png')" class="avatar"></el-image>
								<div class="name">{{item.nickname}}</div>
							</div>
							<div class="content-block-ask">
								{{item.content}}
							</div>
							<div class="content-block-reply" v-if="item.reply">
								回复：{{item.reply}}
							</div>
						</div>
					</div>
					
					<el-pagination
					  background
					  class="pagination"
					  :pager-count="7"
					  :page-size="pageSize"
					  :page-sizes="pageSizes"
					  prev-text="<"
					  next-text=">"
					  :hide-on-single-page="true"
					  :layout='["total","prev","pager","next","sizes","jumper"].join()'
					  :total="total"
					  @current-change="curChange"
					  @prev-click="prevClick"
					  @next-click="nextClick"
					></el-pagination>
				</el-tab-pane>
				
				<el-tab-pane label="选座" name="last">
					<div class="seat-list">
						<div v-for="(item, index) in numberList" :key="index" class="seat-item">
							<img @click="selectTip()" v-if="item.select" class="seat-icon seat-selected" />
							<img @click="selectSeat(item)" v-else-if="!item.active" class="seat-icon seat-unselect" />
							<img @click="unselectSeat(item)" v-else class="seat-icon seat-active" />
							<span>{{item.name}}</span>
						</div>
					</div>
				</el-tab-pane>
			</el-tabs>
		</div>
	</div>
	</template>
	
	<script>
	  import CountDown from '@/components/CountDown';
	  export default {
		//数据集合
		data() {
		  return {
			tablename: 'libseatinfo',
			baseUrl: '',
			breadcrumbItem: [
			  {
				name: '详情信息'
			  }
			],
			title: '',
			detailBanner: [],
			endTime: 0,
			detail: {},
			activeName: 'first',
			form: {
			  content: '',
			  userid: localStorage.getItem('userid'),
			  nickname: localStorage.getItem('username'),
			  avatarurl: '',
			},
			infoList: [],
			total: 1,
			pageSize: 5,
			pageSizes: [10,20,30,50],
			totalPage: 1,
			rules: {
			  content: [
				{ required: true, message: '请输入内容', trigger: 'blur' }
			  ]
			},
			storeupParams: {
			  name: '',
			  picture: '',
			  refid: 0,
			  tablename: 'libseatinfo',
			  userid: localStorage.getItem('userid')
			},
			isStoreup: false,
			storeupInfo: {},
			isCrazilynum: false,
			isThumbsupnum: false,
			thumbsupOrCrazilyInfo: {},
			buynumber: 1,
			numberList: [],
			timeDialogVisible: false,
			timeForm: {
				startTime: '',
				endTime: ''
			},
			timeRules: {
				startTime: [
					{ required: true, message: '请选择开始时间', trigger: 'change' }
				],
				endTime: [
					{ required: true, message: '请选择结束时间', trigger: 'change' }
				]
			},
			startTimeOptions: {
				disabledDate(time) {
					return time.getTime() < Date.now() - 8.64e7; // 不能选择过去的日期
				}
			},
			endTimeOptions: {
				disabledDate(time) {
					return time.getTime() < Date.now() - 8.64e7;
				}
			}
		  }
		},
		created() {
			this.init();
		},
		//方法集合
		methods: {
			init() {
			  this.baseUrl = this.$config.baseUrl;
			  if(this.$route.query.detailObj) {
				this.detail = JSON.parse(this.$route.query.detailObj);
			  }
			  if(this.$route.query.storeupObj) {
				this.detail.id = JSON.parse(this.$route.query.storeupObj).refid;
			  }
			  if(this.$route.query.discussObj) {
				this.detail.id = JSON.parse(this.$route.query.discussObj).goodid;
			  }
			  this.$http.get(this.tablename + '/detail/'  + this.detail.id, {}).then(res => {
				if (res.data.code == 0) {
				  this.detail = res.data.data;
				  this.title = this.detail.libseatmingcheng;
				  this.detailBanner = this.detail.libseatpicture ? this.detail.libseatpicture.split(",") : [];
				  this.$forceUpdate();
				}
			  });
	
			  this.getDiscussList(1);
			  this.getStoreupStatus();
			  this.getThumbsupOrCrazilyStatus();
	
			  let selectArray = this.detail.selected.split(',');
			  for (let i = 1; i <= this.detail.number; i++) {
				this.numberList.push({
				  name: `${i}号`,
				  select: false,
				  active: false
				});
			  }
			  for (let i = 0; i < this.detail.selected.split(',').length; i++) {
				this.numberList[this.detail.selected.split(',')[i]-1].select = true;
			  }
			},
		createOrder() {
		  let order = '';
		  let now = new Date();
		  order += now.getFullYear();
		  order += now.getMonth() + 1;
		  order += now.getDate();
		  order += now.getHours();
		  order += now.getMinutes();
		  order += now.getSeconds();
		  order += now.getMilliseconds();
		  return order;
		},
		showTimeDialog() {
			// 检查是否选择了座位
			let activeSeat = [];
			for(let i=0;i<this.numberList.length;i++){
				if(this.numberList[i].active){
					activeSeat.push(this.numberList[i].name.replace('号',''));
				}
			}
			if (activeSeat.length==0) {
				this.$message({
				  type: 'error',
				  message: '请选择要预定的位置!',
				  duration: 1500
				});
				return;
			}
			// 显示时间选择对话框
			this.timeDialogVisible = true;
		},
		confirmTimeAndBook() {
			// 验证时间表单
			this.$refs.timeForm.validate((valid) => {
				if (valid) {
					// 验证时间范围
					if (!this.timeForm.startTime || !this.timeForm.endTime) {
						this.$message.error('请选择预约时间');
						return;
					}
					
					const startTime = new Date(this.timeForm.startTime);
					const endTime = new Date(this.timeForm.endTime);
					
					if (startTime >= endTime) {
						this.$message.error('结束时间必须晚于开始时间');
						return;
					}
					
					if (startTime < new Date()) {
						this.$message.error('开始时间不能早于当前时间');
						return;
					}
					
					// 关闭对话框并执行预订
					this.timeDialogVisible = false;
					this.bookClick();
				}
			});
		},
		bookClick() {
				let activeSeat = [];
				for(let i=0;i<this.numberList.length;i++){
					if(this.numberList[i].active){
						activeSeat.push(this.numberList[i].name.replace('号',''));
					}
				}
				if (activeSeat.length==0) {
					this.$message({
					  type: 'error',
					  message: '请选择要预定的位置!',
					  duration: 1500
					});
					return
				}
				let data = {
					orderid: this.createOrder(),
					tablename: this.tablename,
					userid: localStorage.getItem('userid'),
					goodid: this.detail.id,
					goodname: this.title,
					picture:this.detailBanner[0],
					goodtype: this.detail.libseattype,
					buynumber: activeSeat.length,
					total: 0,
					discounttotal: 0,
					address: activeSeat.join(','),
					activeSeat: activeSeat.join(','),
					status: '已预约',
					discountprice: this.detail.vipprice,
					startTime: this.timeForm.startTime, // 添加开始时间
					endTime: this.timeForm.endTime // 添加结束时间
				}
				if (this.detail.price) {
					data['status'] = '未支付'
					data['price'] = this.detail.price
					data['total'] = parseFloat(data['price'] * activeSeat.length).toFixed(2)
					localStorage.setItem('orderGoods', JSON.stringify([data]));
					// 跳转到确认下单页面
					let query = {
						type: 1,
						seat: 1
					}
					this.$confirm('是否确认预定？')
					  .then(_ => {
						this.$router.push({path: '/index/shop-order/orderConfirm', query: query});
					  }).catch(_ => {});
				} else {
					data['status'] = '已预约'
					data['price'] = 0
					data['total'] = parseFloat(data['price'] * activeSeat.length).toFixed(2)
					localStorage.setItem('orderGoods', JSON.stringify([data]));
					// 跳转到确认下单页面
					let query = {
						type: 1,
						seat: 1
					}
					this.$confirm('是否确认预定？')
					  .then(_ => {
						this.$router.push({path: '/index/shop-order/orderConfirm', query: query});
					  }).catch(_ => {});
				}
		  },
		  selectTip() {
			this.$message({
			  type: 'error',
			  message: '该座位已被预定!',
			  duration: 1500
			});
		  },
		  selectSeat(item) {
			item.active = true;
		  },
		  unselectSeat(item) {
			item.active = false;
		  },
		  storeup(type) {
			if (type == 1 && !this.isStoreup) {
			  this.storeupParams.name = this.title;
			  this.storeupParams.picture = this.detailBanner[0];
			  this.storeupParams.inteltype = this.detail.libseattype;
			  this.storeupParams.refid = this.detail.id;
			  this.storeupParams.type = type;
			  this.$http.post('storeup/add', this.storeupParams).then(res => {
				if (res.data.code == 0) {
				  this.isStoreup = true;
				  this.$message({
					type: 'success',
					message: '收藏成功!',
					duration: 1500,
				  });
				}
			  });
			}
			if (type == -1 && this.isStoreup) {
			  this.$http.get('storeup/list', {params: {page: 1, limit: 1, type: 1, refid: this.detail.id, tablename: 'libseatinfo', userid: localStorage.getItem('userid')}}).then(res => {
				if (res.data.code == 0 && res.data.data.list.length > 0) {
				  this.isStoreup = true;
				  this.storeupInfo = res.data.data.list[0];
				  let delIds = new Array();
				  delIds.push(this.storeupInfo.id);
				  this.$http.post('storeup/delete', delIds).then(res => {
					if (res.data.code == 0) {
					  this.isStoreup = false;
					  this.$message({
						type: 'success',
						message: '取消成功!',
						duration: 1500,
					  });
					}
				  });
				}
			  });
			}
		  },
		  getStoreupStatus(){
			if(localStorage.getItem("Token")) {
				this.$http.get('storeup/list', {params: {page: 1, limit: 1, type: 1, refid: this.detail.id, tablename: 'libseatinfo', userid: localStorage.getItem('userid')}}).then(res => {
				  if (res.data.code == 0 && res.data.data.list.length > 0) {
					this.isStoreup = true;
					this.storeupInfo = res.data.data.list[0];
				  }
				});
			}
		  },
		  thumbsupOrCrazily(type) {
			this.storeupParams.name = this.title;
			this.storeupParams.picture = this.detailBanner[0];
			this.storeupParams.refid = this.detail.id;
			this.storeupParams.type = type;
			this.$http.post('storeup/add', this.storeupParams).then(res => {
			  if (res.data.code == 0) {
				this.getThumbsupOrCrazilyStatus();
				this.$message({
				  type: 'success',
				  message: '操作成功!',
				  duration: 1500,
				});
			  }
			});
	
			if (type == 21) this.detail.thumbsupnum = Number(this.detail.thumbsupnum) + 1;
			if (type == 22) this.detail.crazilynum = Number(this.detail.crazilynum) + 1;
			this.$http.post('libseatinfo/update', this.detail).then(res => {});
		  },
		  cancelThumbsupOrCrazily(type) {
			let delIds = new Array();
			delIds.push(this.thumbsupOrCrazilyInfo.id);
			this.$http.post('storeup/delete', delIds).then(res => {
			  if (res.data.code == 0) {
				this.isThumbsupnum = false;
				this.isCrazilynum = false;
				this.$message({
				  type: 'success',
				  message: '取消成功!',
				  duration: 1500,
				});
			  }
			});
	
			if (type == 21) this.detail.thumbsupnum -= 1;
			if (type == 22) this.detail.crazilynum -= 1;
			this.$http.post('libseatinfo/update', this.detail).then(res => {});
		  },
		getThumbsupOrCrazilyStatus() {
			if(localStorage.getItem("Token")) {
				this.$http.get('storeup/list', {params: {page: 1, limit: 1, type: 21, refid: this.detail.id, tablename: 'libseatinfo', userid: localStorage.getItem('userid')}}).then(res => {
				  if (res.data.code == 0 && res.data.data.list.length > 0) {
					this.isThumbsupnum = true;
					this.thumbsupOrCrazilyInfo = res.data.data.list[0];
				  }
				});
	
				this.$http.get('storeup/list', {params: {page: 1, limit: 1, type: 22, refid: this.detail.id, tablename: 'libseatinfo', userid: localStorage.getItem('userid')}}).then(res => {
				  if (res.data.code == 0 && res.data.data.list.length > 0) {
					this.isCrazilynum = true;
					this.thumbsupOrCrazilyInfo = res.data.data.list[0];
				  }
				});
			}
		},
		  curChange(page) {
			this.getDiscussList(page);
		  },
		  prevClick(page) {
			this.getDiscussList(page);
		  },
		  nextClick(page) {
			this.getDiscussList(page);
		  },
		  // 下载
		  download(file){
			if(!file) {
				this.$message({
				  type: 'error',
				  message: '文件不存在',
				  duration: 1500,
				});
				return;
			}
			window.open(this.baseUrl+file)
		  },
		  getDiscussList(page) {
			this.$http.get('discusslibseatinfo/list', {params: {page, limit: this.pageSize, refid: this.detail.id}}).then(res => {
			  if (res.data.code == 0) {
				this.infoList = res.data.data.list;
				this.total = res.data.data.total;
				this.pageSize = res.data.data.pageSize;this.pageSizes = [this.pageSize, this.pageSize*2, this.pageSize*3, this.pageSize*5];
				this.totalPage = res.data.data.totalPage;
			  }
			});
		  },
		  submitForm(formName) {
			let sensitiveWords = "";
			let sensitiveWordsArr = [];
			if(sensitiveWords) {
				sensitiveWordsArr = sensitiveWords.split(",");
			}
			for(var i=0; i<sensitiveWordsArr.length; i++){
				//全局替换
				var reg = new RegExp(sensitiveWordsArr[i],"g");
				//判断内容中是否包括敏感词
				if (this.form.content.indexOf(sensitiveWordsArr[i]) > -1) {
					// 将敏感词替换为 **
					this.form.content = this.form.content.replace(reg,"**");
				}
			}
			this.$refs[formName].validate((valid) => {
			  if (valid) {
				this.$http.get('orders/list', {params: {page: 1, limit: 1, status: '已完成', goodid: this.detail.id, userid: localStorage.getItem('userid')}}).then(res => {
					if (res.data.code == 0 && res.data.data.list.length == 0) {
					  this.$message({
						type: 'success',
						message: '请完成预约后再评论!',
						duration: 1500
					  });
					  return false
					} else {
						this.form.refid = this.detail.id;
						this.form.avatarurl = localStorage.getItem('headportrait')?localStorage.getItem('headportrait'):'';
						this.$http.post('discusslibseatinfo/add', this.form).then(res => {
						  if (res.data.code == 0) {
							this.form.content = '';
							this.getDiscussList(1);
							this.$message({
							  type: 'success',
							  message: '评论成功!',
							  duration: 1500,
							});
						  }
						});
					}
				});
			  } else {
				return false;
			  }
			});
		  },
		  resetForm(formName) {
			this.$refs[formName].resetFields();
		  },
			//立即购买
			buyNow() {
				// 保存到storage中，在确认下单页面中获取要购买的商品
				localStorage.setItem('orderGoods', JSON.stringify([{
					tablename: this.tablename,
					goodid: this.detail.id,
					goodname: this.title,
					goodtype: this.detail.libseattype,
	
					picture:this.detailBanner[0],
					buynumber: this.buynumber,
					userid: localStorage.getItem('userid'),
					price: this.detail.price,
					discountprice: this.detail.vipprice ? this.detail.vipprice : 0
				}]));
				// 跳转到确认下单页面
				let query = {
					type: 1,
				}
				this.$router.push({path: '/index/shop-order/orderConfirm', query: query});
			},
	
	
		},
		components: {
		  CountDown
		}
	  }
	</script>
	
	<style scoped>
		/* 全局样式 */
		.detail-preview {
		  width: 100%;
		  padding: 10px 7% 20px;
		  margin: 0px auto 0;
		  position: relative;
		  background: none;
		}
		
		/* 面包屑导航 */
		.breadcrumb-preview {
		  padding: 0px 20px;
		  margin: 10px auto;
		  background: #4A90E2;
		  display: flex;
		  width: 100%;
		  justify-content: space-between;
		  height: 40px;
		  box-shadow: 0 2px 10px rgba(74, 144, 226, 0.15);
		  transition: all 0.3s ease;
		}
		
		.breadcrumb-preview .el-breadcrumb {
		  font-size: 14px;
		  line-height: 40px;
		}
		
		.breadcrumb-preview .el-breadcrumb ::v-deep .el-breadcrumb__separator {
		  margin: 0 9px;
		  color: #fff;
		  font-weight: 500;
		}
		
		.breadcrumb-preview .el-breadcrumb ::v-deep .el-breadcrumb__inner a {
		  color: #fff;
		  display: inline-block;
		  text-decoration: none;
		  transition: all 0.3s ease;
		}
		
		.breadcrumb-preview .el-breadcrumb ::v-deep .el-breadcrumb__inner a:hover {
		  text-decoration: underline;
		  opacity: 0.8;
		}
		
		.breadcrumb-preview .el-breadcrumb ::v-deep .el-breadcrumb__inner {
		  color: #fff;
		  display: inline-block;
		}
		
		/* 属性容器 */
		.attr {
		  border: 1px solid #e1e8ed;
		  min-height: 620px;
		  padding: 10px 0 0px 0px;
		  box-shadow: 0px 3px 15px rgba(74, 144, 226, 0.08);
		  overflow: hidden;
		  flex-wrap: wrap;
		  background: rgba(255,255,255,1);
		  display: flex;
		  position: relative;
		  justify-content: space-between;
		  border-radius: 8px;
		  transition: all 0.3s ease;
		}
		
		/* 轮播图样式 */
		.attr .el-carousel {
		  border: 1px solid #b8daff;
		  box-shadow: inset 0px 0px 56px 0px rgba(184, 218, 255, 0.2);
		  padding: 20px;
		  margin: 10px auto 0;
		  border-radius: 10px;
		  width: 48%;
		  height: 450px;
		  order: 2;
		  transition: all 0.3s ease;
		}
		
		.attr .el-carousel ::v-deep .el-carousel__container .el-carousel__arrow--left {
		  width: 36px;
		  font-size: 12px;
		  height: 36px;
		  background: rgba(255, 255, 255, 0.8);
		  color: #4A90E2;
		  transition: all 0.3s ease;
		}
		
		.attr .el-carousel ::v-deep .el-carousel__container .el-carousel__arrow--left:hover {
		  background: #4A90E2;
		  color: white;
		  transform: scale(1.1);
		}
		
		.attr .el-carousel ::v-deep .el-carousel__container .el-carousel__arrow--right {
		  width: 36px;
		  font-size: 12px;
		  height: 36px;
		  background: rgba(255, 255, 255, 0.8);
		  color: #4A90E2;
		  transition: all 0.3s ease;
		}
		
		.attr .el-carousel ::v-deep .el-carousel__container .el-carousel__arrow--right:hover {
		  background: #4A90E2;
		  color: white;
		  transform: scale(1.1);
		}
		
		.attr .el-carousel ::v-deep .el-carousel__indicators {
		  padding: 0;
		  margin: 0;
		  z-index: 2;
		  bottom: 40px;
		  position: absolute;
		  list-style: none;
		}
		
		.attr .el-carousel ::v-deep .el-carousel__indicators li {
		  border-radius: 10px;
		  padding: 0;
		  margin: 0 4px;
		  background: #fff;
		  display: inline-block;
		  width: 12px;
		  opacity: 0.4;
		  transition: 0.3s;
		  height: 12px;
		}
		
		.attr .el-carousel ::v-deep .el-carousel__indicators li:hover {
		  padding: 0;
		  margin: 0 4px;
		  background: #fff;
		  display: inline-block;
		  width: 24px;
		  opacity: 0.7;
		  height: 12px;
		}
		
		.attr .el-carousel ::v-deep .el-carousel__indicators li.is-active {
		  padding: 0;
		  margin: 0 4px;
		  background: #4A90E2;
		  display: inline-block;
		  width: 24px;
		  opacity: 1;
		  height: 12px;
		}
		
		.el-carousel-item {
		  border-radius: 10px;
		  width: 100%;
		  height: 100%;
		  overflow: hidden;
		}
		
		.image {
		  width: 100%;
		  object-fit: cover;
		  border-radius: 10px;
		  height: 100%;
		  transition: transform 0.5s ease;
		}
		
		.image:hover {
		  transform: scale(1.03);
		}
		
		/* 赞踩按钮区域 */
		.zancai {
		  padding: 0;
		  margin: 0;
		  top: 500px;
		  background: #fff;
		  display: flex;
		  width: 48%;
		  position: absolute;
		  right: 20px;
		  justify-content: space-between;
		  order: 3;
		}
		
		.zan, .cai {
		  border: 3px solid #b8daff;
		  padding: 10px 0;
		  margin: 0;
		  align-items: center;
		  border-radius: 20px;
		  background: #fff;
		  display: flex;
		  width: 150px;
		  justify-content: center;
		  cursor: pointer;
		  transition: all 0.3s ease;
		}
		
		.zan:hover, .cai:hover {
		  background: #f0f7ff;
		  box-shadow: 0 3px 8px rgba(74, 144, 226, 0.2);
		  transform: translateY(-2px);
		}
		
		.zan i, .cai i,
		.zan span, .cai span {
		  color: #4A90E2;
		  margin: 0 3px;
		  font-size: 14px;
		}
		
		/* 信息区域 */
		.info {
		  min-height: 500px;
		  width: 48%;
		  padding: 10px 10px 10px 20px;
		  margin: 0;
		  background: none;
		}
		
		.title-item {
		  border: 2px solid #b8daff;
		  padding: 15px;
		  margin: 0 0 15px 0;
		  align-items: center;
		  background: linear-gradient(320deg, rgba(204,204,204,0) 0%, rgba(255,255,255,0.9) 80%, rgba(204,204,204,0) 100%);
		  display: flex;
		  justify-content: space-between;
		  border-radius: 8px;
		  box-shadow: 0 2px 8px rgba(74, 144, 226, 0.08);
		  transition: all 0.3s ease;
		}
		
		.title-item:hover {
		  box-shadow: 0 4px 12px rgba(74, 144, 226, 0.15);
		}
		
		.title-item > div:first-child {
		  color: #333;
		  font-size: 18px;
		  font-weight: 500;
		  line-height: 1.5;
		}
		
		.storeup-btn {
		  padding: 6px 12px;
		  background: #f0f7ff;
		  border-radius: 20px;
		  cursor: pointer;
		  transition: all 0.3s ease;
		  box-shadow: 0 2px 5px rgba(74, 144, 226, 0.1);
		  display: flex;
		  align-items: center;
		}
		
		.storeup-btn:hover {
		  background: #e6f2ff;
		  box-shadow: 0 3px 8px rgba(74, 144, 226, 0.2);
		}
		
		.storeup-btn.active {
		  background: #e6f2ff;
		  box-shadow: 0 2px 5px rgba(74, 144, 226, 0.2);
		}
		
		.storeup-btn.active:hover {
		  background: #d1e5ff;
		  box-shadow: 0 3px 8px rgba(74, 144, 226, 0.3);
		}
		
		.storeup-btn i {
		  color: #4A90E2;
		  font-size: 14px;
		  margin-right: 5px;
		}
		
		.storeup-btn span {
		  color: #4A90E2;
		  font-size: 14px;
		}
		
		/* 信息项 */
		.item {
		  padding: 0;
		  margin: 0 0 12px 0;
		  border-color: #b8daff;
		  border-width: 0px 0px 1px;
		  display: flex;
		  border-style: solid;
		  justify-content: space-between;
		  transition: all 0.3s ease;
		}
		
		.item:hover {
		  background: rgba(230, 242, 255, 0.3);
		}
		
		.lable {
		  padding: 0 10px;
		  color: #666;
		  text-align: right;
		  background: linear-gradient(90deg, rgba(255,255,255,1) 0%, rgba(230, 242, 255, 0.7) 100%);
		  width: 102px;
		  font-size: 14px;
		  line-height: 40px;
		  height: 40px;
		  font-weight: 500;
		}
		
		.value {
		  width: calc(100% - 102px);
		  padding: 8px 10px 0;
		  font-size: 14px;
		  line-height: 24px;
		  color: #333;
		  background: linear-gradient(270deg, rgba(255,255,255,1) 0%, rgba(230, 242, 255, 0.7) 100%);
		}
		
		.price-value {
		  font-weight: bold;
		}
		
		.score-value {
		  color: red;
		  font-weight: bold;
		}
		
		/* 按钮组 */
		.btn-group {
		  padding: 10px 0;
		  flex-wrap: wrap;
		  display: flex;
		}
		
		.book-btn {
		  border: 0;
		  cursor: pointer;
		  padding: 0 10px;
		  margin: 0 5px 0 0;
		  outline: none;
		  color: #333;
		  border-radius: 4px;
		  background: #e6f2ff;
		  width: auto;
		  line-height: 40px;
		  font-size: 14px;
		  height: 40px;
		  transition: all 0.3s ease;
		}
		
		.book-btn:hover {
		  background: #4A90E2;
		  color: white;
		  box-shadow: 0 2px 8px rgba(74, 144, 226, 0.3);
		}
		
		/* 详情标签页 */
		.detail {
		  border: 2px solid #b8daff;
		  box-shadow: 0 3px 15px rgba(74, 144, 226, 0.08);
		  padding: 10px;
		  margin: 20px 0 0;
		  border-radius: 8px;
		  background: rgba(255,255,255,1);
		  transition: all 0.3s ease;
		}
		
		.detail-preview .detail.el-tabs ::v-deep .el-tabs__header {
		  margin: 0;
		  background: #f8fcff;
		  border-color: #b8daff;
		  border-width: 0 0 1px 0;
		  border-style: solid;
		}
		
		.detail-preview .detail.el-tabs ::v-deep .el-tabs__header .el-tabs__item {
		  border: 0;
		  padding: 0 20px;
		  margin: 0;
		  color: #666;
		  background: transparent;
		  font-weight: 500;
		  display: inline-block;
		  font-size: 14px;
		  line-height: 40px;
		  position: relative;
		  list-style: none;
		  height: 40px;
		  transition: all 0.3s ease;
		}
		
		.detail-preview .detail.el-tabs ::v-deep .el-tabs__header .el-tabs__item:hover {
		  border: 0;
		  color: #4A90E2;
		  background: #e6f2ff;
		}
		
		.detail-preview .detail.el-tabs ::v-deep .el-tabs__header .el-tabs__item.is-active {
		  border: 0;
		  color: #4A90E2;
		  background: #e6f2ff;
		}
		
		.detail-preview .detail.el-tabs ::v-deep .el-tabs__content {
		  padding: 15px;
		}
		
		.intro-content {
		  padding: 20px;
		  line-height: 1.8;
		  color: #333;
		  font-size: 15px;
		  background: #f8fafc;
		  border-radius: 6px;
		  min-height: 300px;
		}
		
		/* 评论区域 */
		.add.comment {
		  box-shadow: 0 1px 6px 0 rgba(74, 144, 226, 0.1);
		  padding: 15px;
		  margin: 0 0 20px;
		  border-radius: 8px;
		  background: #f8fcff;
		  transition: all 0.3s ease;
		}
		
		.comment-item {
		  width: 100%;
		  display: flex;
		  height: auto;
		}
		
		.detail-preview .detail.el-tabs .add ::v-deep .el-form-item__label {
		  padding: 0 10px 0 0;
		  color: #666;
		  width: 80px;
		  font-size: 14px;
		  line-height: 40px;
		  text-align: right;
		}
		
		.detail-preview .detail.el-tabs .add ::v-deep .el-textarea__inner {
		  border: 1px solid #b8daff;
		  border-radius: 6px;
		  padding: 12px;
		  box-shadow: inset 0px 0px 56px 0px rgba(184, 218, 255, 0.1);
		  outline: none;
		  color: #333;
		  width: 100%;
		  max-width: 1058px;
		  font-size: 14px;
		  line-height: 1.8;
		  height: 120px;
		  transition: all 0.3s ease;
		}
		
		.detail-preview .detail.el-tabs .add ::v-deep .el-textarea__inner:focus {
		  border-color: #4A90E2;
		  box-shadow: inset 0px 0px 56px 0px rgba(184, 218, 255, 0.2);
		}
		
		.comment-btn {
		  width: 100%;
		  padding: 0 0 0 80px;
		  margin: 10px 0 0;
		  height: auto;
		}
		
		.submit-btn {
		  border: 0;
		  cursor: pointer;
		  padding: 0;
		  margin: 0 20px 0 0;
		  outline: none;
		  color: #fff;
		  border-radius: 4px;
		  background: #4A90E2;
		  width: 128px;
		  line-height: 40px;
		  font-size: 14px;
		  height: 40px;
		  transition: all 0.3s ease;
		}
		
		.submit-btn:hover {
		  background: #3a80d2;
		  box-shadow: 0 2px 8px rgba(74, 144, 226, 0.3);
		}
		
		.reset-btn {
		  border: 1px solid #ddd;
		  cursor: pointer;
		  padding: 0;
		  margin: 0 20px 0 0;
		  outline: none;
		  color: #666;
		  border-radius: 4px;
		  background: #fff;
		  width: 128px;
		  line-height: 40px;
		  font-size: 14px;
		  height: 40px;
		  transition: all 0.3s ease;
		}
		
		.reset-btn:hover {
		  background: #f5f5f5;
		}
		
		/* 评论列表 */
		.comment-list {
		  box-shadow: 0 1px 6px 0 rgba(74, 144, 226, 0.08);
		  padding: 15px;
		  border-radius: 8px;
		  background: #f8fcff;
		  transition: all 0.3s ease;
		}
		
		.comment-list .comment-item {
		  padding: 15px;
		  box-shadow: inset 0px 0px 56px 0px rgba(184, 218, 255, 0.1);
		  margin: 0 0 15px;
		  border-color: #b8daff;
		  align-items: center;
		  border-width: 0 0 1px 0;
		  width: 100%;
		  border-style: solid;
		  height: auto;
		  border-radius: 6px;
		  transition: all 0.3s ease;
		}
		
		.comment-list .comment-item:hover {
		  box-shadow: inset 0px 0px 56px 0px rgba(184, 218, 255, 0.2);
		}
		
		.user {
		  width: 100%;
		  align-items: center;
		  display: flex;
		  height: auto;
		  margin-bottom: 10px;
		}
		
		.avatar {
		  width: 40px;
		  margin: 0 10px 0 0;
		  border-radius: 100%;
		  object-fit: cover;
		  height: 40px;
		  border: 2px solid #e6f2ff;
		}
		
		.name {
		  color: #333;
		  font-size: 16px;
		  font-weight: 500;
		}
		
		.content-block-ask {
		  padding: 10px;
		  margin: 0px 0px 10px;
		  line-height: 1.8;
		  font-size: 14px;
		  color: #333;
		  border-radius: 4px;
		  background: rgba(255,255,255,0.8);
		}
		
		.content-block-reply {
		  padding: 10px;
		  margin: 0px 0px 10px;
		  line-height: 1.8;
		  font-size: 14px;
		  color: #333;
		  border-radius: 4px;
		  background: rgba(230, 242, 255, 0.5);
		  border-left: 3px solid #4A90E2;
		}
		
		/* 分页样式 */
		.pagination {
		  padding: 20px 7% 20px;
		  margin: 20px 0 0;
		  white-space: nowrap;
		  color: #666;
		  text-align: center;
		  background: #f0f7ff;
		  width: 100%;
		  font-weight: 500;
		  border-radius: 6px;
		  transition: all 0.3s ease;
		}
		
		.el-pagination ::v-deep .el-pagination__total {
		  margin: 0 10px 0 0;
		  color: #666;
		  font-weight: 400;
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  height: 28px;
		}
		
		.el-pagination ::v-deep .btn-prev {
		  border: 1px solid #b8daff;
		  border-radius: 4px;
		  padding: 0;
		  margin: 0 5px;
		  color: #4A90E2;
		  background: #fff;
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  min-width: 35px;
		  height: 28px;
		  transition: all 0.3s ease;
		}
		
		.el-pagination ::v-deep .btn-prev:hover {
		  background: #e6f2ff;
		  border-color: #4A90E2;
		}
		
		.el-pagination ::v-deep .btn-next {
		  border: 1px solid #b8daff;
		  border-radius: 4px;
		  padding: 0;
		  margin: 0 5px;
		  color: #4A90E2;
		  background: #fff;
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  min-width: 35px;
		  height: 28px;
		  transition: all 0.3s ease;
		}
		
		.el-pagination ::v-deep .btn-next:hover {
		  background: #e6f2ff;
		  border-color: #4A90E2;
		}
		
		.el-pagination ::v-deep .btn-prev:disabled {
		  border: 1px solid #e1e8ed;
		  cursor: not-allowed;
		  border-radius: 4px;
		  padding: 0;
		  margin: 0 5px;
		  color: #C0C4CC;
		  background: #ffffff;
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  height: 28px;
		}
		
		.el-pagination ::v-deep .btn-next:disabled {
		  border: 1px solid #e1e8ed;
		  cursor: not-allowed;
		  border-radius: 4px;
		  padding: 0;
		  margin: 0 5px;
		  color: #C0C4CC;
		  background: #ffffff;
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  height: 28px;
		}
		
		.el-pagination ::v-deep .el-pager {
		  padding: 0;
		  margin: 0;
		  display: inline-block;
		  vertical-align: top;
		}
		
		.el-pagination ::v-deep .el-pager .number {
		  cursor: pointer;
		  padding: 0 4px;
		  margin: 0 5px;
		  color: #666;
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  border-radius: 4px;
		  background: #ffffff;
		  text-align: center;
		  min-width: 30px;
		  height: 28px;
		  border: 1px solid #b8daff;
		  transition: all 0.3s ease;
		}
		
		.el-pagination ::v-deep .el-pager .number:hover {
		  cursor: pointer;
		  border-radius: 4px;
		  padding: 0 4px;
		  margin: 0 5px;
		  background: #e6f2ff;
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  text-align: center;
		  min-width: 30px;
		  height: 28px;
		  color: #4A90E2;
		  border-color: #4A90E2;
		}
		
		.el-pagination ::v-deep .el-pager .number.active {
		  cursor: default;
		  padding: 0 4px;
		  margin: 0 5px;
		  color: #FFF;
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  border-radius: 4px;
		  background: #4A90E2;
		  text-align: center;
		  min-width: 30px;
		  height: 28px;
		  border-color: #4A90E2;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes {
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  height: 28px;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes .el-input {
		  margin: 0 5px;
		  width: 100px;
		  position: relative;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes .el-input .el-input__inner {
		  border: 1px solid #b8daff;
		  cursor: pointer;
		  padding: 0 25px 0 8px;
		  color: #606266;
		  display: inline-block;
		  font-size: 13px;
		  line-height: 28px;
		  border-radius: 4px;
		  outline: 0;
		  background: #FFF;
		  width: 100%;
		  text-align: center;
		  height: 28px;
		  transition: all 0.3s ease;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes .el-input .el-input__inner:hover {
		  border-color: #4A90E2;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes .el-input span.el-input__suffix {
		  top: 0;
		  position: absolute;
		  right: 0;
		  height: 100%;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes .el-input .el-input__suffix .el-select__caret {
		  cursor: pointer;
		  color: #4A90E2;
		  width: 25px;
		  font-size: 14px;
		  line-height: 28px;
		  text-align: center;
		}
		
		.el-pagination ::v-deep .el-pagination__jump {
		  margin: 0 0 0 24px;
		  color: #606266;
		  display: inline-block;
		  vertical-align: top;
		  font-size: 13px;
		  line-height: 28px;
		  height: 28px;
		}
		
		.el-pagination ::v-deep .el-pagination__jump .el-input {
		  border-radius: 4px;
		  padding: 0 2px;
		  margin: 0 2px;
		  display: inline-block;
		  width: 50px;
		  font-size: 14px;
		  line-height: 18px;
		  position: relative;
		  text-align: center;
		  height: 28px;
		}
		
		.el-pagination ::v-deep .el-pagination__jump .el-input .el-input__inner {
		  border: 1px solid #b8daff;
		  cursor: pointer;
		  padding: 0 3px;
		  color: #606266;
		  display: inline-block;
		  font-size: 14px;
		  line-height: 28px;
		  border-radius: 4px;
		  outline: 0;
		  background: #FFF;
		  width: 100%;
		  text-align: center;
		  height: 28px;
		  transition: all 0.3s ease;
		}
		
		.el-pagination ::v-deep .el-pagination__jump .el-input .el-input__inner:focus {
		  border-color: #4A90E2;
		}
		
		/* 选座区域 */
		.seat-list {
		  display: flex;
		  align-items: center;
		  flex-wrap: wrap;
		  padding: 20px;
		}
		
		.seat-item {
		  width: 20%;
		  display: flex;
		  flex-direction: column;
		  align-items: center;
		  margin-bottom: 20px;
		  transition: all 0.3s ease;
		}
		
		.seat-item:hover {
		  transform: translateY(-5px);
		}
		
		.seat-icon {
		  width: 60px;
		  height: 60px;
		  border-radius: 8px;
		  transition: all 0.3s ease;
		  cursor: pointer;
		}
		
		.seat-unselect {
		  background-color: #e6f2ff;
		  border: 2px solid #4A90E2;
		}
		
		.seat-unselect:hover {
		  background-color: #d1e5ff;
		}
		
		.seat-selected {
		  background-color: #f0f0f0;
		  border: 2px solid #ccc;
		  cursor: not-allowed;
		}
		
		.seat-active {
		  background-color: #4A90E2;
		  border: 2px solid #3a80d2;
		}
		
		.seat-item span {
		  line-height: 3;
		  color: #333;
		  font-size: 14px;
		}
		
		/* 时间选择对话框样式 */
		::v-deep .el-dialog {
		  border-radius: 12px;
		  box-shadow: 0 5px 20px rgba(74, 144, 226, 0.2);
		}
		
		::v-deep .el-dialog__header {
		  background: linear-gradient(135deg, #4A90E2 0%, #6aa8e6 100%);
		  border-radius: 12px 12px 0 0;
		  padding: 20px;
		}
		
		::v-deep .el-dialog__title {
		  color: #fff;
		  font-size: 18px;
		  font-weight: 500;
		}
		
		::v-deep .el-dialog__headerbtn .el-dialog__close {
		  color: #fff;
		  font-size: 20px;
		}
		
		::v-deep .el-dialog__body {
		  padding: 30px 20px;
		}
		
		::v-deep .el-form-item__label {
		  color: #666;
		  font-weight: 500;
		}
		
		::v-deep .el-date-editor .el-input__inner {
		  border: 1px solid #b8daff;
		  border-radius: 6px;
		  transition: all 0.3s ease;
		}
		
		::v-deep .el-date-editor .el-input__inner:focus {
		  border-color: #4A90E2;
		  box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.1);
		}
		
		.dialog-footer {
		  text-align: right;
		}
		
		.dialog-footer .el-button {
		  padding: 10px 20px;
		  border-radius: 6px;
		  transition: all 0.3s ease;
		}
		
		.dialog-footer .el-button--primary {
		  background: #4A90E2;
		  border-color: #4A90E2;
		}
		
		.dialog-footer .el-button--primary:hover {
		  background: #3a80d2;
		  box-shadow: 0 2px 8px rgba(74, 144, 226, 0.3);
		}
	</style>
	