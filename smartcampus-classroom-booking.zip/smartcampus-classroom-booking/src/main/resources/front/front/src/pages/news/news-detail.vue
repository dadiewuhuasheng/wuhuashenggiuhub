<template>
  <div class="container">
    <div class="section-title">公告信息</div>
    <div class="section-content">
      <div class="content-title">{{detail.title}}</div>
      <div class="content-sub-title">发布时间：{{detail.addtime}}</div>
      <el-divider></el-divider>
      <div class="content-detail" v-html="detail.content"></div>
    </div>
  </div>
</template>

<script>
  export default {
    //数据集合
    data() {
      return {
        detail: {},
      }
    },
    created() {
      this.detail = Object.assign({}, JSON.parse(this.$route.query.detailObj));
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .container {
    width: 1200px;
    padding: 20px;
    margin: 0px auto;
    position: relative;
    background: #f9fbfd;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(106, 168, 230, 0.1);
  }

  .section-title {
    margin: 10px 0;
    color: #fff;
    text-align: center;
    background: #6aa8e6;
    width: 100%;
    font-size: 20px;
    line-height: 54px;
    border-radius: 6px;
    letter-spacing: 1px;
    box-shadow: 0 2px 5px rgba(106, 168, 230, 0.2);
  }

  .section-content {
    margin-top: 30px;
    padding: 30px;
    background: #fff;
    border-radius: 6px;
    border: 1px solid #e6f0fa;
  }
  
  .content-title {
    text-align: center;
    font-size: 24px;
    font-weight: 600;
    color: #2c3e50;
    padding-bottom: 15px;
    border-bottom: 1px solid #e6f0fa;
    margin-bottom: 20px;
    line-height: 1.5;
  }
  
  .content-sub-title {
    text-align: center;
    margin-top: 10px;
    color: #95b1ce;
    font-size: 14px;
    margin-bottom: 20px;
  }
  
  .el-divider {
    margin: 20px 0;
    background-color: #e6f0fa;
  }
  
  .content-detail {
    color: #34495e;
    font-size: 16px;
    line-height: 1.8;
    letter-spacing: 0.5px;
    padding: 10px 0;
    
    /* 优化富文本内容样式 */
    p {
      margin-bottom: 1.2em;
    }
    
    img {
      max-width: 100%;
      height: auto;
      margin: 1.5em auto;
      display: block;
      border-radius: 4px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    }
    
    h1, h2, h3, h4, h5, h6 {
      color: #2c3e50;
      margin: 1.5em 0 0.8em;
      font-weight: 600;
    }
    
    a {
      color: #4a90e2;
      text-decoration: none;
      transition: color 0.3s ease;
      
      &:hover {
        color: #3a80d2;
        text-decoration: underline;
      }
    }
    
    ul, ol {
      margin: 1em 0 1em 2em;
    }
    
    li {
      margin-bottom: 0.5em;
    }
  }
  
  /* 添加页面载入动画 */
  .container {
    animation: fadeIn 0.6s ease-in-out;
  }
  
  @keyframes fadeIn {
    from {
      opacity: 0;
      transform: translateY(10px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
</style>
