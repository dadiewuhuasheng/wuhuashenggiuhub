import { Message, MessageBox } from 'element-ui'

/**
 * 错误处理工具类
 */
class ErrorHandler {
  /**
   * 格式化错误消息
   * @param {Object} error - 错误对象
   * @returns {String} 格式化后的错误消息
   */
  static formatErrorMessage(error) {
    // 如果是响应错误
    if (error.response) {
      const { status, data } = error.response
      
      // 根据HTTP状态码返回不同消息
      switch (status) {
        case 400:
          return data.msg || '请求参数错误，请检查输入'
        case 401:
          return '未授权，请重新登录'
        case 403:
          return '没有权限执行此操作'
        case 404:
          return '请求的资源不存在'
        case 409:
          return data.msg || '操作冲突，请刷新后重试'
        case 500:
          return '服务器错误，请稍后重试'
        default:
          return data.msg || `请求失败 (${status})`
      }
    }
    
    // 如果是请求错误
    if (error.request) {
      return '网络连接失败，请检查网络'
    }
    
    // 其他错误
    return error.message || '操作失败，请重试'
  }

  /**
   * 显示错误消息（Toast）
   * @param {Object|String} error - 错误对象或错误消息
   * @param {Number} duration - 显示时长（毫秒）
   */
  static showError(error, duration = 3000) {
    const message = typeof error === 'string' 
      ? error 
      : this.formatErrorMessage(error)
    
    Message({
      message,
      type: 'error',
      duration,
      showClose: true
    })
  }

  /**
   * 显示成功消息（Toast）
   * @param {String} message - 成功消息
   * @param {Number} duration - 显示时长（毫秒）
   */
  static showSuccess(message, duration = 2000) {
    Message({
      message,
      type: 'success',
      duration,
      showClose: true
    })
  }

  /**
   * 显示警告消息（Toast）
   * @param {String} message - 警告消息
   * @param {Number} duration - 显示时长（毫秒）
   */
  static showWarning(message, duration = 3000) {
    Message({
      message,
      type: 'warning',
      duration,
      showClose: true
    })
  }

  /**
   * 显示信息消息（Toast）
   * @param {String} message - 信息消息
   * @param {Number} duration - 显示时长（毫秒）
   */
  static showInfo(message, duration = 2000) {
    Message({
      message,
      type: 'info',
      duration,
      showClose: true
    })
  }

  /**
   * 显示错误对话框
   * @param {Object|String} error - 错误对象或错误消息
   * @param {String} title - 对话框标题
   */
  static showErrorDialog(error, title = '错误') {
    const message = typeof error === 'string' 
      ? error 
      : this.formatErrorMessage(error)
    
    MessageBox.alert(message, title, {
      confirmButtonText: '确定',
      type: 'error'
    })
  }

  /**
   * 显示冲突错误对话框（带详细信息）
   * @param {Object} conflictData - 冲突数据
   */
  static showConflictDialog(conflictData) {
    const { message, conflicts } = conflictData
    
    let detailHtml = `<p>${message}</p>`
    
    if (conflicts && conflicts.length > 0) {
      detailHtml += '<div style="margin-top: 15px; text-align: left;">'
      detailHtml += '<p style="font-weight: 600; color: #606266;">冲突详情：</p>'
      detailHtml += '<ul style="padding-left: 20px; color: #909399;">'
      
      conflicts.forEach(conflict => {
        detailHtml += `<li style="margin: 5px 0;">${conflict}</li>`
      })
      
      detailHtml += '</ul></div>'
    }
    
    MessageBox.alert(detailHtml, '预约冲突', {
      confirmButtonText: '知道了',
      type: 'warning',
      dangerouslyUseHTMLString: true
    })
  }

  /**
   * 处理验证错误
   * @param {Object} error - 验证错误对象
   * @returns {Object} 字段错误映射
   */
  static handleValidationError(error) {
    if (error.response && error.response.data && error.response.data.errors) {
      return error.response.data.errors
    }
    return {}
  }

  /**
   * 处理API错误（统一处理）
   * @param {Object} error - 错误对象
   * @param {Object} options - 选项
   * @param {Boolean} options.showDialog - 是否显示对话框（默认false，显示Toast）
   * @param {Boolean} options.silent - 是否静默处理（不显示任何提示）
   * @param {Function} options.onUnauthorized - 未授权时的回调
   */
  static handleApiError(error, options = {}) {
    const {
      showDialog = false,
      silent = false,
      onUnauthorized = null
    } = options

    // 静默处理
    if (silent) {
      return
    }

    // 处理401未授权
    if (error.response && error.response.status === 401) {
      if (onUnauthorized) {
        onUnauthorized()
      } else {
        this.showError('登录已过期，请重新登录')
        // 清除本地存储
        localStorage.clear()
        // 跳转到登录页
        setTimeout(() => {
          window.location.href = '/#/login'
        }, 1500)
      }
      return
    }

    // 处理409冲突
    if (error.response && error.response.status === 409) {
      const conflictData = error.response.data
      if (conflictData.conflicts) {
        this.showConflictDialog(conflictData)
        return
      }
    }

    // 显示错误
    if (showDialog) {
      this.showErrorDialog(error)
    } else {
      this.showError(error)
    }
  }
}

export default ErrorHandler
