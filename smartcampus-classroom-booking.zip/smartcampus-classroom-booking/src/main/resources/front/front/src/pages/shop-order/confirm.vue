<template>
  <div class="container">
    <div class="section-title">确认下单</div>
    
    <el-descriptions v-if="seat!=1" title="选择收货地址" class="section-descriptions"></el-descriptions>
    <el-table v-if="seat!=1"
      :data="addressList"
      class="address-table">
      <el-table-column
        label="选择"
        width="55">
        <template slot-scope="scope">
          <el-radio
            v-model="radio"
            :label="scope.$index"
            @change.native="getCurrentRow(scope.$index)">
            &nbsp;</el-radio>
        </template>
      </el-table-column>
      <el-table-column
        label="收件人"
        prop="name">
      </el-table-column>
      <el-table-column
        label="联系方式"
        prop="phone">
      </el-table-column>
      <el-table-column
        label="地址"
        prop="address">
      </el-table-column>
    </el-table>
    
    <el-descriptions title="清单列表" class="section-descriptions"></el-descriptions>
    <el-table
      :data="tableData"
      class="order-table">
      <el-table-column
        label="商品名称">
        <template slot-scope="scope">
          <div class="product-item">
            <el-image
              style="width: 100px; height: 100px"
              :src="baseUrl + scope.row.picture"
              fit="fill"></el-image>
            <span style="margin-left: 10px">{{ scope.row.goodname }}</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        label="价格">
        <template slot-scope="scope">
          <span v-if="type == 2">{{ scope.row.price }} 积分</span>
          <span v-else><span class="currency-symbol">￥</span>{{ scope.row.price }}</span>
        </template>
      </el-table-column>
      <el-table-column v-if="seat==1"
        label="座位">
        <template slot-scope="scope">
          <span>{{ scope.row.activeSeat }}</span>
        </template>
      </el-table-column>
      <el-table-column v-if="seat!=1"
        label="数量">
        <template slot-scope="scope">
          <span>{{ scope.row.buynumber }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="总价">
        <template slot-scope="scope">
          <span v-if="type == 2">{{ scope.row.price * scope.row.buynumber }} 积分</span>
          <span v-else-if="seat==1"><span class="currency-symbol">￥</span>{{scope.row.total}}</span>
          <span v-else><span class="currency-symbol">￥</span>{{ (scope.row.price * scope.row.buynumber).toFixed(2) }}</span>
        </template>
      </el-table-column>
    </el-table>
    
    <div class="remark-container">
        <span class="remark-label">备注：</span>
        <el-input type="textarea" v-model="remark" placeholder="请输入备注信息" class="remark-input"></el-input>
    </div>
    
    <div class="buy-actions" v-if="seat!=1 && tableData.length > 0">
      <template v-if="type == 2">
        <span class="total-price">总价：{{totalPrice}} 积分</span>
        <el-button type="warning" @click="jfClick" class="action-button exchange-button">兑换</el-button>
      </template>
      <template v-else>
        <span class="total-price">总价：<span class="currency-symbol">￥</span>{{totalPrice}}</span>
        <el-button type="success" @click="payClick" class="action-button pay-button">支付</el-button>
      </template>
    </div>
    
    <div class="buy-actions" v-if="seat==1 && tableData.length > 0">
      <template v-if="type == 2">
        <span class="total-price">总价：<span class="currency-symbol">￥</span>{{totalPrice}}</span>
        <el-button type="success" @click="xzJfClick" class="action-button exchange-button">兑换</el-button>
      </template>
      <template v-else>
        <span class="total-price">总价：<span class="currency-symbol">￥</span>{{totalPrice}}</span>
        <el-button type="success" @click="xzPayClick" class="action-button pay-button">支付</el-button>
      </template>
    </div>
  </div>
</template>

<script>
  import config from '@/config/config'
  export default {
    data() {
      return {
        baseUrl: config.baseUrl,
        userTableName: localStorage.getItem('UserTableName'),
        addressList: [],
        tableData: [],
        currentRow: null,
        radio: -1,
        order: {
          address: "",
          buynumber: 0,
          consignee: '',
          discountprice: 0,
          discounttotal: 0,
          goodid: 0,
          goodname: "",
          orderid: "",
          picture: "",
          price: 0,
          status: "未支付",
          tablename: "",
          tel: "",
          total: 0,
          type: 1,
          userid: localStorage.getItem('userid')
        },
        user: {},
        type: 0,
        seat: 0,
        buynumber: 0,
        remark:''
      }
    },
    created() {
      if(this.$route.query.type != undefined) {
        this.type = this.$route.query.type;
      }
      if(this.$route.query.seat != undefined) {
        this.seat = this.$route.query.seat;
      }
      if(this.$route.query.tablename != undefined) {
        this.order.tablename = this.$route.query.tablename;
      }

      this.getSession();
      this.getAddrList();
      // 获取商品购买的清单列表
      var orderGoods = localStorage.getItem('orderGoods')
      // 转换成json类型，localstorage保存的是string数据
      this.tableData = JSON.parse(orderGoods);
      this.type = this.$route.query.type;
    },
    methods: {
      getSession() {
        this.$http.get(`${this.userTableName}/session`, {emulateJSON: true}).then(res => {
          if (res.data.code == 0) {
            this.user = res.data.data;
          }
        });
      },
      getCurrentRow(index) {
        this.radio = index;　
      },
      getAddrList() {
        this.$http.get('address/list', {params: {userid: localStorage.getItem('userid')}}).then(res => {
          if (res.data.code == 0) {
            this.addressList = res.data.data.list;
            this.addressList.forEach((item, index) => {
              if (item.isdefault == '是') {
                this.radio = index;
              }
            });
          }
        });
      },
      getCartList() {
        this.$http.get('cart/list', {params: {page: 1, limit: 1000, userid: localStorage.getItem('userid')}}).then(res => {
          if (res.data.code == 0) {
            this.tableData = res.data.data.list;
            if (this.$route.query.id != undefined || this.$route.query.type != undefined) {
              this.tableData = [];
              this.buynumber = this.$route.query.buynumber;
              let detailObj = JSON.parse(this.$route.query.detailObj);
              this.order.tablename = this.$route.query.tablename;
              if (this.$route.query.type == 1) {
                this.tableData.push({
                  buynumber: this.buynumber,
                  goodid: detailObj.id,
                  picture: this.$route.query.picture,
                  goodname: this.$route.query.goodname,
                  goodtype: this.$route.query.goodtype,
                  tablename: this.$route.query.tablename,
                  userid: localStorage.getItem('userid'),
                  price: this.$route.query.price
                });
              }
              if (this.$route.query.type == 2) {
                this.tableData.push({
                  buynumber: this.buynumber,
                  goodid: detailObj.id,
                  picture: this.$route.query.picture,
                  goodname: this.$route.query.goodname,
                  tablename: this.$route.query.tablename,
                  userid: localStorage.getItem('userid'),
                  jf: detailObj.jf
                });
              }
            }
          }
        });
      },
      handleChange(value, index, goodid) {
        this.$http.get(`${this.order.tablename}/detail/${goodid}`).then(res => {
          if (res.data.code == 0 && value > res.data.data.onelimittimes) {
            this.tableData[index].buynumber = --value;
            this.$message.error(`每人单次只能购买${res.data.data.onelimittimes}件`);
          }
        });
      },
        // 正常下单，生成订单，减少余额，添加积分，减少库存，修改状态已预约
        payClick() {
            if (this.radio == -1) {
              this.$message({
                message: '请选择收货地址',
                type: 'error',
                duration: 1500
              });
              return;
            }

            // 生成订单
            this.tableData.forEach(item => {
                // 获取商品详情信息
                this.$http.get(`${item.tablename}/info/${item.goodid}`).then(res => {
                    // 订单编号
                    var orderId = this.createOrder();
                    let data = res.data.data;
                    data.alllimittimes = data.alllimittimes - item.buynumber;
                    // 更新库存信息
                    this.$http.post(`${item.tablename}/update`, data).then(res => {
                        // 添加订单信息
                        let order = {
                            orderid: orderId,
                            tablename: item.tablename,
                            userid: this.user.id,
                            goodid: item.goodid,
                            goodname: item.goodname,
                            goodtype: item.goodtype,
                            picture: item.picture,
                            buynumber: item.buynumber,
                            discountprice: item.price,
                            price: item.price,
                            total: item.price * item.buynumber,
                            discounttotal: item.price * item.buynumber,
                            type: this.type?this.type:1,
                            //total: this.totalPrice,
                            address: this.addressList[this.radio].address,
                            tel: this.addressList[this.radio].phone,
                            consignee: this.addressList[this.radio].name,
                            remark: this.remark,
                            status: '未支付'
                        }
                        this.$http.post('orders/add', order).then(res => {
                            // 减少余额，更新订单状态
                            // 判断余额是否充足
                            if (Number(this.user.money) < Number(item.price * item.buynumber)) {
                                this.$message({
                                    message: '余额不足，请先充值',
                                    type: 'error',
                                    duration: 1500
                                });
                                return
                            }
                            // 如果该商品存在积分
                            if (data.jf) {
                                this.user.jf = Number(this.user.jf) + Number(item.price * item.buynumber);
                            }
                            this.user.money = this.user.money - item.price * item.buynumber;
                            // 更新用户余额
                            this.$http.post(`${this.userTableName}/update`, this.user).then(res => {
                                order.status = '已预约'
                                var params = {
                                    orderid: orderId,
                                    page: 1,
                                    limit: 1,
                                }
                                this.$http.get('orders/list', {params: params}).then(res => {
                                    order.id = res.data.data.list[0].id;
                                    this.$http.post(`orders/update`, order).then(res => {
                                        // 删除购物车数据(如果是购物车下单)
                                        if (item.id) {
                                            this.$http.post('cart/delete', [item.id]).then(res => {});
                                        }
                                        this.$message({
                                              message: '购买成功',
                                              type: 'success',
                                              duration: 1500,
                                              onClose: () => {
                                                this.$router.push('/index/shop-order/order');
                                              }
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        },

        // 积分兑换，生成订单，减少用户积分，减少库存
        jfClick() {
            if (this.radio == -1) {
              this.$message({
                message: '请选择收货地址',
                type: 'error',
                duration: 1500
              });
              return;
            }

            // 生成订单
            this.tableData.forEach(item => {
                // 订单编号
                var orderId = this.createOrder();
                this.$http.get(`${item.tablename}/info/${item.goodid}`).then(res => {
                    let data = res.data.data;
                    // 减少库存
                    data.alllimittimes = data.alllimittimes - item.buynumber;
                    // 更新库存信息
                    this.$http.post(`${item.tablename}/update`, data).then(res => {
                        // 判断积分是否充足
                        if (this.user.jf < this.totalPrice) {
                            this.$message({
                                message: '积分不足，兑换失败',
                                type: 'error',
                                duration: 1500
                            });
                            return
                        }
                        // 添加订单信息
                        let order = {
                            orderid: orderId,
                            tablename: item.tablename,
                            userid: this.user.id,
                            goodid: item.goodid,
                            goodname: item.goodname,
                            goodtype: item.goodtype,
                            picture: item.picture,
                            buynumber: item.buynumber,
                            discountprice: item.price,
                            price: item.price,
                            total: item.price * item.buynumber,
                            discounttotal: item.price * item.buynumber,
                            type: 2,
                            total: this.totalPrice,
                            address: this.addressList[this.radio].address,
                            tel: this.addressList[this.radio].phone,
                            consignee: this.addressList[this.radio].name,
                            status: '已预约'
                        }
                        this.$http.post('orders/add', order).then(res => {
                            this.user.jf = this.user.jf - item.price * item.buynumber;
                            // 更新用户余额
                            this.$http.post(`${this.userTableName}/update`, this.user).then(res => {
                                this.$message({
                                      message: '兑换成功',
                                      type: 'success',
                                      duration: 1500,
                                      onClose: () => {
                                        this.$router.push('/index/shop-order/order');
                                      }
                                });
                            });
                        });
                    });
                });
            });
        },
        // 选座下单,生成订单，减少余额，添加积分，减少库存，修改状态为已预约
        xzPayClick() {
            // 生成订单
            this.tableData.forEach(item => {
                // 订单编号
                var orderId = this.createOrder();
                // 获取商品详情信息
                this.$http.get(`${item.tablename}/info/${item.goodid}`).then(res => {
                    let data = res.data.data;
                    // 减少库存
                    data.alllimittimes = data.alllimittimes - item.buynumber;
                    // 获取已经被预定的座位号
                    let selectArray = data.selected?data.selected.split(','):[];
                    // 获取用户预定的座位号
                    let activeArray = item.address.split(',');
                    // 新的预定座位号
                    let newSelectArray = selectArray.concat(activeArray);
                    // 赋值给参数
                    data.selected = newSelectArray.join(',');
                    // 更新库存,座位预约
                    this.$http.post(`${item.tablename}/update`, data).then(res => {
                        // 添加订单信息
                        let order = {
                            orderid: orderId,
                            tablename: item.tablename,
                            userid: this.user.id,
                            goodid: item.goodid,
                            goodname: item.goodname,
                            goodtype: item.goodtype,
                            picture: item.picture,
                            buynumber: item.buynumber,
                            discountprice: item.price,
                            price: item.price,
                            total: item.total,
                            discounttotal: item.total,
                            type: 1,
                            address: item.address,
                            remark: this.remark,
                            status: '未支付',
                            startTime: item.startTime,
                            endTime: item.endTime
                        }
                        this.$http.post('orders/add', order).then(res => {
                            // 减少余额，更新订单状态
                            // 判断余额是否充足
                            if (Number(this.user.money) < Number(item.price * item.buynumber)) {
                                this.$message({
                                    message: '余额不足，请先充值',
                                    type: 'error',
                                    duration: 1500
                                });
                                return
                            }
                            // 如果该商品存在积分
                            if (data.jf) {
                                this.user.jf = Number(this.user.jf) + Number(data.jf * item.buynumber);
                            }
                            this.user.money = this.user.money - item.price * item.buynumber;
                            // 更新用户余额
                            this.$http.post(`${this.userTableName}/update`, this.user).then(res => {
                                order.status = '已预约'
                                var params = {
                                    orderid: orderId,
                                    page: 1,
                                    limit: 1,
                                }
                                this.$http.get('orders/list', {params: params}).then(res => {
                                    order.id = res.data.data.list[0].id;
                                    this.$http.post(`orders/update`, order).then(res => {
                                        this.$message({
                                              message: '购买成功',
                                              type: 'success',
                                              duration: 1500,
                                              onClose: () => {
                                                this.$router.push('/index/shop-order/order');
                                              }
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        },
            //二维码支付
        xzQRcodeClick(){
            this.QRcodePayVisible = true
        },
        xzQRcodePaySuccess() {
            // 生成订单
            this.tableData.forEach(item => {
                // 订单编号
                var orderId = this.createOrder();
                // 获取商品详情信息
                this.$http.get(`${item.tablename}/info/${item.goodid}`).then(res => {
                    let data = res.data.data;
                    // 减少库存
                    data.alllimittimes = data.alllimittimes - item.buynumber;
                    // 获取已经被预定的座位号
                    let selectArray = data.selected?data.selected.split(','):[];
                    // 获取用户预定的座位号
                    let activeArray = item.address.split(',');
                    // 新的预定座位号
                    let newSelectArray = selectArray.concat(activeArray);
                    // 赋值给参数
                    data.selected = newSelectArray.join(',');
                    // 更新库存,座位预约
                    this.$http.post(`${item.tablename}/update`, data).then(res => {
                        // 添加订单信息
                        let order = {
                            orderid: orderId,
                            tablename: item.tablename,
                            userid: this.user.id,
                            goodid: item.goodid,
                            goodname: item.goodname,
                            goodtype: item.goodtype,
                            picture: item.picture,
                            buynumber: item.buynumber,
                            discountprice: item.price,
                            price: item.price,
                            total: item.total,
                            discounttotal: item.total,
                            type: 1,
                            address: item.address,
                            remark: this.remark,
                            status: '未支付',
                            startTime: item.startTime,
                            endTime: item.endTime
                        }
                        this.$http.post('orders/add', order).then(res => {
                            // 减少余额，更新订单状态
                            // 判断余额是否充足
                            if (Number(this.user.money) < Number(item.price * item.buynumber)) {
                                this.$message({
                                    message: '余额不足，请先充值',
                                    type: 'error',
                                    duration: 1500
                                });
                                return
                            }
                            // 如果该商品存在积分
                            if (data.jf) {
                                this.user.jf = Number(this.user.jf) + Number(data.jf * item.buynumber);
                            }
                            this.user.money = this.user.money - item.price * item.buynumber;
                            // 更新用户余额
                            this.$http.post(`${this.userTableName}/update`, this.user).then(res => {
                                order.status = '已预约'
                                var params = {
                                    orderid: orderId,
                                    page: 1,
                                    limit: 1,
                                }
                                this.$http.get('orders/list', {params: params}).then(res => {
                                    order.id = res.data.data.list[0].id;
                                    this.$http.post(`orders/update`, order).then(res => {
                                        this.$message({
                                              message: '购买成功',
                                              type: 'success',
                                              duration: 1500,
                                              onClose: () => {
                                                this.$router.push('/index/shop-order/order');
                                              }
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        },
        // 选座下单,生成订单，减少余额，添加积分，减少库存，修改状态为已预约
        xzJfClick() {
            // 生成订单
            this.tableData.forEach(item => {
                // 订单编号
                var orderId = this.createOrder();
                // 获取商品详情信息
                this.$http.get(`${item.tablename}/info/${item.goodid}`).then(res => {
                    let data = res.data.data;
                    // 减少库存
                    data.alllimittimes = data.alllimittimes - item.buynumber;
                    // 获取已经被预定的座位号
                    let selectArray = data.selected?data.selected.split(','):[];
                    // 获取用户预定的座位号
                    let activeArray = item.address.split(',');
                    // 新的预定座位号
                    let newSelectArray = selectArray.concat(activeArray);
                    // 赋值给参数
                    data.selected = newSelectArray.join(',');
                    // 更新库存,座位预约
                    this.$http.post(`${item.tablename}/update`, data).then(res => {
                        // 添加订单信息
                        let order = {
                            orderid: orderId,
                            tablename: item.tablename,
                            userid: this.user.id,
                            goodid: item.goodid,
                            goodname: item.goodname,
                            goodtype: item.goodtype,
                            picture: item.picture,
                            buynumber: item.buynumber,
                            discountprice: item.price,
                            price: item.price,
                            total: item.price * item.buynumber,
                            discounttotal: 0,
                            type: 2,
                            address: item.address,
                            remark: this.remark,
                            status: '未支付',
                            startTime: item.startTime,
                            endTime: item.endTime

                        }
                        this.$http.post('orders/add', order).then(res => {
                            // 减少余额，更新订单状态
                            // 判断余额是否充足
                            if (Number(this.user.jf) < Number(item.jf * item.buynumber)) {
                                this.$message({
                                    message: '积分不足',
                                    type: 'error',
                                    duration: 1500
                                });
                                return
                            }
                            this.user.jf = this.user.jf - item.price * item.buynumber;
                            // 更新用户余额
                            this.$http.post(`${this.userTableName}/update`, this.user).then(res => {
                                order.status = '已预约'
                                var params = {
                                    orderid: orderId,
                                    page: 1,
                                    limit: 1,
                                }
                                this.$http.get('orders/list', {params: params}).then(res => {
                                    order.id = res.data.data.list[0].id;
                                    this.$http.post(`orders/update`, order).then(res => {
                                        this.$message({
                                              message: '购买成功',
                                              type: 'success',
                                              duration: 1500,
                                              onClose: () => {
                                                this.$router.push('/index/shop-order/order');
                                              }
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        },
      createOrder() {
        let order = '';
        let now = new Date();
        order += now.getFullYear();
        order += now.getMonth() + 1;
        order += now.getDate();
        order += now.getHours();
        order += now.getMinutes();
        order += now.getSeconds();
        order += now.getMilliseconds();

        return order;
      }
    },
    computed: {
      totalPrice() {
        let totalPrice = 0;
        this.tableData.forEach(item => {
            totalPrice += item.price * item.buynumber;
        });

        return totalPrice.toFixed(2);
      },
      totalJifen() {
        let totalJifen = 0;
        this.tableData.forEach(item => {
          totalJifen += item.jf * this.buynumber;
        });

        return totalJifen;
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .container {
    width: 1200px;
    padding: 20px;
    margin: 0px auto;
    position: relative;
    background: #f9fbfd;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(106, 168, 230, 0.1);
    animation: fadeIn 0.6s ease-in-out;
  }
  
  @keyframes fadeIn {
    from {
      opacity: 0;
      transform: translateY(10px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  
  .section-title {
    margin: 10px 0;
    color: #fff;
    text-align: center;
    background: #6aa8e6;
    width: 100%;
    font-size: 20px;
    line-height: 54px;
    border-radius: 6px;
    letter-spacing: 1px;
    box-shadow: 0 2px 5px rgba(106, 168, 230, 0.2);
  }
  
  .section-descriptions {
    margin-top: 20px;
    padding: 10px 15px;
    background-color: #f0f7ff;
    border-radius: 6px;
    border-left: 3px solid #6aa8e6;
    
    ::v-deep .el-descriptions__title {
      color: #4a90e2;
      font-weight: 600;
      font-size: 16px;
    }
  }
  
  .address-table, .order-table {
    width: 100%;
    margin-top: 10px;
    border-radius: 6px;
    overflow: hidden;
    border: 1px solid #e6f0fa;
    transition: all 0.3s ease;
    
    ::v-deep .el-table__header-wrapper {
      background-color: #f0f7ff;
      
      th {
        color: #556677;
        font-weight: 600;
        border-bottom: 1px solid #e6f0fa;
        background-color: #f0f7ff !important;
      }
    }
    
    ::v-deep .el-table__body-wrapper {
      tr {
        transition: background-color 0.3s ease;
        
        &:hover > td {
          background-color: #f9fbfd !important;
        }
      }
      
      td {
        border-bottom: 1px solid #f0f7ff;
      }
    }
    
    ::v-deep .el-radio__input.is-checked .el-radio__inner {
      border-color: #6aa8e6;
      background: #6aa8e6;
    }
    
    ::v-deep .el-radio__input.is-checked + .el-radio__label {
      color: #6aa8e6;
    }
  }
  
  .product-item {
    display: flex;
    align-items: center;
    padding: 5px 0;
    transition: transform 0.2s ease;
    
    &:hover {
      transform: translateX(5px);
    }
  }
  
  .currency-symbol {
    font-size: 12px;
  }
  
  .remark-container {
    width: 100%;
    padding: 15px;
    box-sizing: border-box;
    display: flex;
    align-items: flex-start;
    margin-top: 15px;
    background-color: #fff;
    border-radius: 6px;
    border: 1px solid #e6f0fa;
  }
  
  .remark-label {
    width: 80px;
    font-size: 14px;
    color: #556677;
    padding-top: 5px;
    flex-shrink: 0;
  }
  
  .remark-input {
    width: calc(100% - 80px);
    transition: border-color 0.3s ease;
    
    ::v-deep .el-textarea__inner {
      border-color: #b8d4f0;
      border-radius: 4px;
      transition: all 0.3s ease;
      
      &:focus {
        border-color: #6aa8e6;
        box-shadow: 0 0 0 2px rgba(106, 168, 230, 0.2);
      }
    }
  }
  
  .buy-actions {
    text-align: right;
    padding: 15px 20px;
    margin-top: 15px;
    background-color: #f0f7ff;
    border-radius: 6px;
    border: 1px solid #e6f0fa;
  }
  
  .total-price {
    color: #e74c3c;
    margin-right: 15px;
    font-weight: 700;
    font-size: 16px;
  }
  
  .action-button {
    padding: 8px 20px;
    font-size: 14px;
    border-radius: 4px;
    transition: all 0.3s ease;
    transform: translateY(0);
    box-shadow: none;
  }
  
  .pay-button {
    background-color: #6aa8e6;
    border-color: #6aa8e6;
    
    &:hover {
      background-color: #4a90e2;
      border-color: #4a90e2;
      transform: translateY(-2px);
      box-shadow: 0 2px 5px rgba(106, 168, 230, 0.3);
    }
  }
  
  .exchange-button {
    background-color: #6aa8e6;
    border-color: #6aa8e6;
    
    &:hover {
      background-color: #4a90e2;
      border-color: #4a90e2;
      transform: translateY(-2px);
      box-shadow: 0 2px 5px rgba(106, 168, 230, 0.3);
    }
  }
  
  ::v-deep .el-button--success {
    background-color: #6aa8e6;
    border-color: #6aa8e6;
  }
  
  ::v-deep .el-button--warning {
    background-color: #6aa8e6;
    border-color: #6aa8e6;
  }
  
</style>
    