<template>
  <div class="notification-component">
    <!-- 通知铃铛图标 -->
    <el-badge :value="unreadCount" :hidden="unreadCount === 0" class="notification-badge">
      <el-button 
        icon="el-icon-bell" 
        circle 
        @click="toggleDrawer"
        class="notification-btn">
      </el-button>
    </el-badge>

    <!-- 通知抽屉 -->
    <el-drawer
      title="通知中心"
      :visible.sync="drawerVisible"
      direction="rtl"
      size="400px"
      :modal="true"
      :modal-append-to-body="true"
      :append-to-body="true"
      :before-close="handleClose">
      
      <div class="notification-drawer-content">
        <!-- 通知列表 -->
        <div v-if="notifications.length > 0" class="notification-list">
          <div 
            v-for="notification in notifications" 
            :key="notification.id"
            :class="['notification-item', { 'unread': !notification.isRead }]"
            @click="markAsRead(notification)">
            
            <div class="notification-header">
              <el-tag 
                :type="getNotificationType(notification.type)" 
                size="mini"
                class="notification-type-tag">
                {{ getTypeLabel(notification.type) }}
              </el-tag>
              <span class="notification-time">{{ formatTime(notification.addtime) }}</span>
            </div>
            
            <div class="notification-message">
              {{ notification.message }}
            </div>
            
            <div v-if="!notification.isRead" class="unread-indicator">
              <i class="el-icon-circle-check"></i> 点击标记为已读
            </div>
          </div>
        </div>

        <!-- 空状态 -->
        <div v-else class="empty-notifications">
          <i class="el-icon-bell"></i>
          <p>暂无通知</p>
        </div>

        <!-- 加载更多 -->
        <div v-if="hasMore" class="load-more">
          <el-button 
            type="text" 
            @click="loadMore"
            :loading="loading">
            加载更多
          </el-button>
        </div>
      </div>
    </el-drawer>
  </div>
</template>

<script>
export default {
  name: 'Notification',
  data() {
    return {
      drawerVisible: false,
      notifications: [],
      unreadCount: 0,
      currentPage: 1,
      pageSize: 10,
      total: 0,
      loading: false,
      pollingTimer: null
    }
  },
  computed: {
    hasMore() {
      return this.notifications.length < this.total;
    }
  },
  created() {
    // 如果用户已登录，开始轮询
    if (localStorage.getItem('Token')) {
      this.getUnreadCount();
      this.startPolling();
    }
  },
  beforeDestroy() {
    this.stopPolling();
  },
  methods: {
    toggleDrawer() {
      this.drawerVisible = !this.drawerVisible;
      if (this.drawerVisible && this.notifications.length === 0) {
        this.getNotifications();
      }
    },
    
    handleClose() {
      this.drawerVisible = false;
    },
    
    // 获取未读通知数量
    getUnreadCount() {
      this.$http({
        url: 'notification/unread-count',
        method: 'get',
        params: {
          userId: localStorage.getItem('userid')
        }
      }).then(({data}) => {
        if (data && data.code === 0) {
          this.unreadCount = data.data || 0;
        }
      }).catch(() => {
        // 静默失败，不影响用户体验
      });
    },
    
    // 获取通知列表
    getNotifications() {
      this.loading = true;
      this.$http({
        url: 'notification/list',
        method: 'get',
        params: {
          page: this.currentPage,
          limit: this.pageSize,
          userId: localStorage.getItem('userid'),
          sort: 'addtime',
          order: 'desc'
        }
      }).then(({data}) => {
        this.loading = false;
        if (data && data.code === 0) {
          if (this.currentPage === 1) {
            this.notifications = data.data.list || [];
          } else {
            this.notifications = [...this.notifications, ...(data.data.list || [])];
          }
          this.total = data.data.total || 0;
        }
      }).catch(() => {
        this.loading = false;
        this.$message.error('获取通知失败');
      });
    },
    
    // 标记为已读
    markAsRead(notification) {
      if (notification.isRead) return;
      
      this.$http({
        url: `notification/mark-read/${notification.id}`,
        method: 'post'
      }).then(({data}) => {
        if (data && data.code === 0) {
          notification.isRead = true;
          this.unreadCount = Math.max(0, this.unreadCount - 1);
        }
      }).catch(() => {
        // 静默失败
      });
    },
    
    // 加载更多
    loadMore() {
      this.currentPage++;
      this.getNotifications();
    },
    
    // 开始轮询
    startPolling() {
      this.pollingTimer = setInterval(() => {
        this.getUnreadCount();
      }, 30000); // 每30秒轮询一次
    },
    
    // 停止轮询
    stopPolling() {
      if (this.pollingTimer) {
        clearInterval(this.pollingTimer);
        this.pollingTimer = null;
      }
    },
    
    // 格式化时间
    formatTime(time) {
      if (!time) return '';
      const date = new Date(time);
      const now = new Date();
      const diff = now - date;
      
      // 小于1分钟
      if (diff < 60000) {
        return '刚刚';
      }
      // 小于1小时
      if (diff < 3600000) {
        return Math.floor(diff / 60000) + '分钟前';
      }
      // 小于24小时
      if (diff < 86400000) {
        return Math.floor(diff / 3600000) + '小时前';
      }
      // 小于7天
      if (diff < 604800000) {
        return Math.floor(diff / 86400000) + '天前';
      }
      // 超过7天显示具体日期
      return time.replace('T', ' ').substring(0, 16);
    },
    
    // 获取通知类型
    getNotificationType(type) {
      const typeMap = {
        'cancellation': 'warning',
        'approval': 'success',
        'rejection': 'danger',
        'reminder': 'info'
      };
      return typeMap[type] || 'info';
    },
    
    // 获取类型标签
    getTypeLabel(type) {
      const labelMap = {
        'cancellation': '取消通知',
        'approval': '审批通过',
        'rejection': '审批拒绝',
        'reminder': '提醒'
      };
      return labelMap[type] || '通知';
    }
  }
}
</script>

<style scoped>
.notification-component {
  display: inline-block;
}

.notification-badge {
  cursor: pointer;
}

.notification-btn {
  background: #fff;
  border-color: #dcdfe6;
  color: #606266;
  transition: all 0.3s ease;
}

.notification-btn:hover {
  background: #ecf5ff;
  border-color: #4A90E2;
  color: #4A90E2;
}

/* 抽屉内容 */
.notification-drawer-content {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.notification-list {
  flex: 1;
  overflow-y: auto;
  padding: 0 20px;
}

.notification-item {
  padding: 15px;
  margin-bottom: 10px;
  background: #f5f7fa;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
  border-left: 3px solid transparent;
}

.notification-item:hover {
  background: #ecf5ff;
  transform: translateX(5px);
}

.notification-item.unread {
  background: #fff;
  border-left-color: #4A90E2;
  box-shadow: 0 2px 8px rgba(74, 144, 226, 0.1);
}

.notification-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.notification-type-tag {
  font-size: 12px;
}

.notification-time {
  font-size: 12px;
  color: #909399;
}

.notification-message {
  font-size: 14px;
  color: #606266;
  line-height: 1.6;
  margin-bottom: 8px;
}

.unread-indicator {
  font-size: 12px;
  color: #4A90E2;
  display: flex;
  align-items: center;
}

.unread-indicator i {
  margin-right: 4px;
}

/* 空状态 */
.empty-notifications {
  text-align: center;
  padding: 60px 20px;
  color: #909399;
}

.empty-notifications i {
  font-size: 64px;
  color: #c0c4cc;
  margin-bottom: 20px;
}

.empty-notifications p {
  font-size: 16px;
}

/* 加载更多 */
.load-more {
  text-align: center;
  padding: 15px;
  border-top: 1px solid #ebeef5;
}

/* 抽屉标题样式 */
::v-deep .el-drawer__header {
  padding: 20px;
  margin-bottom: 0;
  background: linear-gradient(135deg, #4A90E2 0%, #6aa8e6 100%);
  color: #fff;
}

::v-deep .el-drawer__title {
  color: #fff;
  font-size: 18px;
  font-weight: 500;
}

::v-deep .el-drawer__close-btn {
  color: #fff;
  font-size: 20px;
}

::v-deep .el-drawer__body {
  padding: 20px 0;
}

/* 徽章样式 */
::v-deep .el-badge__content {
  background-color: #f56c6c;
  border: 2px solid #fff;
}

/* 滚动条样式 */
.notification-list::-webkit-scrollbar {
  width: 6px;
}

.notification-list::-webkit-scrollbar-thumb {
  background-color: #dcdfe6;
  border-radius: 3px;
}

.notification-list::-webkit-scrollbar-thumb:hover {
  background-color: #c0c4cc;
}

/* 修复遮罩层样式 */
::v-deep .el-drawer__wrapper {
  z-index: 2000 !important;
}

::v-deep .v-modal {
  z-index: 1999 !important;
}

::v-deep .el-drawer {
  z-index: 2001 !important;
}
</style>
