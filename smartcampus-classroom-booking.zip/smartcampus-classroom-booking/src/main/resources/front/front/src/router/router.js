import VueRouter from 'vue-router'

//引入组件
import Index from '../pages'
import Home from '../pages/home/home'
import Login from '../pages/login/login'
import Register from '../pages/register/register'
import Center from '../pages/center/center'
import Storeup from '../pages/storeup/list'
import AddrList from '../pages/shop-address/list'
import AddrAdd from '../pages/shop-address/addOrUpdate'
import Order from '../pages/shop-order/list'
import OrderConfirm from '../pages/shop-order/confirm'
import Cart from '../pages/shop-cart/list'
import News from '../pages/news/news-list'
import NewsDetail from '../pages/news/news-detail'
import usersList from '../pages/users/list'
import usersDetail from '../pages/users/detail'
import usersAdd from '../pages/users/add'
import noticetypeList from '../pages/noticetype/list'
import noticetypeDetail from '../pages/noticetype/detail'
import noticetypeAdd from '../pages/noticetype/add'
import librarynoticeList from '../pages/librarynotice/list'
import librarynoticeDetail from '../pages/librarynotice/detail'
import librarynoticeAdd from '../pages/librarynotice/add'
import libseattypeList from '../pages/libseattype/list'
import libseattypeDetail from '../pages/libseattype/detail'
import libseattypeAdd from '../pages/libseattype/add'
import libseatinfoList from '../pages/libseatinfo/list'
import libseatinfoDetail from '../pages/libseatinfo/detail'
import libseatinfoAdd from '../pages/libseatinfo/add'
import classroomReservationList from '../pages/classroom-reservation/list'
import myClassroomReservations from '../pages/classroom-reservation/my-reservations'

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
	return originalPush.call(this, location).catch(err => err)
}

//配置路由
export default new VueRouter({
	routes:[
		{
      path: '/',
      redirect: '/index/home'
    },
		{
			path: '/index',
			component: Index,
			children:[
				{
					path: 'home',
					component: Home
				},
				{
					path: 'center',
					component: Center,
				},
				{
					path: 'storeup',
					component: Storeup
				},
                {
                    path: 'shop-address/list',
                    component: AddrList
                },
                {
                    path: 'shop-address/addOrUpdate',
                    component: AddrAdd
                },
				{
					path: 'shop-order/order',
					component: Order
				},
				{
					path: 'cart',
					component: Cart
				},
				{
					path: 'shop-order/orderConfirm',
					component: OrderConfirm
				},
				{
					path: 'news',
					component: News
				},
				{
					path: 'newsDetail',
					component: NewsDetail
				},
				{
					path: 'users',
					component: usersList
				},
				{
					path: 'usersDetail',
					component: usersDetail
				},
				{
					path: 'usersAdd',
					component: usersAdd
				},
				{
					path: 'noticetype',
					component: noticetypeList
				},
				{
					path: 'noticetypeDetail',
					component: noticetypeDetail
				},
				{
					path: 'noticetypeAdd',
					component: noticetypeAdd
				},
				{
					path: 'librarynotice',
					component: librarynoticeList
				},
				{
					path: 'librarynoticeDetail',
					component: librarynoticeDetail
				},
				{
					path: 'librarynoticeAdd',
					component: librarynoticeAdd
				},
				{
					path: 'libseattype',
					component: libseattypeList
				},
				{
					path: 'libseattypeDetail',
					component: libseattypeDetail
				},
				{
					path: 'libseattypeAdd',
					component: libseattypeAdd
				},
				{
					path: 'libseatinfo',
					component: libseatinfoList
				},
				{
					path: 'libseatinfoDetail',
					component: libseatinfoDetail
				},
				{
					path: 'libseatinfoAdd',
					component: libseatinfoAdd
				},
				{
					path: 'classroom-reservation',
					component: classroomReservationList
				},
				{
					path: 'my-classroom-reservations',
					component: myClassroomReservations
				},
			]
		},
		{
			path: '/login',
			component: Login
		},
		{
			path: '/register',
			component: Register
		},
	]
})
