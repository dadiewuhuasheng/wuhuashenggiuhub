/**
 * 加载状态混入
 * 提供统一的加载状态管理
 */
export default {
  data() {
    return {
      loading: false,
      loadingText: '加载中...'
    }
  },
  methods: {
    /**
     * 开始加载
     * @param {String} text - 加载提示文本
     */
    startLoading(text = '加载中...') {
      this.loading = true
      this.loadingText = text
    },

    /**
     * 结束加载
     */
    stopLoading() {
      this.loading = false
    },

    /**
     * 执行异步操作并管理加载状态
     * @param {Function} asyncFn - 异步函数
     * @param {String} loadingText - 加载提示文本
     * @returns {Promise} 异步操作结果
     */
    async withLoading(asyncFn, loadingText = '加载中...') {
      this.startLoading(loadingText)
      try {
        const result = await asyncFn()
        return result
      } finally {
        this.stopLoading()
      }
    }
  }
}
