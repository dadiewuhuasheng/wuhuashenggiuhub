<template>
  <div class="classroom-reservation-container">
    <div class="breadcrumb-preview">
      <el-breadcrumb separator="Ξ">
        <el-breadcrumb-item>首页</el-breadcrumb-item>
        <el-breadcrumb-item>教室预约</el-breadcrumb-item>
      </el-breadcrumb>
    </div>

    <div class="classroom-list">
      <el-card v-for="classroom in classrooms" :key="classroom.id" class="classroom-card">
        <div class="classroom-info">
          <el-image 
            v-if="classroom.libseatpicture" 
            :src="baseUrl + classroom.libseatpicture.split(',')[0]" 
            fit="cover"
            class="classroom-image">
          </el-image>
          <div class="classroom-details">
            <h3 class="classroom-name">{{ classroom.libseatmingcheng }}</h3>
            <p class="classroom-attr"><span class="label">类型：</span>{{ classroom.libseattype }}</p>
            <p class="classroom-attr"><span class="label">位置：</span>{{ classroom.libseataddress }}</p>
            <p class="classroom-attr"><span class="label">座位数：</span>{{ classroom.number }}</p>
            <el-button 
              v-if="userRole === 'teacher'" 
              type="primary" 
              size="small" 
              @click="showReservationDialog(classroom)"
              class="reserve-btn">
              预约教室
            </el-button>
            <el-tag v-else type="info" size="small">仅教师可预约</el-tag>
          </div>
        </div>
      </el-card>
    </div>

    <!-- 教室预约对话框 -->
    <el-dialog title="预约教室" :visible.sync="dialogVisible" width="600px">
      <el-form :model="reservationForm" :rules="reservationRules" ref="reservationForm" label-width="100px">
        <el-form-item label="教室名称">
          <el-input v-model="reservationForm.classroomName" disabled></el-input>
        </el-form-item>
        
        <el-form-item label="开始时间" prop="startTime">
          <el-date-picker
            v-model="reservationForm.startTime"
            type="datetime"
            placeholder="选择开始时间"
            format="yyyy-MM-dd HH:mm:ss"
            value-format="yyyy-MM-dd HH:mm:ss"
            :picker-options="startTimeOptions"
            style="width: 100%;">
          </el-date-picker>
        </el-form-item>
        
        <el-form-item label="结束时间" prop="endTime">
          <el-date-picker
            v-model="reservationForm.endTime"
            type="datetime"
            placeholder="选择结束时间"
            format="yyyy-MM-dd HH:mm:ss"
            value-format="yyyy-MM-dd HH:mm:ss"
            :picker-options="endTimeOptions"
            style="width: 100%;">
          </el-date-picker>
        </el-form-item>
        
        <el-form-item label="使用目的" prop="purpose">
          <el-input
            v-model="reservationForm.purpose"
            type="textarea"
            :rows="4"
            placeholder="请输入使用目的（如：课程教学、学术讲座、会议等）"
            maxlength="500"
            show-word-limit>
          </el-input>
        </el-form-item>
      </el-form>
      
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitReservation" :loading="submitting">确定预约</el-button>
      </div>
    </el-dialog>

    <!-- 分页 -->
    <el-pagination
      v-if="total > 0"
      background
      class="pagination"
      :current-page="currentPage"
      :page-size="pageSize"
      :total="total"
      layout="total, prev, pager, next, jumper"
      @current-change="handlePageChange">
    </el-pagination>
  </div>
</template>

<script>
export default {
  data() {
    return {
      baseUrl: this.$config.baseUrl,
      classrooms: [],
      currentPage: 1,
      pageSize: 12,
      total: 0,
      userRole: '',
      dialogVisible: false,
      submitting: false,
      reservationForm: {
        classroomId: null,
        classroomName: '',
        startTime: '',
        endTime: '',
        purpose: ''
      },
      reservationRules: {
        startTime: [
          { required: true, message: '请选择开始时间', trigger: 'change' }
        ],
        endTime: [
          { required: true, message: '请选择结束时间', trigger: 'change' }
        ],
        purpose: [
          { required: true, message: '请输入使用目的', trigger: 'blur' },
          { min: 5, max: 500, message: '使用目的长度在5到500个字符之间', trigger: 'blur' }
        ]
      },
      startTimeOptions: {
        disabledDate(time) {
          return time.getTime() < Date.now() - 8.64e7;
        }
      },
      endTimeOptions: {
        disabledDate(time) {
          return time.getTime() < Date.now() - 8.64e7;
        }
      }
    }
  },
  created() {
    // Get user role from session storage
    this.userRole = sessionStorage.getItem('role') || localStorage.getItem('userRole') || '';
    this.getClassrooms();
  },
  methods: {
    getClassrooms() {
      this.$http({
        url: 'libseatinfo/list',
        method: 'get',
        params: {
          page: this.currentPage,
          limit: this.pageSize
        }
      }).then(({data}) => {
        if (data && data.code === 0) {
          this.classrooms = data.data.list;
          this.total = data.data.total;
        }
      }).catch(() => {
        this.$message.error('获取教室列表失败');
      });
    },
    
    showReservationDialog(classroom) {
      this.reservationForm.classroomId = classroom.id;
      this.reservationForm.classroomName = classroom.libseatmingcheng;
      this.reservationForm.startTime = '';
      this.reservationForm.endTime = '';
      this.reservationForm.purpose = '';
      this.dialogVisible = true;
      
      // 重置表单验证
      this.$nextTick(() => {
        if (this.$refs.reservationForm) {
          this.$refs.reservationForm.clearValidate();
        }
      });
    },
    
    submitReservation() {
      this.$refs.reservationForm.validate((valid) => {
        if (valid) {
          // 验证时间范围
          const startTime = new Date(this.reservationForm.startTime);
          const endTime = new Date(this.reservationForm.endTime);
          
          if (startTime >= endTime) {
            this.$message.error('结束时间必须晚于开始时间');
            return;
          }
          
          if (startTime < new Date()) {
            this.$message.error('开始时间不能早于当前时间');
            return;
          }
          
          // 提交预约
          this.submitting = true;
          const reservationData = {
            classroomId: this.reservationForm.classroomId,
            classroomName: this.reservationForm.classroomName,
            startTime: this.reservationForm.startTime,
            endTime: this.reservationForm.endTime,
            purpose: this.reservationForm.purpose
          };
          
          this.$http({
            url: 'classroomreservation/create',
            method: 'post',
            body: JSON.stringify(reservationData),
            headers: {
              'Content-Type': 'application/json'
            }
          }).then(({data}) => {
            this.submitting = false;
            if (data && data.code === 0) {
              this.$message.success('预约成功！');
              this.dialogVisible = false;
              // 可以跳转到我的预约页面
              this.$router.push('/index/my-classroom-reservations');
            } else {
              this.$message.error(data.msg || '预约失败，请重试');
            }
          }).catch((error) => {
            this.submitting = false;
            this.$message.error('预约失败，请重试');
          });
        }
      });
    },
    
    handlePageChange(page) {
      this.currentPage = page;
      this.getClassrooms();
    }
  }
}
</script>

<style scoped>
.classroom-reservation-container {
  padding: 20px;
  background: #f5f7fa;
  min-height: 100vh;
}

.breadcrumb-preview {
  padding: 0px 20px;
  margin: 0 0 20px;
  background: #4A90E2;
  display: flex;
  width: 100%;
  justify-content: space-between;
  height: 40px;
  box-shadow: 0 2px 10px rgba(74, 144, 226, 0.15);
  border-radius: 6px;
}

.breadcrumb-preview .el-breadcrumb {
  font-size: 14px;
  line-height: 40px;
}

.breadcrumb-preview ::v-deep .el-breadcrumb__separator {
  margin: 0 9px;
  color: #fff;
  font-weight: 500;
}

.breadcrumb-preview ::v-deep .el-breadcrumb__inner {
  color: #fff;
}

.classroom-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
}

.classroom-card {
  border-radius: 12px;
  overflow: hidden;
  transition: all 0.3s ease;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
}

.classroom-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 4px 20px rgba(74, 144, 226, 0.2);
}

.classroom-info {
  display: flex;
  flex-direction: column;
}

.classroom-image {
  width: 100%;
  height: 200px;
  object-fit: cover;
  border-radius: 8px 8px 0 0;
}

.classroom-details {
  padding: 15px;
}

.classroom-name {
  font-size: 18px;
  font-weight: 600;
  color: #333;
  margin: 0 0 10px 0;
}

.classroom-attr {
  font-size: 14px;
  color: #666;
  margin: 5px 0;
  line-height: 1.6;
}

.classroom-attr .label {
  color: #999;
  font-weight: 500;
}

.reserve-btn {
  margin-top: 15px;
  width: 100%;
  background: #4A90E2;
  border-color: #4A90E2;
  transition: all 0.3s ease;
}

.reserve-btn:hover {
  background: #3a80d2;
  box-shadow: 0 2px 8px rgba(74, 144, 226, 0.3);
}

/* 对话框样式 */
::v-deep .el-dialog {
  border-radius: 12px;
  box-shadow: 0 5px 20px rgba(74, 144, 226, 0.2);
}

::v-deep .el-dialog__header {
  background: linear-gradient(135deg, #4A90E2 0%, #6aa8e6 100%);
  border-radius: 12px 12px 0 0;
  padding: 20px;
}

::v-deep .el-dialog__title {
  color: #fff;
  font-size: 18px;
  font-weight: 500;
}

::v-deep .el-dialog__headerbtn .el-dialog__close {
  color: #fff;
  font-size: 20px;
}

::v-deep .el-dialog__body {
  padding: 30px 20px;
}

::v-deep .el-form-item__label {
  color: #666;
  font-weight: 500;
}

::v-deep .el-input__inner,
::v-deep .el-textarea__inner {
  border: 1px solid #b8daff;
  border-radius: 6px;
  transition: all 0.3s ease;
}

::v-deep .el-input__inner:focus,
::v-deep .el-textarea__inner:focus {
  border-color: #4A90E2;
  box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.1);
}

.dialog-footer {
  text-align: right;
}

.dialog-footer .el-button {
  padding: 10px 20px;
  border-radius: 6px;
  transition: all 0.3s ease;
}

.dialog-footer .el-button--primary {
  background: #4A90E2;
  border-color: #4A90E2;
}

.dialog-footer .el-button--primary:hover {
  background: #3a80d2;
  box-shadow: 0 2px 8px rgba(74, 144, 226, 0.3);
}

/* 分页样式 */
.pagination {
  padding: 20px;
  margin: 20px 0;
  text-align: center;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

::v-deep .el-pagination.is-background .el-pager li:not(.disabled).active {
  background-color: #4A90E2;
}

::v-deep .el-pagination.is-background .el-pager li:hover {
  color: #4A90E2;
}
</style>
