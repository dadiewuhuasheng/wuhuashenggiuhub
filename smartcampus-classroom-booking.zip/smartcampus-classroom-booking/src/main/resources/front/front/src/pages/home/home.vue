<template>
	<div class="home-preview">
		<div class="recommend">
			<div v-if="false" class="idea recommendIdea">
				<div class="box1"></div>
				<div class="box2"></div>
				<div class="box3"></div>
				<div class="box4"></div>
				<div class="box5"></div>
				<div class="box6"></div>
				<div class="box7"></div>
				<div class="box8"></div>
				<div class="box9"></div>
				<div class="box10"></div>
			</div>
			
			<div class="title">
				<span>座位预约推荐</span>
			</div>
			
			<!-- 座位推荐列表 -->
			<div class="list list1 index-pv1">
				<div @click="toDetail('libseatinfoDetail', item)" class="list-item animation-box" v-for="(item,index) in libseatinfoRecommend" :key="index">
					<img v-if="preHttp(item.libseatpicture)" :src="item.libseatpicture.split(',')[0]" alt="座位图片" />
					<img v-else :src="baseUrl + (item.libseatpicture?item.libseatpicture.split(',')[0]:'')" alt="座位图片" />
					<div class="name line1">座位名称:{{item.libseatmingcheng}}</div>
					<div class="name line1">座位类型:{{item.libseattype}}</div>
				</div>
			</div>
			
			<div @click="moreBtn('libseatinfo')" class="more-btn">
				<span>查看更多</span>
				<i v-if="true" class="el-icon-d-arrow-right"></i>
			</div>
		</div>
	
		<!-- 系统简介 -->
		<div class="system-intro">
			<div class="section-title">{{systemIntroductionDetail.title}}</div>
			<div class="section-subtitle" v-if="false">{{systemIntroductionDetail.subtitle}}</div>
			<div class="intro-content">
				<img class="main-img" :src="baseUrl + systemIntroductionDetail.picture1" alt="系统介绍主图">
				<div class="intro-text" v-html="systemIntroductionDetail.content"></div>
				<div class="secondary-images">
					<img :src="baseUrl + systemIntroductionDetail.picture2" alt="系统介绍图片2">
					<img :src="baseUrl + systemIntroductionDetail.picture3" alt="系统介绍图片3">
				</div>
			</div>
		</div>
	
		<div class="lists">
			<div v-if="false" class="idea">
				<div class="box1"></div>
				<div class="box2"></div>
				<div class="box3"></div>
				<div class="box4"></div>
				<div class="box5"></div>
				<div class="box6"></div>
				<div class="box7"></div>
				<div class="box8"></div>
				<div class="box9"></div>
				<div class="box10"></div>
			</div>
			
			<div class="title">
				<span>教室资讯展示</span>
			</div>
			
			<!-- 资讯轮播 -->
			<div class="list list5 index-pv1">
				<div id="lists-five-swiperlibrarynotice" class="swiper-container lists-five-swiper">
					<div class="swiper-wrapper">
						<div class="swiper-slide" v-for="(item,index) in librarynoticeList" :key="index" @click="toDetail('librarynoticeDetail', item)">
							<img v-if="preHttp(item.picture)" :src="item.picture.split(',')[0]" alt="资讯图片" />
							<img v-else :src="baseUrl + (item.picture?item.picture.split(',')[0]:'')" alt="资讯图片" />
						</div>
					</div>
					<!-- 轮播箭头 -->
					<div class="swiper-button-next"></div>
					<div class="swiper-button-prev"></div>
				</div>
			</div>
			
			<div @click="moreBtn('librarynotice')" class="more-btn">
				<span>查看更多</span>
				<i v-if="true" class="el-icon-d-arrow-right"></i>
			</div>
		</div>
	
		<!-- 关于我们 -->
		<div class="about-us">
			<div class="section-title">{{aboutUsDetail.title}}</div>
			<div class="section-subtitle">{{aboutUsDetail.subtitle}}</div>
			<div class="about-content">
				<div class="about-text" v-html="aboutUsDetail.content"></div>
				<img class="about-img" :src="baseUrl + aboutUsDetail.picture1" alt="关于我们图片">
			</div>
		</div>
		
		<div class="news">
			<div v-if="false" class="idea newsIdea">
				<div class="box1"></div>
				<div class="box2"></div>
				<div class="box3"></div>
				<div class="box4"></div>
				<div class="box5"></div>
				<div class="box6"></div>
				<div class="box7"></div>
				<div class="box8"></div>
				<div class="box9"></div>
				<div class="box10"></div>
			</div>
			
			<div class="title">
				<span>公告信息</span>
			</div>
			
			<!-- 公告列表 -->
			<div v-if="newsList.length" class="list list10 index-pv1">
				<div v-if="newsList.length>0" @click="toDetail('newsDetail', newsList[0])" class="new10-list-item animation-box main-news">
					<img :src="baseUrl + newsList[0].picture" alt="新闻图片">
					<div class="new9-list-item-title line1">{{newsList[0].title}}</div>
					<div class="new9-list-item-time">{{newsList[0].addtime.split(' ')[0]}}</div>
					<div class="new9-list-item-descript line2">{{newsList[0].introduction}}</div>
					<div class="new9-list-item-identification">公告</div>
				</div>
				<div v-if="newsList.length>1" class="news-side">
					<div v-for="(item,index) in newsList" v-if="index<4 && index>0" :key="index" @click="toDetail('newsDetail', item)" class="new10-list-item animation-box sub-news">
						<div class="new9-list-item-title line1">{{ item.title }}</div>
						<div class="new9-list-item-time">{{ item.addtime.split(' ')[0] }}</div>
						<div class="new9-list-item-descript line2">{{ item.introduction }}</div>
						<div class="new9-list-item-identification">公告</div>
					</div>
				</div>
			</div>
			
			<div @click="moreBtn('news')" class="more-btn">
				<span>查看更多</span>
				<i v-if="true" class="el-icon-d-arrow-right"></i>
			</div>
		</div>
	</div>
	</template>
	
	<script>
	  export default {
		//数据集合
		data() {
		  return {
			baseUrl: '',
			aboutUsDetail: {},
			systemIntroductionDetail: {},
			newsList: [],
			libseatinfoRecommend: [],
			librarynoticeList: [],
		  }
		},
		created() {
		  this.baseUrl = this.$config.baseUrl;
		  this.getNewsList();
		  this.getAboutUs();
		  this.getSystemIntroduction();
		  this.getList();
		},
		//方法集合
		methods: {
		  preHttp(str) {
			  return str && str.substr(0,4)=='http';
		  },
		  getAboutUs() {
			  this.$http.get('aboutus/detail/1', {}).then(res => {
				if(res.data.code == 0) {
				  this.aboutUsDetail = res.data.data;
				}
			  })
		  },
		  getSystemIntroduction() {
			  this.$http.get('systemintro/detail/1', {}).then(res => {
				if(res.data.code == 0) {
				  this.systemIntroductionDetail = res.data.data;
				}
			  })
		  },
			getNewsList() {
				this.$http.get('news/list', {params: {
					page: 1,
					limit: 11,
					sort: 'addtime',
				order: 'desc'}}).then(res => {
					if (res.data.code == 0) {
						this.newsList = res.data.data.list;
					}
				});
			},
			getList() {
			  let autoSortUrl = "";
			  autoSortUrl = "libseatinfo/autoSort";
			  if(localStorage.getItem('Token')) {
				  autoSortUrl = "libseatinfo/autoSort2";
			  }
				this.$http.get(autoSortUrl, {params: {
					page: 1,
					limit: 4,
				}}).then(res => {
					if (res.data.code == 0) {
						this.libseatinfoRecommend = res.data.data.list;
					}
				});
				
				this.$http.get('librarynotice/list', {params: {
					page: 1,
					limit: 5,
				}}).then(res => {
					if (res.data.code == 0) {
						this.librarynoticeList = res.data.data.list;
						
						// 初始化轮播
						this.$nextTick(() => {
							new Swiper('#lists-five-swiperlibrarynotice', {
								loop: true,
								speed: 500,
								slidesPerView: Number(5),
								spaceBetween: Number(10),
								autoplay: {"delay":3000,"disableOnInteraction":false},
								centeredSlides: true,
								watchSlidesProgress: true,
								on: {
									setTranslate: function() {
										var slides = this.slides
										for (var i = 0; i < slides.length; i++) {
											var slide = slides.eq(i)
											var progress = slides[i].progress
											slide.css({
												'opacity': '',
												'background': ''
											});
											slide.transform(''); 
											slide.transform('scale(' + (1.5 - Math.abs(progress) / 4) + ')');
										}
									},
									setTransition: function(transition) {
										for (var i = 0; i < this.slides.length; i++) {
											var slide = this.slides.eq(i)
											slide.transition(transition);
										}
									},
								},
								navigation: {"nextEl":".swiper-button-next","prevEl":".swiper-button-prev"},
							});
						})
					}
				});
			},
			toDetail(path, item) {
				this.$router.push({path: '/index/' + path, query: {detailObj: JSON.stringify(item)}});
			},
			moreBtn(path) {
				this.$router.push({path: '/index/' + path});
			}
		}
	  }
	</script>
	
	<style scoped>
	/* 基础样式 */
	.home-preview {
		width: 100%;
		margin: 0px auto;
		display: flex;
		flex-wrap: wrap;
		justify-content: center;
		font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
	}
	
	/* 公共标题样式 */
	.title {
		width: 100%;
		margin: 30px auto 50px;
		line-height: 54px;
		text-align: center;
		background: linear-gradient(to right, transparent 30%, #87ceeb 50%, transparent 70%) bottom no-repeat;
		background-size: 100% 3px;
		padding-bottom: 10px;
	}
	
	.title span {
		color: #2980b9;
		font-size: 22px;
		padding: 0 4px 0 20px;
		line-height: 52px;
		font-weight: 500;
	}
	
	/* 查看更多按钮样式 */
	.more-btn {
		border: 1px solid #b8daff;
		padding: 0 20px;
		margin: 20px auto 40px;
		text-align: center;
		display: inline-block;
		min-width: 110px;
		background: #fff;
		width: auto;
		line-height: 40px;
		height: 40px;
		border-radius: 20px;
		cursor: pointer;
		transition: all 0.3s ease;
		box-shadow: 0 2px 5px rgba(52, 152, 219, 0.1);
	}
	
	.more-btn:hover {
		background: #e6f2ff;
		transform: translateY(-2px);
		box-shadow: 0 4px 8px rgba(52, 152, 219, 0.2);
	}
	
	.more-btn span {
		color: #2980b9;
		font-size: 14px;
	}
	
	.more-btn i {
		color: #2980b9;
		font-size: 14px;
		margin-left: 5px;
	}
	
	/* 座位推荐区域 */
	.recommend {
		width: 100%;
		margin: 0px auto;
		flex-wrap: wrap;
		background: #f8fcff;
		flex: 1;
		display: flex;
		justify-content: center;
		padding-bottom: 20px;
	}
	
	.recommend .list1 {
		width: 100%;
		padding: 0 7%;
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		height: auto;
	}
	
	.recommend .list-item {
		margin: 0 0 40px;
		border-radius: 8px;
		background: #fff;
		display: inline-block;
		width: 22%;
		position: relative;
		height: auto;
		overflow: hidden;
		box-shadow: 0 3px 10px rgba(52, 152, 219, 0.08);
		transition: all 0.3s ease;
	}
	
	.recommend .list-item:hover {
		transform: translateY(-5px);
		box-shadow: 0 8px 20px rgba(52, 152, 219, 0.15);
	}
	
	.recommend .list-item img {
		width: 100%;
		margin: 0 0 8px;
		object-fit: cover;
		display: block;
		height: 275px;
		transition: transform 0.5s ease;
	}
	
	.recommend .list-item:hover img {
		transform: scale(1.03);
	}
	
	.recommend .name {
		padding: 4px 10px;
		line-height: 24px;
		font-size: 16px;
		color: #2980b9;
		text-align: center;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}
	
	/* 系统简介区域 */
	.system-intro {
		padding: 40px 7% 60px;
		margin: 0px auto 0px;
		flex-wrap: wrap;
		background: linear-gradient(135deg, #e6f2ff 0%, #87ceeb 100%);
		display: flex;
		flex-direction: column;
		width: 100%;
		position: relative;
		height: auto;
		box-sizing: border-box;
	}
	
	.system-intro .section-title {
		min-height: 52px;
		margin: 0 auto 40px;
		color: #2980b9;
		text-align: center;
		background: linear-gradient(to right, transparent 30%, #2980b9 50%, transparent 70%) bottom no-repeat;
		background-size: 100% 3px;
		width: 100%;
		line-height: 72px;
		font-size: 22px;
		padding-bottom: 10px;
	}
	
	.system-intro .section-subtitle {
		margin: 0 0 20px;
		color: #666;
		text-align: center;
		display: block;
		width: 100%;
		line-height: 1;
		font-size: 16px;
	}
	
	.system-intro .intro-content {
		width: 100%;
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		position: relative;
	}
	
	.system-intro .main-img {
		width: 48%;
		margin: 0px;
		object-fit: cover;
		display: block;
		height: 360px;
		border-radius: 8px;
		box-shadow: 0 5px 15px rgba(52, 152, 219, 0.15);
	}
	
	.system-intro .intro-text {
		border: 1px solid #b8daff;
		padding: 20px;
		box-shadow: inset 0px 0px 30px rgba(52, 152, 219, 0.05);
		margin: 0;
		color: #333;
		text-indent: 2em;
		overflow: hidden;
		background: #fff;
		width: calc(43% - 0px);
		line-height: 2;
		font-size: 14px;
		position: absolute;
		right: 7%;
		top: 30px;
		height: 300px;
		border-radius: 8px;
	}
	
	.system-intro .secondary-images {
		width: 24%;
		margin: 208px 0px 0;
		display: flex;
		flex-direction: column;
		gap: 10px;
	}
	
	.system-intro .secondary-images img {
		width: 100%;
		object-fit: cover;
		display: block;
		height: 150px;
		border-radius: 8px;
		box-shadow: 0 3px 10px rgba(52, 152, 219, 0.1);
	}
	
	/* 资讯展示区域 */
	.lists {
		width: 100%;
		margin: 0px auto 0px;
		text-align: center;
		background: #f8fcff;
		display: block;
		padding-bottom: 20px;
	}
	
	.lists .list5 {
		width: 100%;
		padding: 0;
		margin: 0;
		background: none;
	}
	
	.lists .lists-five-swiper {
		width: 100%;
		padding: 20px 10px 60px;
		margin: 0;
		background: none;
	}
	
	.lists .swiper-slide {
		border: 0;
		cursor: pointer;
		border-radius: 8px;
		background: #fff;
		width: 320px !important;
		font-size: 0;
		position: relative;
		height: 240px;
		box-shadow: 0 3px 10px rgba(52, 152, 219, 0.1);
		transition: all 0.3s ease;
	}
	
	.lists .swiper-slide img {
		border: 4px solid #e6f2ff;
		width: 100%;
		border-radius: 8px;
		background: #fff;
		height: 100%;
		object-fit: cover;
	}
	
	.lists .swiper-button-prev,
	.lists .swiper-button-next {
		width: 45px;
		height: 45px;
		background: rgba(255, 255, 255, 0.8);
		border-radius: 50%;
		box-shadow: 0 2px 10px rgba(52, 152, 219, 0.2);
		transition: all 0.3s ease;
	}
	
	.lists .swiper-button-prev {
		left: 10px;
		right: auto;
	}
	
	.lists .swiper-button-next {
		left: auto;
		right: 10px;
	}
	
	.lists .swiper-button-prev::after,
	.lists .swiper-button-next::after {
		color: #2980b9;
		font-size: 20px;
	}
	
	.lists .swiper-button-prev:hover,
	.lists .swiper-button-next:hover {
		transform: scale(1.1);
		background: #fff;
	}
	
	/* 关于我们区域 */
	.about-us {
		padding: 40px 7% 80px;
		margin: 0px auto 0px;
		background: linear-gradient(135deg, #e6f2ff 0%, #87ceeb 100%);
		display: block;
		width: 100%;
		position: relative;
		height: auto;
		box-sizing: border-box;
	}
	
	.about-us .section-title {
		padding: 0 20px 10px;
		margin: 0 auto 10px;
		color: #2980b9;
		text-align: center;
		background: linear-gradient(to right, transparent 30%, #2980b9 50%, transparent 70%) bottom no-repeat;
		background-size: 100% 3px;
		width: auto;
		line-height: 80px;
		font-size: 22px;
		min-width: 180px;
	}
	
	.about-us .section-subtitle {
		margin: 0 0 20px;
		color: #666;
		text-align: center;
		display: block;
		width: 100%;
		line-height: 1;
		font-size: 16px;
	}
	
	.about-us .about-content {
		position: relative;
		width: 100%;
		height: 420px;
	}
	
	.about-us .about-text {
		padding: 20px;
		box-shadow: inset 0px 0px 30px rgba(52, 152, 219, 0.05);
		margin: 0;
		color: #333;
		text-indent: 2em;
		overflow: hidden;
		background: #fff;
		width: 32%;
		line-height: 24px;
		font-size: 14px;
		position: absolute;
		left: 7%;
		top: 80px;
		height: 236px;
		border-radius: 8px;
		border: 1px solid #b8daff;
	}
	
	.about-us .about-img {
		padding: 15px;
		margin: 0 10px;
		object-fit: cover;
		display: block;
		right: 7%;
		border-radius: 50%;
		top: 40px;
		background: #fff;
		width: 420px;
		position: absolute;
		height: 420px;
		box-shadow: 0 5px 20px rgba(52, 152, 219, 0.15);
		border: 1px solid #87ceeb;
	}
	
	/* 公告信息区域 */
	.news {
		width: 100%;
		margin: 0px auto 0px;
		flex-wrap: wrap;
		background: #f8fcff;
		display: flex;
		justify-content: center;
	}
	
	.news .list10 {
		padding: 10px 7%;
		flex-wrap: wrap;
		background: none;
		display: flex;
		width: 100%;
		justify-content: space-between;
		height: auto;
	}
	
	.news .main-news {
		width: 48%;
		margin: 0;
		position: relative;
		background: none;
		height: auto;
	}
	
	.news .main-news img {
		width: 100%;
		object-fit: cover;
		display: block;
		height: 300px;
		border-radius: 8px;
		box-shadow: 0 3px 10px rgba(52, 152, 219, 0.1);
		transition: all 0.3s ease;
	}
	
	.news .main-news:hover img {
		transform: scale(1.02);
	}
	
	.news .news-side {
		margin: 0 10px;
		background: none;
		flex-direction: column;
		display: block;
		width: 48%;
		position: relative;
		justify-content: space-between;
		height: auto;
	}
	
	.news .sub-news {
		width: 100%;
		position: relative;
		background: #fff;
		height: auto;
		padding: 15px;
		margin-bottom: 20px;
		border-radius: 8px;
		box-shadow: 0 3px 10px rgba(52, 152, 219, 0.08);
		transition: all 0.3s ease;
	}
	
	.news .sub-news:hover {
		transform: translateY(-3px);
		box-shadow: 0 5px 15px rgba(52, 152, 219, 0.15);
	}
	
	.news .new9-list-item-title {
		width: calc(100% - 80px);
		padding: 4px 20px;
		font-size: 16px;
		line-height: 28px;
		overflow: hidden;
		color: #2980b9;
		background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='%232980b9' stroke='%232980b9' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='10'%3E%3C/circle%3E%3Cpolyline points='12 6 12 12 16 14'%3E%3C/polyline%3E%3C/svg%3E") no-repeat 0px center;
	}
	
	.news .new9-list-item-time {
		font-size: 12px;
		line-height: 24px;
		position: absolute;
		right: 20px;
		color: #6da9d5;
		top: 19px;
	}
	
	.news .new9-list-item-descript {
		padding: 0 10px;
		overflow: hidden;
		color: #666;
		font-size: 14px;
		line-height: 24px;
		text-indent: 2em;
		height: 72px;
	}
	
	.news .new9-list-item-identification {
		padding: 0 10px;
		margin: 0 10px 10px;
		color: #fff;
		background: #6da9d5;
		display: inline-block;
		font-size: 12px;
		line-height: 24px;
		border-radius: 4px;
	}
	
	/* 动画效果 */
	.index-pv1 .animation-box {
		transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
	}
	
	/* 滚动动画 */
	@keyframes fadeInUp {
		from {
			opacity: 0;
			transform: translate3d(0, 30px, 0);
		}
		to {
			opacity: 1;
			transform: translate3d(0, 0, 0);
		}
	}
	
	.animation-box {
		animation: fadeInUp 0.6s ease forwards;
		opacity: 0;
	}
	
	.animation-box:nth-child(1) { animation-delay: 0.1s; }
	.animation-box:nth-child(2) { animation-delay: 0.2s; }
	.animation-box:nth-child(3) { animation-delay: 0.3s; }
	.animation-box:nth-child(4) { animation-delay: 0.4s; }
	.animation-box:nth-child(5) { animation-delay: 0.5s; }
	
	/* 响应式调整 */
	@media (max-width: 1200px) {
		.recommend .list-item {
			width: 30%;
		}
		
		.about-us .about-img {
			width: 350px;
			height: 350px;
		}
	}
	
	@media (max-width: 992px) {
		.recommend .list-item {
			width: 45%;
		}
		
		.system-intro .intro-text {
			position: static;
			width: 100%;
			height: auto;
			margin-top: 20px;
		}
		
		.system-intro .main-img,
		.system-intro .secondary-images {
			width: 100%;
			margin: 10px 0;
		}
		
		.about-us .about-text,
		.about-us .about-img {
			position: static;
			width: 100%;
			height: auto;
			margin: 10px 0;
		}
		
		.about-us .about-content {
			height: auto;
		}
		
		.news .main-news,
		.news .news-side {
			width: 100%;
			margin: 10px 0;
		}
	}
	
	@media (max-width: 768px) {
		.recommend .list-item {
			width: 100%;
		}
		
		.lists .swiper-button-prev,
		.lists .swiper-button-next {
			width: 35px;
			height: 35px;
		}
	}
	</style>
	