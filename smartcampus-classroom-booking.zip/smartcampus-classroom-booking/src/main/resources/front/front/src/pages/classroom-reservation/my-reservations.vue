<template>
  <div class="my-reservations-container">
    <div class="breadcrumb-preview">
      <el-breadcrumb separator="Ξ">
        <el-breadcrumb-item>首页</el-breadcrumb-item>
        <el-breadcrumb-item>我的教室预约</el-breadcrumb-item>
      </el-breadcrumb>
    </div>

    <div class="reservations-content">
      <el-table
        :data="reservations"
        style="width: 100%"
        stripe
        border
        :header-cell-style="{background:'#f5f7fa',color:'#606266'}">
        
        <el-table-column
          prop="classroomName"
          label="教室名称"
          width="180">
        </el-table-column>
        
        <el-table-column
          prop="startTime"
          label="开始时间"
          width="180">
          <template slot-scope="scope">
            {{ formatTime(scope.row.startTime) }}
          </template>
        </el-table-column>
        
        <el-table-column
          prop="endTime"
          label="结束时间"
          width="180">
          <template slot-scope="scope">
            {{ formatTime(scope.row.endTime) }}
          </template>
        </el-table-column>
        
        <el-table-column
          prop="purpose"
          label="使用目的"
          show-overflow-tooltip>
        </el-table-column>
        
        <el-table-column
          prop="status"
          label="状态"
          width="120">
          <template slot-scope="scope">
            <el-tag 
              :type="getStatusType(scope.row.status)" 
              size="small">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        
        <el-table-column
          prop="addtime"
          label="预约时间"
          width="180">
          <template slot-scope="scope">
            {{ formatTime(scope.row.addtime) }}
          </template>
        </el-table-column>
        
        <el-table-column
          label="操作"
          width="150"
          fixed="right">
          <template slot-scope="scope">
            <el-button
              v-if="scope.row.status === 'pending' || scope.row.status === 'approved'"
              type="danger"
              size="mini"
              @click="cancelReservation(scope.row)">
              取消预约
            </el-button>
            <el-button
              type="info"
              size="mini"
              @click="viewDetails(scope.row)">
              详情
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 空状态 -->
      <div v-if="reservations.length === 0" class="empty-state">
        <i class="el-icon-document"></i>
        <p>暂无教室预约记录</p>
        <el-button type="primary" size="small" @click="goToReserve">去预约教室</el-button>
      </div>

      <!-- 分页 -->
      <el-pagination
        v-if="total > 0"
        background
        class="pagination"
        :current-page="currentPage"
        :page-size="pageSize"
        :total="total"
        layout="total, prev, pager, next, jumper"
        @current-change="handlePageChange">
      </el-pagination>
    </div>

    <!-- 详情对话框 -->
    <el-dialog title="预约详情" :visible.sync="detailDialogVisible" width="600px">
      <div v-if="currentReservation" class="detail-content">
        <div class="detail-item">
          <span class="detail-label">教室名称：</span>
          <span class="detail-value">{{ currentReservation.classroomName }}</span>
        </div>
        <div class="detail-item">
          <span class="detail-label">开始时间：</span>
          <span class="detail-value">{{ formatTime(currentReservation.startTime) }}</span>
        </div>
        <div class="detail-item">
          <span class="detail-label">结束时间：</span>
          <span class="detail-value">{{ formatTime(currentReservation.endTime) }}</span>
        </div>
        <div class="detail-item">
          <span class="detail-label">使用目的：</span>
          <span class="detail-value">{{ currentReservation.purpose }}</span>
        </div>
        <div class="detail-item">
          <span class="detail-label">预约状态：</span>
          <el-tag :type="getStatusType(currentReservation.status)" size="small">
            {{ currentReservation.status }}
          </el-tag>
        </div>
        <div class="detail-item">
          <span class="detail-label">预约时间：</span>
          <span class="detail-value">{{ formatTime(currentReservation.addtime) }}</span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="detailDialogVisible = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      reservations: [],
      currentPage: 1,
      pageSize: 10,
      total: 0,
      detailDialogVisible: false,
      currentReservation: null
    }
  },
  created() {
    this.getMyReservations();
  },
  methods: {
    getMyReservations() {
      this.$http({
        url: 'classroomreservation/my-reservations',
        method: 'get',
        params: {
          page: this.currentPage,
          limit: this.pageSize
        }
      }).then(({data}) => {
        if (data && data.code === 0) {
          this.reservations = data.data.list || [];
          this.total = data.data.total || 0;
        }
      }).catch(() => {
        this.$message.error('获取预约列表失败');
      });
    },
    
    cancelReservation(reservation) {
      this.$confirm('确定要取消这个预约吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$http({
          url: `classroomreservation/cancel/${reservation.id}`,
          method: 'post'
        }).then(({data}) => {
          if (data && data.code === 0) {
            this.$message.success('取消成功');
            this.getMyReservations();
          } else {
            this.$message.error(data.msg || '取消失败');
          }
        }).catch(() => {
          this.$message.error('取消失败，请重试');
        });
      }).catch(() => {});
    },
    
    viewDetails(reservation) {
      this.currentReservation = reservation;
      this.detailDialogVisible = true;
    },
    
    goToReserve() {
      this.$router.push('/index/classroom-reservation');
    },
    
    handlePageChange(page) {
      this.currentPage = page;
      this.getMyReservations();
    },
    
    formatTime(time) {
      if (!time) return '-';
      return time.replace('T', ' ').substring(0, 19);
    },
    
    getStatusType(status) {
      const typeMap = {
        'pending': 'warning',
        'approved': 'success',
        'cancelled': 'info',
        'rejected': 'danger'
      };
      return typeMap[status] || 'info';
    }
  }
}
</script>

<style scoped>
.my-reservations-container {
  padding: 20px;
  background: #f5f7fa;
  min-height: 100vh;
}

.breadcrumb-preview {
  padding: 0px 20px;
  margin: 0 0 20px;
  background: #4A90E2;
  display: flex;
  width: 100%;
  justify-content: space-between;
  height: 40px;
  box-shadow: 0 2px 10px rgba(74, 144, 226, 0.15);
  border-radius: 6px;
}

.breadcrumb-preview .el-breadcrumb {
  font-size: 14px;
  line-height: 40px;
}

.breadcrumb-preview ::v-deep .el-breadcrumb__separator {
  margin: 0 9px;
  color: #fff;
  font-weight: 500;
}

.breadcrumb-preview ::v-deep .el-breadcrumb__inner {
  color: #fff;
}

.reservations-content {
  background: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
}

.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: #909399;
}

.empty-state i {
  font-size: 64px;
  color: #c0c4cc;
  margin-bottom: 20px;
}

.empty-state p {
  font-size: 16px;
  margin-bottom: 20px;
}

/* 详情对话框 */
::v-deep .el-dialog {
  border-radius: 12px;
}

::v-deep .el-dialog__header {
  background: linear-gradient(135deg, #4A90E2 0%, #6aa8e6 100%);
  border-radius: 12px 12px 0 0;
  padding: 20px;
}

::v-deep .el-dialog__title {
  color: #fff;
  font-size: 18px;
  font-weight: 500;
}

::v-deep .el-dialog__headerbtn .el-dialog__close {
  color: #fff;
  font-size: 20px;
}

.detail-content {
  padding: 10px 0;
}

.detail-item {
  padding: 12px 0;
  border-bottom: 1px solid #f0f0f0;
  display: flex;
  align-items: flex-start;
}

.detail-item:last-child {
  border-bottom: none;
}

.detail-label {
  width: 100px;
  color: #909399;
  font-weight: 500;
  flex-shrink: 0;
}

.detail-value {
  flex: 1;
  color: #606266;
  word-break: break-all;
}

/* 分页样式 */
.pagination {
  padding: 20px 0;
  text-align: center;
}

::v-deep .el-pagination.is-background .el-pager li:not(.disabled).active {
  background-color: #4A90E2;
}

::v-deep .el-pagination.is-background .el-pager li:hover {
  color: #4A90E2;
}

/* 表格样式优化 */
::v-deep .el-table {
  border-radius: 8px;
  overflow: hidden;
}

::v-deep .el-table th {
  font-weight: 600;
}

::v-deep .el-table .el-button--mini {
  padding: 5px 10px;
  border-radius: 4px;
}
</style>
