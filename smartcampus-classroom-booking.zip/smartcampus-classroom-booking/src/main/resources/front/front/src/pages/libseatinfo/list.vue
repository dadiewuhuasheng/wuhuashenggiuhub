<template>
	<div class="page-container">
		<div class="breadcrumb-preview">
			<el-breadcrumb separator="/" class="breadcrumb">
				<el-breadcrumb-item>首页</el-breadcrumb-item>
				<el-breadcrumb-item v-for="(item, index) in breadcrumbItem" :key="index">{{item.name}}</el-breadcrumb-item>
			</el-breadcrumb>
		</div>
		
		<div class="list-preview">
			<div class="category-1">
				<div class="item" :class="swiperIndex == '-1' ? 'active' : ''" @click="getList(1, '全部')" :plain="isPlain">全部</div>
				<div class="item" :class="swiperIndex == index ? 'active' : ''" v-for="(item, index) in fenlei" :key="index" @click="getList(1, item, 'btn' + index)" :ref="'btn' + index" plain>{{item}}</div>
			</div>
			
		
		<el-form :inline="true" :model="formSearch" class="list-form-pv">
		  <el-form-item class="form-item">
			<div class="lable" v-if="false">座位名称</div>
			<el-input v-model="formSearch.libseatmingcheng" placeholder="座位名称" clearable></el-input>
		  </el-form-item>
		  <el-form-item class="form-item">
			<div class="lable" v-if="false">座位类型</div>
			<el-select v-model="formSearch.libseattype" placeholder="请选择座位类型" :clearable="true">
			  <el-option v-for="(item, index) in libseattypeOptions" :key="index" :label="item" :value="item"></el-option>
			</el-select>
		  </el-form-item>
		  <el-form-item class="form-item">
			<div class="lable" v-if="false">价格</div>
			<el-input v-model="formSearch.pricestart" placeholder="最小价格" clearable></el-input>
		  </el-form-item>
		  <el-form-item class="form-item">
			<el-input v-model="formSearch.priceend" placeholder="最大价格" clearable></el-input>
		  </el-form-item>
		  <el-button v-if="true" class="search-btn" type="primary" @click="getList(1, curFenlei)">
			<i class="el-icon-search"></i>查询
		  </el-button>
		  <el-button v-if="isAuth('libseatinfo','新增')" class="add-btn" type="primary" @click="add('/index/libseatinfoAdd')">
			<i class="el-icon-circle-plus-outline"></i>添加
		  </el-button>
		</el-form>
	
		<div class="list">
			<!-- 样式一 -->
			<div class="list1 index-pv1">
				<div class="list-item animation-box" v-for="(item, index) in dataList" :key="index" @click="toDetail(item)">
					<img class="image" v-if="item.libseatpicture && item.libseatpicture.substr(0,4)=='http'" :src="item.libseatpicture" alt="座位图片" />
					<img class="image" v-else :src="baseUrl + (item.libseatpicture?item.libseatpicture.split(',')[0]:'')" alt="座位图片" />
					<div v-if="item.price" class="price"><span>￥</span>{{item.price}}</div>
					<div class="name">座位名称:{{item.libseatmingcheng}}</div>
					<div class="name">座位类型:{{item.libseattype}}</div>
				</div>
			</div>
			
			<!-- 样式二 -->
		</div>
	
		
		<el-pagination
		  background
		  class="pagination"
		  :pager-count="7"
		  :page-size="pageSize"
		  :page-sizes="pageSizes"
		  prev-text="<"
		  next-text=">"
		  :hide-on-single-page="true"
		  :layout='["total","prev","pager","next","sizes","jumper"].join()'
		  :total="total"
		  @current-change="curChange"
		  @size-change="sizeChange"
		  @prev-click="prevClick"
		  @next-click="nextClick"
		></el-pagination>
	
	  </div>
	</div>
	</template>
	
	<script>
	  export default {
		//数据集合
		data() {
		  return {
			layouts: '',
			swiperIndex: -1,
			baseUrl: '',
			breadcrumbItem: [
			  {
				name: '座位预约'
			  }
			],
			formSearch: {
			  libseatmingcheng: '',
			  libseattype: '',
			  price: '',
			},
			fenlei: [],
			dataList: [],
			total: 1,
			pageSize: 16,
			pageSizes: [10,20,30,50],
			totalPage: 1,
			curFenlei: '全部',
			isPlain: false,
			indexQueryCondition: '',
			  libseattypeOptions: [],
			timeRange: []
		  }
		},
		created() {
		  this.indexQueryCondition = this.$route.query.indexQueryCondition ? this.$route.query.indexQueryCondition : '';
		  this.baseUrl = this.$config.baseUrl;
		  this.$http.get('option/libseattype/libseattype').then(res => {
			if (res.data.code == 0) {
			  this.libseattypeOptions = res.data.data;
			}
		  });
		  this.getFenlei();
		  this.getList(1, '全部');
		},
		//方法集合
		methods: {
		  add(path) {
			this.$router.push({path: path});
		  },
		  getFenlei() {
			this.$http.get('option/libseattype/libseattype').then(res => {
			  if (res.data.code == 0) {
				this.fenlei = res.data.data;
			  }
			});
		  },
		  getList(page, fenlei, ref = '') {
			if(fenlei == '全部') this.swiperIndex = -1;
			for(let i=0;i<this.fenlei.length;i++) {
				if(fenlei == this.fenlei[i]) {
					this.swiperIndex = i;
					break;
				}
			}
			this.curFenlei = fenlei;
			if (this.curFenlei == '全部') {
			  this.isPlain = false;
			} else {
			  this.isPlain = true;
			}
			let params = {page, limit: this.pageSize};
			let searchWhere = {};
			if (this.formSearch.libseatmingcheng != '') searchWhere.libseatmingcheng = '%' + this.formSearch.libseatmingcheng + '%';
			if (this.formSearch.libseattype != '') searchWhere.libseattype = this.formSearch.libseattype;
			if(this.formSearch.pricestart!='' && this.formSearch.pricestart!=undefined ){
			  searchWhere.pricestart = this.formSearch.pricestart
			}
			if(this.formSearch.priceend!='' && this.formSearch.priceend!=undefined){
			  searchWhere.priceend = this.formSearch.priceend
			}
			if (this.curFenlei != '全部') searchWhere.libseattype = this.curFenlei;
			this.$http.get('libseatinfo/list', {params: Object.assign(params, searchWhere)}).then(res => {
			  if (res.data.code == 0) {
				this.dataList = res.data.data.list;
				this.total = res.data.data.total;
				this.pageSize = res.data.data.pageSize;
				this.totalPage = res.data.data.totalPage;
				
				this.pageSizes = [this.pageSize, this.pageSize*2, this.pageSize*3, this.pageSize*5];
			  }
			});
		  },
		  curChange(page) {
			this.getList(page,this.curFenlei);
		  },
		  prevClick(page) {
			this.getList(page,this.curFenlei);
		  },
		  sizeChange(size){
			this.pageSize = size
			this.getList(1,this.curFenlei);
		  },
		  nextClick(page) {
			this.getList(page,this.curFenlei);
		  },
		  toDetail(item) {
			this.$router.push({path: '/index/libseatinfoDetail', query: {detailObj: JSON.stringify(item)}});
		  },
		}
	  }
	</script>
	
	<style scoped>
	.page-container {
	  background-color: #f7fafc;
	  min-height: 100vh;
	}
	
	.breadcrumb-preview {
	  padding: 0 20px;
	  margin: 10px auto;
	  background: #4A90E2;
	  display: flex;
	  width: 100%;
	  justify-content: space-between;
	  height: 40px;
	  box-shadow: 0 2px 10px rgba(74, 144, 226, 0.15);
	  transition: all 0.3s ease;
	}
	
	.breadcrumb {
	  font-size: 14px;
	  line-height: 40px;
	}
	
	.breadcrumb-preview .el-breadcrumb ::v-deep .el-breadcrumb__separator {
	  margin: 0 9px;
	  color: #fff;
	  font-weight: 500;
	}
	
	.breadcrumb-preview .el-breadcrumb ::v-deep .el-breadcrumb__inner a,
	.breadcrumb-preview .el-breadcrumb ::v-deep .el-breadcrumb__inner {
	  color: #fff;
	  display: inline-block;
	  transition: color 0.3s ease;
	}
	
	.breadcrumb-preview .el-breadcrumb ::v-deep .el-breadcrumb__inner a:hover {
	  color: #e3f2fd;
	  text-decoration: underline;
	}
	
	.list-preview {
	  width: 100%;
	  padding: 10px 7%;
	  margin: 0 auto;
	  position: relative;
	  background: none;
	}
	
	.category-1 {
	  border: 1px solid #b8daff;
	  padding: 20px;
	  box-shadow: inset 0 0 56px 0 rgba(184, 218, 255, 0.2);
	  flex-wrap: wrap;
	  background: #fff;
	  display: flex;
	  width: 100%;
	  height: auto;
	  border-radius: 8px;
	  margin-bottom: 20px;
	  transition: all 0.3s ease;
	}
	
	.category-1 .item {
	  cursor: pointer;
	  border: 2px solid #81C3FD;
	  padding: 0 15px;
	  margin: 0 8px 10px 0;
	  color: #4A6FA5;
	  font-size: 14px;
	  line-height: 36px;
	  border-radius: 4px;
	  background: linear-gradient(270deg, rgba(235, 245, 251, 1) 0%, rgba(245, 250, 255, 1) 50%, rgba(224, 242, 254, 1) 100%);
	  width: auto;
	  text-align: center;
	  min-width: 80px;
	  height: 40px;
	  transition: all 0.3s ease;
	}
	
	.category-1 .item:hover {
	  border-color: #4A90E2;
	  color: #293A80;
	  transform: translateY(-2px);
	  box-shadow: 0 4px 8px rgba(74, 144, 226, 0.1);
	}
	
	.category-1 .item.active {
	  border-color: #4A90E2;
	  color: #293A80;
	  background: linear-gradient(90deg, rgba(235, 245, 251, 1) 0%, rgba(224, 242, 254, 1) 50%, rgba(197, 225, 255, 1) 100%);
	  box-shadow: 0 4px 8px rgba(74, 144, 226, 0.15);
	}
	
	.list-form-pv {
	  padding: 30px 10px 0;
	  align-items: center;
	  flex-wrap: wrap;
	  background: none;
	  display: flex;
	  width: 100%;
	  height: auto;
	  margin-bottom: 20px;
	}
	
	.form-item {
	  align-items: center;
	  margin: 0 10px 10px 0;
	  display: flex;
	}
	
	.list-form-pv .el-input ::v-deep .el-input__inner {
	  border: 1px solid #b8daff;
	  border-radius: 4px;
	  padding: 0 10px;
	  box-shadow: inset 0 0 32px 0 rgba(184, 218, 255, 0.2);
	  margin: 0 3px;
	  outline: none;
	  color: #333;
	  width: 140px;
	  font-size: 14px;
	  line-height: 40px;
	  height: 40px;
	  transition: all 0.3s ease;
	}
	
	.list-form-pv .el-input ::v-deep .el-input__inner:focus {
	  border-color: #4A90E2;
	  box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.2);
	}
	
	.list-form-pv .el-select ::v-deep .el-input__inner {
	  border: 1px solid #b8daff;
	  border-radius: 4px;
	  padding: 0 10px;
	  box-shadow: inset 0 0 32px 0 rgba(184, 218, 255, 0.2);
	  margin: 0;
	  outline: none;
	  color: #333;
	  width: 140px;
	  font-size: 14px;
	  line-height: 40px;
	  height: 40px;
	  transition: all 0.3s ease;
	}
	
	.list-form-pv .el-select ::v-deep .el-input__inner:focus {
	  border-color: #4A90E2;
	  box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.2);
	}
	
	.search-btn {
	  cursor: pointer;
	  padding: 0 15px;
	  margin: 0 10px 10px 0;
	  border-color: #4A90E2;
	  color: #4A90E2;
	  outline: none;
	  border-radius: 4px;
	  background: #EBF5FB;
	  border-width: 1px;
	  width: auto;
	  font-size: 14px;
	  line-height: 40px;
	  height: 40px;
	  transition: all 0.3s ease;
	  display: inline-flex;
	  align-items: center;
	  justify-content: center;
	}
	
	.search-btn:hover {
	  background: #D6EAF8;
	  transform: translateY(-2px);
	  box-shadow: 0 4px 8px rgba(74, 144, 226, 0.15);
	}
	
	.search-btn i {
	  color: #4A90E2;
	  margin: 0 5px 0 0;
	  font-size: 14px;
	}
	
	.add-btn {
	  cursor: pointer;
	  padding: 0 15px;
	  margin: 0 10px 10px 0;
	  border-color: #3B7AED;
	  color: #3B7AED;
	  outline: none;
	  border-radius: 4px;
	  background: #E8F4FD;
	  border-width: 1px;
	  width: auto;
	  font-size: 14px;
	  line-height: 40px;
	  height: 40px;
	  transition: all 0.3s ease;
	  display: inline-flex;
	  align-items: center;
	  justify-content: center;
	}
	
	.add-btn:hover {
	  background: #D1E7FD;
	  transform: translateY(-2px);
	  box-shadow: 0 4px 8px rgba(59, 122, 237, 0.15);
	}
	
	.add-btn i {
	  color: #3B7AED;
	  margin: 0 5px 0 0;
	  font-size: 14px;
	}
	
	.list {
	  margin: 20px 0 10px;
	  background: none;
	}
	
	.list1.index-pv1 {
	  padding: 0 10px;
	  margin: 30px 0 0;
	  flex-wrap: wrap;
	  background: none;
	  display: flex;
	  width: 100%;
	  justify-content: space-between;
	  height: auto;
	}
	
	.list-item {
	  padding: 15px;
	  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
	  margin: 0 0 25px;
	  border-radius: 8px;
	  flex-wrap: wrap;
	  background: #fff;
	  display: flex;
	  width: 23.5%;
	  position: relative;
	  justify-content: space-between;
	  height: auto;
	  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
	  border: 1px solid #f0f0f0;
	  cursor: pointer;
	}
	
	@media (max-width: 1200px) {
	  .list-item {
		width: 31.5%;
	  }
	}
	
	@media (max-width: 768px) {
	  .list-item {
		width: 48%;
	  }
	}
	
	@media (max-width: 576px) {
	  .list-item {
		width: 100%;
	  }
	}
	
	.animation-box {
	  transform: translate3d(0, 0, 0);
	  z-index: initial;
	}
	
	.animation-box:hover {
	  transform: translate3d(0, -8px, 0);
	  box-shadow: 0 12px 20px rgba(74, 144, 226, 0.1);
	  z-index: 1;
	}
	
	.image {
	  cursor: pointer;
	  width: 100%;
	  margin: 0 0 12px;
	  object-fit: cover;
	  display: block;
	  height: 275px;
	  border-radius: 4px;
	  transition: all 0.5s ease;
	}
	
	.animation-box:hover .image {
	  transform: scale(1.03);
	}
	
	.price {
	  padding: 4px 10px;
	  color: #3B7AED;
	  text-align: right;
	  width: 100%;
	  line-height: 24px;
	  font-size: 16px;
	  order: 2;
	  font-weight: 500;
	}
	
	.price span {
	  font-size: 14px;
	}
	
	.name {
	  width: 100%;
	  padding: 6px 10px;
	  line-height: 24px;
	  font-size: 15px;
	  color: #293A80;
	  text-align: center;
	  white-space: nowrap;
	  overflow: hidden;
	  text-overflow: ellipsis;
	  transition: color 0.3s ease;
	}
	
	.list-item:hover .name {
	  color: #4A90E2;
	}
	
	.pagination {
	  padding: 20px 7% 20px;
	  margin: 30px 0 0;
	  white-space: nowrap;
	  color: #666;
	  text-align: center;
	  background: #f0f7ff;
	  width: 100%;
	  font-weight: 500;
	  border-radius: 8px;
	}
	
	.el-pagination ::v-deep .el-pagination__total {
	  margin: 0 10px 0 0;
	  color: #4A6FA5;
	  font-weight: 400;
	  display: inline-block;
	  vertical-align: top;
	  font-size: 13px;
	  line-height: 28px;
	  height: 28px;
	}
	
	.el-pagination ::v-deep .btn-prev,
	.el-pagination ::v-deep .btn-next {
	  border: 1px solid #b8daff;
	  border-radius: 4px;
	  padding: 0;
	  margin: 0 5px;
	  color: #4A90E2;
	  background: #fff;
	  display: inline-block;
	  vertical-align: top;
	  font-size: 13px;
	  line-height: 28px;
	  min-width: 35px;
	  height: 28px;
	  transition: all 0.3s ease;
	}
	
	.el-pagination ::v-deep .btn-prev:hover,
	.el-pagination ::v-deep .btn-next:hover {
	  background: #EBF5FB;
	  border-color: #4A90E2;
	  transform: translateY(-1px);
	}
	
	.el-pagination ::v-deep .btn-prev:disabled,
	.el-pagination ::v-deep .btn-next:disabled {
	  border: 1px solid #e0e0e0;
	  cursor: not-allowed;
	  border-radius: 4px;
	  padding: 0;
	  margin: 0 5px;
	  color: #C0C4CC;
	  background: #f5f5f5;
	  display: inline-block;
	  vertical-align: top;
	  font-size: 13px;
	  line-height: 28px;
	  height: 28px;
	}
	
	.el-pagination ::v-deep .el-pager {
	  padding: 0;
	  margin: 0;
	  display: inline-block;
	  vertical-align: top;
	}
	
	.el-pagination ::v-deep .el-pager .number {
	  cursor: pointer;
	  padding: 0 8px;
	  margin: 0 3px;
	  color: #4A6FA5;
	  display: inline-block;
	  vertical-align: top;
	  font-size: 13px;
	  line-height: 28px;
	  border-radius: 4px;
	  background: #fff;
	  text-align: center;
	  min-width: 30px;
	  height: 28px;
	  border: 1px solid #e6e6e6;
	  transition: all 0.3s ease;
	}
	
	.el-pagination ::v-deep .el-pager .number:hover {
	  background: #EBF5FB;
	  border-color: #b8daff;
	  color: #4A90E2;
	  transform: translateY(-1px);
	}
	
	.el-pagination ::v-deep .el-pager .number.active {
	  cursor: default;
	  padding: 0 8px;
	  margin: 0 3px;
	  color: #FFF;
	  display: inline-block;
	  vertical-align: top;
	  font-size: 13px;
	  line-height: 28px;
	  border-radius: 4px;
	  background: #4A90E2;
	  text-align: center;
	  min-width: 30px;
	  height: 28px;
	  border-color: #4A90E2;
	}
	
	.el-pagination ::v-deep .el-pagination__sizes {
	  display: inline-block;
	  vertical-align: top;
	  font-size: 13px;
	  line-height: 28px;
	  height: 28px;
	  margin-left: 10px;
	}
	
	.el-pagination ::v-deep .el-pagination__sizes .el-input {
	  margin: 0 5px;
	  width: 100px;
	  position: relative;
	}
	
	.el-pagination ::v-deep .el-pagination__sizes .el-input .el-input__inner {
	  border: 1px solid #b8daff;
	  cursor: pointer;
	  padding: 0 25px 0 8px;
	  color: #4A6FA5;
	  display: inline-block;
	  font-size: 13px;
	  line-height: 28px;
	  border-radius: 4px;
	  outline: 0;
	  background: #fff;
	  width: 100%;
	  text-align: center;
	  height: 28px;
	}
	
	.el-pagination ::v-deep .el-pagination__sizes .el-input span.el-input__suffix {
	  top: 0;
	  position: absolute;
	  right: 0;
	  height: 100%;
	}
	
	.el-pagination ::v-deep .el-pagination__sizes .el-input .el-input__suffix .el-select__caret {
	  cursor: pointer;
	  color: #4A90E2;
	  width: 25px;
	  font-size: 14px;
	  line-height: 28px;
	  text-align: center;
	}
	
	.el-pagination ::v-deep .el-pagination__jump {
	  margin: 0 0 0 15px;
	  color: #4A6FA5;
	  display: inline-block;
	  vertical-align: top;
	  font-size: 13px;
	  line-height: 28px;
	  height: 28px;
	}
	
	.el-pagination ::v-deep .el-pagination__jump .el-input {
	  border-radius: 4px;
	  padding: 0 2px;
	  margin: 0 5px;
	  display: inline-block;
	  width: 50px;
	  font-size: 14px;
	  line-height: 18px;
	  position: relative;
	  text-align: center;
	  height: 28px;
	}
	
	.el-pagination ::v-deep .el-pagination__jump .el-input .el-input__inner {
	  border: 1px solid #b8daff;
	  cursor: pointer;
	  padding: 0 3px;
	  color: #4A6FA5;
	  display: inline-block;
	  font-size: 14px;
	  line-height: 28px;
	  border-radius: 4px;
	  outline: 0;
	  background: #fff;
	  width: 100%;
	  text-align: center;
	  height: 28px;
	}
	</style>
		