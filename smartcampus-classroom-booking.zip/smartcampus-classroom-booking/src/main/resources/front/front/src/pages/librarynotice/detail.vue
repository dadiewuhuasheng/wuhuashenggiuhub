<template>
	<div>
		<div :style='{"padding":"0px 20px","margin":"10px auto","background":"#4A90E2","display":"flex","width":"100%","justifyContent":"space-between","height":"40px","box-shadow":"0 2px 10px rgba(74, 144, 226, 0.15)","transition":"all 0.3s ease"}' class="breadcrumb-preview">
			<el-breadcrumb :separator="'/'" :style='{"fontSize":"14px","lineHeight":"40px"}'>
				<el-breadcrumb-item>首页</el-breadcrumb-item>
				<el-breadcrumb-item v-for="(item, index) in breadcrumbItem" :key="index">{{item.name}}</el-breadcrumb-item>
			</el-breadcrumb>
		</div>
		
		<div class="detail-preview" :style='{"width":"100%","padding":"10px 7% 20px","margin":"0px auto 0","position":"relative","background":"none"}'>
			<div class="attr" :style='{"border":"1px solid #e1e8ed","minHeight":"620px","padding":"10px 0 0px 0px","boxShadow":"0px 3px 15px rgba(74, 144, 226, 0.08)","overflow":"hidden","flexWrap":"wrap","background":"rgba(255,255,255,1)","display":"flex","position":"relative","justifyContent":"space-between","borderRadius":"8px","transition":"all 0.3s ease"}'>
				<el-carousel :style='{"border":"1px solid #b8daff","boxShadow":"inset 0px 0px 56px 0px rgba(184, 218, 255, 0.2)","padding":"20px","margin":"10px auto 0","borderRadius":"10px","width":"48%","height":"450px","order":"2","transition":"all 0.3s ease"}' trigger="click" indicator-position="inside" arrow="always" type="default" direction="horizontal" height="400px" autoplay="true" interval="5000" loop="true">
					<el-carousel-item :style='{"borderRadius":"10px","width":"100%","height":"100%","overflow":"hidden"}' v-for="item in detailBanner" :key="item.id">
						<el-image :style='{"width":"100%","objectFit":"cover","borderRadius":"10px","height":"100%","transition":"transform 0.5s ease","hover:transform":"scale(1.03)"}' v-if="item.substr(0,4)=='http'" :src="item" fit="cover" class="image"></el-image>
						<el-image :style='{"width":"100%","objectFit":"cover","borderRadius":"10px","height":"100%","transition":"transform 0.5s ease","hover:transform":"scale(1.03)"}' v-else :src="baseUrl + item" fit="cover" class="image"></el-image>
					</el-carousel-item>
				</el-carousel>
		
				
				<div class="info" :style='{"minHeight":"500px","width":"48%","padding":"10px 10px 10px 20px","margin":"0","background":"none"}'>
					<div class="item" :style='{"border":"2px solid #b8daff","padding":"15px","margin":"0 0 15px 0","alignItems":"center","background":"linear-gradient(320deg, rgba(204,204,204,0) 0%, rgba(255,255,255,0.9) 80%, rgba(204,204,204,0) 100%)","display":"flex","justifyContent":"space-between","borderRadius":"8px","box-shadow":"0 2px 8px rgba(74, 144, 226, 0.08)","transition":"all 0.3s ease","hover:box-shadow":"0 4px 12px rgba(74, 144, 226, 0.15)"}'>
						<div :style='{"color":"#333","fontSize":"18px","fontWeight":"500","lineHeight":"1.5"}'>
						{{detail.noticetitle}}
						</div>
						<div @click="storeup(1)" v-show="!isStoreup" :style='{"padding":"6px 12px","background":"#f0f7ff","borderRadius":"20px","cursor":"pointer","transition":"all 0.3s ease","boxShadow":"0 2px 5px rgba(74, 144, 226, 0.1)","hover:background":"#e6f2ff","hover:box-shadow":"0 3px 8px rgba(74, 144, 226, 0.2)"}'><i v-if="true" :style='{"color":"#4A90E2","fontSize":"14px","marginRight":"5px"}' class="el-icon-star-off"></i><span :style='{"color":"#4A90E2","fontSize":"14px"}'>点我收藏</span></div>
						<div @click="storeup(-1)" v-show="isStoreup" :style='{"padding":"6px 12px","background":"#e6f2ff","borderRadius":"20px","cursor":"pointer","transition":"all 0.3s ease","boxShadow":"0 2px 5px rgba(74, 144, 226, 0.2)","hover:background":"#d1e5ff","hover:box-shadow":"0 3px 8px rgba(74, 144, 226, 0.3)"}'><i v-if="true" :style='{"color":"#4A90E2","fontSize":"14px","marginRight":"5px"}' class="el-icon-star-on"></i><span :style='{"color":"#4A90E2","fontSize":"14px"}'>取消收藏</span></div>
					</div>
	
					<div class="item" :style='{"padding":"0","margin":"0 0 12px 0","borderColor":"#b8daff","borderWidth":"0px 0px 1px","display":"flex","borderStyle":"solid","justifyContent":"spaceBetween","transition":"all 0.3s ease","hover:background":"rgba(230, 242, 255, 0.3)"}'>
						<div class="lable" :style='{"padding":"0 10px","color":"#666","textAlign":"right","background":"linear-gradient(90deg, rgba(255,255,255,1) 0%, rgba(230, 242, 255, 0.7) 100%)","width":"102px","fontSize":"14px","lineHeight":"40px","height":"40px","fontWeight":"500"}'>资讯编号</div>
						<div  :style='{"width":"calc(100% - 102px)","padding":"8px 10px 0","fontSize":"14px","lineHeight":"24px","color":"#333","background":"linear-gradient(270deg, rgba(255,255,255,1) 0%, rgba(230, 242, 255, 0.7) 100%)"}'>{{detail.noticeno}}</div>
					</div>
					<div class="item" :style='{"padding":"0","margin":"0 0 12px 0","borderColor":"#b8daff","borderWidth":"0px 0px 1px","display":"flex","borderStyle":"solid","justifyContent":"spaceBetween","transition":"all 0.3s ease","hover:background":"rgba(230, 242, 255, 0.3)"}'>
						<div class="lable" :style='{"padding":"0 10px","color":"#666","textAlign":"right","background":"linear-gradient(90deg, rgba(255,255,255,1) 0%, rgba(230, 242, 255, 0.7) 100%)","width":"102px","fontSize":"14px","lineHeight":"40px","height":"40px","fontWeight":"500"}'>资讯类型</div>
						<div  :style='{"width":"calc(100% - 102px)","padding":"8px 10px 0","fontSize":"14px","lineHeight":"24px","color":"#333","background":"linear-gradient(270deg, rgba(255,255,255,1) 0%, rgba(230, 242, 255, 0.7) 100%)"}'>{{detail.noticetype}}</div>
					</div>
					<div class="item" :style='{"padding":"0","margin":"0 0 12px 0","borderColor":"#b8daff","borderWidth":"0px 0px 1px","display":"flex","borderStyle":"solid","justifyContent":"spaceBetween","transition":"all 0.3s ease","hover:background":"rgba(230, 242, 255, 0.3)"}'>
						<div class="lable" :style='{"padding":"0 10px","color":"#666","textAlign":"right","background":"linear-gradient(90deg, rgba(255,255,255,1) 0%, rgba(230, 242, 255, 0.7) 100%)","width":"102px","fontSize":"14px","lineHeight":"40px","height":"40px","fontWeight":"500"}'>资讯简介</div>
						<div  :style='{"width":"calc(100% - 102px)","padding":"8px 10px 0","fontSize":"14px","lineHeight":"24px","color":"#333","background":"linear-gradient(270deg, rgba(255,255,255,1) 0%, rgba(230, 242, 255, 0.7) 100%)"}'>{{detail.noticeintro}}</div>
					</div>
					<div class="item" :style='{"padding":"0","margin":"0 0 12px 0","borderColor":"#b8daff","borderWidth":"0px 0px 1px","display":"flex","borderStyle":"solid","justifyContent":"spaceBetween","transition":"all 0.3s ease","hover:background":"rgba(230, 242, 255, 0.3)"}'>
						<div class="lable" :style='{"padding":"0 10px","color":"#666","textAlign":"right","background":"linear-gradient(90deg, rgba(255,255,255,1) 0%, rgba(230, 242, 255, 0.7) 100%)","width":"102px","fontSize":"14px","lineHeight":"40px","height":"40px","fontWeight":"500"}'>发布时间</div>
						<div  :style='{"width":"calc(100% - 102px)","padding":"8px 10px 0","fontSize":"14px","lineHeight":"24px","color":"#333","background":"linear-gradient(270deg, rgba(255,255,255,1) 0%, rgba(230, 242, 255, 0.7) 100%)"}'>{{detail.updatetime}}</div>
					</div>
					<div class="btn" :style='{"padding":"10px 0","flexWrap":"wrap","display":"flex"}'>
					</div>
				</div>
				
			</div>
			
			
			<el-tabs class="detail" :style='{"border":"2px solid #b8daff","boxShadow":"0 3px 15px rgba(74, 144, 226, 0.08)","padding":"10px","margin":"20px 0 0","borderRadius":"8px","background":"rgba(255,255,255,1)","transition":"all 0.3s ease"}' v-model="activeName" type="border-card">
				<el-tab-pane label="资讯详情" name="first">
					<div v-html="detail.noticecontent" :style='{"padding":"20px","lineHeight":"1.8","color":"#333","fontSize":"15px","background":"#f8fafc","borderRadius":"6px","minHeight":"300px"}'></div>
				</el-tab-pane>
				<el-tab-pane label="评论" name="second">
					<el-form class="add comment" :style='{"boxShadow":"0 1px 6px 0 rgba(74, 144, 226, 0.1)","padding":"15px","margin":"0 0 20px","borderRadius":"8px","background":"#f8fcff","transition":"all 0.3s ease"}' :model="form" :rules="rules" ref="form">
						<el-form-item class="item" :style='{"width":"100%","display":"flex","height":"auto"}' label="评论" prop="content">
							<el-input type="textarea" :rows="5" v-model="form.content" placeholder="请输入内容"></el-input>
						</el-form-item>
						<el-form-item class="btn" :style='{"width":"100%","padding":"0 0 0 80px","margin":"10px 0 0","height":"auto"}'>
							<el-button :style='{"border":"0","cursor":"pointer","padding":"0","margin":"0 20px 0 0","outline":"none","color":"#fff","borderRadius":"4px","background":"#4A90E2","width":"128px","lineHeight":"40px","fontSize":"14px","height":"40px","transition":"all 0.3s ease","hover:background":"#3a80d2","hover:box-shadow":"0 2px 8px rgba(74, 144, 226, 0.3)"}' type="primary" @click="submitForm('form')">立即提交</el-button>
							<el-button :style='{"border":"1px solid #ddd","cursor":"pointer","padding":"0","margin":"0 20px 0 0","outline":"none","color":"#666","borderRadius":"4px","background":"#fff","width":"128px","lineHeight":"40px","fontSize":"14px","height":"40px","transition":"all 0.3s ease","hover:background":"#f5f5f5"}' @click="resetForm('form')">重置</el-button>
						</el-form-item>
					</el-form>
					
					<div v-if="infoList.length" :style='{"boxShadow":"0 1px 6px 0 rgba(74, 144, 226, 0.08)","padding":"15px","borderRadius":"8px","background":"#f8fcff","transition":"all 0.3s ease"}' class="comment">
						<div :style='{"padding":"15px","boxShadow":"inset 0px 0px 56px 0px rgba(184, 218, 255, 0.1)","margin":"0 0 15px","borderColor":"#b8daff","alignItems":"center","borderWidth":"0 0 1px 0","width":"100%","borderStyle":"solid","height":"auto","borderRadius":"6px","transition":"all 0.3s ease","hover:box-shadow":"inset 0px 0px 56px 0px rgba(184, 218, 255, 0.2)"}' v-for="item in infoList" :key="item.id">
							<div class="user" :style='{"width":"100%","alignItems":"center","display":"flex","height":"auto","marginBottom":"10px"}'>
								<el-image v-if="item.avatarurl" :style='{"width":"40px","margin":"0 10px 0 0","borderRadius":"100%","objectFit":"cover","height":"40px","border":"2px solid #e6f2ff"}' :size="50" :src="baseUrl + item.avatarurl"></el-image>
								<el-image v-if="!item.avatarurl" :style='{"width":"40px","margin":"0 10px 0 0","borderRadius":"100%","objectFit":"cover","height":"40px","border":"2px solid #e6f2ff"}' :size="50" :src="require('@/assets/avatar.png')"></el-image>
								<div :style='{"color":"#333","fontSize":"16px","fontWeight":"500"}' class="name">{{item.nickname}}</div>
							</div>
							<div :style='{"padding":"10px","margin":"0px 0px 10px","lineHeight":"1.8","fontSize":"14px","color":"#333","borderRadius":"4px","background":"rgba(255,255,255,0.8)"}' class="content-block-ask">
								{{item.content}}
							</div>
							<div :style='{"padding":"10px","margin":"0px 0px 10px","lineHeight":"1.8","fontSize":"14px","color":"#333","borderRadius":"4px","background":"rgba(230, 242, 255, 0.5)","borderLeft":"3px solid #4A90E2"}' class="content-block-reply" v-if="item.reply">
								回复：{{item.reply}}
							</div>
						</div>
					</div>
					
					<el-pagination
					  background
					  class="pagination"
					  :pager-count="7"
					  :page-size="pageSize"
					  :page-sizes="pageSizes"
					  prev-text="<"
					  next-text=">"
					  :hide-on-single-page="true"
					  :layout='["total","prev","pager","next","sizes","jumper"].join()'
					  :total="total"
					  :style='{"padding":"20px 7% 20px","margin":"20px 0 0","whiteSpace":"nowrap","color":"#666","textAlign":"center","background":"#f0f7ff","width":"100%","fontWeight":"500","borderRadius":"6px","transition":"all 0.3s ease"}'
					  @current-change="curChange"
					  @prev-click="prevClick"
					  @next-click="nextClick"
					></el-pagination>
				</el-tab-pane>
				
			</el-tabs>
		</div>
	</div>
	</template>
	
	<script>
	  import CountDown from '@/components/CountDown';
	  export default {
		//数据集合
		data() {
		  return {
			tablename: 'librarynotice',
			baseUrl: '',
			breadcrumbItem: [
			  {
				name: '详情信息'
			  }
			],
			title: '',
			detailBanner: [],
			endTime: 0,
			detail: {},
			activeName: 'first',
			form: {
			  content: '',
			  userid: localStorage.getItem('userid'),
			  nickname: localStorage.getItem('username'),
			  avatarurl: '',
			},
			infoList: [],
			total: 1,
			pageSize: 5,
			pageSizes: [10,20,30,50],
			totalPage: 1,
			rules: {
			  content: [
				{ required: true, message: '请输入内容', trigger: 'blur' }
			  ]
			},
			storeupParams: {
			  name: '',
			  picture: '',
			  refid: 0,
			  tablename: 'librarynotice',
			  userid: localStorage.getItem('userid')
			},
			isStoreup: false,
			storeupInfo: {},
			buynumber: 1,
		  }
		},
		created() {
			this.init();
		},
		//方法集合
		methods: {
			init() {
			  this.baseUrl = this.$config.baseUrl;
			  if(this.$route.query.detailObj) {
				this.detail = JSON.parse(this.$route.query.detailObj);
			  }
			  if(this.$route.query.storeupObj) {
				this.detail.id = JSON.parse(this.$route.query.storeupObj).refid;
			  }
			  if(this.$route.query.discussObj) {
				this.detail.id = JSON.parse(this.$route.query.discussObj).goodid;
			  }
			  this.$http.get(this.tablename + '/detail/'  + this.detail.id, {}).then(res => {
				if (res.data.code == 0) {
				  this.detail = res.data.data;
				  this.title = this.detail.noticetitle;
				  this.detailBanner = this.detail.picture ? this.detail.picture.split(",") : [];
				  this.$forceUpdate();
				}
			  });
	
			  this.getDiscussList(1);
			  this.getStoreupStatus();
	
			},
		  storeup(type) {
			if (type == 1 && !this.isStoreup) {
			  this.storeupParams.name = this.title;
			  this.storeupParams.picture = this.detailBanner[0];
			  this.storeupParams.refid = this.detail.id;
			  this.storeupParams.type = type;
			  this.$http.post('storeup/add', this.storeupParams).then(res => {
				if (res.data.code == 0) {
				  this.isStoreup = true;
				  this.$message({
					type: 'success',
					message: '收藏成功!',
					duration: 1500,
				  });
				}
			  });
			}
			if (type == -1 && this.isStoreup) {
			  this.$http.get('storeup/list', {params: {page: 1, limit: 1, type: 1, refid: this.detail.id, tablename: 'librarynotice', userid: localStorage.getItem('userid')}}).then(res => {
				if (res.data.code == 0 && res.data.data.list.length > 0) {
				  this.isStoreup = true;
				  this.storeupInfo = res.data.data.list[0];
				  let delIds = new Array();
				  delIds.push(this.storeupInfo.id);
				  this.$http.post('storeup/delete', delIds).then(res => {
					if (res.data.code == 0) {
					  this.isStoreup = false;
					  this.$message({
						type: 'success',
						message: '取消成功!',
						duration: 1500,
					  });
					}
				  });
				}
			  });
			}
		  },
		  getStoreupStatus(){
			if(localStorage.getItem("Token")) {
				this.$http.get('storeup/list', {params: {page: 1, limit: 1, type: 1, refid: this.detail.id, tablename: 'librarynotice', userid: localStorage.getItem('userid')}}).then(res => {
				  if (res.data.code == 0 && res.data.data.list.length > 0) {
					this.isStoreup = true;
					this.storeupInfo = res.data.data.list[0];
				  }
				});
			}
		  },
		  curChange(page) {
			this.getDiscussList(page);
		  },
		  prevClick(page) {
			this.getDiscussList(page);
		  },
		  nextClick(page) {
			this.getDiscussList(page);
		  },
		  // 下载
		  download(file){
			if(!file) {
				this.$message({
				  type: 'error',
				  message: '文件不存在',
				  duration: 1500,
				});
				return;
			}
			window.open(this.baseUrl+file)
		  },
		  getDiscussList(page) {
			this.$http.get('discusslibrarynotice/list', {params: {page, limit: this.pageSize, refid: this.detail.id}}).then(res => {
			  if (res.data.code == 0) {
				this.infoList = res.data.data.list;
				this.total = res.data.data.total;
				this.pageSize = res.data.data.pageSize;this.pageSizes = [this.pageSize, this.pageSize*2, this.pageSize*3, this.pageSize*5];
				this.totalPage = res.data.data.totalPage;
			  }
			});
		  },
		  submitForm(formName) {
			let sensitiveWords = "";
			let sensitiveWordsArr = [];
			if(sensitiveWords) {
				sensitiveWordsArr = sensitiveWords.split(",");
			}
			for(var i=0; i<sensitiveWordsArr.length; i++){
				//全局替换
				var reg = new RegExp(sensitiveWordsArr[i],"g");
				//判断内容中是否包括敏感词
				if (this.form.content.indexOf(sensitiveWordsArr[i]) > -1) {
					// 将敏感词替换为 **
					this.form.content = this.form.content.replace(reg,"**");
				}
			}
			this.$refs[formName].validate((valid) => {
			  if (valid) {
				this.form.refid = this.detail.id;
				this.form.avatarurl = localStorage.getItem('headportrait')?localStorage.getItem('headportrait'):'';
				this.$http.post('discusslibrarynotice/add', this.form).then(res => {
				  if (res.data.code == 0) {
					this.form.content = '';
					this.getDiscussList(1);
					this.$message({
					  type: 'success',
					  message: '评论成功!',
					  duration: 1500,
					});
				  }
				});
			  } else {
				return false;
			  }
			});
		  },
		  resetForm(formName) {
			this.$refs[formName].resetFields();
		  },
	
	
		},
		components: {
		  CountDown
		}
	  }
	</script>
	
	<style scoped>
		.detail-preview {
		
		  .attr {
			.el-carousel ::v-deep .el-carousel__indicator button {
			  width: 0;
			  height: 0;
			  display: none;
			}
		
			.el-input-number__decrease:hover:not(.is-disabled)~.el-input .el-input__inner:not(.is-disabled), 
			.el-input-number__increase:hover:not(.is-disabled)~.el-input .el-input__inner:not(.is-disabled) {
			  border-color: #4A90E2;
			}
		  }
		
		  .detail {
			::v-deep .el-tabs__header .el-tabs__nav-wrap {
			  margin-bottom: 0;
			}
		
			& .add .el-textarea {
			  width: auto;
			}
		  }
		}
		
		.attr .el-carousel ::v-deep .el-carousel__container .el-carousel__arrow--left {
			width: 36px;
			font-size: 12px;
			height: 36px;
			background: rgba(255, 255, 255, 0.8);
			color: #4A90E2;
			transition: all 0.3s ease;
		}
		
		.attr .el-carousel ::v-deep .el-carousel__container .el-carousel__arrow--left:hover {
			background: #4A90E2;
			color: white;
			transform: scale(1.1);
		}
		
		.attr .el-carousel ::v-deep .el-carousel__container .el-carousel__arrow--right {
			width: 36px;
			font-size: 12px;
			height: 36px;
			background: rgba(255, 255, 255, 0.8);
			color: #4A90E2;
			transition: all 0.3s ease;
		}
		
		.attr .el-carousel ::v-deep .el-carousel__container .el-carousel__arrow--right:hover {
			background: #4A90E2;
			color: white;
			transform: scale(1.1);
		}
	
		.attr .el-carousel ::v-deep .el-carousel__indicators {
			padding: 0;
			margin: 0;
			z-index: 2;
			bottom: 40px;
			position: absolute;
			list-style: none;
		}
		
		.attr .el-carousel ::v-deep .el-carousel__indicators li {
			border-radius: 10px;
			padding: 0;
			margin: 0 4px;
			background: #fff;
			display: inline-block;
			width: 12px;
			opacity: 0.4;
			transition: 0.3s;
			height: 12px;
		}
		
		.attr .el-carousel ::v-deep .el-carousel__indicators li:hover {
			padding: 0;
			margin: 0 4px;
			background: #fff;
			display: inline-block;
			width: 24px;
			opacity: 0.7;
			height: 12px;
		}
		
		.attr .el-carousel ::v-deep .el-carousel__indicators li.is-active {
			padding: 0;
			margin: 0 4px;
			background: #4A90E2;
			display: inline-block;
			width: 24px;
			opacity: 1;
			height: 12px;
		}
		
		.attr .el-input-number ::v-deep .el-input-number__decrease {
			cursor: pointer;
			z-index: 1;
			display: flex;
			border-color: #b8daff;
			border-radius: 4px 0 0 4px;
			top: 1px;
			left: 1px;
			background: #f0f7ff;
			width: 40px;
			justify-content: center;
			border-width: 0 1px 0 0;
			align-items: center;
			position: absolute;
			border-style: solid;
			text-align: center;
			height: 38px;
			transition: all 0.3s ease;
		}
		
		.attr .el-input-number ::v-deep .el-input-number__decrease:hover {
			background: #e6f2ff;
		}
		
		.attr .el-input-number ::v-deep .el-input-number__decrease i {
			color: #4A90E2;
			font-size: 14px;
		}
	
		.attr .el-input-number ::v-deep .el-input-number__increase {
			cursor: pointer;
			z-index: 1;
			display: flex;
			border-color: #b8daff;
			right: 1px;
			border-radius: 0 4px 4px 0;
			top: 1px;
			background: #f0f7ff;
			width: 40px;
			justify-content: center;
			border-width: 0 0 0 1px;
			align-items: center;
			position: absolute;
			border-style: solid;
			text-align: center;
			height: 38px;
			transition: all 0.3s ease;
		}
		
		.attr .el-input-number ::v-deep .el-input-number__increase:hover {
			background: #e6f2ff;
		}
		
		.attr .el-input-number ::v-deep .el-input-number__increase i {
			color: #4A90E2;
			font-size: 14px;
		}
		
		.attr .el-input-number ::v-deep .el-input .el-input__inner {
			border: 1px solid #b8daff;
			border-radius: 4px;
			padding: 0 40px;
			outline: none;
			color: #333;
			background: #FFF;
			display: inline-block;
			width: 100%;
			font-size: 14px;
			line-height: 40px;
			text-align: center;
			height: 40px;
			transition: all 0.3s ease;
		}
		
		.attr .el-input-number ::v-deep .el-input .el-input__inner:focus {
			border-color: #4A90E2;
			box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.2);
		}
		
		.detail-preview .detail.el-tabs ::v-deep .el-tabs__header {
			margin: 0;
			background: #f8fcff;
			border-color: #b8daff;
			border-width: 0 0 1px 0;
			border-style: solid;
		}
		
		.detail-preview .detail.el-tabs ::v-deep .el-tabs__header .el-tabs__item {
			border: 0;
			padding: 0 20px;
			margin: 0;
			color: #666;
			background: transparent;
			font-weight: 500;
			display: inline-block;
			font-size: 14px;
			line-height: 40px;
			position: relative;
			list-style: none;
			height: 40px;
			transition: all 0.3s ease;
		}
		
		.detail-preview .detail.el-tabs ::v-deep .el-tabs__header .el-tabs__item:hover {
			border: 0;
			color: #4A90E2;
			background: #e6f2ff;
		}
		
		.detail-preview .detail.el-tabs ::v-deep .el-tabs__header .el-tabs__item.is-active {
			border: 0;
			color: #4A90E2;
			background: #e6f2ff;
		}
		
		.detail-preview .detail.el-tabs ::v-deep .el-tabs__content {
			padding: 15px;
		}
		
		.detail-preview .detail.el-tabs .add ::v-deep .el-form-item__label {
			padding: 0 10px 0 0;
			color: #666;
			width: 80px;
			font-size: 14px;
			line-height: 40px;
			text-align: right;
		}
		
		.detail-preview .detail.el-tabs .add ::v-deep .el-textarea__inner {
			border: 1px solid #b8daff;
			border-radius: 6px;
			padding: 12px;
			box-shadow: inset 0px 0px 56px 0px rgba(184, 218, 255, 0.1);
			outline: none;
			color: #333;
			width: 100%;
			max-width: 1058px;
			font-size: 14px;
			line-height: 1.8;
			height: 120px;
			transition: all 0.3s ease;
		}
		
		.detail-preview .detail.el-tabs .add ::v-deep .el-textarea__inner:focus {
			border-color: #4A90E2;
			box-shadow: inset 0px 0px 56px 0px rgba(184, 218, 255, 0.2);
		}
		
		.breadcrumb-preview .el-breadcrumb ::v-deep .el-breadcrumb__separator {
			margin: 0 9px;
			color: #fff;
			font-weight: 500;
		}
		
		.breadcrumb-preview .el-breadcrumb ::v-deep .el-breadcrumb__inner a {
			color: #fff;
			display: inline-block;
			text-decoration: none;
			transition: all 0.3s ease;
		}
		
		.breadcrumb-preview .el-breadcrumb ::v-deep .el-breadcrumb__inner a:hover {
			text-decoration: underline;
			opacity: 0.8;
		}
	
		.breadcrumb-preview .el-breadcrumb ::v-deep .el-breadcrumb__inner {
			color: #fff;
			display: inline-block;
		}
		
		.el-pagination ::v-deep .el-pagination__total {
			margin: 0 10px 0 0;
			color: #666;
			font-weight: 400;
			display: inline-block;
			vertical-align: top;
			font-size: 13px;
			line-height: 28px;
			height: 28px;
		}
		
		.el-pagination ::v-deep .btn-prev {
			border: 1px solid #b8daff;
			border-radius: 4px;
			padding: 0;
			margin: 0 5px;
			color: #4A90E2;
			background: #fff;
			display: inline-block;
			vertical-align: top;
			font-size: 13px;
			line-height: 28px;
			min-width: 35px;
			height: 28px;
			transition: all 0.3s ease;
		}
		
		.el-pagination ::v-deep .btn-prev:hover {
			background: #e6f2ff;
			border-color: #4A90E2;
		}
		
		.el-pagination ::v-deep .btn-next {
			border: 1px solid #b8daff;
			border-radius: 4px;
			padding: 0;
			margin: 0 5px;
			color: #4A90E2;
			background: #fff;
			display: inline-block;
			vertical-align: top;
			font-size: 13px;
			line-height: 28px;
			min-width: 35px;
			height: 28px;
			transition: all 0.3s ease;
		}
		
		.el-pagination ::v-deep .btn-next:hover {
			background: #e6f2ff;
			border-color: #4A90E2;
		}
		
		.el-pagination ::v-deep .btn-prev:disabled {
			border: 1px solid #e1e8ed;
			cursor: not-allowed;
			border-radius: 4px;
			padding: 0;
			margin: 0 5px;
			color: #C0C4CC;
			background: #ffffff;
			display: inline-block;
			vertical-align: top;
			font-size: 13px;
			line-height: 28px;
			height: 28px;
		}
		
		.el-pagination ::v-deep .btn-next:disabled {
			border: 1px solid #e1e8ed;
			cursor: not-allowed;
			border-radius: 4px;
			padding: 0;
			margin: 0 5px;
			color: #C0C4CC;
			background: #ffffff;
			display: inline-block;
			vertical-align: top;
			font-size: 13px;
			line-height: 28px;
			height: 28px;
		}
		
		.el-pagination ::v-deep .el-pager {
			padding: 0;
			margin: 0;
			display: inline-block;
			vertical-align: top;
		}
		
		.el-pagination ::v-deep .el-pager .number {
			cursor: pointer;
			padding: 0 4px;
			margin: 0 5px;
			color: #666;
			display: inline-block;
			vertical-align: top;
			font-size: 13px;
			line-height: 28px;
			border-radius: 4px;
			background: #ffffff;
			text-align: center;
			min-width: 30px;
			height: 28px;
			border: 1px solid #b8daff;
			transition: all 0.3s ease;
		}
		
		.el-pagination ::v-deep .el-pager .number:hover {
			cursor: pointer;
			border-radius: 4px;
			padding: 0 4px;
			margin: 0 5px;
			background: #e6f2ff;
			display: inline-block;
			vertical-align: top;
			font-size: 13px;
			line-height: 28px;
			text-align: center;
			min-width: 30px;
			height: 28px;
			color: #4A90E2;
			border-color: #4A90E2;
		}
	
		.el-pagination ::v-deep .el-pager .number.active {
			cursor: default;
			padding: 0 4px;
			margin: 0 5px;
			color: #FFF;
			display: inline-block;
			vertical-align: top;
			font-size: 13px;
			line-height: 28px;
			border-radius: 4px;
			background: #4A90E2;
			text-align: center;
			min-width: 30px;
			height: 28px;
			border-color: #4A90E2;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes {
			display: inline-block;
			vertical-align: top;
			font-size: 13px;
			line-height: 28px;
			height: 28px;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes .el-input {
			margin: 0 5px;
			width: 100px;
			position: relative;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes .el-input .el-input__inner {
			border: 1px solid #b8daff;
			cursor: pointer;
			padding: 0 25px 0 8px;
			color: #606266;
			display: inline-block;
			font-size: 13px;
			line-height: 28px;
			border-radius: 4px;
			outline: 0;
			background: #FFF;
			width: 100%;
			text-align: center;
			height: 28px;
			transition: all 0.3s ease;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes .el-input .el-input__inner:hover {
			border-color: #4A90E2;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes .el-input span.el-input__suffix {
			top: 0;
			position: absolute;
			right: 0;
			height: 100%;
		}
		
		.el-pagination ::v-deep .el-pagination__sizes .el-input .el-input__suffix .el-select__caret {
			cursor: pointer;
			color: #4A90E2;
			width: 25px;
			font-size: 14px;
			line-height: 28px;
			text-align: center;
		}
	
		.el-pagination ::v-deep .el-pagination__jump {
			margin: 0 0 0 24px;
			color: #606266;
			display: inline-block;
			vertical-align: top;
			font-size: 13px;
			line-height: 28px;
			height: 28px;
		}
		
		.el-pagination ::v-deep .el-pagination__jump .el-input {
			border-radius: 4px;
			padding: 0 2px;
			margin: 0 2px;
			display: inline-block;
			width: 50px;
			font-size: 14px;
			line-height: 18px;
			position: relative;
			text-align: center;
			height: 28px;
		}
		
		.el-pagination ::v-deep .el-pagination__jump .el-input .el-input__inner {
			border: 1px solid #b8daff;
			cursor: pointer;
			padding: 0 3px;
			color: #606266;
			display: inline-block;
			font-size: 14px;
			line-height: 28px;
			border-radius: 4px;
			outline: 0;
			background: #FFF;
			width: 100%;
			text-align: center;
			height: 28px;
			transition: all 0.3s ease;
		}
		
		.el-pagination ::v-deep .el-pagination__jump .el-input .el-input__inner:focus {
			border-color: #4A90E2;
		}
	</style>
	