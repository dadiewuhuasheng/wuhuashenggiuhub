<template>
	<div class="container">
		<el-button class="back-button el-icon-back" type="warning" size="mini" @click="backClick">返回</el-button>
		<div v-if="storeupType==1" class="section-title">收藏</div>
		<el-form :inline="true" :model="formSearch" class="form-search">
		  <el-form-item>
			<el-input v-model="formSearch.name" placeholder="名称"></el-input>
		  </el-form-item>
		  <el-form-item>
			<el-button type="primary" @click="getStoreupList(1)">查询</el-button>
		  </el-form-item>
		</el-form>
		<el-row :gutter="20">
		  <el-col :span="6" v-for="(item, index) in storeupList" :key="index" @click.native="toDetail(item)">
			<el-card class="collection-card">
			  <el-image v-if="item.picture && item.picture.substr(0,4)=='http'" :src="item.picture" fit="fill" class="image"></el-image>
			  <el-image v-else :src="baseUrl + item.picture" fit="fill" class="image"></el-image>
			  <div class="card-info">
				<span>{{ item.name }}</span>
			  </div>
			</el-card>
		  </el-col>
		</el-row>
		
		<el-pagination
		  background
		  class="pagination"
		  :pager-count="7"
		  :page-size="pageSize"
		  :page-sizes="pageSizes"
		  prev-text="<"
		  next-text=">"
		  :hide-on-single-page="true"
		  :layout='["total","prev","pager","next","sizes","jumper"].join()'
		  :total="total"
		  @current-change="curChange"
		  @prev-click="prevClick"
		  @next-click="nextClick"
		></el-pagination>
		
	</div>
	</template>
	
	<script>
	  import config from '@/config/config'
	  export default {
		data() {
		  return {
			  layouts: '',
			baseUrl: config.baseUrl,
			formSearch: {
			  name: ''
			},
			storeupType: 1,
			storeupList: [],
			total: 1,
			pageSize: 8,
			pageSizes: [10,20,30,50],
			totalPage: 1
		  }
		},
		created() {
		  this.storeupType = localStorage.getItem('storeupType');
		  this.getStoreupList(1);
		},
		methods: {
		  backClick() {
			  this.$router.push('/index/center')
		  },
		  getStoreupList(page) {
			let params = {page, limit: this.pageSize, type: this.storeupType, userid: localStorage.getItem('userid'),sort:"addtime",order:"desc"};
			let searchWhere = {};
			if (this.formSearch.name != '') searchWhere.name = '%' + this.formSearch.name + '%';
			this.$http.get('storeup/list', {params: Object.assign(params, searchWhere)}).then(res => {
			  if (res.data.code == 0) {
				this.storeupList = res.data.data.list;
				this.total = res.data.data.total;
				this.pageSize = res.data.data.pageSize;this.pageSizes = [this.pageSize, this.pageSize*2, this.pageSize*3, this.pageSize*5];
				this.totalPage = res.data.data.totalPage;
			  }
			});
		  },
		  curChange(page) {
			this.getStoreupList(page);
		  },
		  prevClick(page) {
			this.getStoreupList(page);
		  },
		  nextClick(page) {
			this.getStoreupList(page);
		  },
		  toDetail(item) {
			this.$router.push({path: `/index/${item.tablename}Detail`, query: {storeupObj: JSON.stringify(item)}});
		  }
		}
	  }
	</script>
	
	<style rel="stylesheet/scss" lang="scss" scoped>
	  .container {
		width: 1200px;
		padding: 20px;
		margin: 0px auto;
		position: relative;
		background: #f9fbfd;
		border-radius: 8px;
		box-shadow: 0 2px 10px rgba(106, 168, 230, 0.1);
		animation: fadeIn 0.6s ease-in-out;
	  }
	  
	  @keyframes fadeIn {
		from {
		  opacity: 0;
		  transform: translateY(10px);
		}
		to {
		  opacity: 1;
		  transform: translateY(0);
		}
	  }
	  
	  .back-button {
		border: 0;
		cursor: pointer;
		padding: 0 10px;
		margin: 0 5px 10px 0;
		outline: none;
		color: #4a90e2;
		border-radius: 4px;
		background: #e1effa;
		width: auto;
		line-height: 40px;
		font-size: 14px;
		height: 40px;
		transition: all 0.3s ease;
		
		&:hover {
		  background: #c9e0f7;
		  transform: translateX(-2px);
		}
	  }
	  
	  .section-title {
		margin: 10px 0;
		color: #fff;
		text-align: center;
		background: #6aa8e6;
		width: 100%;
		font-size: 20px;
		line-height: 54px;
		border-radius: 6px;
		letter-spacing: 1px;
		box-shadow: 0 2px 5px rgba(106, 168, 230, 0.2);
	  }
	  
	  .form-search {
		text-align: right;
		margin: 15px 0;
		padding: 10px 15px;
		background-color: #f0f7ff;
		border-radius: 6px;
		
		::v-deep .el-input__inner {
		  border-color: #b8d4f0;
		  transition: border-color 0.3s ease;
		  
		  &:focus {
			border-color: #6aa8e6;
			box-shadow: 0 0 0 2px rgba(106, 168, 230, 0.2);
		  }
		}
		
		::v-deep .el-button--primary {
		  background-color: #6aa8e6;
		  border-color: #6aa8e6;
		  
		  &:hover {
			background-color: #4a90e2;
			border-color: #4a90e2;
		  }
		}
	  }
	  
	  .collection-card {
		height: 100%;
		border-radius: 8px;
		overflow: hidden;
		transition: all 0.3s ease;
		border: 1px solid #e6f0fa;
		
		&:hover {
		  transform: translateY(-5px);
		  box-shadow: 0 8px 15px rgba(106, 168, 230, 0.15);
		}
		
		::v-deep .el-card__body {
		  padding: 0;
		}
	  }
	  
	  .image {
		height: 233px;
		width: 100%;
		display: block;
		transition: transform 0.5s ease;
		
		.collection-card:hover & {
		  transform: scale(1.05);
		}
	  }
	  
	  .card-info {
		padding: 14px;
		background-color: #fff;
		border-top: 1px solid #f0f7ff;
		color: #556677;
		font-size: 14px;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	  }
	  
	  .pagination {
		padding: 20px 7% 20px;
		margin: 20px 0 0;
		white-space: nowrap;
		color: #333;
		text-align: center;
		background: #f0f7ff;
		width: 100%;
		font-weight: 500;
		border-radius: 6px;
	  }
	  
	  .el-pagination ::v-deep .el-pagination__total {
		margin: 0 10px 0 0;
		color: #666;
		font-weight: 400;
		display: inline-block;
		vertical-align: top;
		font-size: 13px;
		line-height: 28px;
		height: 28px;
	  }
	  
	  .el-pagination ::v-deep .btn-prev,
	  .el-pagination ::v-deep .btn-next {
		border: none;
		border-radius: 2px;
		padding: 0;
		margin: 0 5px;
		color: #6aa8e6;
		background: #ffffff;
		display: inline-block;
		vertical-align: top;
		font-size: 13px;
		line-height: 28px;
		min-width: 35px;
		height: 28px;
		transition: all 0.2s ease;
		
		&:hover {
		  background-color: #f0f7ff;
		}
	  }
	  
	  .el-pagination ::v-deep .btn-prev:disabled,
	  .el-pagination ::v-deep .btn-next:disabled {
		border: none;
		cursor: not-allowed;
		border-radius: 2px;
		padding: 0;
		margin: 0 5px;
		color: #C0C4CC;
		background: #ffffff;
		display: inline-block;
		vertical-align: top;
		font-size: 13px;
		line-height: 28px;
		height: 28px;
	  }
	  
	  .el-pagination ::v-deep .el-pager {
		padding: 0;
		margin: 0;
		display: inline-block;
		vertical-align: top;
	  }
	  
	  .el-pagination ::v-deep .el-pager .number {
		cursor: pointer;
		padding: 0 4px;
		margin: 0 5px;
		color: #666;
		display: inline-block;
		vertical-align: top;
		font-size: 13px;
		line-height: 28px;
		border-radius: 2px;
		background: #ffffff;
		text-align: center;
		min-width: 30px;
		height: 28px;
		transition: all 0.2s ease;
		
		&:hover {
		  background: #f0f7ff;
		  color: #6aa8e6;
		}
	  }
	  
	  .el-pagination ::v-deep .el-pager .number.active {
		cursor: default;
		padding: 0 4px;
		margin: 0 5px;
		color: #FFF;
		display: inline-block;
		vertical-align: top;
		font-size: 13px;
		line-height: 28px;
		border-radius: 2px;
		background: #6aa8e6;
		text-align: center;
		min-width: 30px;
		height: 28px;
	  }
	  
	  .el-pagination ::v-deep .el-pagination__sizes {
		display: inline-block;
		vertical-align: top;
		font-size: 13px;
		line-height: 28px;
		height: 28px;
	  }
	  
	  .el-pagination ::v-deep .el-pagination__sizes .el-input {
		margin: 0 5px;
		width: 100px;
		position: relative;
	  }
	  
	  .el-pagination ::v-deep .el-pagination__sizes .el-input .el-input__inner {
		border: 1px solid #b8d4f0;
		cursor: pointer;
		padding: 0 25px 0 8px;
		color: #606266;
		display: inline-block;
		font-size: 13px;
		line-height: 28px;
		border-radius: 3px;
		outline: 0;
		background: #FFF;
		width: 100%;
		text-align: center;
		height: 28px;
		transition: border-color 0.3s ease;
		
		&:focus {
		  border-color: #6aa8e6;
		}
	  }
	  
	  .el-pagination ::v-deep .el-pagination__sizes .el-input span.el-input__suffix {
		top: 0;
		position: absolute;
		right: 0;
		height: 100%;
	  }
	  
	  .el-pagination ::v-deep .el-pagination__sizes .el-input .el-input__suffix .el-select__caret {
		cursor: pointer;
		color: #6aa8e6;
		width: 25px;
		font-size: 14px;
		line-height: 28px;
		text-align: center;
	  }
	  
	  .el-pagination ::v-deep .el-pagination__jump {
		margin: 0 0 0 24px;
		color: #606266;
		display: inline-block;
		vertical-align: top;
		font-size: 13px;
		line-height: 28px;
		height: 28px;
	  }
	  
	  .el-pagination ::v-deep .el-pagination__jump .el-input {
		border-radius: 3px;
		padding: 0 2px;
		margin: 0 2px;
		display: inline-block;
		width: 50px;
		font-size: 14px;
		line-height: 18px;
		position: relative;
		text-align: center;
		height: 28px;
	  }
	  
	  .el-pagination ::v-deep .el-pagination__jump .el-input .el-input__inner {
		border: 1px solid #b8d4f0;
		cursor: pointer;
		padding: 0 3px;
		color: #606266;
		display: inline-block;
		font-size: 14px;
		line-height: 28px;
		border-radius: 3px;
		outline: 0;
		background: #FFF;
		width: 100%;
		text-align: center;
		height: 28px;
		transition: border-color 0.3s ease;
		
		&:focus {
		  border-color: #6aa8e6;
		}
	  }
	</style>
		