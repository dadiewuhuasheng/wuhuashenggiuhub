<template>
<div class="container">
    <el-button class="back-button" type="warning" size="mini" @click="backClick" >返回</el-button>
    <div class="section-title">{{ title }}</div>
    <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="未支付" name="未支付"></el-tab-pane>
      <el-tab-pane label="已预约" name="已预约"></el-tab-pane>
      <el-tab-pane label="已完成" name="已完成"></el-tab-pane>
      <el-tab-pane label="已取消" name="已取消"></el-tab-pane>
    </el-tabs>
    <el-table :data="tableData" class="order-table">
      <el-table-column label="预约编号" prop="orderid"></el-table-column>
      <el-table-column label="商品" align="center" width="200px">
        <template slot-scope="scope">
          <div class="product-item">
            <el-image style="width: 100px; height: 100px" :src="baseUrl + scope.row.picture" fit="fill"></el-image>
            <span style="margin-left: 10px" >{{ scope.row.goodname }}</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="价格">
        <template slot-scope="scope">
          <span v-if="scope.row.type == 1 || scope.row.type == 3"><span class="currency-symbol">￥</span>{{ scope.row.price }}</span>
          <span v-if="scope.row.type == 2">{{ scope.row.price }}积分</span>
        </template>
      </el-table-column>
      <el-table-column label="数量" prop="buynumber"></el-table-column>
      <el-table-column label="总价">
        <template slot-scope="scope">
          <span v-if="scope.row.type == 1 || scope.row.type == 3"><span class="currency-symbol">￥</span>{{ scope.row.total }}</span>
          <span v-if="scope.row.type == 2">{{ scope.row.total }}积分</span>
        </template>
      </el-table-column>
      <el-table-column label="座位" prop="address"></el-table-column>
      <el-table-column label="开始时间">
        <template slot-scope="scope">
          <span>{{ scope.row.startTime || '-' }}</span>
        </template>
      </el-table-column>
      <el-table-column label="结束时间">
        <template slot-scope="scope">
          <span>{{ scope.row.endTime || '-' }}</span>
        </template>
      </el-table-column>
      <el-table-column label="备注" prop="remark"></el-table-column>
      <el-table-column label="操作" width="150">
        <template slot-scope="scope">
          <el-button v-show="activeName == '未支付'" type="success" size="mini" @click="pay(scope.row)">支付</el-button>
          <el-button v-show="activeName == '已预约'" type="success" size="mini" @click="exchange(scope.row)">签到</el-button>
          <el-button v-show="activeName == '未支付'" type="danger" size="mini" @click="cancel(scope.row)">取消</el-button>
          <el-button v-show="activeName == '已预约'" type="danger" size="mini" @click="refund(scope.row)">退款</el-button>
          <el-button v-show="activeName == '已完成'" type="primary" size="mini" @click="toDetail(scope.row)">评价</el-button>
          <el-button v-show="activeName == '已使用'" type="success" size="mini" @click="confirm(scope.row)">确认收货</el-button>
        </template>
      </el-table-column>
    </el-table>
    
	<el-pagination
	  background
	  class="pagination"
	  :pager-count="7"
	  :page-size="pageSize"
	  :page-sizes="pageSizes"
	  prev-text="<"
	  next-text=">"
	  :hide-on-single-page="true"
	  :layout='["total","prev","pager","next","sizes","jumper"].join()'
	  :total="total"
	  @current-change="curChange"
	  @prev-click="prevClick"
	  @next-click="nextClick"
	></el-pagination>
</div>
</template>

<script>
  import config from '@/config/config'
  export default {
    data() {
      return {
		layouts: '',
        title: '我的预约',
        baseUrl: config.baseUrl,
        activeName: '未支付',
        tableData: [],
        total: 1,
        pageSize: 10,
        pageSizes: [10,20,30,50],
        totalPage: 1,
        session: {},
        userTableName: localStorage.getItem('UserTableName'),
      }
    },
    created() {
      this.getSession();
      this.getMyOrderList(1);
    },
    methods: {
      backClick() {
          this.$router.push('/index/center')
      },
      getSession() {
        this.$http.get(this.userTableName+'/session', {emulateJSON: true}).then(res => {
          if (res.data.code == 0) {
            this.session = res.data.data;
          }
        });
      },
      handleClick(tab, event) {
        tab.activeName = event.target.outerText;
        this.getMyOrderList(1);
      },
      toDetail(row) {
          this.$router.push({path: '/index/'+row.tablename+'Detail', query: {discussObj: JSON.stringify(row)}});
      },
      handleAction(index, row) {
        if (index == '已预约' && this.session.money < row.total) {
          this.$message.error('余额不足，请先充值');
          return;
        }

        row.status = index;
        this.$http.post('orders/update', row).then(res => {
          if (res.data.code == 0) {
            if (index == '已预约') this.session.money -= row.total;
            if (index == '已取消' && row.type == 1) this.session.money += row.total;
            if (index == '已取消' && row.type == 2) this.session.jifen += row.total;
            if (index == '已预约' || index == '已取消') {
              this.session.money = this.session.money.toFixed(2);
              this.$http.post(this.userTableName+'/update', this.session).then(res => {});
            }
            this.$message({
              message: '操作成功',
              type: 'success',
              duration: 1500,
              onClose: () => {
                this.getMyOrderList(1);
              }
            });
          }
        });
      },
        // 退款
        refund(item) {
            this.$confirm(`确定退款吗？退款金额将返回账户中。`, "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning"
            }).then(() => {
                // 获取商品详情信息
                this.$http.get(item.tablename+'/info/'+item.goodid, {}).then(res => {
                    // 商品信息
                    let good = res.data.data;
                    // 用户当前用户信息
                    let table = localStorage.getItem("UserTableName");
                    this.$http.get(table+'/session', {}).then(res => {
                        this.user = res.data.data;
                        if(item.type==1||item.type==3) {
                            // 如果该商品存在积分
                            if (good.jf) {
                                this.user.jf = Number(this.user.jf) - Number(item.price * item.buynumber);
                            }
                            this.user.money = Number(this.user.money) + Number(item.total);
                            // 更新用户余额
                            this.$http.post(table+'/update', this.user).then(res => {
                                item.status = '已取消'
                                this.$http.post(`orders/update`, item).then(res => {
                                    this.$message({
                                      message: '退款成功',
                                      type: 'success',
                                      duration: 1500,
                                      onClose: () => {
                                        this.getMyOrderList(1);
                                      }
                                    });
                                });
                            });
                        } else if(item.type==2) {
                            this.user.jf = Number(this.user.jf) + Number(item.total);
                            // 更新用户余额
                            this.$http.post(table+'/update', this.user).then(res => {
                                item.status = '已取消'
                                this.$http.post(`orders/update`, item).then(res => {
                                    this.$message({
                                      message: '退款成功',
                                      type: 'success',
                                      duration: 1500,
                                      onClose: () => {
                                        this.getMyOrderList(1);
                                      }
                                    });
                                });
                            });

                        }
                    });
                });
            });
        },

        // 支付
        pay(item) {
            // 获取商品详情信息
            this.$http.get(item.tablename+'/info/'+item.goodid, {}).then(res => {
                // 商品信息
                let data = res.data.data;
                // 用户当前用户信息
                let table = localStorage.getItem("UserTableName");
                this.$http.get(table+'/session', {}).then(res => {
                    this.user = res.data.data;
                    // 判断余额是否充足
                    if (Number(this.user.money) < Number(item.total)) {
                        this.$message({
                            message: '余额不足，请先充值',
                            type: 'error',
                            duration: 1500
                        });
                        return
                    }
                    // 如果该商品存在积分
                    if (data.jf) {
                        this.user.jf = Number(this.user.jf) + Number(data.jf * item.buynumber);
                    }
                    this.user.money = this.user.money - item.total;
                    // 更新用户余额
                    this.$http.post(table+'/update', this.user).then(res => {
                        item.status = '已预约'
                        this.$http.post(`orders/update`, item).then(res => {
                            this.$message({
                              message: '支付成功',
                              type: 'success',
                              duration: 1500,
                              onClose: () => {
                                this.getMyOrderList(1);
                              }
                            });
                        });
                    });
                });
            });
        },
      confirm(item){
          this.$confirm(`是否确定收货？`, "提示", {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "warning"
          }).then(() => {
              item.status = '已完成'
              this.$http.post(`orders/update`, item).then(res => {
                  this.$message({
                    message: '确认收货成功',
                    type: 'success',
                    duration: 1500,
                    onClose: () => {
                      this.getMyOrderList(1);
                    }
                  });
              });
          });
      },
      cancel(item){
          this.$confirm(`是否取消预约？`, "提示", {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "warning"
          }).then(() => {
              item.status = '已取消'
              this.$http.post(`orders/update`, item).then(res => {
                  this.$message({
                    message: '预约取消成功',
                    type: 'success',
                    duration: 1500,
                    onClose: () => {
                      this.getMyOrderList(1);
                    }
                  });
              });
          });
      },
      exchange(item){
          this.$confirm(`是否签到？`, "提示", {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "warning"
          }).then(() => {
              item.status = '已完成'
              this.$http.post(`orders/update`, item).then(res => {
                  this.$message({
                    message: '签到成功',
                    type: 'success',
                    duration: 1500,
                    onClose: () => {
                      this.getMyOrderList(1);
                    }
                  });
              });
          });
      },
      getMyOrderList(page) {
        this.$http.get('orders/list', {params: {page, limit: this.pageSize,sort:'addtime',order:'desc', userid: localStorage.getItem('userid'), status: this.activeName}}).then(res => {
          if (res.data.code == 0) {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
            this.pageSize = res.data.data.pageSize;this.pageSizes = [this.pageSize, this.pageSize*2, this.pageSize*3, this.pageSize*5];
            this.totalPage = res.data.data.totalPage;
          }
        });
      },
      curChange(page) {
        this.getMyOrderList(page);
      },
      prevClick(page) {
        this.getMyOrderList(page);
      },
      nextClick(page) {
        this.getMyOrderList(page);
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .container {
    width: 1200px;
    padding: 20px;
    margin: 0px auto;
    position: relative;
    background: #f9fbfd;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(106, 168, 230, 0.1);
    animation: fadeIn 0.6s ease-in-out;
  }
  
  @keyframes fadeIn {
    from {
      opacity: 0;
      transform: translateY(10px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  
  .back-button {
    border: 0;
    cursor: pointer;
    padding: 0 10px;
    margin: 0 5px 0 0;
    outline: none;
    color: #556677;
    border-radius: 4px;
    background: #e1effa;
    width: auto;
    line-height: 40px;
    font-size: 14px;
    height: 40px;
    transition: all 0.3s ease;
    
    &:hover {
      background: #d1e3f5;
      color: #4a90e2;
      transform: translateY(-2px);
      box-shadow: 0 2px 5px rgba(106, 168, 230, 0.2);
    }
  }
  
  .section-title {
    margin: 10px 0;
    color: #fff;
    text-align: center;
    background: #6aa8e6;
    width: 100%;
    font-size: 20px;
    line-height: 54px;
    border-radius: 6px;
    letter-spacing: 1px;
    box-shadow: 0 2px 5px rgba(106, 168, 230, 0.2);
  }
  
  .el-tabs {
    margin-top: 20px;
    background: #fff;
    border-radius: 6px;
    border: 1px solid #e6f0fa;
    overflow: hidden;
    
    ::v-deep .el-tabs__header {
      background: #f0f7ff;
      border-bottom: 1px solid #e6f0fa;
      
      .el-tabs__item {
        color: #556677;
        font-weight: 500;
        transition: all 0.3s ease;
        padding: 0 20px !important;
        
        &:hover {
          color: #4a90e2;
          background-color: rgba(106, 168, 230, 0.1);
        }
        
        &.is-active {
          color: #4a90e2;
          font-weight: 600;
          border-bottom: 3px solid #4a90e2;
        }
      }
    }
    
    ::v-deep .el-tabs__content {
      padding: 20px !important;
    }
  }
  
  .order-table {
    width: 100%;
    margin-top: 15px;
    border-radius: 6px;
    overflow: hidden;
    border: 1px solid #e6f0fa;
    
    ::v-deep .el-table__header-wrapper {
      background-color: #f0f7ff;
      
      th {
        color: #556677;
        font-weight: 600;
        border-bottom: 1px solid #e6f0fa;
        background-color: #f0f7ff !important;
      }
    }
    
    ::v-deep .el-table__body-wrapper {
      tr {
        transition: background-color 0.3s ease;
        
        &:hover > td {
          background-color: #f9fbfd !important;
        }
      }
      
      td {
        border-bottom: 1px solid #f0f7ff;
      }
    }
    
    ::v-deep .el-table--enable-row-hover .el-table__body tr:hover>td {
      background-color: #f9fbfd;
    }
  }
  
  .product-item {
    display: flex;
    align-items: center;
    padding: 5px 0;
  }
  
  .currency-symbol {
    font-size: 12px;
  }
  
  ::v-deep .el-button--success {
    background-color: #6aa8e6;
    border-color: #6aa8e6;
    margin: 2px auto;
    transition: all 0.3s ease;
    
    &:hover {
      background-color: #4a90e2;
      border-color: #4a90e2;
      transform: translateY(-2px);
      box-shadow: 0 2px 5px rgba(106, 168, 230, 0.3);
    }
  }
  
  ::v-deep .el-button--danger {
    margin: 2px auto;
    transition: all 0.3s ease;
    
    &:hover {
      transform: translateY(-2px);
      box-shadow: 0 2px 5px rgba(231, 76, 60, 0.3);
    }
  }
  
  ::v-deep .el-button--primary {
    margin: 2px auto;
    background-color: #6aa8e6;
    border-color: #6aa8e6;
    transition: all 0.3s ease;
    
    &:hover {
      background-color: #4a90e2;
      border-color: #4a90e2;
      transform: translateY(-2px);
      box-shadow: 0 2px 5px rgba(106, 168, 230, 0.3);
    }
  }
  
  .pagination {
    padding: 20px 7% 20px;
    margin: 20px 0 0;
    white-space: nowrap;
    color: #333;
    text-align: center;
    background: #f0f7ff;
    width: 100%;
    font-weight: 500;
    border-radius: 6px;
    border: 1px solid #e6f0fa;
  }
  
  .el-pagination ::v-deep .el-pagination__total {
    margin: 0 10px 0 0;
    color: #666;
    font-weight: 400;
    display: inline-block;
    vertical-align: top;
    font-size: 13px;
    line-height: 28px;
    height: 28px;
  }
  
  .el-pagination ::v-deep .btn-prev,
  .el-pagination ::v-deep .btn-next {
    border: 1px solid #b8d4f0;
    border-radius: 4px;
    padding: 0;
    margin: 0 5px;
    color: #6aa8e6;
    background: #fff;
    display: inline-block;
    vertical-align: top;
    font-size: 13px;
    line-height: 28px;
    min-width: 35px;
    height: 28px;
    transition: all 0.3s ease;
    
    &:hover {
      background-color: #f0f7ff;
      border-color: #6aa8e6;
    }
  }
  
  .el-pagination ::v-deep .btn-prev:disabled,
  .el-pagination ::v-deep .btn-next:disabled {
    border: 1px solid #e6e6e6;
    cursor: not-allowed;
    color: #C0C4CC;
    background: #f9f9f9;
  }
  
  .el-pagination ::v-deep .el-pager {
    padding: 0;
    margin: 0;
    display: inline-block;
    vertical-align: top;
  }
  
  .el-pagination ::v-deep .el-pager .number {
    cursor: pointer;
    padding: 0 4px;
    margin: 0 5px;
    color: #666;
    display: inline-block;
    vertical-align: top;
    font-size: 13px;
    line-height: 28px;
    border-radius: 4px;
    background: #ffffff;
    text-align: center;
    min-width: 30px;
    height: 28px;
    border: 1px solid #e6f0fa;
    transition: all 0.3s ease;
    
    &:hover {
      background: #f0f7ff;
      border-color: #b8d4f0;
      color: #4a90e2;
    }
  }
  
  .el-pagination ::v-deep .el-pager .number.active {
    cursor: default;
    padding: 0 4px;
    margin: 0 5px;
    color: #FFF;
    background: #6aa8e6;
    border-color: #6aa8e6;
    text-align: center;
    min-width: 30px;
    height: 28px;
  }
  
  .el-pagination ::v-deep .el-pagination__sizes {
    display: inline-block;
    vertical-align: top;
    font-size: 13px;
    line-height: 28px;
    height: 28px;
  }
  
  .el-pagination ::v-deep .el-pagination__sizes .el-input {
    margin: 0 5px;
    width: 100px;
    position: relative;
  }
  
  .el-pagination ::v-deep .el-pagination__sizes .el-input .el-input__inner {
    border: 1px solid #b8d4f0;
    cursor: pointer;
    padding: 0 25px 0 8px;
    color: #606266;
    display: inline-block;
    font-size: 13px;
    line-height: 28px;
    border-radius: 4px;
    outline: 0;
    background: #FFF;
    width: 100%;
    text-align: center;
    height: 28px;
    transition: border-color 0.3s ease;
    
    &:focus {
      border-color: #6aa8e6;
    }
  }
  
  .el-pagination ::v-deep .el-pagination__jump {
    margin: 0 0 0 24px;
    color: #606266;
    display: inline-block;
    vertical-align: top;
    font-size: 13px;
    line-height: 28px;
    height: 28px;
  }
  
  .el-pagination ::v-deep .el-pagination__jump .el-input {
    border-radius: 4px;
    padding: 0 2px;
    margin: 0 2px;
    display: inline-block;
    width: 50px;
    font-size: 14px;
    line-height: 18px;
    position: relative;
    text-align: center;
    height: 28px;
  }
  
  .el-pagination ::v-deep .el-pagination__jump .el-input .el-input__inner {
    border: 1px solid #b8d4f0;
    cursor: pointer;
    padding: 0 3px;
    color: #606266;
    display: inline-block;
    font-size: 14px;
    line-height: 28px;
    border-radius: 4px;
    outline: 0;
    background: #FFF;
    width: 100%;
    text-align: center;
    height: 28px;
    transition: border-color 0.3s ease;
    
    &:focus {
      border-color: #6aa8e6;
    }
  }
</style>
