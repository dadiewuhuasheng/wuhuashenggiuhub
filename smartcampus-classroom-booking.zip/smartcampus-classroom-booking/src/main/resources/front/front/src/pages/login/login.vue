<template>
	<div>
		<div class="container">
			<el-form ref="loginForm" :model="loginForm" class="login-form" :rules="rules">
				<div class="login-title">智能化校园教室预约管理系统登录</div>
				<el-form-item v-if="loginType==1" class="form-item" prop="username">
					<div class="form-label">账号：</div>
					<input class="form-input" v-model="loginForm.username" placeholder="请输入账户">
				</el-form-item>
				<el-form-item v-if="loginType==1" class="form-item" prop="password">
					<div class="form-label">密码：</div>
					<input class="form-input" v-model="loginForm.password" placeholder="请输入密码" type="password">
				</el-form-item>
				<el-form-item v-if="loginType==1" class="form-item" prop="userRole">
					<div class="form-label">角色：</div>
					<el-select v-model="loginForm.userRole" placeholder="请选择角色" class="form-select">
						<el-option label="学生" value="student"></el-option>
						<el-option label="教师" value="teacher"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item v-if="roles.length>1" class="form-type" prop="role">
					<el-radio v-model="loginForm.tableName" :label="item.tableName" v-for="(item, index) in roles" :key="index" @change.native="getCurrentRow(item)">{{item.roleName}}</el-radio>
				</el-form-item>
				<el-form-item class="form-actions">
					<el-button v-if="loginType==1" class="login-button" @click="submitForm('loginForm')">登录</el-button>
					<el-button v-if="loginType==1" class="reset-button" @click="resetForm('loginForm')">重置</el-button>
				</el-form-item>
				<div class="register-links">
					<router-link class="register-link" :to="{path: '/register', query: {role: item.tableName,pageFlag:'register'}}" v-if="item.hasFrontRegister=='是'" v-for="(item, index) in roles" :key="index">注册{{item.roleName.replace('注册','')}}</router-link>
				</div>
			</el-form>
		</div>
	</div>
	</template>
	
	<script>
	
	export default {
		//数据集合
		data() {
			return {
				baseUrl: this.$config.baseUrl,
				loginType: 1,
				roleMenus: [{"backMenu":[{"child":[{"appFrontIcon":"cuIcon-rank","buttons":["新增","查看","修改","删除"],"menu":"用户","menuJump":"列表","tableName":"users"}],"menu":"用户管理"},{"child":[{"appFrontIcon":"cuIcon-pay","buttons":["新增","查看","修改","删除"],"menu":"座位类型","menuJump":"列表","tableName":"noticetype"}],"menu":"座位类型管理"},{"child":[{"appFrontIcon":"cuIcon-attentionfavor","buttons":["新增","查看","修改","删除","查看评论"],"menu":"教室资讯","menuJump":"列表","tableName":"librarynotice"}],"menu":"教室资讯管理"},{"child":[{"appFrontIcon":"cuIcon-camera","buttons":["新增","查看","修改","删除"],"menu":"座位类型","menuJump":"列表","tableName":"libseattype"}],"menu":"座位类型管理"},{"child":[{"appFrontIcon":"cuIcon-link","buttons":["新增","查看","修改","删除","查看评论"],"menu":"座位预约","menuJump":"列表","tableName":"libseatinfo"}],"menu":"座位预约管理"},{"child":[{"appFrontIcon":"cuIcon-news","buttons":["新增","查看","修改","删除"],"menu":"公告信息","tableName":"news"},{"appFrontIcon":"cuIcon-service","buttons":["新增","查看","修改","删除"],"menu":"在线咨询","tableName":"chat"},{"appFrontIcon":"cuIcon-pay","buttons":["查看","修改"],"menu":"关于我们","tableName":"aboutus"},{"appFrontIcon":"cuIcon-goodsnew","buttons":["查看","修改"],"menu":"系统简介","tableName":"systemintro"},{"appFrontIcon":"cuIcon-pay","buttons":["新增","查看","修改","删除"],"menu":"轮播图管理","tableName":"config"}],"menu":"系统管理"},{"child":[{"appFrontIcon":"cuIcon-pic","buttons":["查看","删除"],"menu":"已取消预约","tableName":"orders/已取消"},{"appFrontIcon":"cuIcon-skin","buttons":["查看","删除"],"menu":"已取消预约","tableName":"orders/已取消"},{"appFrontIcon":"cuIcon-phone","buttons":["查看","删除"],"menu":"已使用预约","tableName":"orders/已使用"},{"appFrontIcon":"cuIcon-full","buttons":["查看","删除","日销量","月销量","日销额","月销额","年销额","年销量"],"menu":"已预约预约","tableName":"orders/已预约"},{"appFrontIcon":"cuIcon-form","buttons":["查看","删除","日销量","月销量","日销额","月销额","年销额","年销量"],"menu":"已完成预约","tableName":"orders/已完成"}],"menu":"预约管理"}],"frontMenu":[{"child":[{"appFrontIcon":"cuIcon-goodsnew","buttons":["查看"],"menu":"教室资讯列表","menuJump":"列表","tableName":"librarynotice"}],"menu":"教室资讯模块"},{"child":[{"appFrontIcon":"cuIcon-form","buttons":["查看"],"menu":"座位预约列表","menuJump":"列表","tableName":"libseatinfo"}],"menu":"座位预约模块"}],"hasBackLogin":"是","hasBackRegister":"否","hasFrontLogin":"否","hasFrontRegister":"否","roleName":"管理员","tableName":"admin"},{"backMenu":[],"frontMenu":[{"child":[{"appFrontIcon":"cuIcon-goodsnew","buttons":["查看"],"menu":"教室资讯列表","menuJump":"列表","tableName":"librarynotice"}],"menu":"教室资讯模块"},{"child":[{"appFrontIcon":"cuIcon-form","buttons":["查看"],"menu":"座位预约列表","menuJump":"列表","tableName":"libseatinfo"}],"menu":"座位预约模块"}],"hasBackLogin":"否","hasBackRegister":"否","hasFrontLogin":"是","hasFrontRegister":"是","roleName":"用户","tableName":"users"}],
				loginForm: {
					username: '',
					password: '',
					tableName: '',
					code: '',
					userRole: 'student', // 默认学生角色
				},
				role: '',
				roles: [],
				rules: {
					username: [
						{ required: true, message: '请输入账户', trigger: 'blur' }
					],
					password: [
						{ required: true, message: '请输入密码', trigger: 'blur' }
					],
					userRole: [
						{ required: true, message: '请选择角色', trigger: 'change' }
					]
				},
				codes: [{
					num: 1,
					color: '#000',
					rotate: '10deg',
					size: '16px'
				}, {
					num: 2,
					color: '#000',
					rotate: '10deg',
					size: '16px'
				}, {
					num: 3,
					color: '#000',
					rotate: '10deg',
					size: '16px'
				}, {
					num: 4,
					color: '#000',
					rotate: '10deg',
					size: '16px'
				}]
			}
		},
	  components: {
	  },
		created() {
			for(let item in this.roleMenus) {
				if(this.roleMenus[item].hasFrontLogin=='是') {
					this.roles.push(this.roleMenus[item]);
				}
			}
		},
		mounted() {
		},
		//方法集合
		methods: {
			randomString() {
				var len = 4;
				var chars = [
				  'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k',
				  'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
				  'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G',
				  'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
				  'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2',
				  '3', '4', '5', '6', '7', '8', '9'
				]
				var colors = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f']
				var sizes = ['14', '15', '16', '17', '18']
				
				var output = []
				for (var i = 0; i < len; i++) {
				  // 随机验证码
				  var key = Math.floor(Math.random() * chars.length)
				  this.codes[i].num = chars[key]
				  // 随机验证码颜色
				  var code = '#'
				  for (var j = 0; j < 6; j++) {
					var key = Math.floor(Math.random() * colors.length)
					code += colors[key]
				  }
				  this.codes[i].color = code
				  // 随机验证码方向
				  var rotate = Math.floor(Math.random() * 45)
				  var plus = Math.floor(Math.random() * 2)
				  if (plus == 1) rotate = '-' + rotate
				  this.codes[i].rotate = 'rotate(' + rotate + 'deg)'
				  // 随机验证码字体大小
				  var size = Math.floor(Math.random() * sizes.length)
				  this.codes[i].size = sizes[size] + 'px'
				}
			},
		  getCurrentRow(row) {
			this.role = row.roleName;
		  },
		  submitForm(formName) {
			if (this.roles.length!=1) {
				if (!this.role) {
					this.$message.error("请选择登录用户类型");
					return false;
				}
			} else {
				this.role = this.roles[0].roleName;
				this.loginForm.tableName = this.roles[0].tableName;
			}
			
			// 验证角色选择
			if (!this.loginForm.userRole) {
				this.$message.error("请选择角色（学生/教师）");
				return false;
			}
			
			this.$refs[formName].validate((valid) => {
			  if (valid) {
				// 将角色参数添加到请求中
				const loginParams = {
					...this.loginForm,
					role: this.loginForm.userRole
				};
				
				this.$http.get(`${this.loginForm.tableName}/login`, {params: loginParams}).then(res => {
				  if (res.data.code === 0) {
					localStorage.setItem('Token', res.data.token);
					localStorage.setItem('UserTableName', this.loginForm.tableName);
					localStorage.setItem('username', this.loginForm.username);
					localStorage.setItem('adminName', this.loginForm.username);
					localStorage.setItem('sessionTable', this.loginForm.tableName);
					localStorage.setItem('role', this.role);
					localStorage.setItem('userRole', this.loginForm.userRole); // 存储用户角色
					localStorage.setItem('keyPath', this.$config.indexNav.length+2);
					this.$router.push('/index/center');
					this.$message({
					  message: '登录成功',
					  type: 'success',
					  duration: 1500,
					});
				  } else {
					this.$message.error(res.data.msg);
				  }
				});
			  } else {
				return false;
			  }
			});
		  },
		  resetForm(formName) {
			this.$refs[formName].resetFields();
		  }
		}
	  }
	</script>
	
	<style rel="stylesheet/scss" lang="scss" scoped>
		.container {
			min-height: 100vh;
			display: flex;
			align-items: center;
			justify-content: center;
			width: 100%;
			background-color: #f0f7ff;
			background: url(../../assets/bg.jpg) no-repeat center top / 100% 100%;
			animation: fadeIn 1s ease-in-out;
		}
		
		@keyframes fadeIn {
			from {
				opacity: 0;
			}
			to {
				opacity: 1;
			}
		}
		
		.login-form {
			width: 880px;
			padding: 60px 40px 30px;
			margin: 0;
			background: rgba(255, 255, 255, 0.95);
			border-radius: 12px;
			box-shadow: 0 5px 20px rgba(106, 168, 230, 0.15);
			position: relative;
			display: flex;
			flex-wrap: wrap;
			justify-content: space-between;
			height: auto;
			border: 1px solid #e6f0fa;
		}
		
		.login-title {
			position: absolute;
			top: -25px;
			left: 10%;
			width: 80%;
			line-height: 50px;
			font-size: 20px;
			text-align: center;
			color: #4a90e2;
			background: #fff;
			border-radius: 8px;
			box-shadow: 0 3px 10px rgba(106, 168, 230, 0.1);
			border: 1px solid #e6f0fa;
			animation: slideDown 0.5s ease-out;
		}
		
		@keyframes slideDown {
			from {
				transform: translateY(-20px);
				opacity: 0;
			}
			to {
				transform: translateY(0);
				opacity: 1;
			}
		}
		
		.form-item {
			width: 67%;
			padding: 0 0 0 100px;
			margin: 0 0 24px;
			position: relative;
			display: flex;
			flex-wrap: wrap;
		}
		
		.form-label {
			position: absolute;
			left: -100px;
			width: 100px;
			line-height: 44px;
			font-size: 14px;
			text-align: right;
			color: #556677;
		}
		
		.form-input {
			width: 100%;
			height: 44px;
			padding: 0 15px;
			font-size: 14px;
			color: #333;
			border: 1px solid #b8d4f0;
			border-radius: 8px;
			outline: none;
			background-color: #fff;
			box-shadow: inset 0 1px 3px rgba(106, 168, 230, 0.1);
			transition: all 0.3s ease;
			
			&:focus {
				border-color: #6aa8e6;
				box-shadow: 0 0 0 3px rgba(106, 168, 230, 0.15);
			}
		}
		
		.form-select {
			width: 100%;
			
			::v-deep .el-input__inner {
				height: 44px;
				line-height: 44px;
				padding: 0 15px;
				font-size: 14px;
				color: #333;
				border: 1px solid #b8d4f0;
				border-radius: 8px;
				background-color: #fff;
				box-shadow: inset 0 1px 3px rgba(106, 168, 230, 0.1);
				transition: all 0.3s ease;
			}
			
			::v-deep .el-input__inner:focus {
				border-color: #6aa8e6;
				box-shadow: 0 0 0 3px rgba(106, 168, 230, 0.15);
			}
			
			::v-deep .el-input__icon {
				line-height: 44px;
			}
		}
		
		.form-type {
			width: 67%;
			padding: 0 0 0 100px;
			margin: 20px 0 10px;
			
			::v-deep .el-radio {
				margin-right: 20px;
			}
			
			::v-deep .el-radio__input .el-radio__inner {
				background: transparent;
				border-color: #6aa8e6;
			}
			
			::v-deep .el-radio__input.is-checked .el-radio__inner {
				background: #6aa8e6;
				border-color: #6aa8e6;
			}
			
			::v-deep .el-radio__label {
				color: #556677;
				font-size: 14px;
				transition: color 0.2s ease;
			}
			
			::v-deep .el-radio__input.is-checked + .el-radio__label {
				color: #6aa8e6;
				font-weight: 500;
			}
		}
		
		.form-actions {
			width: 67%;
			padding: 10px 0 0 100px;
			margin: 20px 0 0;
			display: flex;
			gap: 15px;
		}
		
		.login-button {
			flex: 1;
			height: 44px;
			padding: 0 20px;
			font-size: 16px;
			color: #fff;
			background-color: #6aa8e6;
			border: none;
			border-radius: 8px;
			cursor: pointer;
			transition: all 0.3s ease;
			box-shadow: 0 2px 5px rgba(106, 168, 230, 0.2);
			
			&:hover {
				background-color: #4a90e2;
				transform: translateY(-2px);
				box-shadow: 0 4px 8px rgba(106, 168, 230, 0.3);
			}
			
			&:active {
				transform: translateY(0);
				box-shadow: 0 2px 3px rgba(106, 168, 230, 0.2);
			}
		}
		
		.reset-button {
			flex: 1;
			height: 44px;
			padding: 0 20px;
			font-size: 16px;
			color: #6aa8e6;
			background-color: #f0f7ff;
			border: 1px solid #b8d4f0;
			border-radius: 8px;
			cursor: pointer;
			transition: all 0.3s ease;
			
			&:hover {
				background-color: #e1effa;
				transform: translateY(-2px);
				box-shadow: 0 2px 5px rgba(106, 168, 230, 0.1);
			}
			
			&:active {
				transform: translateY(0);
			}
		}
		
		.register-links {
			width: 25%;
			margin: 0 40px 0 0;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			position: absolute;
			top: 50%;
			right: 4px;
			transform: translateY(-50%);
			height: auto;
		}
		
		.register-link {
			width: 80%;
			margin: 10px 0;
			padding: 8px 10px;
			text-align: center;
			font-size: 14px;
			color: #4a90e2;
			background-color: #f0f7ff;
			border: 1px solid #b8d4f0;
			border-radius: 6px;
			text-decoration: none;
			transition: all 0.3s ease;
			
			&:hover {
				background-color: #e1effa;
				transform: translateX(5px);
				color: #3a80d2;
			}
		}
		
		::v-deep .el-form-item__content {
			width: 100%;
		}
	</style>
		