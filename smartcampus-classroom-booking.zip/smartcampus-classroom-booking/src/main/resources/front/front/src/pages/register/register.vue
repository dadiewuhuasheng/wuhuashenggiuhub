<template>
	<div>
		<div class="container">
			<el-form class='register-form' v-if="pageFlag=='register'" ref="registerForm" :model="registerForm" :rules="rules">
				<div class="register-title">智能化校园教室预约管理系统注册</div>
				
				<el-form-item class="form-item" v-if="tableName=='users'" prop="username">
					<div class="form-label">用户账号：</div>
					<input class="form-input" v-model="registerForm.username" placeholder="请输入用户账号" />
				</el-form-item>
				
				<el-form-item class="form-item" v-if="tableName=='users'" prop="password">
					<div class="form-label">密码：</div>
					<input class="form-input" v-model="registerForm.password" type="password" placeholder="请输入密码" />
				</el-form-item>
				
				<el-form-item class="form-item" v-if="tableName=='users'" prop="password2">
					<div class="form-label">确认密码：</div>
					<input class="form-input" v-model="registerForm.password2" type="password" placeholder="请再次输入密码" />
				</el-form-item>
				
				<el-form-item class="form-item" v-if="tableName=='users'" prop="nickname">
					<div class="form-label">用户姓名：</div>
					<input class="form-input" v-model="registerForm.nickname" placeholder="请输入用户姓名" />
				</el-form-item>
				
				<el-form-item class="form-item" v-if="tableName=='users'" prop="gender">
					<div class="form-label">性别：</div>
					<el-select v-model="registerForm.gender" placeholder="请选择性别" class="form-select">
						<el-option v-for="(item,index) in usersgenderOptions" :key="index" :label="item" :value="item"></el-option>
					</el-select>
				</el-form-item>
				
				<el-form-item class="form-item" v-if="tableName=='users'" prop="avatar">
					<div class="form-label">头像：</div>
					<file-upload
						tip="点击上传头像"
						action="file/upload"
						:limit="1"
						:multiple="true"
						:fileUrls="registerForm.avatar?registerForm.avatar:''"
						@change="usersavatarUploadChange"
					></file-upload>
				</el-form-item>
				
				<el-form-item class="form-item" v-if="tableName=='users'" prop="telephone">
					<div class="form-label">用户电话：</div>
					<input class="form-input" v-model="registerForm.telephone" placeholder="请输入用户电话" />
				</el-form-item>
				
				<el-form-item class="form-item" v-if="tableName=='users'" prop="role">
					<div class="form-label">角色：</div>
					<el-select v-model="registerForm.role" placeholder="请选择角色" class="form-select">
						<el-option label="学生" value="student"></el-option>
						<el-option label="教师" value="teacher"></el-option>
					</el-select>
				</el-form-item>
				
				<el-form-item class="form-actions">
					<el-button class="register-button" type="primary" @click="submitForm('registerForm')">注册</el-button>
					<el-button class="reset-button" @click="resetForm('registerForm')">重置</el-button>
				</el-form-item>
				
				<div class="login-link-container">
					<router-link class="login-link" to="/login">已有账户登录</router-link>
				</div>
			</el-form>
		</div>
	</div>
</template>

<script>

export default {
    //数据集合
    data() {
		return {
            pageFlag : '',
			tableName: '',
			registerForm: {
                gender: '',
                role: 'student', // 默认学生角色
            },
			rules: {},
            usersgenderOptions: [],
		}
    },
	mounted() {
	},
    created() {
      this.pageFlag = this.$route.query.pageFlag;
      this.tableName = this.$route.query.role;
      if ('users' == this.tableName) {
        this.rules.username = [{ required: true, message: '请输入用户账号', trigger: 'blur' }];
      }
      if ('users' == this.tableName) {
        this.rules.password = [{ required: true, message: '请输入密码', trigger: 'blur' }];
      }
        this.usersgenderOptions = "男,女".split(',');
      if ('users' == this.tableName) {
        this.rules.telephone = [{ required: true, validator: this.$validate.isMobile, trigger: 'blur' }];
      }
      if ('users' == this.tableName) {
        this.rules.role = [{ required: true, message: '请选择角色', trigger: 'change' }];
      }
      if ('users' == this.tableName) {
        this.rules.money = [{ required: true, validator: this.$validate.isNumber, trigger: 'blur' }];
      }
    },
    //方法集合
    methods: {
      // 获取uuid
      getUUID () {
        return new Date().getTime();
      },
        // 下二随
      usersavatarUploadChange(fileUrls) {
          this.registerForm.avatar = fileUrls.replace(new RegExp(this.$config.baseUrl,"g"),"");
      },

        // 多级联动参数


      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            var url=this.tableName+"/register";
               if(`users` == this.tableName && this.registerForm.password!=this.registerForm.password2) {
                this.$message.error(`两次密码输入不一致`);
                return
               }
            this.$http.post(url, this.registerForm).then(res => {
              if (res.data.code === 0) {
                this.$message({
                  message: '注册成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.$router.push('/login');
                  }
                });
              } else {
                this.$message.error(res.data.msg);
              }
            });
          } else {
            return false;
          }
        });
      },
      resetForm(formName) {
        this.$refs[formName].resetFields();
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
	.container {
		min-height: 100vh;
		display: flex;
		align-items: center;
		justify-content: center;
		width: 100%;
		background-color: #f0f7ff;
		background: url(../../assets/bg.jpg) no-repeat center top / 100% 100%;
		animation: fadeIn 1s ease-in-out;
	}
	
	@keyframes fadeIn {
		from {
			opacity: 0;
		}
		to {
			opacity: 1;
		}
	}
	
	.register-form {
		width: 880px;
		padding: 60px 40px 30px;
		margin: 0;
		background: rgba(255, 255, 255, 0.95);
		border-radius: 12px;
		box-shadow: 0 5px 20px rgba(106, 168, 230, 0.15);
		position: relative;
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		height: auto;
		border: 1px solid #e6f0fa;
	}
	
	.register-title {
		position: absolute;
		top: -25px;
		left: 10%;
		width: 80%;
		line-height: 50px;
		font-size: 20px;
		text-align: center;
		color: #4a90e2;
		background: #fff;
		border-radius: 8px;
		box-shadow: 0 3px 10px rgba(106, 168, 230, 0.1);
		border: 1px solid #e6f0fa;
		animation: slideDown 0.5s ease-out;
	}
	
	@keyframes slideDown {
		from {
			transform: translateY(-20px);
			opacity: 0;
		}
		to {
			transform: translateY(0);
			opacity: 1;
		}
	}
	
	.form-item {
		width: 100%;
		padding: 0 0 0 120px;
		margin: 0 0 24px;
		position: relative;
		display: flex;
		flex-wrap: wrap;
	}
	
	.form-label {
		position: absolute;
		left: -120px;
		width: 120px;
		line-height: 44px;
		font-size: 14px;
		text-align: right;
		color: #556677;
		padding-right: 10px;
	}
	
	.form-input {
		width: 100%;
		height: 44px;
		padding: 0 15px;
		font-size: 14px;
		color: #333;
		border: 1px solid #b8d4f0;
		border-radius: 8px;
		outline: none;
		background-color: #fff;
		box-shadow: inset 0 1px 3px rgba(106, 168, 230, 0.1);
		transition: all 0.3s ease;
		
		&:focus {
			border-color: #6aa8e6;
			box-shadow: 0 0 0 3px rgba(106, 168, 230, 0.15);
		}
	}
	
	.form-select {
		width: 100%;
		
		::v-deep .el-input__inner {
			height: 44px;
			line-height: 44px;
			padding: 0 15px;
			font-size: 14px;
			color: #333;
			border: 1px solid #b8d4f0;
			border-radius: 8px;
			background-color: #fff;
			box-shadow: inset 0 1px 3px rgba(106, 168, 230, 0.1);
			transition: all 0.3s ease;
		}
		
		::v-deep .el-input__inner:focus {
			border-color: #6aa8e6;
			box-shadow: 0 0 0 3px rgba(106, 168, 230, 0.15);
		}
		
		::v-deep .el-input__icon {
			line-height: 44px;
		}
	}
	
	.form-actions {
		width: 100%;
		padding: 10px 0 0 120px;
		margin: 20px 0 0;
		display: flex;
		gap: 15px;
	}
	
	.register-button {
		flex: 1;
		height: 44px;
		padding: 0 20px;
		font-size: 16px;
		color: #fff;
		background-color: #6aa8e6;
		border: none;
		border-radius: 8px;
		cursor: pointer;
		transition: all 0.3s ease;
		box-shadow: 0 2px 5px rgba(106, 168, 230, 0.2);
		
		&:hover {
			background-color: #4a90e2;
			transform: translateY(-2px);
			box-shadow: 0 4px 8px rgba(106, 168, 230, 0.3);
		}
		
		&:active {
			transform: translateY(0);
			box-shadow: 0 2px 3px rgba(106, 168, 230, 0.2);
		}
	}
	
	.reset-button {
		flex: 1;
		height: 44px;
		padding: 0 20px;
		font-size: 16px;
		color: #6aa8e6;
		background-color: #f0f7ff;
		border: 1px solid #b8d4f0;
		border-radius: 8px;
		cursor: pointer;
		transition: all 0.3s ease;
		
		&:hover {
			background-color: #e1effa;
			transform: translateY(-2px);
			box-shadow: 0 2px 5px rgba(106, 168, 230, 0.1);
		}
		
		&:active {
			transform: translateY(0);
		}
	}
	
	.login-link-container {
		width: 100%;
		text-align: center;
		padding: 10px 0 0 120px;
		margin-top: 10px;
	}
	
	.login-link {
		color: #4a90e2;
		font-size: 14px;
		text-decoration: none;
		transition: all 0.3s ease;
		
		&:hover {
			color: #3a80d2;
			text-decoration: underline;
		}
	}
	
	::v-deep .el-form-item__content {
		width: 100%;
	}
	
	::v-deep .el-upload--picture-card {
		background: transparent;
		border: 1px dashed #b8d4f0;
		border-radius: 8px;
		width: 100px;
		height: 100px;
		line-height: 100px;
		transition: all 0.3s ease;
		
		&:hover {
			border-color: #6aa8e6;
		}
	}
	
	::v-deep .upload .upload-img {
		border: 1px dashed #b8d4f0;
		cursor: pointer;
		border-radius: 8px;
		color: #6aa8e6;
		width: 100px;
		font-size: 32px;
		line-height: 100px;
		text-align: center;
		height: 100px;
		transition: all 0.3s ease;
		
		&:hover {
			border-color: #6aa8e6;
			background-color: #f0f7ff;
		}
	}
	
	::v-deep .el-upload-list .el-upload-list__item {
		border: 1px dashed #b8d4f0;
		border-radius: 8px;
		width: 100px;
		height: 100px;
		transition: all 0.3s ease;
	}
	
	::v-deep .el-upload .el-icon-plus {
		color: #6aa8e6;
		font-size: 32px;
	}
</style>
