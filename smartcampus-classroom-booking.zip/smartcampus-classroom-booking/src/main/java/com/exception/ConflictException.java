package com.exception;

/**
 * 冲突异常
 * 当预约时间与现有预约冲突时抛出
 * 
 * @author 
 * @email 
 */
public class ConflictException extends RuntimeException {
    
    private static final long serialVersionUID = 1L;
    
    private String conflictDetails;
    
    public ConflictException(String message) {
        super(message);
    }
    
    public ConflictException(String message, String conflictDetails) {
        super(message);
        this.conflictDetails = conflictDetails;
    }
    
    public ConflictException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public ConflictException(String message, String conflictDetails, Throwable cause) {
        super(message, cause);
        this.conflictDetails = conflictDetails;
    }
    
    public String getConflictDetails() {
        return conflictDetails;
    }
    
    public void setConflictDetails(String conflictDetails) {
        this.conflictDetails = conflictDetails;
    }
}
