package com.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.entity.AuditLogEntity;

/**
 * 审计日志
 * 数据库访问层
 * @author 
 * @email 
 */
public interface AuditLogDao extends BaseMapper<AuditLogEntity> {
    
}
