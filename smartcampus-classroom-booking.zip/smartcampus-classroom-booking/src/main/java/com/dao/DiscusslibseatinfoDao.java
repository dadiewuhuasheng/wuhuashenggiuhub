package com.dao;

import com.entity.DiscusslibseatinfoEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.DiscusslibseatinfoVO;
import com.entity.view.DiscusslibseatinfoView;


/**
 * 座位信息评论表
 * 
 * @author 
 * @email 
 */
public interface DiscusslibseatinfoDao extends BaseMapper<DiscusslibseatinfoEntity> {
	
	List<DiscusslibseatinfoVO> selectListVO(@Param("ew") Wrapper<DiscusslibseatinfoEntity> wrapper);
	
	DiscusslibseatinfoVO selectVO(@Param("ew") Wrapper<DiscusslibseatinfoEntity> wrapper);
	
	List<DiscusslibseatinfoView> selectListView(@Param("ew") Wrapper<DiscusslibseatinfoEntity> wrapper);

	List<DiscusslibseatinfoView> selectListView(Pagination page,@Param("ew") Wrapper<DiscusslibseatinfoEntity> wrapper);
	
	DiscusslibseatinfoView selectView(@Param("ew") Wrapper<DiscusslibseatinfoEntity> wrapper);
	

}
