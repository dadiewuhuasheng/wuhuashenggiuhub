package com.dao;

import com.entity.NoticetypeEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.NoticetypeVO;
import com.entity.view.NoticetypeView;


/**
 * 座位类型
 * 
 * @author 
 * @email 
 */
public interface NoticetypeDao extends BaseMapper<NoticetypeEntity> {
	
	List<NoticetypeVO> selectListVO(@Param("ew") Wrapper<NoticetypeEntity> wrapper);
	
	NoticetypeVO selectVO(@Param("ew") Wrapper<NoticetypeEntity> wrapper);
	
	List<NoticetypeView> selectListView(@Param("ew") Wrapper<NoticetypeEntity> wrapper);

	List<NoticetypeView> selectListView(Pagination page,@Param("ew") Wrapper<NoticetypeEntity> wrapper);
	
	NoticetypeView selectView(@Param("ew") Wrapper<NoticetypeEntity> wrapper);
	

}
