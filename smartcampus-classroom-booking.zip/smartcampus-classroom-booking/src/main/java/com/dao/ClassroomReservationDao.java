package com.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;
import com.entity.ClassroomReservationEntity;
import com.entity.view.ClassroomReservationView;
import com.entity.vo.ClassroomReservationVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 教室预约
 * 数据库访问层
 * @author 
 * @email 
 */
public interface ClassroomReservationDao extends BaseMapper<ClassroomReservationEntity> {
    
    List<ClassroomReservationVO> selectListVO(@Param("ew") Wrapper<ClassroomReservationEntity> wrapper);
    
    ClassroomReservationVO selectVO(@Param("ew") Wrapper<ClassroomReservationEntity> wrapper);
    
    List<ClassroomReservationView> selectListView(@Param("ew") Wrapper<ClassroomReservationEntity> wrapper);
    
    List<ClassroomReservationView> selectListView(Pagination page, @Param("ew") Wrapper<ClassroomReservationEntity> wrapper);
    
    ClassroomReservationView selectView(@Param("ew") Wrapper<ClassroomReservationEntity> wrapper);
}
