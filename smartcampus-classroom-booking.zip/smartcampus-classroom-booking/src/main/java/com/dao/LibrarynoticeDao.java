package com.dao;

import com.entity.LibrarynoticeEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.LibrarynoticeVO;
import com.entity.view.LibrarynoticeView;


/**
 * 教室宣传
 * 
 * @author 
 * @email 
 */
public interface LibrarynoticeDao extends BaseMapper<LibrarynoticeEntity> {
	
	List<LibrarynoticeVO> selectListVO(@Param("ew") Wrapper<LibrarynoticeEntity> wrapper);
	
	LibrarynoticeVO selectVO(@Param("ew") Wrapper<LibrarynoticeEntity> wrapper);
	
	List<LibrarynoticeView> selectListView(@Param("ew") Wrapper<LibrarynoticeEntity> wrapper);

	List<LibrarynoticeView> selectListView(Pagination page,@Param("ew") Wrapper<LibrarynoticeEntity> wrapper);
	
	LibrarynoticeView selectView(@Param("ew") Wrapper<LibrarynoticeEntity> wrapper);
	

}
