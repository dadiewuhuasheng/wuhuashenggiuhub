package com.dao;

import com.entity.LibseatinfoEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.LibseatinfoVO;
import com.entity.view.LibseatinfoView;


/**
 * 座位信息
 * 
 * @author 
 * @email 
 */
public interface LibseatinfoDao extends BaseMapper<LibseatinfoEntity> {
	
	List<LibseatinfoVO> selectListVO(@Param("ew") Wrapper<LibseatinfoEntity> wrapper);
	
	LibseatinfoVO selectVO(@Param("ew") Wrapper<LibseatinfoEntity> wrapper);
	
	List<LibseatinfoView> selectListView(@Param("ew") Wrapper<LibseatinfoEntity> wrapper);

	List<LibseatinfoView> selectListView(Pagination page,@Param("ew") Wrapper<LibseatinfoEntity> wrapper);
	
	LibseatinfoView selectView(@Param("ew") Wrapper<LibseatinfoEntity> wrapper);
	

}
