package com.dao;

import com.entity.DiscusslibrarynoticeEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.DiscusslibrarynoticeVO;
import com.entity.view.DiscusslibrarynoticeView;


/**
 * 教室宣传评论表
 * 
 * @author 
 * @email 
 */
public interface DiscusslibrarynoticeDao extends BaseMapper<DiscusslibrarynoticeEntity> {
	
	List<DiscusslibrarynoticeVO> selectListVO(@Param("ew") Wrapper<DiscusslibrarynoticeEntity> wrapper);
	
	DiscusslibrarynoticeVO selectVO(@Param("ew") Wrapper<DiscusslibrarynoticeEntity> wrapper);
	
	List<DiscusslibrarynoticeView> selectListView(@Param("ew") Wrapper<DiscusslibrarynoticeEntity> wrapper);

	List<DiscusslibrarynoticeView> selectListView(Pagination page,@Param("ew") Wrapper<DiscusslibrarynoticeEntity> wrapper);
	
	DiscusslibrarynoticeView selectView(@Param("ew") Wrapper<DiscusslibrarynoticeEntity> wrapper);
	

}
