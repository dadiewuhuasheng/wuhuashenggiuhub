package com.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.entity.NotificationEntity;
import org.apache.ibatis.annotations.Param;

/**
 * 通知
 * 数据库访问层
 * @author 
 * @email 
 */
public interface NotificationDao extends BaseMapper<NotificationEntity> {
    
    /**
     * 获取用户未读通知数量
     * @param userId 用户ID
     * @return 未读通知数量
     */
    Integer getUnreadCount(@Param("userId") Long userId);
}
