package com.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;
import com.entity.AddressEntity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 地址
 */
public interface AddressDao extends BaseMapper<AddressEntity> {
    
    List<AddressEntity> selectListVO(@Param("ew") Wrapper<AddressEntity> wrapper);
    
    AddressEntity selectVO(@Param("ew") Wrapper<AddressEntity> wrapper);
    
    List<AddressEntity> selectListView(@Param("ew") Wrapper<AddressEntity> wrapper);

    List<AddressEntity> selectListView(Pagination page, @Param("ew") Wrapper<AddressEntity> wrapper);

    AddressEntity selectView(@Param("ew") Wrapper<AddressEntity> wrapper);
}
