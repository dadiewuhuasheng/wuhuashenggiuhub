package com.dao;

import com.entity.LibseattypeEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.LibseattypeVO;
import com.entity.view.LibseattypeView;


/**
 * 座位类型
 * 
 * @author 
 * @email 
 */
public interface LibseattypeDao extends BaseMapper<LibseattypeEntity> {
	
	List<LibseattypeVO> selectListVO(@Param("ew") Wrapper<LibseattypeEntity> wrapper);
	
	LibseattypeVO selectVO(@Param("ew") Wrapper<LibseattypeEntity> wrapper);
	
	List<LibseattypeView> selectListView(@Param("ew") Wrapper<LibseattypeEntity> wrapper);

	List<LibseattypeView> selectListView(Pagination page,@Param("ew") Wrapper<LibseattypeEntity> wrapper);
	
	LibseattypeView selectView(@Param("ew") Wrapper<LibseattypeEntity> wrapper);
	

}
