package com.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.lang.reflect.InvocationTargetException;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.beanutils.BeanUtils;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.baomidou.mybatisplus.enums.IdType;


/**
 * 教室宣传
 * 数据库通用操作实体类（普通增删改查）
 * @author 
 * @email 
 */
@TableName("librarynotice")
public class LibrarynoticeEntity<T> implements Serializable {
	private static final long serialVersionUID = 1L;


	public LibrarynoticeEntity() {
		
	}
	
	public LibrarynoticeEntity(T t) {
		try {
			BeanUtils.copyProperties(this, t);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 主键id
	 */
	@TableId
	private Long id;
	/**
	 * 座位编号
	 */
					
	private String noticeno;
	
	/**
	 * 座位标题
	 */
					
	private String noticetitle;
	
	/**
	 * 座位类型
	 */
					
	private String noticetype;
	
	/**
	 * 封面
	 */
					
	private String picture;
	
	/**
	 * 座位简介
	 */
					
	private String noticeintro;
	
	/**
	 * 座位详情
	 */
					
	private String noticecontent;
	
	/**
	 * 发布时间
	 */
				
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
	@DateTimeFormat 		
	private Date updatetime;
	
	
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat
	private Date addtime;

	public Date getAddtime() {
		return addtime;
	}
	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 设置：座位编号
	 */
	public void setNoticeno(String noticeno) {
		this.noticeno = noticeno;
	}
	/**
	 * 获取：座位编号
	 */
	public String getNoticeno() {
		return noticeno;
	}
	/**
	 * 设置：座位标题
	 */
	public void setNoticetitle(String noticetitle) {
		this.noticetitle = noticetitle;
	}
	/**
	 * 获取：座位标题
	 */
	public String getNoticetitle() {
		return noticetitle;
	}
	/**
	 * 设置：座位类型
	 */
	public void setNoticetype(String noticetype) {
		this.noticetype = noticetype;
	}
	/**
	 * 获取：座位类型
	 */
	public String getNoticetype() {
		return noticetype;
	}
	/**
	 * 设置：封面
	 */
	public void setPicture(String picture) {
		this.picture = picture;
	}
	/**
	 * 获取：封面
	 */
	public String getPicture() {
		return picture;
	}
	/**
	 * 设置：座位简介
	 */
	public void setNoticeintro(String noticeintro) {
		this.noticeintro = noticeintro;
	}
	/**
	 * 获取：座位简介
	 */
	public String getNoticeintro() {
		return noticeintro;
	}
	/**
	 * 设置：座位详情
	 */
	public void setNoticecontent(String noticecontent) {
		this.noticecontent = noticecontent;
	}
	/**
	 * 获取：座位详情
	 */
	public String getNoticecontent() {
		return noticecontent;
	}
	/**
	 * 设置：发布时间
	 */
	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}
	/**
	 * 获取：发布时间
	 */
	public Date getUpdatetime() {
		return updatetime;
	}

}
