package com.entity.view;

import com.entity.DiscusslibrarynoticeEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import org.apache.commons.beanutils.BeanUtils;
import java.lang.reflect.InvocationTargetException;

import java.io.Serializable;
 

/**
 * 教室宣传评论表
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 */
@TableName("discusslibrarynotice")
public class DiscusslibrarynoticeView  extends DiscusslibrarynoticeEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public DiscusslibrarynoticeView(){
	}
 
 	public DiscusslibrarynoticeView(DiscusslibrarynoticeEntity discusslibrarynoticeEntity){
 	try {
			BeanUtils.copyProperties(this, discusslibrarynoticeEntity);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}
}
