package com.entity.view;

import com.entity.LibrarynoticeEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import org.apache.commons.beanutils.BeanUtils;
import java.lang.reflect.InvocationTargetException;

import java.io.Serializable;
 

/**
 * 教室宣传
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 */
@TableName("librarynotice")
public class LibrarynoticeView  extends LibrarynoticeEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public LibrarynoticeView(){
	}
 
 	public LibrarynoticeView(LibrarynoticeEntity librarynoticeEntity){
 	try {
			BeanUtils.copyProperties(this, librarynoticeEntity);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}
}
