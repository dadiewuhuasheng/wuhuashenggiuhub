package com.entity.view;

import com.entity.NotificationEntity;
import com.baomidou.mybatisplus.annotations.TableName;
import org.apache.commons.beanutils.BeanUtils;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;

/**
 * 通知
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 */
@TableName("notification")
public class NotificationView extends NotificationEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    public NotificationView() {
    }

    public NotificationView(NotificationEntity notificationEntity) {
        try {
            BeanUtils.copyProperties(this, notificationEntity);
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}
