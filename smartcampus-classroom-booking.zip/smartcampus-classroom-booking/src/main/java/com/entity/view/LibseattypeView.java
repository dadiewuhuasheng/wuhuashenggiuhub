package com.entity.view;

import com.entity.LibseattypeEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import org.apache.commons.beanutils.BeanUtils;
import java.lang.reflect.InvocationTargetException;

import java.io.Serializable;
 

/**
 * 座位类型
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 */
@TableName("libseattype")
public class LibseattypeView  extends LibseattypeEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public LibseattypeView(){
	}
 
 	public LibseattypeView(LibseattypeEntity libseattypeEntity){
 	try {
			BeanUtils.copyProperties(this, libseattypeEntity);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}
}
