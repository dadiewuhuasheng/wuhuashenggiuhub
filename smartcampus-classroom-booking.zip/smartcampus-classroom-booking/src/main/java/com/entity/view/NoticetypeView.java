package com.entity.view;

import com.entity.NoticetypeEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import org.apache.commons.beanutils.BeanUtils;
import java.lang.reflect.InvocationTargetException;

import java.io.Serializable;
 

/**
 * 座位类型
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 */
@TableName("noticetype")
public class NoticetypeView  extends NoticetypeEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public NoticetypeView(){
	}
 
 	public NoticetypeView(NoticetypeEntity noticetypeEntity){
 	try {
			BeanUtils.copyProperties(this, noticetypeEntity);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}
}
