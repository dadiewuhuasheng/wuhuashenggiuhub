package com.entity.view;

import com.entity.DiscusslibseatinfoEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import org.apache.commons.beanutils.BeanUtils;
import java.lang.reflect.InvocationTargetException;

import java.io.Serializable;
 

/**
 * 座位信息评论表
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 */
@TableName("discusslibseatinfo")
public class DiscusslibseatinfoView  extends DiscusslibseatinfoEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public DiscusslibseatinfoView(){
	}
 
 	public DiscusslibseatinfoView(DiscusslibseatinfoEntity discusslibseatinfoEntity){
 	try {
			BeanUtils.copyProperties(this, discusslibseatinfoEntity);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}
}
