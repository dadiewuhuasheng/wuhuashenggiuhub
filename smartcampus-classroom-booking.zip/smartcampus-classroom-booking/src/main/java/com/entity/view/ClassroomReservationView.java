package com.entity.view;

import com.entity.ClassroomReservationEntity;
import com.baomidou.mybatisplus.annotations.TableName;
import org.apache.commons.beanutils.BeanUtils;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;

/**
 * 教室预约
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 */
@TableName("classroom_reservation")
public class ClassroomReservationView extends ClassroomReservationEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    public ClassroomReservationView() {
    }

    public ClassroomReservationView(ClassroomReservationEntity classroomReservationEntity) {
        try {
            BeanUtils.copyProperties(this, classroomReservationEntity);
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}
