package com.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 分配结果实体
 * 用于贪心算法的输出
 * 
 * @author 
 * @email 
 */
public class AllocationResult implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private List<ReservationRequest> allocated;
    private List<ReservationRequest> rejected;
    private int totalRequests;
    private int allocatedCount;
    private int rejectedCount;
    
    public AllocationResult() {
        this.allocated = new ArrayList<>();
        this.rejected = new ArrayList<>();
        this.totalRequests = 0;
        this.allocatedCount = 0;
        this.rejectedCount = 0;
    }
    
    public void addAllocated(ReservationRequest request) {
        this.allocated.add(request);
        this.allocatedCount++;
        this.totalRequests++;
    }
    
    public void addRejected(ReservationRequest request) {
        this.rejected.add(request);
        this.rejectedCount++;
        this.totalRequests++;
    }

    public List<ReservationRequest> getAllocated() {
        return allocated;
    }

    public void setAllocated(List<ReservationRequest> allocated) {
        this.allocated = allocated;
        this.allocatedCount = allocated != null ? allocated.size() : 0;
    }

    public List<ReservationRequest> getRejected() {
        return rejected;
    }

    public void setRejected(List<ReservationRequest> rejected) {
        this.rejected = rejected;
        this.rejectedCount = rejected != null ? rejected.size() : 0;
    }

    public int getTotalRequests() {
        return totalRequests;
    }

    public void setTotalRequests(int totalRequests) {
        this.totalRequests = totalRequests;
    }

    public int getAllocatedCount() {
        return allocatedCount;
    }

    public void setAllocatedCount(int allocatedCount) {
        this.allocatedCount = allocatedCount;
    }

    public int getRejectedCount() {
        return rejectedCount;
    }

    public void setRejectedCount(int rejectedCount) {
        this.rejectedCount = rejectedCount;
    }
}
