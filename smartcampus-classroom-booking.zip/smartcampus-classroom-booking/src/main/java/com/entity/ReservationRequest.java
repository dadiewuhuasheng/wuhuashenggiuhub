package com.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 预约请求实体
 * 用于贪心算法的输入
 * 
 * @author 
 * @email 
 */
public class ReservationRequest implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private Long userId;
    private String username;
    private String userRole;
    private Long resourceId;
    private String resourceName;
    private Date startTime;
    private Date endTime;
    private String purpose;
    
    public ReservationRequest() {
    }
    
    public ReservationRequest(Long userId, String userRole, Long resourceId, Date startTime, Date endTime) {
        this.userId = userId;
        this.userRole = userRole;
        this.resourceId = resourceId;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserRole() {
        return userRole;
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

    public Long getResourceId() {
        return resourceId;
    }

    public void setResourceId(Long resourceId) {
        this.resourceId = resourceId;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }
    
    /**
     * 计算预约时长（毫秒）
     */
    public long getDuration() {
        if (startTime == null || endTime == null) {
            return 0;
        }
        return endTime.getTime() - startTime.getTime();
    }
}
