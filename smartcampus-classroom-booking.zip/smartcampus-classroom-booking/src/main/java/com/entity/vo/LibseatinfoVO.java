package com.entity.vo;

import com.entity.LibseatinfoEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 座位信息
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 */
public class LibseatinfoVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 座位类型
	 */
	
	private String libseattype;
		
	/**
	 * 座位封面
	 */
	
	private String libseatpicture;
		

		
	/**
	 * 座位地区
	 */
	
	private String libseataddress;
		

		
	/**
	 * 座位简介
	 */
	
	private String libseatintro;
		
	/**
	 * 座位时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date shangyingtime;
		
	/**
	 * 赞
	 */
	
	private Integer thumbsupnum;
		
	/**
	 * 踩
	 */
	
	private Integer crazilynum;
		
	/**
	 * 最近点击时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date clicktime;
		
	/**
	 * 点击次数
	 */
	
	private Integer clicknum;
		
	/**
	 * 价格
	 */
	
	private Float price;
		
	/**
	 * 座位总数
	 */
	
	private Integer number;
		
	/**
	 * 已选座位[用,号隔开]
	 */
	
	private String selected;
				
	
	/**
	 * 设置：座位类型
	 */
	 
	public void setLibseattype(String libseattype) {
		this.libseattype = libseattype;
	}
	
	/**
	 * 获取：座位类型
	 */
	public String getLibseattype() {
		return libseattype;
	}
				
	
	/**
	 * 设置：座位封面
	 */
	 
	public void setLibseatpicture(String libseatpicture) {
		this.libseatpicture = libseatpicture;
	}
	
	/**
	 * 获取：座位封面
	 */
	public String getLibseatpicture() {
		return libseatpicture;
	}
				
	

				
	
	/**
	 * 设置：座位地区
	 */
	 
	public void setLibseataddress(String libseataddress) {
		this.libseataddress = libseataddress;
	}
	
	/**
	 * 获取：座位地区
	 */
	public String getLibseataddress() {
		return libseataddress;
	}

				
	
	/**
	 * 设置：座位简介
	 */
	 
	public void setLibseatintro(String libseatintro) {
		this.libseatintro = libseatintro;
	}
	
	/**
	 * 获取：座位简介
	 */
	public String getLibseatintro() {
		return libseatintro;
	}
				
	
	/**
	 * 设置：座位时间
	 */
	 
	public void setShangyingtime(Date shangyingtime) {
		this.shangyingtime = shangyingtime;
	}
	
	/**
	 * 获取：座位时间
	 */
	public Date getShangyingtime() {
		return shangyingtime;
	}
				
	
	/**
	 * 设置：赞
	 */
	 
	public void setThumbsupnum(Integer thumbsupnum) {
		this.thumbsupnum = thumbsupnum;
	}
	
	/**
	 * 获取：赞
	 */
	public Integer getThumbsupnum() {
		return thumbsupnum;
	}
				
	
	/**
	 * 设置：踩
	 */
	 
	public void setCrazilynum(Integer crazilynum) {
		this.crazilynum = crazilynum;
	}
	
	/**
	 * 获取：踩
	 */
	public Integer getCrazilynum() {
		return crazilynum;
	}
				
	
	/**
	 * 设置：最近点击时间
	 */
	 
	public void setClicktime(Date clicktime) {
		this.clicktime = clicktime;
	}
	
	/**
	 * 获取：最近点击时间
	 */
	public Date getClicktime() {
		return clicktime;
	}
				
	
	/**
	 * 设置：点击次数
	 */
	 
	public void setClicknum(Integer clicknum) {
		this.clicknum = clicknum;
	}
	
	/**
	 * 获取：点击次数
	 */
	public Integer getClicknum() {
		return clicknum;
	}
				
	
	/**
	 * 设置：价格
	 */
	 
	public void setPrice(Float price) {
		this.price = price;
	}
	
	/**
	 * 获取：价格
	 */
	public Float getPrice() {
		return price;
	}
				
	
	/**
	 * 设置：座位总数
	 */
	 
	public void setNumber(Integer number) {
		this.number = number;
	}
	
	/**
	 * 获取：座位总数
	 */
	public Integer getNumber() {
		return number;
	}
				
	
	/**
	 * 设置：已选座位[用,号隔开]
	 */
	 
	public void setSelected(String selected) {
		this.selected = selected;
	}
	
	/**
	 * 获取：已选座位[用,号隔开]
	 */
	public String getSelected() {
		return selected;
	}
			
}
