package com.entity.vo;

import com.entity.LibrarynoticeEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 教室宣传
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 */
public class LibrarynoticeVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 座位标题
	 */
	
	private String noticetitle;
		
	/**
	 * 座位类型
	 */
	
	private String noticetype;
		
	/**
	 * 封面
	 */
	
	private String picture;
		
	/**
	 * 座位简介
	 */
	
	private String noticeintro;
		
	/**
	 * 座位详情
	 */
	
	private String noticecontent;
		
	/**
	 * 发布时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date updatetime;
				
	
	/**
	 * 设置：座位标题
	 */
	 
	public void setNoticetitle(String noticetitle) {
		this.noticetitle = noticetitle;
	}
	
	/**
	 * 获取：座位标题
	 */
	public String getNoticetitle() {
		return noticetitle;
	}
				
	
	/**
	 * 设置：座位类型
	 */
	 
	public void setNoticetype(String noticetype) {
		this.noticetype = noticetype;
	}
	
	/**
	 * 获取：座位类型
	 */
	public String getNoticetype() {
		return noticetype;
	}
				
	
	/**
	 * 设置：封面
	 */
	 
	public void setPicture(String picture) {
		this.picture = picture;
	}
	
	/**
	 * 获取：封面
	 */
	public String getPicture() {
		return picture;
	}
				
	
	/**
	 * 设置：座位简介
	 */
	 
	public void setNoticeintro(String noticeintro) {
		this.noticeintro = noticeintro;
	}
	
	/**
	 * 获取：座位简介
	 */
	public String getNoticeintro() {
		return noticeintro;
	}
				
	
	/**
	 * 设置：座位详情
	 */
	 
	public void setNoticecontent(String noticecontent) {
		this.noticecontent = noticecontent;
	}
	
	/**
	 * 获取：座位详情
	 */
	public String getNoticecontent() {
		return noticecontent;
	}
				
	
	/**
	 * 设置：发布时间
	 */
	 
	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}
	
	/**
	 * 获取：发布时间
	 */
	public Date getUpdatetime() {
		return updatetime;
	}
			
}
