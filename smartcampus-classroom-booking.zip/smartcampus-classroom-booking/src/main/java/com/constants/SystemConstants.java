package com.constants;

/**
 * 系统常量
 * 
 * @author 
 * @email 
 */
public class SystemConstants {
    
    // ==================== 用户角色 ====================
    
    /**
     * 学生角色
     */
    public static final String ROLE_STUDENT = "student";
    
    /**
     * 教师角色
     */
    public static final String ROLE_TEACHER = "teacher";
    
    /**
     * 学生角色（中文）
     */
    public static final String ROLE_STUDENT_CN = "学生";
    
    /**
     * 教师角色（中文）
     */
    public static final String ROLE_TEACHER_CN = "教师";
    
    // ==================== 预约状态 ====================
    
    /**
     * 待审核
     */
    public static final String STATUS_PENDING = "pending";
    
    /**
     * 已批准
     */
    public static final String STATUS_APPROVED = "approved";
    
    /**
     * 已取消
     */
    public static final String STATUS_CANCELLED = "cancelled";
    
    /**
     * 已完成
     */
    public static final String STATUS_COMPLETED = "completed";
    
    /**
     * 已取消（中文）
     */
    public static final String STATUS_CANCELLED_CN = "已取消";
    
    /**
     * 已完成（中文）
     */
    public static final String STATUS_COMPLETED_CN = "已完成";
    
    // ==================== 通知类型 ====================
    
    /**
     * 取消通知
     */
    public static final String NOTIFICATION_TYPE_CANCELLATION = "cancellation";
    
    /**
     * 批准通知
     */
    public static final String NOTIFICATION_TYPE_APPROVAL = "approval";
    
    /**
     * 提醒通知
     */
    public static final String NOTIFICATION_TYPE_REMINDER = "reminder";
    
    // ==================== 预约类型 ====================
    
    /**
     * 座位预约
     */
    public static final String RESERVATION_TYPE_SEAT = "seat";
    
    /**
     * 教室预约
     */
    public static final String RESERVATION_TYPE_CLASSROOM = "classroom";
    
    // ==================== 审计日志操作类型 ====================
    
    /**
     * 创建操作
     */
    public static final String ACTION_CREATE = "create";
    
    /**
     * 更新操作
     */
    public static final String ACTION_UPDATE = "update";
    
    /**
     * 取消操作
     */
    public static final String ACTION_CANCEL = "cancel";
    
    /**
     * 删除操作
     */
    public static final String ACTION_DELETE = "delete";
    
    // ==================== 资源类型 ====================
    
    /**
     * 座位资源
     */
    public static final String RESOURCE_TYPE_SEAT = "seat";
    
    /**
     * 教室资源
     */
    public static final String RESOURCE_TYPE_CLASSROOM = "classroom";
    
    // ==================== 表名 ====================
    
    /**
     * 座位信息表
     */
    public static final String TABLE_LIBSEATINFO = "libseatinfo";
    
    /**
     * 用户表
     */
    public static final String TABLE_USERS = "users";
    
    /**
     * 订单表
     */
    public static final String TABLE_ORDERS = "orders";
    
    /**
     * 教室预约表
     */
    public static final String TABLE_CLASSROOM_RESERVATION = "classroom_reservation";
    
    /**
     * 通知表
     */
    public static final String TABLE_NOTIFICATION = "notification";
    
    /**
     * 审计日志表
     */
    public static final String TABLE_AUDIT_LOG = "audit_log";
    
    // ==================== 时间配置 ====================
    
    /**
     * 工作开始时间（小时）
     */
    public static final int WORK_START_HOUR = 8;
    
    /**
     * 工作结束时间（小时）
     */
    public static final int WORK_END_HOUR = 22;
    
    /**
     * 最大预约时长（小时）
     */
    public static final int MAX_RESERVATION_HOURS = 8;
    
    /**
     * 最小预约时长（分钟）
     */
    public static final int MIN_RESERVATION_MINUTES = 30;
    
    /**
     * 提前预约天数
     */
    public static final int ADVANCE_RESERVATION_DAYS = 7;
    
    // ==================== 通知配置 ====================
    
    /**
     * 未读状态
     */
    public static final int NOTIFICATION_UNREAD = 0;
    
    /**
     * 已读状态
     */
    public static final int NOTIFICATION_READ = 1;
    
    /**
     * 通知保留天数
     */
    public static final int NOTIFICATION_RETENTION_DAYS = 90;
    
    // ==================== 审计日志配置 ====================
    
    /**
     * 审计日志保留天数
     */
    public static final int AUDIT_LOG_RETENTION_DAYS = 180;
    
    // ==================== 错误消息 ====================
    
    /**
     * 未登录错误
     */
    public static final String ERROR_NOT_LOGGED_IN = "请先登录";
    
    /**
     * 权限不足错误
     */
    public static final String ERROR_PERMISSION_DENIED = "权限不足";
    
    /**
     * 参数错误
     */
    public static final String ERROR_INVALID_PARAMS = "参数错误";
    
    /**
     * 时间冲突错误
     */
    public static final String ERROR_TIME_CONFLICT = "该时间段已有预约，请选择其他时间";
    
    /**
     * 教师专属功能错误
     */
    public static final String ERROR_TEACHER_ONLY = "只有教师可以预约教室";
    
    /**
     * 预约不存在错误
     */
    public static final String ERROR_RESERVATION_NOT_FOUND = "预约不存在";
    
    /**
     * 无权操作错误
     */
    public static final String ERROR_NO_PERMISSION = "无权操作此预约";
    
    // ==================== 成功消息 ====================
    
    /**
     * 操作成功
     */
    public static final String SUCCESS_OPERATION = "操作成功";
    
    /**
     * 预约成功
     */
    public static final String SUCCESS_RESERVATION = "预约成功";
    
    /**
     * 取消成功
     */
    public static final String SUCCESS_CANCEL = "取消成功";
    
    /**
     * 标记成功
     */
    public static final String SUCCESS_MARK = "标记成功";
}
