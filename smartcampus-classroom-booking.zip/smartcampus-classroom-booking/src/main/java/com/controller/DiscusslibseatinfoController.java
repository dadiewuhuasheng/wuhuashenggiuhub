package com.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import com.utils.ValidatorUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.annotation.IgnoreAuth;

import com.entity.DiscusslibseatinfoEntity;
import com.entity.view.DiscusslibseatinfoView;

import com.service.DiscusslibseatinfoService;
import com.service.TokenService;
import com.utils.PageUtils;
import com.utils.R;
import com.utils.MD5Util;
import com.utils.MPUtil;
import com.utils.CommonUtil;
import java.io.IOException;

/**
 * 座位信息评论表
 * 后端接口
 * @author 
 * @email 
 */
@RestController
@RequestMapping("/discusslibseatinfo")
public class DiscusslibseatinfoController {
    @Autowired
    private DiscusslibseatinfoService discusslibseatinfoService;


    


    /**
     * 后端列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params,DiscusslibseatinfoEntity discusslibseatinfo,
		HttpServletRequest request){
        EntityWrapper<DiscusslibseatinfoEntity> ew = new EntityWrapper<DiscusslibseatinfoEntity>();

		PageUtils page = discusslibseatinfoService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, discusslibseatinfo), params), params));

        return R.ok().put("data", page);
    }
    
    /**
     * 前端列表
     */
	@IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params,DiscusslibseatinfoEntity discusslibseatinfo, 
		HttpServletRequest request){
        EntityWrapper<DiscusslibseatinfoEntity> ew = new EntityWrapper<DiscusslibseatinfoEntity>();

		PageUtils page = discusslibseatinfoService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, discusslibseatinfo), params), params));
        return R.ok().put("data", page);
    }

	/**
     * 列表
     */
    @RequestMapping("/lists")
    public R list( DiscusslibseatinfoEntity discusslibseatinfo){
       	EntityWrapper<DiscusslibseatinfoEntity> ew = new EntityWrapper<DiscusslibseatinfoEntity>();
      	ew.allEq(MPUtil.allEQMapPre( discusslibseatinfo, "discusslibseatinfo")); 
        return R.ok().put("data", discusslibseatinfoService.selectListView(ew));
    }

	 /**
     * 查询
     */
    @RequestMapping("/query")
    public R query(DiscusslibseatinfoEntity discusslibseatinfo){
        EntityWrapper< DiscusslibseatinfoEntity> ew = new EntityWrapper< DiscusslibseatinfoEntity>();
 		ew.allEq(MPUtil.allEQMapPre( discusslibseatinfo, "discusslibseatinfo")); 
		DiscusslibseatinfoView discusslibseatinfoView =  discusslibseatinfoService.selectView(ew);
		return R.ok("查询座位信息评论表成功").put("data", discusslibseatinfoView);
    }
	
    /**
     * 后端详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id){
        DiscusslibseatinfoEntity discusslibseatinfo = discusslibseatinfoService.selectById(id);
        return R.ok().put("data", discusslibseatinfo);
    }

    /**
     * 前端详情
     */
	@IgnoreAuth
    @RequestMapping("/detail/{id}")
    public R detail(@PathVariable("id") Long id){
        DiscusslibseatinfoEntity discusslibseatinfo = discusslibseatinfoService.selectById(id);
        return R.ok().put("data", discusslibseatinfo);
    }
    



    /**
     * 后端保存
     */
    @RequestMapping("/save")
    public R save(@RequestBody DiscusslibseatinfoEntity discusslibseatinfo, HttpServletRequest request){
    	discusslibseatinfo.setId(new Date().getTime()+new Double(Math.floor(Math.random()*1000)).longValue());
    	//ValidatorUtils.validateEntity(discusslibseatinfo);
        discusslibseatinfoService.insert(discusslibseatinfo);
        return R.ok();
    }
    
    /**
     * 前端保存
     */
    @RequestMapping("/add")
    public R add(@RequestBody DiscusslibseatinfoEntity discusslibseatinfo, HttpServletRequest request){
    	discusslibseatinfo.setId(new Date().getTime()+new Double(Math.floor(Math.random()*1000)).longValue());
    	//ValidatorUtils.validateEntity(discusslibseatinfo);
        discusslibseatinfoService.insert(discusslibseatinfo);
        return R.ok();
    }



    /**
     * 修改
     */
    @RequestMapping("/update")
    @Transactional
    public R update(@RequestBody DiscusslibseatinfoEntity discusslibseatinfo, HttpServletRequest request){
        //ValidatorUtils.validateEntity(discusslibseatinfo);
        discusslibseatinfoService.updateById(discusslibseatinfo);//全部更新
        return R.ok();
    }


    

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Long[] ids){
        discusslibseatinfoService.deleteBatchIds(Arrays.asList(ids));
        return R.ok();
    }
    
    /**
     * 提醒接口
     */
	@RequestMapping("/remind/{columnName}/{type}")
	public R remindCount(@PathVariable("columnName") String columnName, HttpServletRequest request, 
						 @PathVariable("type") String type,@RequestParam Map<String, Object> map) {
		map.put("column", columnName);
		map.put("type", type);
		
		if(type.equals("2")) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Calendar c = Calendar.getInstance();
			Date remindStartDate = null;
			Date remindEndDate = null;
			if(map.get("remindstart")!=null) {
				Integer remindStart = Integer.parseInt(map.get("remindstart").toString());
				c.setTime(new Date()); 
				c.add(Calendar.DAY_OF_MONTH,remindStart);
				remindStartDate = c.getTime();
				map.put("remindstart", sdf.format(remindStartDate));
			}
			if(map.get("remindend")!=null) {
				Integer remindEnd = Integer.parseInt(map.get("remindend").toString());
				c.setTime(new Date());
				c.add(Calendar.DAY_OF_MONTH,remindEnd);
				remindEndDate = c.getTime();
				map.put("remindend", sdf.format(remindEndDate));
			}
		}
		
		Wrapper<DiscusslibseatinfoEntity> wrapper = new EntityWrapper<DiscusslibseatinfoEntity>();
		if(map.get("remindstart")!=null) {
			wrapper.ge(columnName, map.get("remindstart"));
		}
		if(map.get("remindend")!=null) {
			wrapper.le(columnName, map.get("remindend"));
		}


		int count = discusslibseatinfoService.selectCount(wrapper);
		return R.ok().put("count", count);
	}
	









}
