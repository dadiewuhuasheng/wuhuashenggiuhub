package com.controller;

import com.annotation.IgnoreAuth;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.entity.NotificationEntity;
import com.service.NotificationService;
import com.utils.MPUtil;
import com.utils.PageUtils;
import com.utils.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.Map;

/**
 * 通知
 * 后端接口
 * @author 
 * @email 
 */
@RestController
@RequestMapping("/notification")
public class NotificationController {
    
    @Autowired
    private NotificationService notificationService;

    /**
     * 后端列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params, NotificationEntity notification,
                  HttpServletRequest request) {
        EntityWrapper<NotificationEntity> ew = new EntityWrapper<NotificationEntity>();
        PageUtils page = notificationService.queryPage(params, 
            MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, notification), params), params));
        return R.ok().put("data", page);
    }
    
    /**
     * 用户通知列表
     */
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params, HttpServletRequest request) {
        Long userId = (Long) request.getSession().getAttribute("userId");
        
        if (userId == null) {
            return R.error("请先登录");
        }
        
        // Add userId to params
        params.put("userId", userId.toString());
        
        PageUtils page = notificationService.queryPage(params);
        return R.ok().put("data", page);
    }

    /**
     * 获取未读通知数量
     */
    @RequestMapping("/unread-count")
    public R unreadCount(HttpServletRequest request) {
        Long userId = (Long) request.getSession().getAttribute("userId");
        
        if (userId == null) {
            return R.error("请先登录");
        }
        
        Integer count = notificationService.getUnreadCount(userId);
        return R.ok().put("count", count);
    }

    /**
     * 标记通知为已读
     */
    @RequestMapping("/mark-read/{id}")
    public R markAsRead(@PathVariable("id") Long id, HttpServletRequest request) {
        Long userId = (Long) request.getSession().getAttribute("userId");
        
        if (userId == null) {
            return R.error("请先登录");
        }
        
        boolean success = notificationService.markAsRead(id, userId);
        
        if (success) {
            return R.ok();
        } else {
            return R.error("标记失败");
        }
    }

    /**
     * 批量标记为已读
     */
    @RequestMapping("/mark-read")
    @PostMapping
    public R markAsReadBatch(@RequestBody Long[] ids, HttpServletRequest request) {
        // For admin, allow marking any notification as read
        // For regular users, verify ownership
        Long userId = (Long) request.getSession().getAttribute("userId");
        String role = (String) request.getSession().getAttribute("role");
        
        if (userId == null) {
            return R.error("请先登录");
        }
        
        int successCount = 0;
        for (Long id : ids) {
            // Admin can mark any notification, users can only mark their own
            if ("admin".equals(role)) {
                NotificationEntity notification = notificationService.selectById(id);
                if (notification != null) {
                    notification.setIsRead(1);
                    notificationService.updateById(notification);
                    successCount++;
                }
            } else {
                boolean success = notificationService.markAsRead(id, userId);
                if (success) {
                    successCount++;
                }
            }
        }
        
        return R.ok().put("successCount", successCount);
    }

    /**
     * 详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id, HttpServletRequest request) {
        Long userId = (Long) request.getSession().getAttribute("userId");
        
        if (userId == null) {
            return R.error("请先登录");
        }
        
        NotificationEntity notification = notificationService.selectById(id);
        
        if (notification == null) {
            return R.error("通知不存在");
        }
        
        // Verify ownership
        if (!notification.getUserId().equals(userId)) {
            return R.error("无权查看此通知");
        }
        
        // Auto mark as read when viewing
        if (notification.getIsRead() == 0) {
            notificationService.markAsRead(id, userId);
        }
        
        return R.ok().put("data", notification);
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Long[] ids, HttpServletRequest request) {
        Long userId = (Long) request.getSession().getAttribute("userId");
        String role = (String) request.getSession().getAttribute("role");
        
        if (userId == null) {
            return R.error("请先登录");
        }
        
        // Admin can delete any notification, users can only delete their own
        if (!"admin".equals(role)) {
            // Verify ownership for all ids
            for (Long id : ids) {
                NotificationEntity notification = notificationService.selectById(id);
                if (notification != null && !notification.getUserId().equals(userId)) {
                    return R.error("无权删除此通知");
                }
            }
        }
        
        notificationService.deleteBatchIds(java.util.Arrays.asList(ids));
        return R.ok();
    }
}
