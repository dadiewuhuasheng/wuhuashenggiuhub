package com.controller;

import com.annotation.IgnoreAuth;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.entity.AddressEntity;
import com.service.AddressService;
import com.utils.MPUtil;
import com.utils.PageUtils;
import com.utils.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 地址
 */
@RestController
@RequestMapping("/address")
public class AddressController {

    @Autowired
    private AddressService addressService;

    /**
     * 后端列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params, AddressEntity address,
                  HttpServletRequest request) {
        EntityWrapper<AddressEntity> ew = new EntityWrapper<AddressEntity>();
        PageUtils page = addressService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, address), params), params));
        return R.ok().put("data", page);
    }

    /**
     * 前端列表（用户只能查看自己的地址）
     */
    @IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params, AddressEntity address,
                  HttpServletRequest request) {
        EntityWrapper<AddressEntity> ew = new EntityWrapper<AddressEntity>();
        ew.eq("user_id", request.getParameter("userid"));
        PageUtils page = addressService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, address), params), params));
        return R.ok().put("data", page);
    }

    /**
     * 前端列表（用户只能查看自己的地址，通过session获取userId）
     */
    @RequestMapping("/my-list")
    public R myList(@RequestParam Map<String, Object> params, HttpServletRequest request) {
        Long userId = (Long) request.getSession().getAttribute("userId");
        if (userId == null) {
            return R.error("请先登录");
        }
        EntityWrapper<AddressEntity> ew = new EntityWrapper<AddressEntity>();
        ew.eq("user_id", userId);
        PageUtils page = addressService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, null), params), params));
        return R.ok().put("data", page);
    }

    /**
     * 列表
     */
    @RequestMapping("/lists")
    public R lists(AddressEntity address) {
        EntityWrapper<AddressEntity> ew = new EntityWrapper<AddressEntity>();
        ew.allEq(MPUtil.allEQMapPre(address, "address"));
        return R.ok().put("data", addressService.selectListView(ew));
    }

    /**
     * 查询
     */
    @RequestMapping("/query")
    public R query(AddressEntity address) {
        EntityWrapper<AddressEntity> ew = new EntityWrapper<AddressEntity>();
        ew.allEq(MPUtil.allEQMapPre(address, "address"));
        return R.ok().put("data", addressService.selectView(ew));
    }

    /**
     * 后端详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id) {
        AddressEntity address = addressService.selectById(id);
        return R.ok().put("data", address);
    }

    /**
     * 前端详情
     */
    @IgnoreAuth
    @RequestMapping("/detail/{id}")
    public R detail(@PathVariable("id") Long id) {
        AddressEntity address = addressService.selectById(id);
        return R.ok().put("data", address);
    }

    /**
     * 后端保存
     */
    @RequestMapping("/save")
    public R save(@RequestBody AddressEntity address, HttpServletRequest request) {
        address.setId(new Date().getTime() + new Double(Math.floor(Math.random() * 1000)).longValue());
        addressService.insert(address);
        return R.ok();
    }

    /**
     * 前端保存
     */
    @RequestMapping("/add")
    public R add(@RequestBody AddressEntity address, HttpServletRequest request) {
        address.setId(new Date().getTime() + new Double(Math.floor(Math.random() * 1000)).longValue());
        addressService.insert(address);
        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    public R update(@RequestBody AddressEntity address, HttpServletRequest request) {
        addressService.updateById(address);
        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Long[] ids) {
        addressService.deleteBatchIds(Arrays.asList(ids));
        return R.ok();
    }
}
