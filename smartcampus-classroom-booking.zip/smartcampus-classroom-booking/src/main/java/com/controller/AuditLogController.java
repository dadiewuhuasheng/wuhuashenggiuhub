package com.controller;

import com.annotation.IgnoreAuth;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.entity.AuditLogEntity;
import com.service.AuditLogService;
import com.utils.MPUtil;
import com.utils.PageUtils;
import com.utils.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * 审计日志
 * 后端接口
 * @author 
 * @email 
 */
@RestController
@RequestMapping("/auditlog")
public class AuditLogController {
    
    @Autowired
    private AuditLogService auditLogService;

    /**
     * 后端列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params, AuditLogEntity auditLog,
                  HttpServletRequest request) {
        EntityWrapper<AuditLogEntity> ew = new EntityWrapper<AuditLogEntity>();
        
        // Handle date range filtering
        String startDate = (String) params.get("startDate");
        String endDate = (String) params.get("endDate");
        
        if (startDate != null && !startDate.isEmpty()) {
            ew.ge("timestamp", startDate + " 00:00:00");
        }
        
        if (endDate != null && !endDate.isEmpty()) {
            ew.le("timestamp", endDate + " 23:59:59");
        }
        
        PageUtils page = auditLogService.queryPage(params, 
            MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, auditLog), params), params));
        return R.ok().put("data", page);
    }
    
    /**
     * 前端列表
     */
    @IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params, AuditLogEntity auditLog,
                  HttpServletRequest request) {
        EntityWrapper<AuditLogEntity> ew = new EntityWrapper<AuditLogEntity>();
        PageUtils page = auditLogService.queryPage(params, 
            MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, auditLog), params), params));
        return R.ok().put("data", page);
    }

    /**
     * 详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id) {
        AuditLogEntity auditLog = auditLogService.selectById(id);
        return R.ok().put("data", auditLog);
    }

    /**
     * 查询用户操作日志
     */
    @RequestMapping("/user/{userId}")
    public R userLogs(@PathVariable("userId") Long userId, @RequestParam Map<String, Object> params) {
        params.put("userId", userId.toString());
        
        EntityWrapper<AuditLogEntity> ew = new EntityWrapper<AuditLogEntity>();
        ew.eq("user_id", userId);
        
        PageUtils page = auditLogService.queryPage(params, 
            MPUtil.sort(MPUtil.between(ew, params), params));
        return R.ok().put("data", page);
    }

    /**
     * 按操作类型查询
     */
    @RequestMapping("/action/{actionType}")
    public R actionLogs(@PathVariable("actionType") String actionType, @RequestParam Map<String, Object> params) {
        params.put("actionType", actionType);
        
        EntityWrapper<AuditLogEntity> ew = new EntityWrapper<AuditLogEntity>();
        ew.eq("action_type", actionType);
        
        PageUtils page = auditLogService.queryPage(params, 
            MPUtil.sort(MPUtil.between(ew, params), params));
        return R.ok().put("data", page);
    }

    /**
     * 按资源类型查询
     */
    @RequestMapping("/resource/{resourceType}")
    public R resourceLogs(@PathVariable("resourceType") String resourceType, @RequestParam Map<String, Object> params) {
        params.put("resourceType", resourceType);
        
        EntityWrapper<AuditLogEntity> ew = new EntityWrapper<AuditLogEntity>();
        ew.eq("resource_type", resourceType);
        
        PageUtils page = auditLogService.queryPage(params, 
            MPUtil.sort(MPUtil.between(ew, params), params));
        return R.ok().put("data", page);
    }
}
