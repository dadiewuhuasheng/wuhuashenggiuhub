package com.controller;

import com.annotation.IgnoreAuth;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.entity.ClassroomReservationEntity;
import com.service.ClassroomReservationService;
import com.utils.MPUtil;
import com.utils.PageUtils;
import com.utils.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 教室预约
 * 后端接口
 * @author 
 * @email 
 */
@RestController
@RequestMapping("/classroomreservation")
public class ClassroomReservationController {
    
    @Autowired
    private ClassroomReservationService classroomReservationService;

    /**
     * 后端列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params, ClassroomReservationEntity reservation,
                  HttpServletRequest request) {
        EntityWrapper<ClassroomReservationEntity> ew = new EntityWrapper<ClassroomReservationEntity>();
        PageUtils page = classroomReservationService.queryPage(params, 
            MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, reservation), params), params));
        return R.ok().put("data", page);
    }
    
    /**
     * 前端列表
     */
    @IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params, ClassroomReservationEntity reservation,
                  HttpServletRequest request) {
        EntityWrapper<ClassroomReservationEntity> ew = new EntityWrapper<ClassroomReservationEntity>();
        PageUtils page = classroomReservationService.queryPage(params, 
            MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, reservation), params), params));
        return R.ok().put("data", page);
    }

    /**
     * 创建教室预约
     */
    @RequestMapping("/create")
    @Transactional
    public R create(@RequestBody ClassroomReservationEntity reservation, HttpServletRequest request) {
        // Get user info from session
        Long userId = (Long) request.getSession().getAttribute("userId");
        String username = (String) request.getSession().getAttribute("username");
        String role = (String) request.getSession().getAttribute("role");
        
        if (userId == null) {
            return R.error("请先登录");
        }
        
        // Set user info
        reservation.setUserId(userId);
        reservation.setUsername(username);
        
        // Generate ID
        reservation.setId(new Date().getTime() + new Double(Math.floor(Math.random() * 1000)).longValue());
        
        // Call service to create reservation with priority logic
        R result = classroomReservationService.createReservation(reservation, role);
        
        return result;
    }

    /**
     * 取消教室预约
     */
    @RequestMapping("/cancel/{id}")
    @Transactional
    public R cancel(@PathVariable("id") Long id, 
                   @RequestParam(required = false) String reason,
                   HttpServletRequest request) {
        Long userId = (Long) request.getSession().getAttribute("userId");
        String role = (String) request.getSession().getAttribute("role");
        
        if (userId == null) {
            return R.error("请先登录");
        }
        
        // Admin can cancel any reservation
        if ("admin".equals(role)) {
            R result = classroomReservationService.cancelReservation(id, null, reason);
            return result;
        } else {
            R result = classroomReservationService.cancelReservation(id, userId, reason);
            return result;
        }
    }

    /**
     * 查询用户的教室预约
     */
    @RequestMapping("/my-reservations")
    public R myReservations(@RequestParam Map<String, Object> params, HttpServletRequest request) {
        Long userId = (Long) request.getSession().getAttribute("userId");
        
        if (userId == null) {
            return R.error("请先登录");
        }
        
        PageUtils page = classroomReservationService.queryUserReservations(userId, params);
        return R.ok().put("data", page);
    }

    /**
     * 获取教室可用时间段
     */
    @RequestMapping("/available-slots")
    public R availableSlots(@RequestParam Long classroomId,
                           @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date date) {
        if (classroomId == null || date == null) {
            return R.error("参数错误");
        }
        
        List<Map<String, Object>> slots = classroomReservationService.getAvailableTimeSlots(classroomId, date);
        return R.ok().put("data", slots);
    }

    /**
     * 详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id) {
        ClassroomReservationEntity reservation = classroomReservationService.selectById(id);
        return R.ok().put("data", reservation);
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    @Transactional
    public R update(@RequestBody ClassroomReservationEntity reservation, HttpServletRequest request) {
        Long userId = (Long) request.getSession().getAttribute("userId");
        
        if (userId == null) {
            return R.error("请先登录");
        }
        
        // Verify ownership
        ClassroomReservationEntity existing = classroomReservationService.selectById(reservation.getId());
        if (existing == null) {
            return R.error("预约不存在");
        }
        
        if (!existing.getUserId().equals(userId)) {
            return R.error("无权修改此预约");
        }
        
        classroomReservationService.updateById(reservation);
        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Long[] ids, HttpServletRequest request) {
        Long userId = (Long) request.getSession().getAttribute("userId");
        String role = (String) request.getSession().getAttribute("role");
        
        if (userId == null) {
            return R.error("请先登录");
        }
        
        // Admin can delete any reservation, users can only delete their own
        if (!"admin".equals(role)) {
            // Verify ownership for all ids
            for (Long id : ids) {
                ClassroomReservationEntity reservation = classroomReservationService.selectById(id);
                if (reservation != null && !reservation.getUserId().equals(userId)) {
                    return R.error("无权删除此预约");
                }
            }
        }
        
        classroomReservationService.deleteBatchIds(java.util.Arrays.asList(ids));
        return R.ok();
    }
}
