package com.utils;

import com.constants.SystemConstants;

import java.util.Date;
import java.util.regex.Pattern;

/**
 * 验证工具类
 * 
 * @author 
 * @email 
 */
public class ValidationUtil {
    
    // 手机号正则
    private static final Pattern PHONE_PATTERN = Pattern.compile("^1[3-9]\\d{9}$");
    
    // 邮箱正则
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    
    /**
     * 验证字符串非空
     */
    public static boolean isNotEmpty(String str) {
        return str != null && !str.trim().isEmpty();
    }
    
    /**
     * 验证字符串为空
     */
    public static boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }
    
    /**
     * 验证对象非空
     */
    public static boolean isNotNull(Object obj) {
        return obj != null;
    }
    
    /**
     * 验证对象为空
     */
    public static boolean isNull(Object obj) {
        return obj == null;
    }
    
    /**
     * 验证手机号
     */
    public static boolean isValidPhone(String phone) {
        if (isEmpty(phone)) {
            return false;
        }
        return PHONE_PATTERN.matcher(phone).matches();
    }
    
    /**
     * 验证邮箱
     */
    public static boolean isValidEmail(String email) {
        if (isEmpty(email)) {
            return false;
        }
        return EMAIL_PATTERN.matcher(email).matches();
    }
    
    /**
     * 验证用户角色
     */
    public static boolean isValidRole(String role) {
        if (isEmpty(role)) {
            return false;
        }
        return SystemConstants.ROLE_STUDENT.equals(role) || 
               SystemConstants.ROLE_TEACHER.equals(role) ||
               SystemConstants.ROLE_STUDENT_CN.equals(role) ||
               SystemConstants.ROLE_TEACHER_CN.equals(role);
    }
    
    /**
     * 验证预约状态
     */
    public static boolean isValidStatus(String status) {
        if (isEmpty(status)) {
            return false;
        }
        return SystemConstants.STATUS_PENDING.equals(status) ||
               SystemConstants.STATUS_APPROVED.equals(status) ||
               SystemConstants.STATUS_CANCELLED.equals(status) ||
               SystemConstants.STATUS_COMPLETED.equals(status) ||
               SystemConstants.STATUS_CANCELLED_CN.equals(status) ||
               SystemConstants.STATUS_COMPLETED_CN.equals(status);
    }
    
    /**
     * 验证时间范围
     */
    public static String validateTimeRange(Date startTime, Date endTime) {
        if (startTime == null || endTime == null) {
            return "开始时间和结束时间不能为空";
        }
        
        if (!startTime.before(endTime)) {
            return "开始时间必须早于结束时间";
        }
        
        Date now = new Date();
        if (startTime.before(now)) {
            return "预约时间不能在过去";
        }
        
        // 检查是否在工作时间内
        if (!DateUtil.isInWorkHours(startTime) || !DateUtil.isInWorkHours(endTime)) {
            return "预约时间必须在工作时间内（8:00-22:00）";
        }
        
        // 检查时长
        long hours = DateUtil.getHoursBetween(startTime, endTime);
        if (hours > SystemConstants.MAX_RESERVATION_HOURS) {
            return "预约时长不能超过" + SystemConstants.MAX_RESERVATION_HOURS + "小时";
        }
        
        long minutes = DateUtil.getMinutesBetween(startTime, endTime);
        if (minutes < SystemConstants.MIN_RESERVATION_MINUTES) {
            return "预约时长不能少于" + SystemConstants.MIN_RESERVATION_MINUTES + "分钟";
        }
        
        // 检查提前预约天数
        Date maxAdvanceDate = DateUtil.addDays(now, SystemConstants.ADVANCE_RESERVATION_DAYS);
        if (startTime.after(maxAdvanceDate)) {
            return "只能提前" + SystemConstants.ADVANCE_RESERVATION_DAYS + "天预约";
        }
        
        return null;
    }
    
    /**
     * 验证ID
     */
    public static boolean isValidId(Long id) {
        return id != null && id > 0;
    }
    
    /**
     * 验证字符串长度
     */
    public static boolean isValidLength(String str, int minLength, int maxLength) {
        if (str == null) {
            return false;
        }
        int length = str.length();
        return length >= minLength && length <= maxLength;
    }
    
    /**
     * 验证数字范围
     */
    public static boolean isInRange(Number value, Number min, Number max) {
        if (value == null) {
            return false;
        }
        double val = value.doubleValue();
        double minVal = min.doubleValue();
        double maxVal = max.doubleValue();
        return val >= minVal && val <= maxVal;
    }
    
    /**
     * 验证教室预约必填字段
     */
    public static String validateClassroomReservation(Long classroomId, Date startTime, Date endTime, String purpose) {
        if (!isValidId(classroomId)) {
            return "教室ID不能为空";
        }
        
        if (startTime == null || endTime == null) {
            return "预约时间不能为空";
        }
        
        if (isEmpty(purpose)) {
            return "使用目的不能为空";
        }
        
        if (!isValidLength(purpose, 1, 500)) {
            return "使用目的长度必须在1-500字符之间";
        }
        
        return validateTimeRange(startTime, endTime);
    }
    
    /**
     * 验证座位预约必填字段
     */
    public static String validateSeatReservation(Long seatId, Date startTime, Date endTime) {
        if (!isValidId(seatId)) {
            return "座位ID不能为空";
        }
        
        if (startTime == null || endTime == null) {
            return "预约时间不能为空";
        }
        
        return validateTimeRange(startTime, endTime);
    }
    
    /**
     * 验证用户注册信息
     */
    public static String validateUserRegistration(String username, String password, String role) {
        if (isEmpty(username)) {
            return "用户名不能为空";
        }
        
        if (!isValidLength(username, 3, 50)) {
            return "用户名长度必须在3-50字符之间";
        }
        
        if (isEmpty(password)) {
            return "密码不能为空";
        }
        
        if (!isValidLength(password, 6, 50)) {
            return "密码长度必须在6-50字符之间";
        }
        
        if (!isValidRole(role)) {
            return "角色必须是学生或教师";
        }
        
        return null;
    }
}
