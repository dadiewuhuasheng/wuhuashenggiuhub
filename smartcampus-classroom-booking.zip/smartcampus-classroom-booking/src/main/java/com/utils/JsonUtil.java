package com.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * JSON工具类
 * 
 * @author 
 * @email 
 */
public class JsonUtil {
    
    private static final ObjectMapper objectMapper = new ObjectMapper();
    
    static {
        // 配置日期格式
        objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
        // 禁用空对象转换失败
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
    }
    
    /**
     * 对象转JSON字符串
     */
    public static String toJson(Object obj) {
        if (obj == null) {
            return null;
        }
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * JSON字符串转对象
     */
    public static <T> T fromJson(String json, Class<T> clazz) {
        if (json == null || json.trim().isEmpty()) {
            return null;
        }
        try {
            return objectMapper.readValue(json, clazz);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * 对象转Map
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> toMap(Object obj) {
        if (obj == null) {
            return new HashMap<>();
        }
        return objectMapper.convertValue(obj, Map.class);
    }
    
    /**
     * Map转对象
     */
    public static <T> T fromMap(Map<String, Object> map, Class<T> clazz) {
        if (map == null || map.isEmpty()) {
            return null;
        }
        return objectMapper.convertValue(map, clazz);
    }
    
    /**
     * 构建审计日志详情JSON
     */
    public static String buildAuditDetails(String... keyValues) {
        if (keyValues == null || keyValues.length == 0 || keyValues.length % 2 != 0) {
            return "{}";
        }
        
        Map<String, Object> details = new HashMap<>();
        for (int i = 0; i < keyValues.length; i += 2) {
            details.put(keyValues[i], keyValues[i + 1]);
        }
        
        return toJson(details);
    }
    
    /**
     * 构建预约详情JSON
     */
    public static String buildReservationDetails(Long resourceId, String resourceName, 
                                                 String startTime, String endTime, String purpose) {
        Map<String, Object> details = new HashMap<>();
        if (resourceId != null) {
            details.put("resource_id", resourceId);
        }
        if (resourceName != null) {
            details.put("resource_name", resourceName);
        }
        if (startTime != null) {
            details.put("start_time", startTime);
        }
        if (endTime != null) {
            details.put("end_time", endTime);
        }
        if (purpose != null) {
            details.put("purpose", purpose);
        }
        return toJson(details);
    }
    
    /**
     * 构建取消详情JSON
     */
    public static String buildCancelDetails(String reason, Float refundAmount) {
        Map<String, Object> details = new HashMap<>();
        if (reason != null) {
            details.put("reason", reason);
        }
        if (refundAmount != null) {
            details.put("refund_amount", refundAmount);
        }
        return toJson(details);
    }
    
    /**
     * 美化JSON输出
     */
    public static String toPrettyJson(Object obj) {
        if (obj == null) {
            return null;
        }
        try {
            return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return null;
        }
    }
}
