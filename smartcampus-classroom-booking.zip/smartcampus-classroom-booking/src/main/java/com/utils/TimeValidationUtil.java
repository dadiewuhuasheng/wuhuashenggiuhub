package com.utils;

import java.util.Date;

/**
 * 时间验证工具类
 * 用于验证预约时间范围的有效性
 * 
 * @author 
 * @email 
 */
public class TimeValidationUtil {

    /**
     * 验证时间范围是否有效
     * 
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return 验证结果消息，如果验证通过返回null
     */
    public static String validateTimeRange(Date startTime, Date endTime) {
        // Check if times are not null
        if (startTime == null) {
            return "开始时间不能为空";
        }
        
        if (endTime == null) {
            return "结束时间不能为空";
        }
        
        // Check if start time is not in the past
        Date now = new Date();
        if (startTime.before(now)) {
            return "开始时间不能早于当前时间";
        }
        
        // Check if start < end
        if (!startTime.before(endTime)) {
            return "结束时间必须晚于开始时间";
        }
        
        // All validations passed
        return null;
    }

    /**
     * 验证时间范围是否有效（布尔返回值版本）
     * 
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return true if valid, false otherwise
     */
    public static boolean isValidTimeRange(Date startTime, Date endTime) {
        return validateTimeRange(startTime, endTime) == null;
    }

    /**
     * 检查两个时间段是否重叠
     * 
     * @param start1 第一个时间段的开始时间
     * @param end1 第一个时间段的结束时间
     * @param start2 第二个时间段的开始时间
     * @param end2 第二个时间段的结束时间
     * @return true if overlapping, false otherwise
     */
    public static boolean isTimeOverlap(Date start1, Date end1, Date start2, Date end2) {
        if (start1 == null || end1 == null || start2 == null || end2 == null) {
            return false;
        }
        
        // Two time periods overlap if: start1 < end2 AND start2 < end1
        return start1.before(end2) && start2.before(end1);
    }

    /**
     * 计算两个时间之间的分钟数
     * 
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return 分钟数
     */
    public static long getMinutesBetween(Date startTime, Date endTime) {
        if (startTime == null || endTime == null) {
            return 0;
        }
        
        long diffInMillis = endTime.getTime() - startTime.getTime();
        return diffInMillis / (60 * 1000);
    }

    /**
     * 计算两个时间之间的小时数
     * 
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return 小时数
     */
    public static long getHoursBetween(Date startTime, Date endTime) {
        return getMinutesBetween(startTime, endTime) / 60;
    }
}
