package com.utils;

import com.constants.SystemConstants;

import java.util.HashMap;
import java.util.Map;

/**
 * 响应工具类
 * 用于统一API响应格式
 * 
 * @author 
 * @email 
 */
public class ResponseUtil {
    
    /**
     * 成功响应（无数据）
     */
    public static R success() {
        return R.ok(SystemConstants.SUCCESS_OPERATION);
    }
    
    /**
     * 成功响应（带消息）
     */
    public static R success(String message) {
        return R.ok(message);
    }
    
    /**
     * 成功响应（带数据）
     */
    public static R success(String key, Object value) {
        return R.ok().put(key, value);
    }
    
    /**
     * 成功响应（带多个数据）
     */
    public static R success(Map<String, Object> data) {
        R r = R.ok();
        if (data != null) {
            for (Map.Entry<String, Object> entry : data.entrySet()) {
                r.put(entry.getKey(), entry.getValue());
            }
        }
        return r;
    }
    
    /**
     * 失败响应
     */
    public static R error(String message) {
        return R.error(message);
    }
    
    /**
     * 失败响应（带错误码）
     */
    public static R error(int code, String message) {
        return R.error(code, message);
    }
    
    /**
     * 未登录响应
     */
    public static R notLoggedIn() {
        return R.error(401, SystemConstants.ERROR_NOT_LOGGED_IN);
    }
    
    /**
     * 权限不足响应
     */
    public static R permissionDenied() {
        return R.error(403, SystemConstants.ERROR_PERMISSION_DENIED);
    }
    
    /**
     * 参数错误响应
     */
    public static R invalidParams() {
        return R.error(SystemConstants.ERROR_INVALID_PARAMS);
    }
    
    /**
     * 参数错误响应（带详细信息）
     */
    public static R invalidParams(String detail) {
        return R.error(SystemConstants.ERROR_INVALID_PARAMS + ": " + detail);
    }
    
    /**
     * 时间冲突响应
     */
    public static R timeConflict() {
        return R.error(SystemConstants.ERROR_TIME_CONFLICT);
    }
    
    /**
     * 教师专属功能响应
     */
    public static R teacherOnly() {
        return R.error(SystemConstants.ERROR_TEACHER_ONLY);
    }
    
    /**
     * 预约不存在响应
     */
    public static R reservationNotFound() {
        return R.error(SystemConstants.ERROR_RESERVATION_NOT_FOUND);
    }
    
    /**
     * 无权操作响应
     */
    public static R noPermission() {
        return R.error(SystemConstants.ERROR_NO_PERMISSION);
    }
    
    /**
     * 构建分页响应
     */
    public static R page(PageUtils pageUtils) {
        return R.ok().put("page", pageUtils);
    }
    
    /**
     * 构建列表响应
     */
    public static R list(Object list) {
        return R.ok().put("list", list);
    }
    
    /**
     * 构建详情响应
     */
    public static R detail(Object data) {
        return R.ok().put("data", data);
    }
    
    /**
     * 构建计数响应
     */
    public static R count(long count) {
        return R.ok().put("count", count);
    }
    
    /**
     * 构建统计响应
     */
    public static R stats(Map<String, Object> stats) {
        return R.ok().put("stats", stats);
    }
}
