package com.utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Session工具类
 * 
 * @author 
 * @email 
 */
public class SessionUtil {
    
    // Session key常量
    public static final String USER_ID = "userId";
    public static final String USERNAME = "username";
    public static final String ROLE = "role";
    public static final String TABLE_NAME = "tableName";
    
    /**
     * 获取用户ID
     */
    public static Long getUserId(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return null;
        }
        Object userId = session.getAttribute(USER_ID);
        if (userId instanceof Long) {
            return (Long) userId;
        }
        if (userId instanceof Integer) {
            return ((Integer) userId).longValue();
        }
        if (userId instanceof String) {
            try {
                return Long.parseLong((String) userId);
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }
    
    /**
     * 获取用户名
     */
    public static String getUsername(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return null;
        }
        Object username = session.getAttribute(USERNAME);
        return username != null ? username.toString() : null;
    }
    
    /**
     * 获取用户角色
     */
    public static String getRole(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return null;
        }
        Object role = session.getAttribute(ROLE);
        return role != null ? role.toString() : null;
    }
    
    /**
     * 获取表名
     */
    public static String getTableName(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return null;
        }
        Object tableName = session.getAttribute(TABLE_NAME);
        return tableName != null ? tableName.toString() : null;
    }
    
    /**
     * 设置用户信息
     */
    public static void setUserInfo(HttpServletRequest request, Long userId, String username, String role) {
        HttpSession session = request.getSession(true);
        session.setAttribute(USER_ID, userId);
        session.setAttribute(USERNAME, username);
        session.setAttribute(ROLE, role);
    }
    
    /**
     * 设置用户信息（含表名）
     */
    public static void setUserInfo(HttpServletRequest request, Long userId, String username, String role, String tableName) {
        HttpSession session = request.getSession(true);
        session.setAttribute(USER_ID, userId);
        session.setAttribute(USERNAME, username);
        session.setAttribute(ROLE, role);
        session.setAttribute(TABLE_NAME, tableName);
    }
    
    /**
     * 清除用户信息
     */
    public static void clearUserInfo(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.removeAttribute(USER_ID);
            session.removeAttribute(USERNAME);
            session.removeAttribute(ROLE);
            session.removeAttribute(TABLE_NAME);
        }
    }
    
    /**
     * 销毁Session
     */
    public static void invalidate(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
    }
    
    /**
     * 检查用户是否已登录
     */
    public static boolean isLoggedIn(HttpServletRequest request) {
        return getUserId(request) != null;
    }
    
    /**
     * 检查用户是否是教师
     */
    public static boolean isTeacher(HttpServletRequest request) {
        String role = getRole(request);
        return "teacher".equals(role) || "教师".equals(role);
    }
    
    /**
     * 检查用户是否是学生
     */
    public static boolean isStudent(HttpServletRequest request) {
        String role = getRole(request);
        return "student".equals(role) || "学生".equals(role);
    }
}
