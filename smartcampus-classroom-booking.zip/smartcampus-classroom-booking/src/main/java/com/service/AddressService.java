package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.entity.AddressEntity;
import com.utils.PageUtils;

import java.util.List;
import java.util.Map;

/**
 * 地址服务接口
 */
public interface AddressService extends IService<AddressEntity> {

    PageUtils queryPage(Map<String, Object> params);

    PageUtils queryPage(Map<String, Object> params, Wrapper<AddressEntity> wrapper);

    List<AddressEntity> selectListView(Wrapper<AddressEntity> wrapper);

    AddressEntity selectView(Wrapper<AddressEntity> wrapper);
}
