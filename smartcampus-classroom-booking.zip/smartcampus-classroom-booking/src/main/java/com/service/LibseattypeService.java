package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.LibseattypeEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.LibseattypeVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.LibseattypeView;


/**
 * 座位类型
 *
 * @author 
 * @email 
 */
public interface LibseattypeService extends IService<LibseattypeEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<LibseattypeVO> selectListVO(Wrapper<LibseattypeEntity> wrapper);
   	
   	LibseattypeVO selectVO(@Param("ew") Wrapper<LibseattypeEntity> wrapper);
   	
   	List<LibseattypeView> selectListView(Wrapper<LibseattypeEntity> wrapper);
   	
   	LibseattypeView selectView(@Param("ew") Wrapper<LibseattypeEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<LibseattypeEntity> wrapper);
   	

}

