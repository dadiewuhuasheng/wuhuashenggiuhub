package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.utils.R;
import com.entity.OrdersEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.OrdersVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.OrdersView;


/**
 * 预约
 *
 * @author 
 * @email 
 */
public interface OrdersService extends IService<OrdersEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<OrdersVO> selectListVO(Wrapper<OrdersEntity> wrapper);
   	
   	OrdersVO selectVO(@Param("ew") Wrapper<OrdersEntity> wrapper);
   	
   	List<OrdersView> selectListView(Wrapper<OrdersEntity> wrapper);
   	
   	OrdersView selectView(@Param("ew") Wrapper<OrdersEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<OrdersEntity> wrapper);
   	

    List<Map<String, Object>> selectValue(Map<String, Object> params,Wrapper<OrdersEntity> wrapper);

    List<Map<String, Object>> selectTimeStatValue(Map<String, Object> params,Wrapper<OrdersEntity> wrapper);

    List<Map<String, Object>> selectGroup(Map<String, Object> params,Wrapper<OrdersEntity> wrapper);

	List<Map<String, Object>> ordergroup(Map<String, Object> params, Wrapper<OrdersEntity> wrapper);

	/**
	 * 创建带时间的座位预约
	 * 
	 * @param order 预约信息（包含开始时间和结束时间）
	 * @return 预约结果
	 */
	R createReservationWithTime(OrdersEntity order);

	/**
	 * 批量取消座位预约（用于教室预约优先级）
	 * 
	 * @param orderIds 预约ID列表
	 * @param reason 取消原因
	 * @return 取消结果
	 */
	R batchCancelWithRefund(List<Long> orderIds, String reason);


}

