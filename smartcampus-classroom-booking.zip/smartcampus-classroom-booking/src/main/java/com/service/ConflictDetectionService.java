package com.service;

import com.entity.OrdersEntity;
import java.util.Date;
import java.util.List;

/**
 * 冲突检测服务接口
 * 用于检测座位和教室预约的时间冲突
 * 
 * @author 
 * @email 
 */
public interface ConflictDetectionService {
    
    /**
     * 检查座位预约时间冲突
     * 
     * @param seatId 座位ID
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @param excludeOrderId 排除的预约ID（用于更新时）
     * @return true if conflict exists, false otherwise
     */
    boolean checkSeatConflict(Long seatId, Date startTime, Date endTime, Long excludeOrderId);
    
    /**
     * 检查教室预约时间冲突
     * 
     * @param classroomId 教室ID
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @param excludeReservationId 排除的预约ID
     * @return true if conflict exists, false otherwise
     */
    boolean checkClassroomConflict(Long classroomId, Date startTime, Date endTime, Long excludeReservationId);
    
    /**
     * 获取与教室预约冲突的座位预约列表
     * 
     * @param classroomId 教室ID
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @return 冲突的座位预约列表
     */
    List<OrdersEntity> getConflictingSeatReservations(Long classroomId, Date startTime, Date endTime);
}
