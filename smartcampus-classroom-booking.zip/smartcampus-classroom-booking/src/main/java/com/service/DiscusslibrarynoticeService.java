package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.DiscusslibrarynoticeEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.DiscusslibrarynoticeVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.DiscusslibrarynoticeView;


/**
 * 教室宣传评论表
 *
 * @author 
 * @email 
 */
public interface DiscusslibrarynoticeService extends IService<DiscusslibrarynoticeEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<DiscusslibrarynoticeVO> selectListVO(Wrapper<DiscusslibrarynoticeEntity> wrapper);
   	
   	DiscusslibrarynoticeVO selectVO(@Param("ew") Wrapper<DiscusslibrarynoticeEntity> wrapper);
   	
   	List<DiscusslibrarynoticeView> selectListView(Wrapper<DiscusslibrarynoticeEntity> wrapper);
   	
   	DiscusslibrarynoticeView selectView(@Param("ew") Wrapper<DiscusslibrarynoticeEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<DiscusslibrarynoticeEntity> wrapper);
   	

}

