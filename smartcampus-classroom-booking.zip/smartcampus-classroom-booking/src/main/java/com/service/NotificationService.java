package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.entity.NotificationEntity;
import com.entity.OrdersEntity;
import com.utils.PageUtils;

import java.util.Map;

/**
 * 通知服务接口
 * 
 * @author 
 * @email 
 */
public interface NotificationService extends IService<NotificationEntity> {
    
    /**
     * 分页查询通知
     * 
     * @param params 查询参数
     * @return 分页结果
     */
    PageUtils queryPage(Map<String, Object> params);
    
    /**
     * 分页查询通知（带条件）
     * 
     * @param params 查询参数
     * @param wrapper 查询条件
     * @return 分页结果
     */
    PageUtils queryPage(Map<String, Object> params, Wrapper<NotificationEntity> wrapper);
    
    /**
     * 创建座位预约取消通知
     * 
     * @param order 被取消的座位预约
     * @param reason 取消原因
     */
    void createCancellationNotification(OrdersEntity order, String reason);
    
    /**
     * 获取用户未读通知数量
     * 
     * @param userId 用户ID
     * @return 未读通知数量
     */
    Integer getUnreadCount(Long userId);
    
    /**
     * 标记通知为已读
     * 
     * @param notificationId 通知ID
     * @param userId 用户ID（用于验证权限）
     * @return 是否成功
     */
    boolean markAsRead(Long notificationId, Long userId);
}
