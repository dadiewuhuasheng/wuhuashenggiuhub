package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.entity.AuditLogEntity;
import com.utils.PageUtils;

import java.util.Map;

/**
 * 审计日志服务接口
 * 
 * @author 
 * @email 
 */
public interface AuditLogService extends IService<AuditLogEntity> {
    
    /**
     * 分页查询审计日志
     * 
     * @param params 查询参数
     * @return 分页结果
     */
    PageUtils queryPage(Map<String, Object> params);
    
    /**
     * 分页查询审计日志（带条件）
     * 
     * @param params 查询参数
     * @param wrapper 查询条件
     * @return 分页结果
     */
    PageUtils queryPage(Map<String, Object> params, Wrapper<AuditLogEntity> wrapper);
    
    /**
     * 记录预约创建日志
     * 
     * @param userId 用户ID
     * @param username 用户名
     * @param resourceType 资源类型 (seat/classroom)
     * @param resourceId 资源ID
     * @param details 详情
     */
    void logReservationCreate(Long userId, String username, String resourceType, Long resourceId, String details);
    
    /**
     * 记录预约取消日志
     * 
     * @param userId 用户ID
     * @param username 用户名
     * @param resourceType 资源类型 (seat/classroom)
     * @param resourceId 资源ID
     * @param details 详情
     */
    void logReservationCancel(Long userId, String username, String resourceType, Long resourceId, String details);
    
    /**
     * 记录预约修改日志
     * 
     * @param userId 用户ID
     * @param username 用户名
     * @param resourceType 资源类型 (seat/classroom)
     * @param resourceId 资源ID
     * @param details 详情
     */
    void logReservationModify(Long userId, String username, String resourceType, Long resourceId, String details);
}
