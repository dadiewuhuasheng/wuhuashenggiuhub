package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.NoticetypeEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.NoticetypeVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.NoticetypeView;


/**
 * 座位类型
 *
 * @author 
 * @email 
 */
public interface NoticetypeService extends IService<NoticetypeEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<NoticetypeVO> selectListVO(Wrapper<NoticetypeEntity> wrapper);
   	
   	NoticetypeVO selectVO(@Param("ew") Wrapper<NoticetypeEntity> wrapper);
   	
   	List<NoticetypeView> selectListView(Wrapper<NoticetypeEntity> wrapper);
   	
   	NoticetypeView selectView(@Param("ew") Wrapper<NoticetypeEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<NoticetypeEntity> wrapper);
   	

}

