package com.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.dao.ClassroomReservationDao;
import com.dao.OrdersDao;
import com.entity.ClassroomReservationEntity;
import com.entity.OrdersEntity;
import com.service.ConflictDetectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * 冲突检测服务实现
 * 
 * @author 
 * @email 
 */
@Service("conflictDetectionService")
public class ConflictDetectionServiceImpl implements ConflictDetectionService {

    @Autowired
    private OrdersDao ordersDao;
    
    @Autowired
    private ClassroomReservationDao classroomReservationDao;

    @Override
    public boolean checkSeatConflict(Long seatId, Date startTime, Date endTime, Long excludeOrderId) {
        if (seatId == null || startTime == null || endTime == null) {
            return false;
        }
        
        // Build query for conflicting reservations
        EntityWrapper<OrdersEntity> wrapper = new EntityWrapper<>();
        wrapper.eq("goodid", seatId);
        wrapper.eq("tablename", "libseatinfo");
        wrapper.notIn("status", new String[]{"已取消", "已完成"});
        
        // Time overlap condition: start1 < end2 AND start2 < end1
        // In SQL: start_time < ? AND end_time > ?
        wrapper.lt("start_time", endTime);
        wrapper.gt("end_time", startTime);
        
        // Exclude current order if updating
        if (excludeOrderId != null) {
            wrapper.ne("id", excludeOrderId);
        }
        
        // Check if any conflicts exist
        int count = ordersDao.selectCount(wrapper);
        return count > 0;
    }

    @Override
    public boolean checkClassroomConflict(Long classroomId, Date startTime, Date endTime, Long excludeReservationId) {
        if (classroomId == null || startTime == null || endTime == null) {
            return false;
        }
        
        // Build query for conflicting classroom reservations
        EntityWrapper<ClassroomReservationEntity> wrapper = new EntityWrapper<>();
        wrapper.eq("classroom_id", classroomId);
        wrapper.notIn("status", new String[]{"cancelled"});
        
        // Time overlap condition: start1 < end2 AND start2 < end1
        wrapper.lt("start_time", endTime);
        wrapper.gt("end_time", startTime);
        
        // Exclude current reservation if updating
        if (excludeReservationId != null) {
            wrapper.ne("id", excludeReservationId);
        }
        
        // Check if any conflicts exist
        int count = classroomReservationDao.selectCount(wrapper);
        return count > 0;
    }

    @Override
    public List<OrdersEntity> getConflictingSeatReservations(Long classroomId, Date startTime, Date endTime) {
        if (classroomId == null || startTime == null || endTime == null) {
            return null;
        }
        
        // Build query for conflicting seat reservations in the classroom
        EntityWrapper<OrdersEntity> wrapper = new EntityWrapper<>();
        wrapper.eq("goodid", classroomId);
        wrapper.eq("tablename", "libseatinfo");
        wrapper.notIn("status", new String[]{"已取消", "已完成"});
        
        // Time overlap condition
        wrapper.lt("start_time", endTime);
        wrapper.gt("end_time", startTime);
        
        return ordersDao.selectList(wrapper);
    }
}
