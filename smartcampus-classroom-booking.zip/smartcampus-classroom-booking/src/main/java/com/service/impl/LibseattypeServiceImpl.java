package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.LibseattypeDao;
import com.entity.LibseattypeEntity;
import com.service.LibseattypeService;
import com.entity.vo.LibseattypeVO;
import com.entity.view.LibseattypeView;

@Service("libseattypeService")
public class LibseattypeServiceImpl extends ServiceImpl<LibseattypeDao, LibseattypeEntity> implements LibseattypeService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<LibseattypeEntity> page = this.selectPage(
                new Query<LibseattypeEntity>(params).getPage(),
                new EntityWrapper<LibseattypeEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<LibseattypeEntity> wrapper) {
		  Page<LibseattypeView> page =new Query<LibseattypeView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<LibseattypeVO> selectListVO(Wrapper<LibseattypeEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public LibseattypeVO selectVO(Wrapper<LibseattypeEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<LibseattypeView> selectListView(Wrapper<LibseattypeEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public LibseattypeView selectView(Wrapper<LibseattypeEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
