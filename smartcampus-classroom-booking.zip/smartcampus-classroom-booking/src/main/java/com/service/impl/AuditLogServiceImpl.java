package com.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.dao.AuditLogDao;
import com.entity.AuditLogEntity;
import com.service.AuditLogService;
import com.utils.PageUtils;
import com.utils.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Map;

/**
 * 审计日志服务实现
 * 
 * @author 
 * @email 
 */
@Service("auditLogService")
public class AuditLogServiceImpl extends ServiceImpl<AuditLogDao, AuditLogEntity> implements AuditLogService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        String userId = (String) params.get("userId");
        String actionType = (String) params.get("actionType");
        String resourceType = (String) params.get("resourceType");
        String resourceId = (String) params.get("resourceId");
        
        EntityWrapper<AuditLogEntity> wrapper = new EntityWrapper<>();
        
        if (userId != null && !userId.isEmpty()) {
            wrapper.eq("user_id", userId);
        }
        
        if (actionType != null && !actionType.isEmpty()) {
            wrapper.eq("action_type", actionType);
        }
        
        if (resourceType != null && !resourceType.isEmpty()) {
            wrapper.eq("resource_type", resourceType);
        }
        
        if (resourceId != null && !resourceId.isEmpty()) {
            wrapper.eq("resource_id", resourceId);
        }
        
        // Order by time descending (newest first)
        wrapper.orderBy("addtime", false);
        
        Page<AuditLogEntity> page = this.selectPage(
                new Query<AuditLogEntity>(params).getPage(),
                wrapper
        );
        
        return new PageUtils(page);
    }
    
    @Override
    public PageUtils queryPage(Map<String, Object> params, Wrapper<AuditLogEntity> wrapper) {
        Page<AuditLogEntity> page = this.selectPage(
                new Query<AuditLogEntity>(params).getPage(),
                wrapper
        );
        
        return new PageUtils(page);
    }

    @Override
    @Transactional
    public void logReservationCreate(Long userId, String username, String resourceType, Long resourceId, String details) {
        createLog(userId, username, "create", resourceType, resourceId, details);
    }

    @Override
    @Transactional
    public void logReservationCancel(Long userId, String username, String resourceType, Long resourceId, String details) {
        createLog(userId, username, "cancel", resourceType, resourceId, details);
    }

    @Override
    @Transactional
    public void logReservationModify(Long userId, String username, String resourceType, Long resourceId, String details) {
        createLog(userId, username, "update", resourceType, resourceId, details);
    }
    
    /**
     * 创建审计日志记录
     */
    private void createLog(Long userId, String username, String actionType, 
                          String resourceType, Long resourceId, String details) {
        AuditLogEntity log = new AuditLogEntity();
        log.setUserId(userId);
        log.setUsername(username);
        log.setActionType(actionType);
        log.setResourceType(resourceType);
        log.setResourceId(resourceId);
        log.setDetails(details);
        log.setAddtime(new Date());
        
        this.insert(log);
    }
}
