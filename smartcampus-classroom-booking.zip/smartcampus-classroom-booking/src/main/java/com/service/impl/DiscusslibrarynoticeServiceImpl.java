package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.DiscusslibrarynoticeDao;
import com.entity.DiscusslibrarynoticeEntity;
import com.service.DiscusslibrarynoticeService;
import com.entity.vo.DiscusslibrarynoticeVO;
import com.entity.view.DiscusslibrarynoticeView;

@Service("discusslibrarynoticeService")
public class DiscusslibrarynoticeServiceImpl extends ServiceImpl<DiscusslibrarynoticeDao, DiscusslibrarynoticeEntity> implements DiscusslibrarynoticeService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<DiscusslibrarynoticeEntity> page = this.selectPage(
                new Query<DiscusslibrarynoticeEntity>(params).getPage(),
                new EntityWrapper<DiscusslibrarynoticeEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<DiscusslibrarynoticeEntity> wrapper) {
		  Page<DiscusslibrarynoticeView> page =new Query<DiscusslibrarynoticeView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<DiscusslibrarynoticeVO> selectListVO(Wrapper<DiscusslibrarynoticeEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public DiscusslibrarynoticeVO selectVO(Wrapper<DiscusslibrarynoticeEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<DiscusslibrarynoticeView> selectListView(Wrapper<DiscusslibrarynoticeEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public DiscusslibrarynoticeView selectView(Wrapper<DiscusslibrarynoticeEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
