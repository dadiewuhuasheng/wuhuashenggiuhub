package com.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.dao.ClassroomReservationDao;
import com.entity.ClassroomReservationEntity;
import com.entity.OrdersEntity;
import com.service.AuditLogService;
import com.service.ClassroomReservationService;
import com.service.ConflictDetectionService;
import com.service.NotificationService;
import com.service.OrdersService;
import com.utils.PageUtils;
import com.utils.Query;
import com.utils.R;
import com.utils.TimeValidationUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 教室预约服务实现
 * 
 * @author 
 * @email 
 */
@Service("classroomReservationService")
public class ClassroomReservationServiceImpl extends ServiceImpl<ClassroomReservationDao, ClassroomReservationEntity> 
        implements ClassroomReservationService {

    @Autowired
    private ConflictDetectionService conflictDetectionService;
    
    @Autowired
    private OrdersService ordersService;
    
    @Autowired
    private NotificationService notificationService;
    
    @Autowired
    private AuditLogService auditLogService;

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        EntityWrapper<ClassroomReservationEntity> wrapper = new EntityWrapper<>();
        
        String classroomId = (String) params.get("classroomId");
        String userId = (String) params.get("userId");
        String status = (String) params.get("status");
        
        if (classroomId != null && !classroomId.isEmpty()) {
            wrapper.eq("classroom_id", classroomId);
        }
        
        if (userId != null && !userId.isEmpty()) {
            wrapper.eq("user_id", userId);
        }
        
        if (status != null && !status.isEmpty()) {
            wrapper.eq("status", status);
        }
        
        wrapper.orderBy("addtime", false);
        
        Page<ClassroomReservationEntity> page = this.selectPage(
                new Query<ClassroomReservationEntity>(params).getPage(),
                wrapper
        );
        
        return new PageUtils(page);
    }

    @Override
    public PageUtils queryPage(Map<String, Object> params, Wrapper<ClassroomReservationEntity> wrapper) {
        Page<ClassroomReservationEntity> page = this.selectPage(
                new Query<ClassroomReservationEntity>(params).getPage(),
                wrapper
        );
        return new PageUtils(page);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public R createReservation(ClassroomReservationEntity reservation, String userRole) {
        // 1. Validate user has permission (must be teacher)
//        if (!"教师".equals(userRole)) {
//            return R.error("只有教师可以预约教室");
//        }
        
        // 2. Validate required fields
        if (reservation.getClassroomId() == null) {
            return R.error("教室ID不能为空");
        }
        if (reservation.getStartTime() == null || reservation.getEndTime() == null) {
            return R.error("预约时间不能为空");
        }
        if (reservation.getPurpose() == null || reservation.getPurpose().trim().isEmpty()) {
            return R.error("使用目的不能为空");
        }
        
        // 3. Validate time range
        String timeError = TimeValidationUtil.validateTimeRange(
            reservation.getStartTime(), 
            reservation.getEndTime()
        );
        if (timeError != null) {
            return R.error(timeError);
        }
        
        // 4. Check for classroom conflicts
        boolean hasClassroomConflict = conflictDetectionService.checkClassroomConflict(
            reservation.getClassroomId(),
            reservation.getStartTime(),
            reservation.getEndTime(),
            null
        );
        
        if (hasClassroomConflict) {
            return R.error("该时间段教室已被预约");
        }
        
        // 5. Get conflicting seat reservations
        List<OrdersEntity> conflictingSeats = conflictDetectionService.getConflictingSeatReservations(
            reservation.getClassroomId(),
            reservation.getStartTime(),
            reservation.getEndTime()
        );
        
        // 6. Create classroom reservation
        reservation.setStatus("approved");
        reservation.setAddtime(new Date());
        boolean created = this.insert(reservation);
        
        if (!created) {
            throw new RuntimeException("创建教室预约失败");
        }
        
        // Log reservation creation
        auditLogService.logReservationCreate(
            reservation.getUserId(),
            reservation.getUsername(),
            "classroom",
            reservation.getId(),
            String.format("教室预约: %s, 时间: %s - %s, 目的: %s",
                reservation.getClassroomName(),
                formatDate(reservation.getStartTime()),
                formatDate(reservation.getEndTime()),
                reservation.getPurpose())
        );
        
        // 7. Cancel conflicting seat reservations and create notifications
        if (conflictingSeats != null && !conflictingSeats.isEmpty()) {
            String cancelReason = String.format(
                "教室预约优先：%s 在 %s 至 %s 预约了该教室",
                reservation.getUsername() != null ? reservation.getUsername() : "教师",
                formatDate(reservation.getStartTime()),
                formatDate(reservation.getEndTime())
            );
            
            // Collect order IDs for batch refund
            List<Long> orderIds = new ArrayList<>();
            for (OrdersEntity seat : conflictingSeats) {
                orderIds.add(seat.getId());
            }
            
            // Process batch cancellation with refund
            R refundResult = ordersService.batchCancelWithRefund(orderIds, cancelReason);
            if (refundResult.get("code") != null && (Integer)refundResult.get("code") != 0) {
                throw new RuntimeException("退款处理失败");
            }
            
            // Create notifications for affected users
            for (OrdersEntity seat : conflictingSeats) {
                notificationService.createCancellationNotification(seat, cancelReason);
            }
        }
        
        return R.ok().put("reservation", reservation)
                     .put("cancelledSeats", conflictingSeats != null ? conflictingSeats.size() : 0);
    }

    @Override
    @Transactional
    public R cancelReservation(Long reservationId, Long userId, String reason) {
        if (reservationId == null || userId == null) {
            return R.error("参数错误");
        }
        
        // Verify reservation exists and belongs to user
        ClassroomReservationEntity reservation = this.selectById(reservationId);
        if (reservation == null) {
            return R.error("预约不存在");
        }
        
        // Admin can cancel any reservation (userId is null for admin)
        if (userId != null && !reservation.getUserId().equals(userId)) {
            return R.error("无权取消此预约");
        }
        
        if ("cancelled".equals(reservation.getStatus())) {
            return R.error("预约已取消");
        }
        
        // Update status
        reservation.setStatus("cancelled");
        boolean updated = this.updateById(reservation);
        
        if (!updated) {
            return R.error("取消预约失败");
        }
        
        // Log cancellation
        auditLogService.logReservationCancel(
            userId != null ? userId : reservation.getUserId(),
            reservation.getUsername(),
            "classroom",
            reservationId,
            String.format("取消原因: %s", reason != null ? reason : (userId == null ? "管理员取消" : "用户主动取消"))
        );
        
        return R.ok();
    }

    @Override
    public PageUtils queryUserReservations(Long userId, Map<String, Object> params) {
        if (userId == null) {
            return new PageUtils(new Page<>());
        }
        
        EntityWrapper<ClassroomReservationEntity> wrapper = new EntityWrapper<>();
        wrapper.eq("user_id", userId);
        wrapper.orderBy("addtime", false);
        
        Page<ClassroomReservationEntity> page = this.selectPage(
                new Query<ClassroomReservationEntity>(params).getPage(),
                wrapper
        );
        
        return new PageUtils(page);
    }

    @Override
    public List<Map<String, Object>> getAvailableTimeSlots(Long classroomId, Date date) {
        if (classroomId == null || date == null) {
            return new ArrayList<>();
        }
        
        // Get start and end of the day
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        Date dayStart = cal.getTime();
        
        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 59);
        cal.set(Calendar.SECOND, 59);
        Date dayEnd = cal.getTime();
        
        // Query existing reservations for the day
        EntityWrapper<ClassroomReservationEntity> wrapper = new EntityWrapper<>();
        wrapper.eq("classroom_id", classroomId);
        wrapper.notIn("status", new String[]{"cancelled"});
        wrapper.ge("start_time", dayStart);
        wrapper.le("end_time", dayEnd);
        wrapper.orderBy("start_time", true);
        
        List<ClassroomReservationEntity> reservations = this.selectList(wrapper);
        
        // Calculate available slots
        List<Map<String, Object>> availableSlots = new ArrayList<>();
        
        // Define working hours (8:00 - 22:00)
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 8);
        cal.set(Calendar.MINUTE, 0);
        Date workStart = cal.getTime();
        
        cal.set(Calendar.HOUR_OF_DAY, 22);
        cal.set(Calendar.MINUTE, 0);
        Date workEnd = cal.getTime();
        
        Date currentStart = workStart;
        
        for (ClassroomReservationEntity reservation : reservations) {
            if (reservation.getStartTime().after(currentStart)) {
                // Add available slot before this reservation
                Map<String, Object> slot = new HashMap<>();
                slot.put("startTime", currentStart);
                slot.put("endTime", reservation.getStartTime());
                availableSlots.add(slot);
            }
            currentStart = reservation.getEndTime();
        }
        
        // Add final slot if there's time remaining
        if (currentStart.before(workEnd)) {
            Map<String, Object> slot = new HashMap<>();
            slot.put("startTime", currentStart);
            slot.put("endTime", workEnd);
            availableSlots.add(slot);
        }
        
        return availableSlots;
    }
    
    private String formatDate(Date date) {
        if (date == null) return "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        return sdf.format(date);
    }
}
