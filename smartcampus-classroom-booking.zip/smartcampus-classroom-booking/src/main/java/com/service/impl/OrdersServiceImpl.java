package com.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Map;
import java.util.List;
import java.util.Date;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;
import com.utils.R;
import com.utils.TimeValidationUtil;
import com.exception.ConflictException;


import com.dao.OrdersDao;
import com.entity.OrdersEntity;
import com.entity.UsersEntity;
import com.service.AuditLogService;
import com.service.OrdersService;
import com.service.ConflictDetectionService;
import com.service.UsersService;
import com.entity.vo.OrdersVO;
import com.entity.view.OrdersView;

@Service("ordersService")
public class OrdersServiceImpl extends ServiceImpl<OrdersDao, OrdersEntity> implements OrdersService {

	@Autowired
	private ConflictDetectionService conflictDetectionService;
	
	@Autowired
	private UsersService usersService;
	
	@Autowired
	private AuditLogService auditLogService;

	@Override
	public PageUtils queryPage(Map<String, Object> params) {
		Page<OrdersEntity> page = this.selectPage(
				new Query<OrdersEntity>(params).getPage(),
				new EntityWrapper<OrdersEntity>()
		);
		return new PageUtils(page);
	}

	@Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<OrdersEntity> wrapper) {
		Page<OrdersView> page = new Query<OrdersView>(params).getPage();
		page.setRecords(baseMapper.selectListView(page, wrapper));
		PageUtils pageUtil = new PageUtils(page);
		return pageUtil;
	}

	@Override
	public List<OrdersVO> selectListVO(Wrapper<OrdersEntity> wrapper) {
		return baseMapper.selectListVO(wrapper);
	}

	@Override
	public OrdersVO selectVO(Wrapper<OrdersEntity> wrapper) {
		return baseMapper.selectVO(wrapper);
	}

	@Override
	public List<OrdersView> selectListView(Wrapper<OrdersEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public OrdersView selectView(Wrapper<OrdersEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}

	@Override
	public List<Map<String, Object>> selectValue(Map<String, Object> params, Wrapper<OrdersEntity> wrapper) {
		return baseMapper.selectValue(params, wrapper);
	}

	@Override
	public List<Map<String, Object>> selectTimeStatValue(Map<String, Object> params, Wrapper<OrdersEntity> wrapper) {
		return baseMapper.selectTimeStatValue(params, wrapper);
	}

	@Override
	public List<Map<String, Object>> selectGroup(Map<String, Object> params, Wrapper<OrdersEntity> wrapper) {
		return baseMapper.selectGroup(params, wrapper);
	}

	@Override
	public List<Map<String, Object>> ordergroup(Map<String, Object> params, Wrapper<OrdersEntity> wrapper) {
		return baseMapper.ordergroup(params, wrapper);
	}

	@Override
	public R createReservationWithTime(OrdersEntity order) {
		// Validate time range
		String validationError = TimeValidationUtil.validateTimeRange(order.getStartTime(), order.getEndTime());
		if (validationError != null) {
			return R.error(validationError);
		}
		
		// Check for conflicts
		boolean hasConflict = conflictDetectionService.checkSeatConflict(
			order.getGoodid(), 
			order.getStartTime(), 
			order.getEndTime(), 
			null
		);
		
		if (hasConflict) {
			return R.error("该时间段已有预约，请选择其他时间");
		}
		
		// Set creation time
		if (order.getAddtime() == null) {
			order.setAddtime(new Date());
		}
		
		// Insert order
		boolean success = this.insert(order);
		
		if (success) {
			// Log reservation creation
			auditLogService.logReservationCreate(
				order.getUserid(),
				null, // Username can be fetched if needed
				"seat",
				order.getId(),
				String.format("座位预约: %s, 时间: %s - %s", 
					order.getGoodname(),
					order.getStartTime(),
					order.getEndTime())
			);
			return R.ok();
		} else {
			return R.error("预约创建失败");
		}
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public R batchCancelWithRefund(List<Long> orderIds, String reason) {
		if (orderIds == null || orderIds.isEmpty()) {
			return R.ok().put("refundedCount", 0).put("totalRefund", 0.0f);
		}
		
		int refundedCount = 0;
		float totalRefund = 0.0f;
		
		for (Long orderId : orderIds) {
			OrdersEntity order = this.selectById(orderId);
			if (order == null) {
				continue;
			}
			
			// Skip if already cancelled
			if ("已取消".equals(order.getStatus())) {
				continue;
			}
			
			// Calculate refund amount (use discounttotal if available, otherwise total)
			Float refundAmount = order.getDiscounttotal() != null ? order.getDiscounttotal() : order.getTotal();
			if (refundAmount == null) {
				refundAmount = 0.0f;
			}
			
			// Update order status
			order.setStatus("已取消");
			order.setRemark(reason);
			boolean orderUpdated = this.updateById(order);
			
			if (!orderUpdated) {
				throw new RuntimeException("更新订单状态失败: " + orderId);
			}
			
			// Log cancellation
			auditLogService.logReservationCancel(
				order.getUserid(),
				null,
				"seat",
				order.getId(),
				String.format("取消原因: %s", reason)
			);
			
			// Update user balance
			if (order.getUserid() != null && refundAmount > 0) {
				UsersEntity user = usersService.selectById(order.getUserid());
				if (user != null) {
					Float currentBalance = user.getMoney() != null ? user.getMoney() : 0.0f;
					user.setMoney(currentBalance + refundAmount);
					boolean userUpdated = usersService.updateById(user);
					
					if (!userUpdated) {
						throw new RuntimeException("更新用户余额失败: " + user.getId());
					}
					
					totalRefund += refundAmount;
					refundedCount++;
				}
			}
		}
		
		return R.ok()
				.put("refundedCount", refundedCount)
				.put("totalRefund", totalRefund);
	}
}
