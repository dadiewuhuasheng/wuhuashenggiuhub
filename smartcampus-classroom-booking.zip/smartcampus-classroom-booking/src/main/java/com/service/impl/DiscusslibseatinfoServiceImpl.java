package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.DiscusslibseatinfoDao;
import com.entity.DiscusslibseatinfoEntity;
import com.service.DiscusslibseatinfoService;
import com.entity.vo.DiscusslibseatinfoVO;
import com.entity.view.DiscusslibseatinfoView;

@Service("discusslibseatinfoService")
public class DiscusslibseatinfoServiceImpl extends ServiceImpl<DiscusslibseatinfoDao, DiscusslibseatinfoEntity> implements DiscusslibseatinfoService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<DiscusslibseatinfoEntity> page = this.selectPage(
                new Query<DiscusslibseatinfoEntity>(params).getPage(),
                new EntityWrapper<DiscusslibseatinfoEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<DiscusslibseatinfoEntity> wrapper) {
		  Page<DiscusslibseatinfoView> page =new Query<DiscusslibseatinfoView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<DiscusslibseatinfoVO> selectListVO(Wrapper<DiscusslibseatinfoEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public DiscusslibseatinfoVO selectVO(Wrapper<DiscusslibseatinfoEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<DiscusslibseatinfoView> selectListView(Wrapper<DiscusslibseatinfoEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public DiscusslibseatinfoView selectView(Wrapper<DiscusslibseatinfoEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
