package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.LibrarynoticeDao;
import com.entity.LibrarynoticeEntity;
import com.service.LibrarynoticeService;
import com.entity.vo.LibrarynoticeVO;
import com.entity.view.LibrarynoticeView;

@Service("librarynoticeService")
public class LibrarynoticeServiceImpl extends ServiceImpl<LibrarynoticeDao, LibrarynoticeEntity> implements LibrarynoticeService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<LibrarynoticeEntity> page = this.selectPage(
                new Query<LibrarynoticeEntity>(params).getPage(),
                new EntityWrapper<LibrarynoticeEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<LibrarynoticeEntity> wrapper) {
		  Page<LibrarynoticeView> page =new Query<LibrarynoticeView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<LibrarynoticeVO> selectListVO(Wrapper<LibrarynoticeEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public LibrarynoticeVO selectVO(Wrapper<LibrarynoticeEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<LibrarynoticeView> selectListView(Wrapper<LibrarynoticeEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public LibrarynoticeView selectView(Wrapper<LibrarynoticeEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
