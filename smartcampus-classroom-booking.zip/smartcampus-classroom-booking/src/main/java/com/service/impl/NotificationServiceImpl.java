package com.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.dao.NotificationDao;
import com.entity.NotificationEntity;
import com.entity.OrdersEntity;
import com.service.NotificationService;
import com.utils.PageUtils;
import com.utils.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 * 通知服务实现
 * 
 * @author 
 * @email 
 */
@Service("notificationService")
public class NotificationServiceImpl extends ServiceImpl<NotificationDao, NotificationEntity> implements NotificationService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        String userId = (String) params.get("userId");
        String isRead = (String) params.get("isRead");
        
        EntityWrapper<NotificationEntity> wrapper = new EntityWrapper<>();
        
        if (userId != null && !userId.isEmpty()) {
            wrapper.eq("user_id", userId);
        }
        
        if (isRead != null && !isRead.isEmpty()) {
            wrapper.eq("is_read", isRead);
        }
        
        // Order by creation time descending (newest first)
        wrapper.orderBy("addtime", false);
        
        Page<NotificationEntity> page = this.selectPage(
                new Query<NotificationEntity>(params).getPage(),
                wrapper
        );
        
        return new PageUtils(page);
    }

    @Override
    public PageUtils queryPage(Map<String, Object> params, Wrapper<NotificationEntity> wrapper) {
        Page<NotificationEntity> page = this.selectPage(
                new Query<NotificationEntity>(params).getPage(),
                wrapper
        );
        return new PageUtils(page);
    }

    @Override
    @Transactional
    public void createCancellationNotification(OrdersEntity order, String reason) {
        if (order == null || order.getUserid() == null) {
            return;
        }
        
        // Build notification message with reservation details
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        StringBuilder message = new StringBuilder();
        message.append("您的座位预约已被取消。\n");
        message.append("座位: ").append(order.getGoodname() != null ? order.getGoodname() : "未知").append("\n");
        
        if (order.getStartTime() != null && order.getEndTime() != null) {
            message.append("预约时间: ")
                   .append(sdf.format(order.getStartTime()))
                   .append(" 至 ")
                   .append(sdf.format(order.getEndTime()))
                   .append("\n");
        }
        
        message.append("取消原因: ").append(reason != null ? reason : "系统取消");
        
        // Create notification entity
        NotificationEntity notification = new NotificationEntity();
        notification.setUserId(order.getUserid());
        notification.setMessage(message.toString());
        notification.setType("cancellation");
        notification.setRelatedReservationId(order.getId());
        notification.setReservationType("seat");
        notification.setIsRead(0);
        notification.setAddtime(new Date());
        
        // Save notification
        this.insert(notification);
    }

    @Override
    public Integer getUnreadCount(Long userId) {
        if (userId == null) {
            return 0;
        }
        return baseMapper.getUnreadCount(userId);
    }

    @Override
    @Transactional
    public boolean markAsRead(Long notificationId, Long userId) {
        if (notificationId == null || userId == null) {
            return false;
        }
        
        // Verify notification belongs to user
        NotificationEntity notification = this.selectById(notificationId);
        if (notification == null || !notification.getUserId().equals(userId)) {
            return false;
        }
        
        // Update read status
        notification.setIsRead(1);
        return this.updateById(notification);
    }
}
