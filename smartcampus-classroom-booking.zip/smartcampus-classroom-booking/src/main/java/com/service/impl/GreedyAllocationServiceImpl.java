package com.service.impl;

import com.entity.AllocationResult;
import com.entity.ReservationRequest;
import com.service.ConflictDetectionService;
import com.service.GreedyAllocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * 贪心算法分配服务实现
 * 
 * @author 
 * @email 
 */
@Service("greedyAllocationService")
public class GreedyAllocationServiceImpl implements GreedyAllocationService {

    @Autowired
    private ConflictDetectionService conflictDetectionService;

    @Override
    public AllocationResult allocateSeats(List<ReservationRequest> requests) {
        AllocationResult result = new AllocationResult();
        
        if (requests == null || requests.isEmpty()) {
            return result;
        }
        
        // Sort by: (1) start time ascending, (2) duration ascending
        List<ReservationRequest> sortedRequests = new ArrayList<>(requests);
        sortedRequests.sort((r1, r2) -> {
            // First compare by start time
            int timeCompare = r1.getStartTime().compareTo(r2.getStartTime());
            if (timeCompare != 0) {
                return timeCompare;
            }
            // Then compare by duration (shorter first)
            return Long.compare(r1.getDuration(), r2.getDuration());
        });
        
        // Track allocated reservations to check conflicts
        List<ReservationRequest> allocated = new ArrayList<>();
        
        // Process each request in order
        for (ReservationRequest request : sortedRequests) {
            boolean hasConflict = false;
            
            // Check conflict with already allocated reservations
            for (ReservationRequest existing : allocated) {
                if (existing.getResourceId().equals(request.getResourceId())) {
                    // Check time overlap
                    if (isTimeOverlap(existing.getStartTime(), existing.getEndTime(),
                                     request.getStartTime(), request.getEndTime())) {
                        hasConflict = true;
                        break;
                    }
                }
            }
            
            if (!hasConflict) {
                result.addAllocated(request);
                allocated.add(request);
            } else {
                result.addRejected(request);
            }
        }
        
        return result;
    }

    @Override
    public AllocationResult allocateClassrooms(List<ReservationRequest> requests) {
        AllocationResult result = new AllocationResult();
        
        if (requests == null || requests.isEmpty()) {
            return result;
        }
        
        // Sort by: (1) start time ascending, (2) role priority (teacher > student), (3) duration ascending
        List<ReservationRequest> sortedRequests = new ArrayList<>(requests);
        sortedRequests.sort((r1, r2) -> {
            // First compare by start time
            int timeCompare = r1.getStartTime().compareTo(r2.getStartTime());
            if (timeCompare != 0) {
                return timeCompare;
            }
            
            // Then compare by role (teacher has higher priority)
            int role1Priority = "教师".equals(r1.getUserRole()) ? 1 : 0;
            int role2Priority = "教师".equals(r2.getUserRole()) ? 1 : 0;
            int roleCompare = Integer.compare(role2Priority, role1Priority); // Descending
            if (roleCompare != 0) {
                return roleCompare;
            }
            
            // Finally compare by duration (shorter first)
            return Long.compare(r1.getDuration(), r2.getDuration());
        });
        
        // Track allocated reservations to check conflicts
        List<ReservationRequest> allocated = new ArrayList<>();
        
        // Process each request in order
        for (ReservationRequest request : sortedRequests) {
            boolean hasConflict = false;
            boolean canCancelConflict = "教师".equals(request.getUserRole());
            List<ReservationRequest> conflictingRequests = new ArrayList<>();
            
            // Check conflict with already allocated reservations
            for (ReservationRequest existing : allocated) {
                if (existing.getResourceId().equals(request.getResourceId())) {
                    // Check time overlap
                    if (isTimeOverlap(existing.getStartTime(), existing.getEndTime(),
                                     request.getStartTime(), request.getEndTime())) {
                        hasConflict = true;
                        conflictingRequests.add(existing);
                    }
                }
            }
            
            if (!hasConflict) {
                // No conflict, allocate directly
                result.addAllocated(request);
                allocated.add(request);
            } else if (canCancelConflict) {
                // Teacher can cancel conflicting student reservations
                boolean canAllocate = true;
                for (ReservationRequest conflict : conflictingRequests) {
                    if ("教师".equals(conflict.getUserRole())) {
                        // Cannot cancel teacher's reservation
                        canAllocate = false;
                        break;
                    }
                }
                
                if (canAllocate) {
                    // Remove conflicting student reservations
                    for (ReservationRequest conflict : conflictingRequests) {
                        allocated.remove(conflict);
                        result.getAllocated().remove(conflict);
                        result.addRejected(conflict);
                    }
                    // Allocate teacher's request
                    result.addAllocated(request);
                    allocated.add(request);
                } else {
                    result.addRejected(request);
                }
            } else {
                // Student cannot override, reject
                result.addRejected(request);
            }
        }
        
        return result;
    }
    
    /**
     * 检查两个时间段是否重叠
     */
    private boolean isTimeOverlap(Date start1, Date end1, Date start2, Date end2) {
        // Overlap condition: start1 < end2 AND start2 < end1
        return start1.before(end2) && start2.before(end1);
    }
}
