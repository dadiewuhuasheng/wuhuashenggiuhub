package com.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.dao.AddressDao;
import com.entity.AddressEntity;
import com.service.AddressService;
import com.utils.PageUtils;
import com.utils.Query;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * 地址服务实现
 */
@Service("addressService")
public class AddressServiceImpl extends ServiceImpl<AddressDao, AddressEntity> implements AddressService {

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<AddressEntity> page = this.selectPage(
                new Query<AddressEntity>(params).getPage(),
                new EntityWrapper<AddressEntity>()
        );
        return new PageUtils(page);
    }

    @Override
    public PageUtils queryPage(Map<String, Object> params, Wrapper<AddressEntity> wrapper) {
        Page<AddressEntity> page = this.selectPage(
                new Query<AddressEntity>(params).getPage(),
                wrapper
        );
        return new PageUtils(page);
    }

    @Override
    public List<AddressEntity> selectListView(Wrapper<AddressEntity> wrapper) {
        return baseMapper.selectListView(wrapper);
    }

    @Override
    public AddressEntity selectView(Wrapper<AddressEntity> wrapper) {
        return baseMapper.selectView(wrapper);
    }
}
