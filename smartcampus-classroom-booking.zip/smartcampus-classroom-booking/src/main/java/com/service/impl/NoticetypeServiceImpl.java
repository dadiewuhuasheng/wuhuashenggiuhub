package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.NoticetypeDao;
import com.entity.NoticetypeEntity;
import com.service.NoticetypeService;
import com.entity.vo.NoticetypeVO;
import com.entity.view.NoticetypeView;

@Service("noticetypeService")
public class NoticetypeServiceImpl extends ServiceImpl<NoticetypeDao, NoticetypeEntity> implements NoticetypeService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<NoticetypeEntity> page = this.selectPage(
                new Query<NoticetypeEntity>(params).getPage(),
                new EntityWrapper<NoticetypeEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<NoticetypeEntity> wrapper) {
		  Page<NoticetypeView> page =new Query<NoticetypeView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<NoticetypeVO> selectListVO(Wrapper<NoticetypeEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public NoticetypeVO selectVO(Wrapper<NoticetypeEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<NoticetypeView> selectListView(Wrapper<NoticetypeEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public NoticetypeView selectView(Wrapper<NoticetypeEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
