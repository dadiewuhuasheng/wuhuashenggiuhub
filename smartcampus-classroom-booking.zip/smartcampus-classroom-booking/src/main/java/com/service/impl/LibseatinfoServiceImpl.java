package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.LibseatinfoDao;
import com.entity.LibseatinfoEntity;
import com.service.LibseatinfoService;
import com.entity.vo.LibseatinfoVO;
import com.entity.view.LibseatinfoView;

@Service("libseatinfoService")
public class LibseatinfoServiceImpl extends ServiceImpl<LibseatinfoDao, LibseatinfoEntity> implements LibseatinfoService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<LibseatinfoEntity> page = this.selectPage(
                new Query<LibseatinfoEntity>(params).getPage(),
                new EntityWrapper<LibseatinfoEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<LibseatinfoEntity> wrapper) {
		  Page<LibseatinfoView> page =new Query<LibseatinfoView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<LibseatinfoVO> selectListVO(Wrapper<LibseatinfoEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public LibseatinfoVO selectVO(Wrapper<LibseatinfoEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<LibseatinfoView> selectListView(Wrapper<LibseatinfoEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public LibseatinfoView selectView(Wrapper<LibseatinfoEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
