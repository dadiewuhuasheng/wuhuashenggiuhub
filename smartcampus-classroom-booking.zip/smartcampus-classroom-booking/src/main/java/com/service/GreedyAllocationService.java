package com.service;

import com.entity.AllocationResult;
import com.entity.ReservationRequest;

import java.util.List;

/**
 * 贪心算法分配服务接口
 * 用于优化资源分配
 * 
 * @author 
 * @email 
 */
public interface GreedyAllocationService {
    
    /**
     * 分配座位预约
     * 使用贪心算法：按开始时间升序，时长升序排序
     * 
     * @param requests 预约请求列表
     * @return 分配结果
     */
    AllocationResult allocateSeats(List<ReservationRequest> requests);
    
    /**
     * 分配教室预约
     * 使用贪心算法：按开始时间升序，角色优先级（教师>学生），时长升序排序
     * 
     * @param requests 预约请求列表
     * @return 分配结果
     */
    AllocationResult allocateClassrooms(List<ReservationRequest> requests);
}
