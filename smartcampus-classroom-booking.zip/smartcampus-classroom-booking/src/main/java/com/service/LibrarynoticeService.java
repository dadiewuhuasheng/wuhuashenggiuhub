package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.LibrarynoticeEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.LibrarynoticeVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.LibrarynoticeView;


/**
 * 教室宣传
 *
 * @author 
 * @email 
 */
public interface LibrarynoticeService extends IService<LibrarynoticeEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<LibrarynoticeVO> selectListVO(Wrapper<LibrarynoticeEntity> wrapper);
   	
   	LibrarynoticeVO selectVO(@Param("ew") Wrapper<LibrarynoticeEntity> wrapper);
   	
   	List<LibrarynoticeView> selectListView(Wrapper<LibrarynoticeEntity> wrapper);
   	
   	LibrarynoticeView selectView(@Param("ew") Wrapper<LibrarynoticeEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<LibrarynoticeEntity> wrapper);
   	

}

