package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.LibseatinfoEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.LibseatinfoVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.LibseatinfoView;


/**
 * 座位信息
 *
 * @author 
 * @email 
 */
public interface LibseatinfoService extends IService<LibseatinfoEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<LibseatinfoVO> selectListVO(Wrapper<LibseatinfoEntity> wrapper);
   	
   	LibseatinfoVO selectVO(@Param("ew") Wrapper<LibseatinfoEntity> wrapper);
   	
   	List<LibseatinfoView> selectListView(Wrapper<LibseatinfoEntity> wrapper);
   	
   	LibseatinfoView selectView(@Param("ew") Wrapper<LibseatinfoEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<LibseatinfoEntity> wrapper);
   	

}

