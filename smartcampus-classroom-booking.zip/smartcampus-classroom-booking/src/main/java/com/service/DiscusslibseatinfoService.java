package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.DiscusslibseatinfoEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.DiscusslibseatinfoVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.DiscusslibseatinfoView;


/**
 * 座位信息评论表
 *
 * @author 
 * @email 
 */
public interface DiscusslibseatinfoService extends IService<DiscusslibseatinfoEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<DiscusslibseatinfoVO> selectListVO(Wrapper<DiscusslibseatinfoEntity> wrapper);
   	
   	DiscusslibseatinfoVO selectVO(@Param("ew") Wrapper<DiscusslibseatinfoEntity> wrapper);
   	
   	List<DiscusslibseatinfoView> selectListView(Wrapper<DiscusslibseatinfoEntity> wrapper);
   	
   	DiscusslibseatinfoView selectView(@Param("ew") Wrapper<DiscusslibseatinfoEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<DiscusslibseatinfoEntity> wrapper);
   	

}

