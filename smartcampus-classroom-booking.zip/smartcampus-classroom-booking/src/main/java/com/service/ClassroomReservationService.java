package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.entity.ClassroomReservationEntity;
import com.utils.PageUtils;
import com.utils.R;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 教室预约服务接口
 * 
 * @author 
 * @email 
 */
public interface ClassroomReservationService extends IService<ClassroomReservationEntity> {
    
    /**
     * 分页查询教室预约
     * 
     * @param params 查询参数
     * @return 分页结果
     */
    PageUtils queryPage(Map<String, Object> params);
    
    /**
     * 分页查询教室预约（带条件）
     * 
     * @param params 查询参数
     * @param wrapper 查询条件
     * @return 分页结果
     */
    PageUtils queryPage(Map<String, Object> params, Wrapper<ClassroomReservationEntity> wrapper);
    
    /**
     * 创建教室预约（带优先级逻辑）
     * 
     * @param reservation 教室预约信息
     * @param userRole 用户角色
     * @return 操作结果
     */
    R createReservation(ClassroomReservationEntity reservation, String userRole);
    
    /**
     * 取消教室预约
     * 
     * @param reservationId 预约ID
     * @param userId 用户ID
     * @param reason 取消原因
     * @return 操作结果
     */
    R cancelReservation(Long reservationId, Long userId, String reason);
    
    /**
     * 查询用户的教室预约
     * 
     * @param userId 用户ID
     * @param params 分页参数
     * @return 分页结果
     */
    PageUtils queryUserReservations(Long userId, Map<String, Object> params);
    
    /**
     * 获取教室可用时间段
     * 
     * @param classroomId 教室ID
     * @param date 日期
     * @return 可用时间段列表
     */
    List<Map<String, Object>> getAvailableTimeSlots(Long classroomId, Date date);
}
