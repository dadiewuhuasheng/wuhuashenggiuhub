package com;

import com.controller.UsersController;
import com.dao.UsersDao;
import com.entity.UsersEntity;
import com.utils.R;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import static org.junit.Assert.*;

/**
 * 基于角色的身份验证属性测试
 * 
 * Feature: classroom-reservation-enhancement, Property 2: Role-Based Authentication
 * Validates: Requirements 1.3, 2.2, 2.3, 2.4
 * 
 * Property: For any user with a stored role, login attempts should succeed only when 
 * the provided username, password, and role all match the stored values.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class RoleBasedAuthenticationPropertyTest {

    @Autowired
    private UsersController usersController;

    @Autowired
    private UsersDao usersDao;

    private List<Long> createdUserIds = new ArrayList<>();
    private Random random = new Random();
    private MockHttpServletRequest request;

    @Before
    public void setup() {
        request = new MockHttpServletRequest();
    }

    @After
    public void cleanup() {
        for (Long userId : createdUserIds) {
            try {
                usersDao.deleteById(userId);
            } catch (Exception e) {
                // Ignore cleanup errors
            }
        }
        createdUserIds.clear();
    }

    /**
     * 属性测试：正确的用户名、密码和角色应该登录成功
     * 
     * 对于任意用户，当提供正确的用户名、密码和角色时，登录应该成功
     */
    @Test
    public void testCorrectCredentialsAndRoleSucceed() {
        for (int i = 0; i < 100; i++) {
            // Create random user
            UsersEntity user = generateRandomUser();
            usersDao.insert(user);
            createdUserIds.add(user.getId());
            
            // Attempt login with correct credentials and role
            R result = usersController.login(
                user.getUsername(), 
                user.getPassword(), 
                user.getRole(), 
                null, 
                request
            );
            
            // Verify login succeeded
            assertEquals("正确的凭据和角色应该登录成功 (iteration " + i + ")", 
                        Integer.valueOf(0), result.get("code"));
            assertNotNull("应该返回token", result.get("token"));
            assertEquals("应该返回正确的角色", user.getRole(), result.get("role"));
        }
    }

    /**
     * 属性测试：错误的角色应该导致登录失败
     * 
     * 对于任意用户，当提供正确的用户名和密码但错误的角色时，登录应该失败
     */
    @Test
    public void testIncorrectRoleFails() {
        for (int i = 0; i < 100; i++) {
            // Create random user
            UsersEntity user = generateRandomUser();
            usersDao.insert(user);
            createdUserIds.add(user.getId());
            
            // Determine wrong role
            String wrongRole = user.getRole().equals("student") ? "teacher" : "student";
            
            // Attempt login with wrong role
            R result = usersController.login(
                user.getUsername(), 
                user.getPassword(), 
                wrongRole, 
                null, 
                request
            );
            
            // Verify login failed
            assertNotEquals("错误的角色应该导致登录失败 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
            assertNull("不应该返回token", result.get("token"));
        }
    }

    /**
     * 属性测试：错误的密码应该导致登录失败（无论角色是否正确）
     * 
     * 对于任意用户，当提供错误的密码时，登录应该失败
     */
    @Test
    public void testIncorrectPasswordFails() {
        for (int i = 0; i < 50; i++) {
            // Create random user
            UsersEntity user = generateRandomUser();
            usersDao.insert(user);
            createdUserIds.add(user.getId());
            
            // Attempt login with wrong password but correct role
            R result = usersController.login(
                user.getUsername(), 
                "wrongpassword" + random.nextInt(10000), 
                user.getRole(), 
                null, 
                request
            );
            
            // Verify login failed
            assertNotEquals("错误的密码应该导致登录失败 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
            assertNull("不应该返回token", result.get("token"));
        }
    }

    /**
     * 属性测试：不存在的用户名应该导致登录失败
     * 
     * 对于任意不存在的用户名，登录应该失败
     */
    @Test
    public void testNonexistentUsernameFails() {
        for (int i = 0; i < 50; i++) {
            // Generate random non-existent username
            String nonexistentUsername = "nonexistent_" + System.currentTimeMillis() + "_" + random.nextInt(100000);
            
            // Attempt login
            R result = usersController.login(
                nonexistentUsername, 
                "anypassword", 
                "student", 
                null, 
                request
            );
            
            // Verify login failed
            assertNotEquals("不存在的用户名应该导致登录失败 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
            assertNull("不应该返回token", result.get("token"));
        }
    }

    /**
     * 属性测试：学生角色用户只能以学生身份登录
     * 
     * 对于任意学生角色用户，尝试以教师身份登录应该失败
     */
    @Test
    public void testStudentCannotLoginAsTeacher() {
        for (int i = 0; i < 50; i++) {
            // Create student user
            UsersEntity user = generateRandomUser();
            user.setRole("student");
            usersDao.insert(user);
            createdUserIds.add(user.getId());
            
            // Attempt login as teacher
            R result = usersController.login(
                user.getUsername(), 
                user.getPassword(), 
                "teacher", 
                null, 
                request
            );
            
            // Verify login failed
            assertNotEquals("学生不能以教师身份登录 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
            assertNull("不应该返回token", result.get("token"));
        }
    }

    /**
     * 属性测试：教师角色用户只能以教师身份登录
     * 
     * 对于任意教师角色用户，尝试以学生身份登录应该失败
     */
    @Test
    public void testTeacherCannotLoginAsStudent() {
        for (int i = 0; i < 50; i++) {
            // Create teacher user
            UsersEntity user = generateRandomUser();
            user.setRole("teacher");
            usersDao.insert(user);
            createdUserIds.add(user.getId());
            
            // Attempt login as student
            R result = usersController.login(
                user.getUsername(), 
                user.getPassword(), 
                "student", 
                null, 
                request
            );
            
            // Verify login failed
            assertNotEquals("教师不能以学生身份登录 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
            assertNull("不应该返回token", result.get("token"));
        }
    }

    /**
     * 属性测试：null角色应该被接受（向后兼容）
     * 
     * 对于任意用户，当角色参数为null时，只要用户名和密码正确就应该登录成功
     */
    @Test
    public void testNullRoleAccepted() {
        for (int i = 0; i < 50; i++) {
            // Create random user
            UsersEntity user = generateRandomUser();
            usersDao.insert(user);
            createdUserIds.add(user.getId());
            
            // Attempt login with null role
            R result = usersController.login(
                user.getUsername(), 
                user.getPassword(), 
                null, 
                null, 
                request
            );
            
            // Verify login succeeded (backward compatibility)
            assertEquals("null角色应该被接受以保持向后兼容 (iteration " + i + ")", 
                        Integer.valueOf(0), result.get("code"));
            assertNotNull("应该返回token", result.get("token"));
        }
    }

    /**
     * 生成随机用户实体
     */
    private UsersEntity generateRandomUser() {
        UsersEntity user = new UsersEntity();
        
        long timestamp = System.currentTimeMillis();
        int randomSuffix = random.nextInt(100000);
        
        user.setId(timestamp + randomSuffix);
        user.setUsername("testuser_" + timestamp + "_" + randomSuffix);
        user.setPassword("password" + randomSuffix);
        user.setNickname("测试用户" + randomSuffix);
        user.setGender(random.nextBoolean() ? "男" : "女");
        user.setTelephone("1" + String.format("%010d", random.nextInt(1000000000)));
        user.setRole(random.nextBoolean() ? "student" : "teacher");
        user.setMoney(random.nextFloat() * 1000);
        user.setAddtime(new Date());
        
        return user;
    }
}
