package com;

import com.controller.UsersController;
import com.dao.UsersDao;
import com.entity.UsersEntity;
import com.utils.R;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import static org.junit.Assert.*;

/**
 * 注册角色验证属性测试
 * 
 * Feature: classroom-reservation-enhancement, Property 3: Registration Role Validation
 * Validates: Requirements 1.2
 * 
 * Property: For any user registration request without a role field, the system should 
 * reject the request with a validation error.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class RegistrationRoleValidationPropertyTest {

    @Autowired
    private UsersController usersController;

    @Autowired
    private UsersDao usersDao;

    private List<Long> createdUserIds = new ArrayList<>();
    private Random random = new Random();

    @After
    public void cleanup() {
        for (Long userId : createdUserIds) {
            try {
                usersDao.deleteById(userId);
            } catch (Exception e) {
                // Ignore cleanup errors
            }
        }
        createdUserIds.clear();
    }

    /**
     * 属性测试：没有角色字段的注册应该被拒绝
     * 
     * 对于任意用户注册请求，如果没有提供角色字段，应该返回错误
     */
    @Test
    public void testRegistrationWithoutRoleFails() {
        for (int i = 0; i < 100; i++) {
            // Create user without role
            UsersEntity user = generateRandomUser();
            user.setRole(null);
            
            // Attempt registration
            R result = usersController.register(user);
            
            // Verify registration failed
            assertNotEquals("没有角色的注册应该失败 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
            
            // Verify user was not created
            UsersEntity checkUser = usersDao.selectById(user.getId());
            assertNull("用户不应该被创建", checkUser);
        }
    }

    /**
     * 属性测试：空角色字符串的注册应该被拒绝
     * 
     * 对于任意用户注册请求，如果角色字段为空字符串，应该返回错误
     */
    @Test
    public void testRegistrationWithEmptyRoleFails() {
        for (int i = 0; i < 100; i++) {
            // Create user with empty role
            UsersEntity user = generateRandomUser();
            user.setRole("");
            
            // Attempt registration
            R result = usersController.register(user);
            
            // Verify registration failed
            assertNotEquals("空角色的注册应该失败 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
            
            // Verify user was not created
            UsersEntity checkUser = usersDao.selectById(user.getId());
            assertNull("用户不应该被创建", checkUser);
        }
    }

    /**
     * 属性测试：有效的学生角色注册应该成功
     * 
     * 对于任意用户注册请求，如果角色为 'student'，应该注册成功
     */
    @Test
    public void testRegistrationWithStudentRoleSucceeds() {
        for (int i = 0; i < 50; i++) {
            // Create user with student role
            UsersEntity user = generateRandomUser();
            user.setRole("student");
            
            // Attempt registration
            R result = usersController.register(user);
            
            // Verify registration succeeded
            assertEquals("学生角色注册应该成功 (iteration " + i + ")", 
                        Integer.valueOf(0), result.get("code"));
            
            // Verify user was created with correct role
            UsersEntity createdUser = usersDao.selectById(user.getId());
            assertNotNull("用户应该被创建", createdUser);
            assertEquals("角色应该是student", "student", createdUser.getRole());
            
            createdUserIds.add(user.getId());
        }
    }

    /**
     * 属性测试：有效的教师角色注册应该成功
     * 
     * 对于任意用户注册请求，如果角色为 'teacher'，应该注册成功
     */
    @Test
    public void testRegistrationWithTeacherRoleSucceeds() {
        for (int i = 0; i < 50; i++) {
            // Create user with teacher role
            UsersEntity user = generateRandomUser();
            user.setRole("teacher");
            
            // Attempt registration
            R result = usersController.register(user);
            
            // Verify registration succeeded
            assertEquals("教师角色注册应该成功 (iteration " + i + ")", 
                        Integer.valueOf(0), result.get("code"));
            
            // Verify user was created with correct role
            UsersEntity createdUser = usersDao.selectById(user.getId());
            assertNotNull("用户应该被创建", createdUser);
            assertEquals("角色应该是teacher", "teacher", createdUser.getRole());
            
            createdUserIds.add(user.getId());
        }
    }

    /**
     * 属性测试：无效的角色值应该被拒绝
     * 
     * 对于任意用户注册请求，如果角色不是 'student' 或 'teacher'，应该返回错误
     */
    @Test
    public void testRegistrationWithInvalidRoleFails() {
        String[] invalidRoles = {"admin", "guest", "moderator", "user", "STUDENT", "TEACHER", "123", "null"};
        
        for (int i = 0; i < 100; i++) {
            // Create user with invalid role
            UsersEntity user = generateRandomUser();
            String invalidRole = invalidRoles[random.nextInt(invalidRoles.length)];
            user.setRole(invalidRole);
            
            // Attempt registration
            R result = usersController.register(user);
            
            // Verify registration failed
            assertNotEquals("无效角色 '" + invalidRole + "' 的注册应该失败 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
            
            // Verify user was not created
            UsersEntity checkUser = usersDao.selectById(user.getId());
            assertNull("用户不应该被创建", checkUser);
        }
    }

    /**
     * 属性测试：角色验证应该在用户名重复检查之前或同时进行
     * 
     * 即使用户名已存在，如果角色无效，也应该返回角色验证错误
     */
    @Test
    public void testRoleValidationOccursBeforeOrWithDuplicateCheck() {
        // Create an existing user
        UsersEntity existingUser = generateRandomUser();
        existingUser.setRole("student");
        usersDao.insert(existingUser);
        createdUserIds.add(existingUser.getId());
        
        for (int i = 0; i < 20; i++) {
            // Try to register with same username but no role
            UsersEntity duplicateUser = generateRandomUser();
            duplicateUser.setUsername(existingUser.getUsername());
            duplicateUser.setRole(null);
            
            // Attempt registration
            R result = usersController.register(duplicateUser);
            
            // Verify registration failed (either role validation or duplicate username)
            assertNotEquals("注册应该失败 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
        }
    }

    /**
     * 属性测试：角色字段大小写敏感
     * 
     * 对于任意用户注册请求，角色值应该严格匹配 'student' 或 'teacher'（小写）
     */
    @Test
    public void testRoleIsCaseSensitive() {
        String[] caseMismatchRoles = {"Student", "STUDENT", "Teacher", "TEACHER", "StUdEnT", "TeAcHeR"};
        
        for (int i = 0; i < 50; i++) {
            // Create user with case mismatch role
            UsersEntity user = generateRandomUser();
            String caseMismatchRole = caseMismatchRoles[random.nextInt(caseMismatchRoles.length)];
            user.setRole(caseMismatchRole);
            
            // Attempt registration
            R result = usersController.register(user);
            
            // Verify registration failed
            assertNotEquals("大小写不匹配的角色 '" + caseMismatchRole + "' 应该失败 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
            
            // Verify user was not created
            UsersEntity checkUser = usersDao.selectById(user.getId());
            assertNull("用户不应该被创建", checkUser);
        }
    }

    /**
     * 生成随机用户实体
     */
    private UsersEntity generateRandomUser() {
        UsersEntity user = new UsersEntity();
        
        long timestamp = System.currentTimeMillis();
        int randomSuffix = random.nextInt(100000);
        
        user.setId(timestamp + randomSuffix);
        user.setUsername("testuser_" + timestamp + "_" + randomSuffix);
        user.setPassword("password" + randomSuffix);
        user.setNickname("测试用户" + randomSuffix);
        user.setGender(random.nextBoolean() ? "男" : "女");
        user.setTelephone("1" + String.format("%010d", random.nextInt(1000000000)));
        user.setMoney(random.nextFloat() * 1000);
        user.setAddtime(new Date());
        
        return user;
    }
}
