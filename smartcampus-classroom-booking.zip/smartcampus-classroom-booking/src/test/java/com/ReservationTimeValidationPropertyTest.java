package com;

import com.entity.OrdersEntity;
import com.service.OrdersService;
import com.utils.R;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import static org.junit.Assert.*;

/**
 * 预约时间验证属性测试
 * 
 * Feature: classroom-reservation-enhancement, Property 4: Reservation Time Validation
 * Validates: Requirements 3.1, 3.2, 3.3, 5.2
 * 
 * Property: For any seat or classroom reservation request, the system should reject it if:
 * (a) start time or end time is missing, (b) start time >= end time, or (c) start time is in the past.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class ReservationTimeValidationPropertyTest {

    @Autowired
    private OrdersService ordersService;

    private Random random = new Random();

    /**
     * 属性测试：缺少开始时间应该被拒绝
     * 
     * 对于任意预约请求，如果缺少开始时间，应该返回错误
     */
    @Test
    public void testMissingStartTimeRejected() {
        for (int i = 0; i < 100; i++) {
            OrdersEntity order = generateRandomOrder();
            order.setStartTime(null);
            order.setEndTime(generateFutureTime(1, 3));
            
            R result = ordersService.createReservationWithTime(order);
            
            assertNotEquals("缺少开始时间应该被拒绝 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
        }
    }

    /**
     * 属性测试：缺少结束时间应该被拒绝
     * 
     * 对于任意预约请求，如果缺少结束时间，应该返回错误
     */
    @Test
    public void testMissingEndTimeRejected() {
        for (int i = 0; i < 100; i++) {
            OrdersEntity order = generateRandomOrder();
            order.setStartTime(generateFutureTime(1, 3));
            order.setEndTime(null);
            
            R result = ordersService.createReservationWithTime(order);
            
            assertNotEquals("缺少结束时间应该被拒绝 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
        }
    }

    /**
     * 属性测试：开始时间在过去应该被拒绝
     * 
     * 对于任意预约请求，如果开始时间在过去，应该返回错误
     */
    @Test
    public void testPastStartTimeRejected() {
        for (int i = 0; i < 100; i++) {
            OrdersEntity order = generateRandomOrder();
            
            // Generate past start time
            Date pastTime = generatePastTime(1, 10);
            Date endTime = new Date(pastTime.getTime() + (1 + random.nextInt(5)) * 3600000L);
            
            order.setStartTime(pastTime);
            order.setEndTime(endTime);
            
            R result = ordersService.createReservationWithTime(order);
            
            assertNotEquals("过去的开始时间应该被拒绝 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
        }
    }

    /**
     * 属性测试：开始时间等于结束时间应该被拒绝
     * 
     * 对于任意预约请求，如果开始时间等于结束时间，应该返回错误
     */
    @Test
    public void testEqualStartEndTimeRejected() {
        for (int i = 0; i < 100; i++) {
            OrdersEntity order = generateRandomOrder();
            Date time = generateFutureTime(1, 10);
            
            order.setStartTime(time);
            order.setEndTime(time);
            
            R result = ordersService.createReservationWithTime(order);
            
            assertNotEquals("开始时间等于结束时间应该被拒绝 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
        }
    }

    /**
     * 属性测试：开始时间晚于结束时间应该被拒绝
     * 
     * 对于任意预约请求，如果开始时间晚于结束时间，应该返回错误
     */
    @Test
    public void testStartAfterEndTimeRejected() {
        for (int i = 0; i < 100; i++) {
            OrdersEntity order = generateRandomOrder();
            
            Date endTime = generateFutureTime(1, 5);
            Date startTime = new Date(endTime.getTime() + (1 + random.nextInt(5)) * 3600000L);
            
            order.setStartTime(startTime);
            order.setEndTime(endTime);
            
            R result = ordersService.createReservationWithTime(order);
            
            assertNotEquals("开始时间晚于结束时间应该被拒绝 (iteration " + i + ")", 
                           Integer.valueOf(0), result.get("code"));
        }
    }

    /**
     * 属性测试：有效的时间范围应该被接受
     * 
     * 对于任意预约请求，如果时间范围有效（开始时间在未来且早于结束时间），应该成功
     */
    @Test
    public void testValidTimeRangeAccepted() {
        for (int i = 0; i < 100; i++) {
            OrdersEntity order = generateRandomOrder();
            
            Date startTime = generateFutureTime(1, 10);
            Date endTime = new Date(startTime.getTime() + (1 + random.nextInt(5)) * 3600000L);
            
            order.setStartTime(startTime);
            order.setEndTime(endTime);
            
            R result = ordersService.createReservationWithTime(order);
            
            assertEquals("有效的时间范围应该被接受 (iteration " + i + ")", 
                        Integer.valueOf(0), result.get("code"));
        }
    }

    /**
     * 属性测试：极短的预约时间（1分钟）应该被接受
     * 
     * 对于任意预约请求，即使预约时长很短（如1分钟），只要时间有效就应该被接受
     */
    @Test
    public void testVeryShortDurationAccepted() {
        for (int i = 0; i < 50; i++) {
            OrdersEntity order = generateRandomOrder();
            
            Date startTime = generateFutureTime(1, 10);
            Date endTime = new Date(startTime.getTime() + 60000L); // 1 minute later
            
            order.setStartTime(startTime);
            order.setEndTime(endTime);
            
            R result = ordersService.createReservationWithTime(order);
            
            assertEquals("极短的预约时间应该被接受 (iteration " + i + ")", 
                        Integer.valueOf(0), result.get("code"));
        }
    }

    /**
     * 属性测试：极长的预约时间（数天）应该被接受
     * 
     * 对于任意预约请求，即使预约时长很长（如数天），只要时间有效就应该被接受
     */
    @Test
    public void testVeryLongDurationAccepted() {
        for (int i = 0; i < 50; i++) {
            OrdersEntity order = generateRandomOrder();
            
            Date startTime = generateFutureTime(1, 5);
            int daysToAdd = 1 + random.nextInt(10); // 1-10 days
            Date endTime = new Date(startTime.getTime() + daysToAdd * 86400000L);
            
            order.setStartTime(startTime);
            order.setEndTime(endTime);
            
            R result = ordersService.createReservationWithTime(order);
            
            assertEquals("极长的预约时间应该被接受 (iteration " + i + ")", 
                        Integer.valueOf(0), result.get("code"));
        }
    }

    /**
     * 属性测试：边界情况 - 开始时间刚好在当前时间之后1毫秒
     * 
     * 对于任意预约请求，如果开始时间刚好在当前时间之后，应该被接受
     */
    @Test
    public void testStartTimeJustAfterNowAccepted() {
        for (int i = 0; i < 50; i++) {
            OrdersEntity order = generateRandomOrder();
            
            // Sleep briefly to ensure time has passed
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                // Ignore
            }
            
            Date startTime = new Date(System.currentTimeMillis() + 1000L); // 1 second from now
            Date endTime = new Date(startTime.getTime() + 3600000L); // 1 hour later
            
            order.setStartTime(startTime);
            order.setEndTime(endTime);
            
            R result = ordersService.createReservationWithTime(order);
            
            assertEquals("刚好在当前时间之后的开始时间应该被接受 (iteration " + i + ")", 
                        Integer.valueOf(0), result.get("code"));
        }
    }

    /**
     * 生成随机预约实体
     */
    private OrdersEntity generateRandomOrder() {
        OrdersEntity order = new OrdersEntity();
        
        long timestamp = System.currentTimeMillis();
        int randomSuffix = random.nextInt(100000);
        
        order.setId(timestamp + randomSuffix);
        order.setOrderid("ORDER_" + timestamp + "_" + randomSuffix);
        order.setTablename("libseatinfo");
        order.setUserid(1L + random.nextInt(1000));
        order.setGoodid(1L + random.nextInt(100));
        order.setGoodname("座位" + random.nextInt(100));
        order.setBuynumber(1);
        order.setPrice(10.0f);
        order.setTotal(10.0f);
        order.setStatus("已预约");
        order.setAddtime(new Date());
        
        return order;
    }

    /**
     * 生成未来时间
     * 
     * @param minHours 最小小时数
     * @param maxHours 最大小时数
     * @return 未来时间
     */
    private Date generateFutureTime(int minHours, int maxHours) {
        long hoursToAdd = minHours + random.nextInt(maxHours - minHours + 1);
        return new Date(System.currentTimeMillis() + hoursToAdd * 3600000L);
    }

    /**
     * 生成过去时间
     * 
     * @param minHours 最小小时数
     * @param maxHours 最大小时数
     * @return 过去时间
     */
    private Date generatePastTime(int minHours, int maxHours) {
        long hoursToSubtract = minHours + random.nextInt(maxHours - minHours + 1);
        return new Date(System.currentTimeMillis() - hoursToSubtract * 3600000L);
    }
}
