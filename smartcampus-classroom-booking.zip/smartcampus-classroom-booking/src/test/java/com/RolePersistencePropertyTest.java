package com;

import com.dao.UsersDao;
import com.entity.UsersEntity;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import static org.junit.Assert.*;

/**
 * 角色持久化属性测试
 * 
 * Feature: classroom-reservation-enhancement, Property 1: Role Persistence Round Trip
 * Validates: Requirements 1.4, 1.5
 * 
 * Property: For any user created with a specific role, retrieving that user from the 
 * database should return the same role value.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class RolePersistencePropertyTest {

    @Autowired
    private UsersDao usersDao;

    private List<Long> createdUserIds = new ArrayList<>();
    private Random random = new Random();

    @After
    public void cleanup() {
        // Clean up test data
        for (Long userId : createdUserIds) {
            try {
                usersDao.deleteById(userId);
            } catch (Exception e) {
                // Ignore cleanup errors
            }
        }
        createdUserIds.clear();
    }

    /**
     * 属性测试：角色持久化往返一致性
     * 
     * 对于任意用户和角色值，创建用户后从数据库检索应该返回相同的角色值
     */
    @Test
    public void testRolePersistenceRoundTrip() {
        // Run property test with 100 iterations
        for (int i = 0; i < 100; i++) {
            // Generate random user with random role
            UsersEntity user = generateRandomUser();
            String originalRole = user.getRole();
            
            // Insert user into database
            usersDao.insert(user);
            createdUserIds.add(user.getId());
            
            // Retrieve user from database
            UsersEntity retrievedUser = usersDao.selectById(user.getId());
            
            // Verify role persisted correctly
            assertNotNull("检索到的用户不应为null", retrievedUser);
            assertEquals("检索到的角色应该与原始角色相同 (iteration " + i + ")", 
                        originalRole, retrievedUser.getRole());
        }
    }

    /**
     * 属性测试：学生角色持久化
     * 
     * 对于任意具有 'student' 角色的用户，检索后应该返回 'student'
     */
    @Test
    public void testStudentRolePersistence() {
        for (int i = 0; i < 50; i++) {
            UsersEntity user = generateRandomUser();
            user.setRole("student");
            
            usersDao.insert(user);
            createdUserIds.add(user.getId());
            
            UsersEntity retrievedUser = usersDao.selectById(user.getId());
            
            assertNotNull("检索到的用户不应为null", retrievedUser);
            assertEquals("学生角色应该正确持久化", "student", retrievedUser.getRole());
        }
    }

    /**
     * 属性测试：教师角色持久化
     * 
     * 对于任意具有 'teacher' 角色的用户，检索后应该返回 'teacher'
     */
    @Test
    public void testTeacherRolePersistence() {
        for (int i = 0; i < 50; i++) {
            UsersEntity user = generateRandomUser();
            user.setRole("teacher");
            
            usersDao.insert(user);
            createdUserIds.add(user.getId());
            
            UsersEntity retrievedUser = usersDao.selectById(user.getId());
            
            assertNotNull("检索到的用户不应为null", retrievedUser);
            assertEquals("教师角色应该正确持久化", "teacher", retrievedUser.getRole());
        }
    }

    /**
     * 属性测试：角色更新持久化
     * 
     * 对于任意用户，更新角色后检索应该返回新的角色值
     */
    @Test
    public void testRoleUpdatePersistence() {
        for (int i = 0; i < 50; i++) {
            // Create user with initial role
            UsersEntity user = generateRandomUser();
            String initialRole = user.getRole();
            
            usersDao.insert(user);
            createdUserIds.add(user.getId());
            
            // Update to opposite role
            String newRole = initialRole.equals("student") ? "teacher" : "student";
            user.setRole(newRole);
            usersDao.updateById(user);
            
            // Retrieve and verify
            UsersEntity retrievedUser = usersDao.selectById(user.getId());
            
            assertNotNull("检索到的用户不应为null", retrievedUser);
            assertEquals("更新后的角色应该正确持久化", newRole, retrievedUser.getRole());
            assertNotEquals("角色应该已经改变", initialRole, retrievedUser.getRole());
        }
    }

    /**
     * 生成随机用户实体
     */
    private UsersEntity generateRandomUser() {
        UsersEntity user = new UsersEntity();
        
        long timestamp = System.currentTimeMillis();
        int randomSuffix = random.nextInt(100000);
        
        user.setId(timestamp + randomSuffix);
        user.setUsername("testuser_" + timestamp + "_" + randomSuffix);
        user.setPassword("password" + randomSuffix);
        user.setNickname("测试用户" + randomSuffix);
        user.setGender(random.nextBoolean() ? "男" : "女");
        user.setTelephone("1" + String.format("%010d", random.nextInt(1000000000)));
        user.setRole(random.nextBoolean() ? "student" : "teacher");
        user.setMoney(random.nextFloat() * 1000);
        user.setAddtime(new Date());
        
        return user;
    }
}
