package com;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * 数据库架构测试
 * 验证数据库迁移后的架构完整性
 * 
 * Feature: classroom-reservation-enhancement, Property: Schema Integrity
 * Validates: Requirements 11.1, 11.2, 11.3, 11.4, 11.5
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class DatabaseSchemaTest {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * 测试users表是否有role字段
     * Validates: Requirement 11.1
     */
    @Test
    public void testUsersTableHasRoleColumn() {
        String sql = "SELECT COLUMN_NAME, DATA_TYPE, COLUMN_DEFAULT " +
                    "FROM INFORMATION_SCHEMA.COLUMNS " +
                    "WHERE TABLE_SCHEMA = 'boot_smartcampusclassressys' " +
                    "AND TABLE_NAME = 'users' " +
                    "AND COLUMN_NAME = 'role'";
        
        List<Map<String, Object>> result = jdbcTemplate.queryForList(sql);
        
        assertFalse("users表应该有role字段", result.isEmpty());
        assertEquals("role字段类型应该是varchar", "varchar", result.get(0).get("DATA_TYPE"));
    }

    /**
     * 测试orders表是否有start_time和end_time字段
     * Validates: Requirement 11.2
     */
    @Test
    public void testOrdersTableHasTimeColumns() {
        String sql = "SELECT COLUMN_NAME, DATA_TYPE " +
                    "FROM INFORMATION_SCHEMA.COLUMNS " +
                    "WHERE TABLE_SCHEMA = 'boot_smartcampusclassressys' " +
                    "AND TABLE_NAME = 'orders' " +
                    "AND COLUMN_NAME IN ('start_time', 'end_time')";
        
        List<Map<String, Object>> result = jdbcTemplate.queryForList(sql);
        
        assertEquals("orders表应该有2个时间字段", 2, result.size());
        
        for (Map<String, Object> column : result) {
            assertEquals("时间字段类型应该是datetime", "datetime", column.get("DATA_TYPE"));
        }
    }

    /**
     * 测试classroom_reservation表是否存在且结构正确
     * Validates: Requirement 11.3
     */
    @Test
    public void testClassroomReservationTableExists() {
        // 检查表是否存在
        String checkTableSql = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES " +
                              "WHERE TABLE_SCHEMA = 'boot_smartcampusclassressys' " +
                              "AND TABLE_NAME = 'classroom_reservation'";
        
        Integer count = jdbcTemplate.queryForObject(checkTableSql, Integer.class);
        assertEquals("classroom_reservation表应该存在", Integer.valueOf(1), count);
        
        // 检查必需字段
        String checkColumnsSql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS " +
                                "WHERE TABLE_SCHEMA = 'boot_smartcampusclassressys' " +
                                "AND TABLE_NAME = 'classroom_reservation' " +
                                "AND COLUMN_NAME IN ('id', 'classroom_id', 'user_id', 'start_time', 'end_time', 'purpose', 'status')";
        
        List<Map<String, Object>> columns = jdbcTemplate.queryForList(checkColumnsSql);
        assertEquals("classroom_reservation表应该有7个必需字段", 7, columns.size());
    }

    /**
     * 测试notification表是否存在且结构正确
     * Validates: Requirement 11.4
     */
    @Test
    public void testNotificationTableExists() {
        // 检查表是否存在
        String checkTableSql = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES " +
                              "WHERE TABLE_SCHEMA = 'boot_smartcampusclassressys' " +
                              "AND TABLE_NAME = 'notification'";
        
        Integer count = jdbcTemplate.queryForObject(checkTableSql, Integer.class);
        assertEquals("notification表应该存在", Integer.valueOf(1), count);
        
        // 检查必需字段
        String checkColumnsSql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS " +
                                "WHERE TABLE_SCHEMA = 'boot_smartcampusclassressys' " +
                                "AND TABLE_NAME = 'notification' " +
                                "AND COLUMN_NAME IN ('id', 'user_id', 'message', 'type', 'is_read')";
        
        List<Map<String, Object>> columns = jdbcTemplate.queryForList(checkColumnsSql);
        assertEquals("notification表应该有5个必需字段", 5, columns.size());
    }

    /**
     * 测试索引是否正确创建
     * Validates: Requirement 11.5
     */
    @Test
    public void testIndexesCreated() {
        // 检查orders表的冲突检测索引
        String checkOrdersIndexSql = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS " +
                                    "WHERE TABLE_SCHEMA = 'boot_smartcampusclassressys' " +
                                    "AND TABLE_NAME = 'orders' " +
                                    "AND INDEX_NAME = 'idx_orders_conflict'";
        
        Integer ordersIndexCount = jdbcTemplate.queryForObject(checkOrdersIndexSql, Integer.class);
        assertTrue("orders表应该有idx_orders_conflict索引", ordersIndexCount > 0);
        
        // 检查classroom_reservation表的时间索引
        String checkClassroomIndexSql = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS " +
                                       "WHERE TABLE_SCHEMA = 'boot_smartcampusclassressys' " +
                                       "AND TABLE_NAME = 'classroom_reservation' " +
                                       "AND INDEX_NAME = 'idx_classroom_time'";
        
        Integer classroomIndexCount = jdbcTemplate.queryForObject(checkClassroomIndexSql, Integer.class);
        assertTrue("classroom_reservation表应该有idx_classroom_time索引", classroomIndexCount > 0);
        
        // 检查notification表的用户通知索引
        String checkNotificationIndexSql = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS " +
                                          "WHERE TABLE_SCHEMA = 'boot_smartcampusclassressys' " +
                                          "AND TABLE_NAME = 'notification' " +
                                          "AND INDEX_NAME = 'idx_user_notifications'";
        
        Integer notificationIndexCount = jdbcTemplate.queryForObject(checkNotificationIndexSql, Integer.class);
        assertTrue("notification表应该有idx_user_notifications索引", notificationIndexCount > 0);
    }

    /**
     * 测试audit_log表是否存在
     * Validates: Requirement 11.5
     */
    @Test
    public void testAuditLogTableExists() {
        String checkTableSql = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES " +
                              "WHERE TABLE_SCHEMA = 'boot_smartcampusclassressys' " +
                              "AND TABLE_NAME = 'audit_log'";
        
        Integer count = jdbcTemplate.queryForObject(checkTableSql, Integer.class);
        assertEquals("audit_log表应该存在", Integer.valueOf(1), count);
    }

    /**
     * 测试所有表的字符集是否正确
     */
    @Test
    public void testTableCharacterSet() {
        String sql = "SELECT TABLE_NAME, TABLE_COLLATION " +
                    "FROM INFORMATION_SCHEMA.TABLES " +
                    "WHERE TABLE_SCHEMA = 'boot_smartcampusclassressys' " +
                    "AND TABLE_NAME IN ('users', 'orders', 'classroom_reservation', 'notification', 'audit_log')";
        
        List<Map<String, Object>> tables = jdbcTemplate.queryForList(sql);
        
        for (Map<String, Object> table : tables) {
            String collation = (String) table.get("TABLE_COLLATION");
            assertTrue("表的字符集应该是utf8", 
                      collation != null && collation.startsWith("utf8"));
        }
    }
}
