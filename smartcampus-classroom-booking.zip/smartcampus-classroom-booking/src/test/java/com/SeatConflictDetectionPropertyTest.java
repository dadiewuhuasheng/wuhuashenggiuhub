package com;

import com.dao.OrdersDao;
import com.entity.OrdersEntity;
import com.service.ConflictDetectionService;
import com.service.OrdersService;
import com.utils.R;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import static org.junit.Assert.*;

/**
 * 座位冲突检测属性测试
 * 
 * Feature: classroom-reservation-enhancement, Property 6: Seat Conflict Detection
 * Validates: Requirements 4.2, 4.3, 4.4, 4.5
 * 
 * Property: For any seat and time period [start, end], if there exists an active reservation 
 * [start2, end2] where start < end2 AND start2 < end, then a new reservation request for that 
 * seat and time period should be rejected with a conflict error.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class SeatConflictDetectionPropertyTest {

    @Autowired
    private OrdersService ordersService;

    @Autowired
    private ConflictDetectionService conflictDetectionService;

    @Autowired
    private OrdersDao ordersDao;

    private List<Long> createdOrderIds = new ArrayList<>();
    private Random random = new Random();

    @After
    public void cleanup() {
        for (Long orderId : createdOrderIds) {
            try {
                ordersDao.deleteById(orderId);
            } catch (Exception e) {
                // Ignore
            }
        }
        createdOrderIds.clear();
    }

    /**
     * 属性测试：重叠预约应该被检测为冲突
     */
    @Test
    public void testOverlappingReservationsDetected() {
        for (int i = 0; i < 100; i++) {
            Long seatId = 1L + random.nextInt(100);
            
            // Create first reservation
            OrdersEntity order1 = generateRandomOrder();
            order1.setGoodid(seatId);
            Date start1 = generateFutureTime(1, 10);
            Date end1 = new Date(start1.getTime() + 3600000L * 2); // 2 hours
            order1.setStartTime(start1);
            order1.setEndTime(end1);
            
            R result1 = ordersService.createReservationWithTime(order1);
            assertEquals("第一个预约应该成功", Integer.valueOf(0), result1.get("code"));
            createdOrderIds.add(order1.getId());
            
            // Try to create overlapping reservation
            OrdersEntity order2 = generateRandomOrder();
            order2.setGoodid(seatId);
            Date start2 = new Date(start1.getTime() + 1800000L); // 30 min after start1
            Date end2 = new Date(end1.getTime() + 1800000L); // 30 min after end1
            order2.setStartTime(start2);
            order2.setEndTime(end2);
            
            R result2 = ordersService.createReservationWithTime(order2);
            assertNotEquals("重叠预约应该被拒绝 (iteration " + i + ")", 
                           Integer.valueOf(0), result2.get("code"));
        }
    }

    /**
     * 属性测试：不重叠的预约应该被允许
     */
    @Test
    public void testNonOverlappingReservationsAllowed() {
        for (int i = 0; i < 50; i++) {
            Long seatId = 1L + random.nextInt(100);
            
            // Create first reservation
            OrdersEntity order1 = generateRandomOrder();
            order1.setGoodid(seatId);
            Date start1 = generateFutureTime(1, 10);
            Date end1 = new Date(start1.getTime() + 3600000L); // 1 hour
            order1.setStartTime(start1);
            order1.setEndTime(end1);
            
            R result1 = ordersService.createReservationWithTime(order1);
            assertEquals("第一个预约应该成功", Integer.valueOf(0), result1.get("code"));
            createdOrderIds.add(order1.getId());
            
            // Create non-overlapping reservation (after first)
            OrdersEntity order2 = generateRandomOrder();
            order2.setGoodid(seatId);
            Date start2 = new Date(end1.getTime() + 60000L); // 1 min after end1
            Date end2 = new Date(start2.getTime() + 3600000L); // 1 hour
            order2.setStartTime(start2);
            order2.setEndTime(end2);
            
            R result2 = ordersService.createReservationWithTime(order2);
            assertEquals("不重叠预约应该成功 (iteration " + i + ")", 
                        Integer.valueOf(0), result2.get("code"));
            createdOrderIds.add(order2.getId());
        }
    }

    /**
     * 属性测试：完全包含的预约应该被检测为冲突
     */
    @Test
    public void testContainedReservationsDetected() {
        for (int i = 0; i < 50; i++) {
            Long seatId = 1L + random.nextInt(100);
            
            // Create outer reservation
            OrdersEntity order1 = generateRandomOrder();
            order1.setGoodid(seatId);
            Date start1 = generateFutureTime(1, 10);
            Date end1 = new Date(start1.getTime() + 7200000L); // 2 hours
            order1.setStartTime(start1);
            order1.setEndTime(end1);
            
            R result1 = ordersService.createReservationWithTime(order1);
            assertEquals("外层预约应该成功", Integer.valueOf(0), result1.get("code"));
            createdOrderIds.add(order1.getId());
            
            // Try to create contained reservation
            OrdersEntity order2 = generateRandomOrder();
            order2.setGoodid(seatId);
            Date start2 = new Date(start1.getTime() + 1800000L); // 30 min after start1
            Date end2 = new Date(end1.getTime() - 1800000L); // 30 min before end1
            order2.setStartTime(start2);
            order2.setEndTime(end2);
            
            R result2 = ordersService.createReservationWithTime(order2);
            assertNotEquals("包含的预约应该被拒绝 (iteration " + i + ")", 
                           Integer.valueOf(0), result2.get("code"));
        }
    }

    /**
     * 属性测试：不同座位的预约不应该冲突
     */
    @Test
    public void testDifferentSeatsNoConflict() {
        for (int i = 0; i < 50; i++) {
            Long seatId1 = 1L + random.nextInt(50);
            Long seatId2 = 51L + random.nextInt(50);
            
            Date start = generateFutureTime(1, 10);
            Date end = new Date(start.getTime() + 3600000L);
            
            // Create reservation for seat 1
            OrdersEntity order1 = generateRandomOrder();
            order1.setGoodid(seatId1);
            order1.setStartTime(start);
            order1.setEndTime(end);
            
            R result1 = ordersService.createReservationWithTime(order1);
            assertEquals("座位1预约应该成功", Integer.valueOf(0), result1.get("code"));
            createdOrderIds.add(order1.getId());
            
            // Create same time reservation for seat 2
            OrdersEntity order2 = generateRandomOrder();
            order2.setGoodid(seatId2);
            order2.setStartTime(start);
            order2.setEndTime(end);
            
            R result2 = ordersService.createReservationWithTime(order2);
            assertEquals("座位2预约应该成功 (iteration " + i + ")", 
                        Integer.valueOf(0), result2.get("code"));
            createdOrderIds.add(order2.getId());
        }
    }

    private OrdersEntity generateRandomOrder() {
        OrdersEntity order = new OrdersEntity();
        long timestamp = System.currentTimeMillis();
        int randomSuffix = random.nextInt(100000);
        
        order.setId(timestamp + randomSuffix);
        order.setOrderid("ORDER_" + timestamp + "_" + randomSuffix);
        order.setTablename("libseatinfo");
        order.setUserid(1L + random.nextInt(1000));
        order.setGoodname("座位" + random.nextInt(100));
        order.setBuynumber(1);
        order.setPrice(10.0f);
        order.setTotal(10.0f);
        order.setStatus("已预约");
        order.setAddtime(new Date());
        
        return order;
    }

    private Date generateFutureTime(int minHours, int maxHours) {
        long hoursToAdd = minHours + random.nextInt(maxHours - minHours + 1);
        return new Date(System.currentTimeMillis() + hoursToAdd * 3600000L);
    }
}
