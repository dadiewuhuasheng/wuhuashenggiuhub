package com;

import com.dao.OrdersDao;
import com.entity.OrdersEntity;
import com.service.OrdersService;
import com.utils.R;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import static org.junit.Assert.*;

/**
 * 预约时间持久化属性测试
 * 
 * Feature: classroom-reservation-enhancement, Property 5: Reservation Time Persistence
 * Validates: Requirements 3.4
 * 
 * Property: For any created reservation with start and end times, retrieving that 
 * reservation should return the same time values.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class ReservationTimePersistencePropertyTest {

    @Autowired
    private OrdersService ordersService;

    @Autowired
    private OrdersDao ordersDao;

    private List<Long> createdOrderIds = new ArrayList<>();
    private Random random = new Random();

    @After
    public void cleanup() {
        for (Long orderId : createdOrderIds) {
            try {
                ordersDao.deleteById(orderId);
            } catch (Exception e) {
                // Ignore cleanup errors
            }
        }
        createdOrderIds.clear();
    }

    /**
     * 属性测试：预约时间往返一致性
     * 
     * 对于任意预约，创建后检索应该返回相同的开始时间和结束时间
     */
    @Test
    public void testReservationTimePersistenceRoundTrip() {
        for (int i = 0; i < 100; i++) {
            OrdersEntity order = generateRandomOrder();
            
            Date originalStartTime = order.getStartTime();
            Date originalEndTime = order.getEndTime();
            
            // Create reservation
            R result = ordersService.createReservationWithTime(order);
            assertEquals("预约创建应该成功 (iteration " + i + ")", 
                        Integer.valueOf(0), result.get("code"));
            
            createdOrderIds.add(order.getId());
            
            // Retrieve reservation
            OrdersEntity retrievedOrder = ordersDao.selectById(order.getId());
            
            // Verify times persisted correctly
            assertNotNull("检索到的预约不应为null", retrievedOrder);
            assertNotNull("开始时间不应为null", retrievedOrder.getStartTime());
            assertNotNull("结束时间不应为null", retrievedOrder.getEndTime());
            
            // Compare times (allowing for millisecond precision differences)
            long startTimeDiff = Math.abs(originalStartTime.getTime() - retrievedOrder.getStartTime().getTime());
            long endTimeDiff = Math.abs(originalEndTime.getTime() - retrievedOrder.getEndTime().getTime());
            
            assertTrue("开始时间应该匹配 (iteration " + i + ")", startTimeDiff < 1000);
            assertTrue("结束时间应该匹配 (iteration " + i + ")", endTimeDiff < 1000);
        }
    }

    /**
     * 属性测试：短时间预约的持久化
     * 
     * 对于任意短时间预约（如1小时），时间应该正确持久化
     */
    @Test
    public void testShortDurationPersistence() {
        for (int i = 0; i < 50; i++) {
            OrdersEntity order = generateRandomOrder();
            
            Date startTime = generateFutureTime(1, 5);
            Date endTime = new Date(startTime.getTime() + 3600000L); // 1 hour
            
            order.setStartTime(startTime);
            order.setEndTime(endTime);
            
            R result = ordersService.createReservationWithTime(order);
            assertEquals("预约创建应该成功", Integer.valueOf(0), result.get("code"));
            
            createdOrderIds.add(order.getId());
            
            OrdersEntity retrievedOrder = ordersDao.selectById(order.getId());
            
            assertNotNull("检索到的预约不应为null", retrievedOrder);
            
            long duration = retrievedOrder.getEndTime().getTime() - retrievedOrder.getStartTime().getTime();
            long expectedDuration = 3600000L;
            
            assertTrue("预约时长应该约为1小时 (iteration " + i + ")", 
                      Math.abs(duration - expectedDuration) < 1000);
        }
    }

    /**
     * 属性测试：长时间预约的持久化
     * 
     * 对于任意长时间预约（如数天），时间应该正确持久化
     */
    @Test
    public void testLongDurationPersistence() {
        for (int i = 0; i < 50; i++) {
            OrdersEntity order = generateRandomOrder();
            
            Date startTime = generateFutureTime(1, 5);
            int daysToAdd = 1 + random.nextInt(10);
            Date endTime = new Date(startTime.getTime() + daysToAdd * 86400000L);
            
            order.setStartTime(startTime);
            order.setEndTime(endTime);
            
            R result = ordersService.createReservationWithTime(order);
            assertEquals("预约创建应该成功", Integer.valueOf(0), result.get("code"));
            
            createdOrderIds.add(order.getId());
            
            OrdersEntity retrievedOrder = ordersDao.selectById(order.getId());
            
            assertNotNull("检索到的预约不应为null", retrievedOrder);
            
            long duration = retrievedOrder.getEndTime().getTime() - retrievedOrder.getStartTime().getTime();
            long expectedDuration = daysToAdd * 86400000L;
            
            assertTrue("预约时长应该约为" + daysToAdd + "天 (iteration " + i + ")", 
                      Math.abs(duration - expectedDuration) < 1000);
        }
    }

    /**
     * 属性测试：跨午夜预约的持久化
     * 
     * 对于任意跨午夜的预约，时间应该正确持久化
     */
    @Test
    public void testMidnightCrossingPersistence() {
        for (int i = 0; i < 50; i++) {
            OrdersEntity order = generateRandomOrder();
            
            // Create a time late in the day
            Date startTime = generateFutureTime(1, 5);
            Date endTime = new Date(startTime.getTime() + 12 * 3600000L); // 12 hours later
            
            order.setStartTime(startTime);
            order.setEndTime(endTime);
            
            R result = ordersService.createReservationWithTime(order);
            assertEquals("预约创建应该成功", Integer.valueOf(0), result.get("code"));
            
            createdOrderIds.add(order.getId());
            
            OrdersEntity retrievedOrder = ordersDao.selectById(order.getId());
            
            assertNotNull("检索到的预约不应为null", retrievedOrder);
            assertNotNull("开始时间不应为null", retrievedOrder.getStartTime());
            assertNotNull("结束时间不应为null", retrievedOrder.getEndTime());
            
            assertTrue("结束时间应该晚于开始时间", 
                      retrievedOrder.getEndTime().after(retrievedOrder.getStartTime()));
        }
    }

    /**
     * 属性测试：更新预约时间后的持久化
     * 
     * 对于任意预约，更新时间后检索应该返回新的时间值
     */
    @Test
    public void testUpdatedTimePersistence() {
        for (int i = 0; i < 50; i++) {
            OrdersEntity order = generateRandomOrder();
            
            // Create initial reservation
            R result = ordersService.createReservationWithTime(order);
            assertEquals("预约创建应该成功", Integer.valueOf(0), result.get("code"));
            
            createdOrderIds.add(order.getId());
            
            // Update times
            Date newStartTime = generateFutureTime(10, 20);
            Date newEndTime = new Date(newStartTime.getTime() + 7200000L); // 2 hours
            
            order.setStartTime(newStartTime);
            order.setEndTime(newEndTime);
            
            ordersDao.updateById(order);
            
            // Retrieve and verify
            OrdersEntity retrievedOrder = ordersDao.selectById(order.getId());
            
            assertNotNull("检索到的预约不应为null", retrievedOrder);
            
            long startTimeDiff = Math.abs(newStartTime.getTime() - retrievedOrder.getStartTime().getTime());
            long endTimeDiff = Math.abs(newEndTime.getTime() - retrievedOrder.getEndTime().getTime());
            
            assertTrue("更新后的开始时间应该匹配 (iteration " + i + ")", startTimeDiff < 1000);
            assertTrue("更新后的结束时间应该匹配 (iteration " + i + ")", endTimeDiff < 1000);
        }
    }

    /**
     * 属性测试：多个预约的时间独立性
     * 
     * 对于任意多个预约，每个预约的时间应该独立持久化，互不影响
     */
    @Test
    public void testMultipleReservationsTimeIndependence() {
        List<OrdersEntity> orders = new ArrayList<>();
        
        // Create multiple reservations with different times
        for (int i = 0; i < 20; i++) {
            OrdersEntity order = generateRandomOrder();
            
            R result = ordersService.createReservationWithTime(order);
            assertEquals("预约创建应该成功", Integer.valueOf(0), result.get("code"));
            
            orders.add(order);
            createdOrderIds.add(order.getId());
        }
        
        // Verify each reservation has correct times
        for (int i = 0; i < orders.size(); i++) {
            OrdersEntity originalOrder = orders.get(i);
            OrdersEntity retrievedOrder = ordersDao.selectById(originalOrder.getId());
            
            assertNotNull("检索到的预约不应为null (order " + i + ")", retrievedOrder);
            
            long startTimeDiff = Math.abs(originalOrder.getStartTime().getTime() - 
                                         retrievedOrder.getStartTime().getTime());
            long endTimeDiff = Math.abs(originalOrder.getEndTime().getTime() - 
                                       retrievedOrder.getEndTime().getTime());
            
            assertTrue("开始时间应该匹配 (order " + i + ")", startTimeDiff < 1000);
            assertTrue("结束时间应该匹配 (order " + i + ")", endTimeDiff < 1000);
        }
    }

    /**
     * 生成随机预约实体
     */
    private OrdersEntity generateRandomOrder() {
        OrdersEntity order = new OrdersEntity();
        
        long timestamp = System.currentTimeMillis();
        int randomSuffix = random.nextInt(100000);
        
        order.setId(timestamp + randomSuffix);
        order.setOrderid("ORDER_" + timestamp + "_" + randomSuffix);
        order.setTablename("libseatinfo");
        order.setUserid(1L + random.nextInt(1000));
        order.setGoodid(1L + random.nextInt(100));
        order.setGoodname("座位" + random.nextInt(100));
        order.setBuynumber(1);
        order.setPrice(10.0f);
        order.setTotal(10.0f);
        order.setStatus("已预约");
        order.setAddtime(new Date());
        
        // Generate random future times
        Date startTime = generateFutureTime(1, 10);
        Date endTime = new Date(startTime.getTime() + (1 + random.nextInt(10)) * 3600000L);
        
        order.setStartTime(startTime);
        order.setEndTime(endTime);
        
        return order;
    }

    /**
     * 生成未来时间
     */
    private Date generateFutureTime(int minHours, int maxHours) {
        long hoursToAdd = minHours + random.nextInt(maxHours - minHours + 1);
        return new Date(System.currentTimeMillis() + hoursToAdd * 3600000L);
    }
}
