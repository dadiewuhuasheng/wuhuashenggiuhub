package com;

import com.utils.TimeValidationUtil;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.Assert.*;

/**
 * 时间重叠逻辑单元测试
 * 
 * Validates: Requirements 4.4
 */
public class TimeOverlapLogicTest {

    /**
     * 测试完全重叠
     */
    @Test
    public void testExactOverlap() {
        Date start1 = createDate(2026, 1, 27, 10, 0);
        Date end1 = createDate(2026, 1, 27, 12, 0);
        Date start2 = createDate(2026, 1, 27, 10, 0);
        Date end2 = createDate(2026, 1, 27, 12, 0);
        
        assertTrue("完全重叠应该被检测", 
                  TimeValidationUtil.isTimeOverlap(start1, end1, start2, end2));
    }

    /**
     * 测试部分重叠（开始时间在中间）
     */
    @Test
    public void testPartialOverlapStartInMiddle() {
        Date start1 = createDate(2026, 1, 27, 10, 0);
        Date end1 = createDate(2026, 1, 27, 12, 0);
        Date start2 = createDate(2026, 1, 27, 11, 0);
        Date end2 = createDate(2026, 1, 27, 13, 0);
        
        assertTrue("部分重叠应该被检测", 
                  TimeValidationUtil.isTimeOverlap(start1, end1, start2, end2));
    }

    /**
     * 测试部分重叠（结束时间在中间）
     */
    @Test
    public void testPartialOverlapEndInMiddle() {
        Date start1 = createDate(2026, 1, 27, 10, 0);
        Date end1 = createDate(2026, 1, 27, 12, 0);
        Date start2 = createDate(2026, 1, 27, 9, 0);
        Date end2 = createDate(2026, 1, 27, 11, 0);
        
        assertTrue("部分重叠应该被检测", 
                  TimeValidationUtil.isTimeOverlap(start1, end1, start2, end2));
    }

    /**
     * 测试包含关系（第二个时间段包含第一个）
     */
    @Test
    public void testContainedTimeRange() {
        Date start1 = createDate(2026, 1, 27, 10, 0);
        Date end1 = createDate(2026, 1, 27, 12, 0);
        Date start2 = createDate(2026, 1, 27, 9, 0);
        Date end2 = createDate(2026, 1, 27, 13, 0);
        
        assertTrue("包含关系应该被检测为重叠", 
                  TimeValidationUtil.isTimeOverlap(start1, end1, start2, end2));
    }

    /**
     * 测试包含关系（第一个时间段包含第二个）
     */
    @Test
    public void testContainingTimeRange() {
        Date start1 = createDate(2026, 1, 27, 9, 0);
        Date end1 = createDate(2026, 1, 27, 13, 0);
        Date start2 = createDate(2026, 1, 27, 10, 0);
        Date end2 = createDate(2026, 1, 27, 12, 0);
        
        assertTrue("包含关系应该被检测为重叠", 
                  TimeValidationUtil.isTimeOverlap(start1, end1, start2, end2));
    }

    /**
     * 测试相邻时间段（无重叠）
     */
    @Test
    public void testAdjacentTimeSlots() {
        Date start1 = createDate(2026, 1, 27, 10, 0);
        Date end1 = createDate(2026, 1, 27, 12, 0);
        Date start2 = createDate(2026, 1, 27, 12, 0);
        Date end2 = createDate(2026, 1, 27, 14, 0);
        
        assertFalse("相邻时间段不应该重叠", 
                   TimeValidationUtil.isTimeOverlap(start1, end1, start2, end2));
    }

    /**
     * 测试完全分离的时间段（第二个在后）
     */
    @Test
    public void testSeparatedTimeSlotsAfter() {
        Date start1 = createDate(2026, 1, 27, 10, 0);
        Date end1 = createDate(2026, 1, 27, 12, 0);
        Date start2 = createDate(2026, 1, 27, 13, 0);
        Date end2 = createDate(2026, 1, 27, 15, 0);
        
        assertFalse("分离的时间段不应该重叠", 
                   TimeValidationUtil.isTimeOverlap(start1, end1, start2, end2));
    }

    /**
     * 测试完全分离的时间段（第二个在前）
     */
    @Test
    public void testSeparatedTimeSlotsBefore() {
        Date start1 = createDate(2026, 1, 27, 13, 0);
        Date end1 = createDate(2026, 1, 27, 15, 0);
        Date start2 = createDate(2026, 1, 27, 10, 0);
        Date end2 = createDate(2026, 1, 27, 12, 0);
        
        assertFalse("分离的时间段不应该重叠", 
                   TimeValidationUtil.isTimeOverlap(start1, end1, start2, end2));
    }

    /**
     * 测试1分钟重叠
     */
    @Test
    public void testOneMinuteOverlap() {
        Date start1 = createDate(2026, 1, 27, 10, 0);
        Date end1 = createDate(2026, 1, 27, 12, 0);
        Date start2 = createDate(2026, 1, 27, 11, 59);
        Date end2 = createDate(2026, 1, 27, 14, 0);
        
        assertTrue("1分钟重叠应该被检测", 
                  TimeValidationUtil.isTimeOverlap(start1, end1, start2, end2));
    }

    /**
     * 测试跨天时间段
     */
    @Test
    public void testOvernightTimeSlots() {
        Date start1 = createDate(2026, 1, 27, 22, 0);
        Date end1 = createDate(2026, 1, 28, 2, 0);
        Date start2 = createDate(2026, 1, 28, 0, 0);
        Date end2 = createDate(2026, 1, 28, 4, 0);
        
        assertTrue("跨天重叠应该被检测", 
                  TimeValidationUtil.isTimeOverlap(start1, end1, start2, end2));
    }

    /**
     * 测试null值处理
     */
    @Test
    public void testNullValues() {
        Date start = createDate(2026, 1, 27, 10, 0);
        Date end = createDate(2026, 1, 27, 12, 0);
        
        assertFalse("null值应该返回false", 
                   TimeValidationUtil.isTimeOverlap(null, end, start, end));
        assertFalse("null值应该返回false", 
                   TimeValidationUtil.isTimeOverlap(start, null, start, end));
        assertFalse("null值应该返回false", 
                   TimeValidationUtil.isTimeOverlap(start, end, null, end));
        assertFalse("null值应该返回false", 
                   TimeValidationUtil.isTimeOverlap(start, end, start, null));
    }

    /**
     * 辅助方法：创建指定日期时间
     */
    private Date createDate(int year, int month, int day, int hour, int minute) {
        Calendar cal = Calendar.getInstance();
        cal.set(year, month - 1, day, hour, minute, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }
}
