# 智能化校园教室预约管理系统

面向高校场景的教室 / 座位预约系统：学生在线查空教室、按时间段预约，教师与管理员审核管理；系统自动处理时间冲突、教室与座位预约的优先级、冲突退款与站内通知，并留存审计日志。

- **在线演示（可直接打开操作）**：<https://campus-classroom-booking.app.workbuddy.host/?sharecode=3WGI653OIK>
- 学生端：`/`　管理端：`/admin/`
- 演示账号：学生 `1 / 1`、`用户账号2 / 123456`；管理员 `admin / admin`

> 公网托管环境只提供单个 HTTP 端口，没有 JVM 与 MySQL，因此演示版是把原工程的接口与业务规则
> 用 Node 复刻的单端口服务；原始实现仍是本仓库根目录的 Spring Boot 工程。两套实现的规则口径一致，
> 见 [核心业务规则](#核心业务规则)。

## 功能概览

| 模块 | 能力 |
| --- | --- |
| 教室预约 | 选定教室与时间段提交，服务端做非空 / 时序 / 不早于当前时刻三重校验，再做重叠判定 |
| 冲突处理 | 教室预约优先于座位预约：命中冲突时批量取消座位单、按订单金额退回余额、写站内通知 |
| 座位预约 | 教室（座位）列表、类型筛选、收藏、下单与订单状态流转 |
| 通知中心 | 预约成功 / 冲突取消 / 审核结果三类消息，支持未读计数与标记已读 |
| 审核与统计 | 管理端预约审核、订单分组统计、按月 / 日预约量图表、教室热度排序 |
| 审计日志 | 预约、取消、退款、增删改等关键动作落库，记录操作人、资源与详情 |
| 用户体系 | 学生 / 教师双角色注册登录，基于 Token 的会话鉴权，余额与个人中心 |

## 仓库结构

```
.
├── src/main/java/com/          原始 Spring Boot 后端（21 个 Controller、185 个 Java 文件）
│   ├── controller/             接口层
│   ├── service/impl/           业务实现：冲突检测、优先级退款、贪心分配、审计
│   ├── interceptor/            Token 鉴权拦截器
│   └── utils/                  时间校验、分页、查询条件拼装
├── src/main/resources/
│   ├── admin/admin/            管理端 Vue 2 工程（含已构建 dist）
│   ├── front/front/            学生端 Vue 2 工程（含已构建 dist）
│   └── mapper/                 MyBatis XML（21 个）
├── db/boot_smartcampusclassressys.sql   19 张表的建表脚本与初始数据
├── demo/                       在线演示服务（Node，零依赖）
│   ├── server.js               单端口 HTTP 服务：静态托管 + 接口
│   ├── lib/                    存储、查询语义、业务规则、接口分发
│   ├── data/base.json          由 SQL 抽取的种子数据
│   └── tools/                  种子生成、资源准备、接口自测
└── docs/                       启动说明与课程设计文档
```

## 快速开始

### 方式一：运行演示服务（无需数据库）

需要 Node 16+，无需 `npm install`：

```bash
cd demo
node tools/prepare-assets.js   # 把两个前端的 dist 复制到 demo/public/
node server.js                 # 默认 18080 端口
```

学生端 <http://127.0.0.1:18080/>，管理端 <http://127.0.0.1:18080/admin/>。

数据落在 `demo/data/db.json`；删除该文件后重启即恢复初始演示数据（种子里的预约日期按启动当天生成，所以演示永远有"今天/明天"的预约）。接口自测：

```bash
node tools/check-endpoints.js http://127.0.0.1:18080
```

### 方式二：运行原始 Spring Boot 工程

前置条件：JDK 8、Maven（仅解析依赖）、MySQL 8，端口 8080，context-path `/smartcampusclassressys`。
建库并导入 `db/boot_smartcampusclassressys.sql` 后，按 `docs/JAVA-START.md` 的 `javac + java -cp` 方式启动
（`src/main/resources` 下静态资源很多，`mvn package` 会卡在资源复制阶段十几分钟）。

- 学生端：`/smartcampusclassressys/front/dist/index.html`
- 管理端：`/smartcampusclassressys/admin/dist/index.html`

## 核心业务规则

这套系统的价值不在增删改查，而在下面四条规则。代码位置同时给出 Java 与演示实现：

1. **时间校验**（`utils/TimeValidationUtil.java` / `demo/lib/business.js`）
   时间为空 → 拒绝；`end <= start` → 拒绝；`start < now` → 拒绝。按顺序短路返回，错误信息直接给前端展示。

2. **重叠判定**（`service/impl/ConflictDetectionServiceImpl.java`）
   半开区间 `start1 < end2 && start2 < end1`，等价 SQL 为
   `start_time < #{end} AND end_time > #{start}`，并排除 `cancelled` 状态。
   **首尾相接（前者 10:00 结束、后者 10:00 开始）不算冲突** —— 这是最容易写错的一处。

3. **优先级与退款**（`service/impl/ClassroomReservationServiceImpl.java`）
   教室预约优先。与既有座位预约重叠时：批量把座位单置为「已取消」→ `users.money += total` 退回余额 →
   给每位受影响用户写站内通知 → 记审计日志，整段在同一事务内完成。

4. **可用时段切分**（`demo/lib/business.js` 的 `availableSlots`）
   把当天 08:00—22:00 按已有预约排序后一次线性扫描切出空档，复杂度 O(n log n)，避免逐分钟试探的 O(n·m) 写法。

## 接口约定

沿用代码生成器留下的约定，前端不需要区分两套后端：

- 统一响应 `{ code, msg, data }`，`code = 0` 成功，`401` 未登录；
- 分页返回 `data = { total, pageSize, totalPage, currPage, list }`；
- 查询参数：值里带 `%` 走模糊匹配，`xxx_start` / `xxx_end` 走区间，`order=desc&sort=field` 排序；
- 鉴权头 `Token`；`POST /users/login`（管理端 `/admin/login`）返回 token。

## 数据说明

- `db/boot_smartcampusclassressys.sql` 是原始 MySQL 脚本，19 张表；
- `demo/data/base.json` 由 `demo/tools/gen_seed.py` 从该脚本抽取，保证演示数据与建表脚本同源；
- `demo/lib/seed.js` 在其上按启动日期补齐预约 / 订单 / 通知 / 审计记录，让冲突检测随时可演示；
- 原脚本的 `libseatinfo` 沿用了图书馆座位模板的字段名，演示层只改展示值为教室名称，表结构不变。

## 已知限制

- 演示服务用 JSON 文件持久化，适合演示与教学，不适合高并发生产；
- 演示环境口令为明文（与原工程一致），请勿在真实场景复用；
- 托管沙箱只有单个 HTTP 端口，故演示版不含 MySQL；完整特性以根目录 Java 工程为准。

## 文档

- `docs/JAVA-START.md`：原始工程在本机的编译与启动说明（JDK 8、`-parameters`、静态资源零复制）
- `docs/课程设计报告.docx`：需求分析、模块设计、数据库设计、系统实现与测试
- `docs/中期检查报告.docx`：进度、已完成工作与阶段成果

## License

MIT
