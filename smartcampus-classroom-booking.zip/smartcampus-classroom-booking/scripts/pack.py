#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把项目打成可以上传到 GitHub 的 zip。

默认排除构建产物、编辑器缓存、运行时数据和 source map —— 这些都能重新生成，
留着只会让压缩包从十几 MB 涨到上百 MB。

用法：
    python scripts/pack.py                  # 默认：排除 *.map
    python scripts/pack.py --keep-maps      # 保留 source map（调试用，包会大很多）
    python scripts/pack.py --drop-docs      # 连 docs 里的 docx 一起排除
    python scripts/pack.py --drop-dist      # 排除两套前端 dist（需自己 npm run build）

产物：dist/smartcampus-classroom-booking.zip
"""

import argparse
import fnmatch
import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(ROOT, 'dist')
OUT_NAME = 'smartcampus-classroom-booking.zip'
PREFIX = 'smartcampus-classroom-booking'

# 只打这些顶层条目，避免把 .git / target / .workbuddy 之类误装进去
ROOTS = [
    'README.md', 'LICENSE', '.gitignore',
    'pom.xml', 'pom-war.xml', 'mvnw', 'mvnw.cmd', '.mvn',
    'src', 'db', 'docs', 'demo', 'scripts',
]

# 整个目录跳过（注意不要写 'dist'：两套前端的 dist 是 demo 的资源来源，必须留）
SKIP_DIRS = {
    '.git', '.workbuddy', 'target', 'node_modules',
    '__pycache__', '.idea', '.vscode',
}
# 相对路径以这些前缀开头的也跳过（生成物）——注意 demo/data/ 里 base.json 是种子数据，必须留
SKIP_PREFIXES = (
    'demo/public/',
    'demo/.tmp/',
)

# 运行时才生成的文件：db.json 是演示库快照，打包时不该带走上一次的测试数据
SKIP_EXACT = (
    'demo/data/db.json',
    'demo/data/base.tmp.json',
)

# 任何位置出现都跳过
SKIP_FILES = [
    '*.log', '*.err', '*.genie', '.DS_Store', 'Thumbs.db',
    'cp.txt', 'sources.txt', '说明.txt',
]

# 明确要留在包里的例外（前缀匹配），不受上面的通配规则影响
KEEP_ALWAYS = (
    '.mvn/wrapper/maven-wrapper.jar',
)


def skipped_file(name, profile):
    if profile['drop_maps'] and name.endswith('.map'):
        return True
    for pattern in SKIP_FILES:
        if fnmatch.fnmatch(name, pattern):
            return True
    return False


def gather(profile):
    picked = []
    for entry in ROOTS:
        path = os.path.join(ROOT, entry)
        if not os.path.exists(path):
            continue
        if os.path.isfile(path):
            picked.append((path, entry))
            continue
        for dirpath, dirnames, filenames in os.walk(path):
            dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS)
            for name in sorted(filenames):
                full = os.path.join(dirpath, name)
                rel = os.path.relpath(full, ROOT).replace(os.sep, '/')
                if any(rel.startswith(p) for p in SKIP_PREFIXES):
                    continue
                if rel in SKIP_EXACT:
                    continue
                if profile['drop_docs'] and rel.startswith('docs/') and name.lower().endswith('.docx'):
                    continue
                if profile['drop_dist'] and '/dist/' in '/' + rel:
                    continue
                if any(rel == k for k in KEEP_ALWAYS):
                    picked.append((full, rel))
                    continue
                if skipped_file(name, profile):
                    continue
                picked.append((full, rel))
    return picked


def human(n):
    for unit in ('B', 'KB', 'MB', 'GB'):
        if n < 1024 or unit == 'GB':
            return '%.1f %s' % (n, unit)
        n /= 1024.0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--keep-maps', action='store_true', help='保留 .map（调试符号）')
    parser.add_argument('--drop-docs', action='store_true', help='排除 docs/ 下的 docx')
    parser.add_argument('--drop-dist', action='store_true', help='排除两套前端 dist')
    parser.add_argument('--out', default=None, help='输出文件名（默认 dist/xxx.zip）')
    args = parser.parse_args()

    profile = {
        'drop_maps': not args.keep_maps,
        'drop_docs': args.drop_docs,
        'drop_dist': args.drop_dist,
    }

    files = gather(profile)
    if not files:
        print('没有可打包的文件，检查 ROOTS 配置')
        return 1

    os.makedirs(OUT_DIR, exist_ok=True)
    out_path = os.path.join(OUT_DIR, args.out or OUT_NAME)
    if os.path.exists(out_path):
        os.remove(out_path)

    total_raw = 0
    with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for full, rel in files:
            zf.write(full, PREFIX + '/' + rel)
            total_raw += os.path.getsize(full)

    size = os.path.getsize(out_path)
    print('输出：%s' % os.path.relpath(out_path, ROOT))
    print('文件：%d 个' % len(files))
    print('原始：%s  →  压缩后：%s（%.0f%%）' % (human(total_raw), human(size), size * 100.0 / max(total_raw, 1)))

    # 列出压缩包里最大的几项，方便下次再裁
    tops = sorted(((os.path.getsize(f), os.path.relpath(f, ROOT)) for f, _ in files), reverse=True)[:8]
    print('\n最大的几项：')
    for size_i, rel in tops:
        print('  %8s  %s' % (human(size_i), rel.replace(os.sep, '/')))

    if size > 25 * 1024 * 1024:
        print('\n注意：超过 25 MB，GitHub 网页上传会拒绝；建议 --drop-docs 或 --drop-dist。')
    return 0


if __name__ == '__main__':
    sys.exit(main())
