'use strict';
/**
 * 智能化校园教室预约管理系统 —— 在线演示服务
 *
 * 一个进程同时干三件事：
 *   1. 托管两个 Vue 单页应用（学生端 /  管理端 /admin/）
 *   2. 提供 /smartcampusclassressys/** 的 HTTP 接口（与原 Spring Boot 工程同形）
 *   3. 把数据落在 data/db.json，重启不丢，删掉即恢复演示初始状态
 *
 * 之所以用 Node 重写而不是直接跑原工程：公网托管沙箱只提供单个 HTTP 端口，
 * 没有 JVM 也没有 MySQL。业务规则（时间校验、冲突检测、优先级退款、时段切分）
 * 与原 Java 实现一一对应，见 lib/business.js 的注释。
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const { Store } = require('./lib/store');
const { build } = require('./lib/seed');
const { createApi, needsAuth } = require('./lib/api');
const { verifyToken } = require('./lib/token');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_FILE = process.env.DATA_FILE || path.join(ROOT, 'data', 'db.json');
const UPLOAD_DIR = path.join(PUBLIC_DIR, 'upload');
const API_PREFIX = process.env.API_PREFIX || '/smartcampusclassressys';
const PORT = Number(process.env.PORT || 18080);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.eot': 'application/vnd.ms-fontobject',
  '.mp4': 'video/mp4',
  '.pdf': 'application/pdf',
  '.txt': 'text/plain; charset=utf-8'
};

const store = new Store({ file: DATA_FILE, build }).init();

const api = createApi({ store, uploadDir: UPLOAD_DIR, log: (...args) => console.log(...args) });

/* ------------------------------- 请求体解析 ------------------------------- */

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > 20 * 1024 * 1024) {
        reject(new Error('请求体过大'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

/** 只取第一个文件字段，够演示里的头像 / 封面 / 图片上传用 */
function parseMultipart(buffer, contentType) {
  const match = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || '');
  if (!match) return { fields: {}, file: null };
  const boundary = Buffer.from('--' + (match[1] || match[2]).trim());
  const parts = [];
  let start = buffer.indexOf(boundary);
  while (start >= 0) {
    const next = buffer.indexOf(boundary, start + boundary.length);
    if (next < 0) break;
    parts.push(buffer.slice(start + boundary.length, next));
    start = next;
  }
  const fields = {};
  let file = null;
  parts.forEach((raw) => {
    const part = raw.slice(raw.indexOf('\r\n') + 2);
    const split = part.indexOf('\r\n\r\n');
    if (split < 0) return;
    const head = part.slice(0, split).toString('utf8');
    const content = part.slice(split + 4, part.length - 2);
    const nameMatch = /name="([^"]+)"/i.exec(head);
    const fileMatch = /filename="([^"]*)"/i.exec(head);
    if (!nameMatch) return;
    if (fileMatch && fileMatch[1]) {
      file = { field: nameMatch[1], filename: path.basename(fileMatch[1]), data: content };
    } else {
      fields[nameMatch[1]] = content.toString('utf8');
    }
  });
  return { fields, file };
}

async function buildContext(req, res, pathname, query) {
  const contentType = req.headers['content-type'] || '';
  let body = {};
  let file = null;
  const raw = await readBody(req);
  if (raw.length) {
    if (contentType.indexOf('application/json') >= 0) {
      try {
        body = JSON.parse(raw.toString('utf8'));
      } catch (err) {
        body = {};
      }
    } else if (contentType.indexOf('multipart/form-data') >= 0) {
      const parsed = parseMultipart(raw, contentType);
      body = parsed.fields;
      file = parsed.file;
    } else if (contentType.indexOf('application/x-www-form-urlencoded') >= 0) {
      const parsed = new URLSearchParams(raw.toString('utf8'));
      parsed.forEach((value, key) => {
        body[key] = value;
      });
    }
  }

  // 取 token 的候选来源，按可靠性排序：
  //   1) 前端自带的 Token 头   2) 查询串（网关会丢自定义头时的兜底）
  //   3) Cookie               4) authorization —— 网关自己会注入同名头，所以放最后且必须验签通过才算
  const candidates = [];
  const push = (value, source) => {
    if (!value) return;
    const text = String(value).replace(/^Bearer\s+/i, '').trim();
    if (text) candidates.push({ value: text, source });
  };
  push(req.headers.token, 'header');
  push(req.headers.Token, 'header');
  push(query && query.token, 'query');
  if (req.headers.cookie) {
    const match = /(?:^|;\s*)Token=([^;]+)/.exec(req.headers.cookie);
    if (match) push(decodeURIComponent(match[1]), 'cookie');
  }
  push(req.headers.authorization, 'authorization');

  let user = null;
  let rawToken = null;
  let tokenSource = null;
  for (let i = 0; i < candidates.length; i++) {
    const item = candidates[i];
    const payload = verifyToken(item.value);
    const profile = payload ? store.findById(payload.table, payload.id) : null;
    if (profile) {
      user = { id: profile.id, table: payload.table, profile, token: item.value };
      rawToken = item.value;
      tokenSource = item.source;
      break;
    }
    // 兜底：兼容早期写入 token 表的会话
    const row = store.all('token').find((entry) => entry.token === item.value);
    const legacy = row ? store.findById(row.tablename, row.userid) : null;
    if (legacy) {
      user = { id: legacy.id, table: row.tablename, profile: legacy, token: item.value };
      rawToken = item.value;
      tokenSource = item.source;
      break;
    }
    if (!rawToken) {
      rawToken = item.value;
      tokenSource = item.source;
    }
  }

  return {
    req,
    res,
    method: req.method,
    url: pathname,
    query,
    params: Object.assign({}, query, body),
    body,
    file,
    user,
    token: rawToken,
    tokenSource,
    segs: pathname.split('/').filter(Boolean)
  };
}

/* --------------------------------- 静态文件 -------------------------------- */

function safeJoin(base, target) {
  const resolved = path.resolve(base, '.' + path.posix.normalize('/' + target));
  if (!resolved.startsWith(path.resolve(base))) return null;
  return resolved;
}

function sendFile(res, filePath) {
  fs.stat(filePath, (err, stat) => {
    if (err || !stat.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('404 Not Found');
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    const type = MIME[ext] || 'application/octet-stream';
    const maxAge = ext === '.html' ? 0 : 604800;
    res.writeHead(200, {
      'Content-Type': type,
      'Content-Length': stat.size,
      'Cache-Control': maxAge ? 'public, max-age=' + maxAge : 'no-cache'
    });
    fs.createReadStream(filePath).pipe(res);
  });
}

function serveStatic(res, pathname) {
  let rel = pathname;
  // 图片地址由前端 config.baseUrl 拼接，形如 /smartcampusclassressys/upload/xxx.jpg
  const upload = /^\/smartcampusclassressys\/(?:front\/)?upload\/(.+)$/.exec(rel);
  if (upload) {
    const file = safeJoin(UPLOAD_DIR, upload[1]);
    if (file) {
      sendFile(res, file);
      return;
    }
  }
  if (rel === '/' || rel === '') rel = '/index.html';
  if (rel.endsWith('/')) rel += 'index.html';

  const direct = safeJoin(PUBLIC_DIR, rel);
  if (direct && fs.existsSync(direct) && fs.statSync(direct).isFile()) {
    sendFile(res, direct);
    return;
  }

  // 单页应用的前端路由回退
  if (rel.startsWith('/admin')) {
    sendFile(res, path.join(PUBLIC_DIR, 'admin', 'index.html'));
    return;
  }
  if (!path.extname(rel)) {
    sendFile(res, path.join(PUBLIC_DIR, 'index.html'));
    return;
  }
  sendFile(res, direct || path.join(PUBLIC_DIR, 'index.html'));
}

/* ---------------------------------- 启动 ---------------------------------- */

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  let pathname;
  try {
    pathname = decodeURIComponent(parsed.pathname);
  } catch (err) {
    pathname = parsed.pathname;
  }

  // 图片等上传资源必须先于 API 分发：否则 /smartcampusclassressys/upload/x.jpg 会被
  // 当成 "upload 表" 的接口调用，返回 {code:0,data:null}，浏览器拿到的不是图片。
  if (/^\/smartcampusclassressys\/(?:front\/)?upload\//.test(pathname)) {
    serveStatic(res, pathname);
    return;
  }

  if (pathname.indexOf(API_PREFIX) === 0) {
    const apiPath = pathname.slice(API_PREFIX.length) || '/';
    res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Headers', 'Token,Content-Type,X-Requested-With,Origin,Accept,authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    if (req.method === 'OPTIONS') {
      res.writeHead(200);
      res.end();
      return;
    }
    try {
      store.sync(); // 别的实例刚写过数据就重新载入，避免读到过期快照
      const ctx = await buildContext(req, res, apiPath, parsed.query);
      // 自检端点：用来确认托管环境的网关到底有没有把 Token 头和查询串传过来
      if (apiPath === '/__debug/whoami') {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({
          code: 0,
          data: {
            headerNames: Object.keys(req.headers),
            tokenSource: ctx.tokenSource,
            hasUser: Boolean(ctx.user),
            user: ctx.user ? { id: ctx.user.id, table: ctx.user.table } : null
          }
        }));
        return;
      }
      if (needsAuth(ctx) && !ctx.user) {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ code: 401, msg: '请先登录' }));
        return;
      }
      const result = api(ctx);
      const headers = { 'Content-Type': 'application/json; charset=utf-8' };
      // 登录成功时顺手下发 Cookie：网关会丢掉自定义请求头，但不会丢 Cookie，
      // 这样即使前端补丁没生效，后续请求也能靠 Cookie 认出会话。
      if (result && result.token) {
        headers['Set-Cookie'] = 'Token=' + encodeURIComponent(result.token) +
          '; Path=/; Max-Age=43200; SameSite=Lax';
      }
      res.writeHead(200, headers);
      res.end(JSON.stringify(result));
    } catch (err) {
      console.error('[api] 处理失败', apiPath, err);
      res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ code: 500, msg: '服务端异常：' + err.message }));
    }
    return;
  }

  serveStatic(res, pathname);
});

server.listen(PORT, '0.0.0.0', () => {
  const count = Object.keys(store.data.tables).reduce((sum, key) => sum + store.all(key).length, 0);
  console.log('智能化校园教室预约管理系统 · 演示服务已启动');
  console.log('  学生端   http://127.0.0.1:' + PORT + '/');
  console.log('  管理端   http://127.0.0.1:' + PORT + '/admin/');
  console.log('  接口前缀 ' + API_PREFIX);
  console.log('  数据文件 ' + DATA_FILE + '（' + count + ' 条记录）');
});
