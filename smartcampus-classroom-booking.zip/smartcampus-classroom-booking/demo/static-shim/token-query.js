/**
 * 托管环境的分享码网关会丢掉自定义请求头（Token），导致登录后所有鉴权接口 401。
 * 这里给 XMLHttpRequest 打一个补丁：请求接口时把 localStorage 里的 Token 追加成查询参数，
 * 服务端同时支持 header 与 query 两种取值，网关只改 URL、不改路径，因此能稳定穿过去。
 *
 * 只在浏览器里生效，不影响原工程（原工程读 header，本文件不会被它加载）。
 */
(function () {
  if (typeof window === 'undefined') return;

  var API_HINT = 'smartcampusclassressys';

  function withToken(url) {
    try {
      if (typeof url !== 'string') return url;
      if (url.indexOf(API_HINT) < 0) return url;
      if (url.indexOf('token=') >= 0) return url;
      var token = window.localStorage.getItem('Token');
      if (!token) return url;
      return url + (url.indexOf('?') < 0 ? '?' : '&') + 'token=' + encodeURIComponent(token);
    } catch (err) {
      return url;
    }
  }

  if (typeof XMLHttpRequest !== 'undefined') {
    var originalOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (method, url, async, user, password) {
      return originalOpen.call(this, method, withToken(url), async === undefined ? true : async, user, password);
    };
  }

  if (typeof window.fetch === 'function') {
    var originalFetch = window.fetch;
    window.fetch = function (input, init) {
      if (typeof input === 'string') {
        return originalFetch.call(this, withToken(input), init);
      }
      if (input && input.url) {
        return originalFetch.call(this, withToken(input.url), init);
      }
      return originalFetch.apply(this, arguments);
    };
  }
})();
