# demo —— 在线演示服务

这个目录不是原工程的替代品，而是**为了让项目有个能直接点开的网址**而写的单端口服务。

## 为什么不用原工程直接部署

公网托管只给一个 HTTP 端口：没有 JVM，也没有 MySQL / Redis。Spring Boot + MySQL 的工程传不上去。
所以这里用零依赖的 Node 复刻了同一套接口与业务规则，前端仍是原工程构建出来的那两套 Vue 页面 ——
换的只是"执行引擎"，不是"产品"。

## 结构

| 文件 | 作用 |
| --- | --- |
| `server.js` | HTTP 服务：托管两个 SPA + 分发 `/smartcampusclassressys/**` 接口 |
| `lib/store.js` | JSON 文件存储，附带跨实例的 mtime 同步（托管环境可能并行多实例） |
| `lib/query.js` | 复刻 `MPUtil` + `Query`：`%` 模糊、`_start/_end` 区间、`order/sort` 排序、`PageUtils` 分页结构 |
| `lib/business.js` | 时间校验、半开区间重叠判定、教室优先级批量取消+退款+通知、可用时段切分 |
| `lib/api.js` | 21 个 Controller 的调用面收敛成一个通用分发器 + 业务路由 |
| `lib/token.js` | HMAC 自签名 token（不依赖进程内存，重启/多实例都能验） |
| `lib/seed.js` | 以 SQL 种子为底座，按启动日期生成"今天/明天"的预约，保证冲突随时可演示 |
| `tools/gen_seed.py` | 从 `db/*.sql` 抽取初始数据到 `data/base.json` |
| `tools/prepare-assets.js` | 复制两个前端的 dist，把写死的 `localhost:8080` 改成同源地址，并注入 Token 传递补丁 |
| `tools/check-endpoints.js` | 从打包产物里抓出前端实际调用的接口，逐个请求自测 |
| `static-shim/token-query.js` | 把 localStorage 里的 Token 追加为查询参数（见下） |
| `static-assets/logo.svg` | 项目自己的 logo，用来替换模板里那张人像占位图 |
| `static-assets/remote/` + `remote-map.json` | 打包产物里 http 外链图片的本地副本与地址映射 |

## 和环境 / 打包有关的几个坑

1. **前端把接口地址写死了**。原工程 `src/main/resources/front/front/src/config/config.js` 里是
   `baseUrl: 'http://localhost:8080/smartcampusclassressys/'`，打包后原样进了 `app.js`。
   本地跑没问题，一放公网就变成"请求访问者自己电脑的 8080"，浏览器直接 `ERR_CONNECTION_REFUSED`。
   `prepare-assets.js` 在复制后统一把 `http://localhost:8080`、`http://127.0.0.1:8080` 改写成空串，
   变成同源相对路径 `/smartcampusclassressys/`；图片地址（`baseUrl + 'upload/xxx.jpg'`）因此变成
   `/smartcampusclassressys/upload/xxx.jpg`。
2. **`/smartcampusclassressys/upload/*` 会被 API 前缀吞掉**。服务起初是先判 `API_PREFIX` 再走静态，
   图片请求被当成"upload 表"的接口调用，返回 `{"code":0,"data":null}` 且 `Content-Type: application/json`，
   页面上一片图片裂开。现在在 API 分发之前先拦 `^/smartcampusclassressys/(front/)?upload/` 交给静态分发。
3. **打包产物里还有 http 图片外链**。模板自带的 logo、登录页底纹、菜单小图标共 7 处指向
   `http://codegen.caihongy.cn/...`，https 页面会被浏览器按混合内容升级后加载失败。
   这些图已下载到 `static-assets/remote/`，映射写在 `static-assets/remote-map.json`，
   `prepare-assets.js` 复制资产时把 7 个地址替换成 `/img/remote/*`；其中被当作 logo 的人像占位换成了
   项目自己的 `static-assets/logo.svg`。
4. **自定义请求头会被网关丢掉**。托管环境前面有一层带分享码的网关，`Token` 头到不了应用，
   它自己还会注入一个 `authorization` 头。处理方式：
   - 服务端按 `Token 头 → 查询串 → Cookie → authorization` 的顺序逐个验签，验过且查得到用户才算数；
   - 登录成功时回写 `Set-Cookie: Token=...; Path=/`，Cookie 能正常透传；
   - 前端补丁把 Token 追加成 `?token=`，覆盖 XHR 与 fetch 两条路径。
5. **进程可能在请求之间重启、也可能并行多实例**。所以 token 用 HMAC 自签名而不是内存会话表，
   存储层每次请求前比对 `db.json` 的修改时间，别家写过就重新载入。

这些都不影响本地运行，`node server.js` 起来就是干净的单实例行为。

## 本地运行

```bash
node tools/prepare-assets.js   # 需要 ../src/main/resources 下的两个 dist
node server.js                 # 默认 18080
```

删除 `data/db.json` 即可恢复初始演示数据。
