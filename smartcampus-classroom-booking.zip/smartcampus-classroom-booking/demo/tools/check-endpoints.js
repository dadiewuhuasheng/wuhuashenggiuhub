'use strict';
/**
 * 接口覆盖自测：从打包产物里抽出所有 “表名/动作” 形式的请求路径，
 * 逐个打到本地服务上，确认没有 404 / 500。
 *
 *   node tools/check-endpoints.js [baseUrl]
 */
const fs = require('fs');
const path = require('path');
const http = require('http');

const BASE = process.argv[2] || 'http://127.0.0.1:18080';
const PREFIX = '/smartcampusclassressys';
const PUBLIC = path.join(__dirname, '..', 'public');

const ACTIONS = [
  'page', 'list', 'lists', 'query', 'info', 'detail', 'save', 'add', 'update', 'delete',
  'login', 'logout', 'session', 'register', 'resetPass', 'updatePassword',
  'create', 'cancel', 'my-reservations', 'available-slots',
  'ordergroup', 'group', 'value', 'autoSort', 'autoSort2', 'mark-read', 'unread-count',
  'thumbsup', 'upload', 'download', 'option', 'cal', 'follow', 'remind'
];

function listJs(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter((f) => f.endsWith('.js'))
    .map((f) => path.join(dir, f));
}

function collect() {
  const files = [].concat(
    listJs(path.join(PUBLIC, 'js')),
    listJs(path.join(PUBLIC, 'admin', 'js'))
  );
  const found = new Set();
  const pattern = new RegExp('([a-z][a-z0-9]{2,25})/(' + ACTIONS.join('|') + ')(?=[\\`"\'/])', 'g');
  files.forEach((file) => {
    const text = fs.readFileSync(file, 'utf8');
    let m;
    while ((m = pattern.exec(text)) !== null) {
      found.add(m[1] + '/' + m[2]);
    }
  });
  return Array.from(found).sort();
}

function request(method, urlPath, token, body) {
  return new Promise((resolve) => {
    const u = new URL(BASE + urlPath);
    const data = body ? JSON.stringify(body) : null;
    const req = http.request({
      hostname: u.hostname,
      port: u.port,
      path: u.pathname + u.search,
      method,
      headers: Object.assign(
        { 'Content-Type': 'application/json' },
        token ? { Token: token } : {},
        data ? { 'Content-Length': Buffer.byteLength(data) } : {}
      )
    }, (res) => {
      let text = '';
      res.on('data', (c) => { text += c; });
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(text); } catch (err) { /* 非 JSON 说明路由错了 */ }
        resolve({ status: res.statusCode, json, text: text.slice(0, 120) });
      });
    });
    req.on('error', (err) => resolve({ status: 0, json: null, text: err.message }));
    if (data) req.write(data);
    req.end();
  });
}

async function main() {
  const login = await request('POST', PREFIX + '/users/login?username=1&password=1');
  const token = login.json && login.json.token;
  if (!token) {
    console.error('登录失败，无法继续：', login.text);
    process.exit(1);
  }

  const endpoints = collect();
  console.log('从打包产物中提取到 ' + endpoints.length + ' 个接口，开始逐个请求……\n');

  const problems = [];
  for (const item of endpoints) {
    const [table, action] = item.split('/');
    const query = action === 'page' || action === 'list' || action === 'lists' || action === 'query'
      ? '?page=1&limit=5' : '';
    const target = PREFIX + '/' + table + '/' + action + (['info', 'detail', 'cancel', 'thumbsup'].indexOf(action) >= 0 ? '/51' : '') + query;
    const method = ['save', 'add', 'update', 'delete', 'login', 'register', 'create'].indexOf(action) >= 0 ? 'POST' : 'GET';
    const res = await request(method, target, token, method === 'POST' ? {} : null);
    const code = res.json ? res.json.code : -1;
    const okFlag = res.status === 200 && (code === 0 || code === 401 || code === 500);
    if (!okFlag) {
      problems.push(item + ' -> HTTP ' + res.status + ' ' + res.text);
    }
    console.log((okFlag ? '  ok   ' : '  FAIL ') + item.padEnd(28) + (res.json ? 'code=' + res.json.code + ' ' + (res.json.msg || '') : res.text));
  }

  console.log('\n检查完毕，异常 ' + problems.length + ' 项');
  if (problems.length) {
    problems.forEach((p) => console.log('  ' + p));
    process.exit(1);
  }
}

main();
