'use strict';
/**
 * 把原始工程里已构建好的前端产物复制到 demo/public/。
 * 仓库里不重复存一份 26MB 的 dist，克隆后跑一次这个脚本即可。
 *
 *   node tools/prepare-assets.js
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..', '..');
const PUBLIC = path.join(__dirname, '..', 'public');

const SOURCES = [
  {
    label: '学生端',
    from: path.join(ROOT, 'src', 'main', 'resources', 'front', 'front', 'dist'),
    to: path.join(PUBLIC)
  },
  {
    label: '管理端',
    from: path.join(ROOT, 'src', 'main', 'resources', 'admin', 'admin', 'dist'),
    to: path.join(PUBLIC, 'admin')
  },
  {
    label: '上传图片',
    from: path.join(ROOT, 'src', 'main', 'resources', 'static', 'upload'),
    to: path.join(PUBLIC, 'upload')
  }
];

function copyDir(from, to) {
  fs.mkdirSync(to, { recursive: true });
  fs.readdirSync(from, { withFileTypes: true }).forEach((entry) => {
    const src = path.join(from, entry.name);
    const dest = path.join(to, entry.name);
    if (entry.isDirectory()) {
      copyDir(src, dest);
    } else {
      fs.copyFileSync(src, dest);
    }
  });
}

function rmDir(target) {
  if (!fs.existsSync(target)) return;
  fs.readdirSync(target, { withFileTypes: true }).forEach((entry) => {
    const p = path.join(target, entry.name);
    if (entry.isDirectory()) rmDir(p);
    else fs.unlinkSync(p);
  });
  fs.rmdirSync(target);
}

/**
 * 原始工程的 config/config.js 把接口根地址写成了 http://localhost:8080/smartcampusclassressys/，
 * 打包后这句被原样编进 app.js。本地跑没问题，一放公网就变成“请求访问者自己电脑的 8080”，
 * 浏览器直接 ERR_CONNECTION_REFUSED。这里统一改写成同源相对路径。
 */
const HARDCODED = [/https?:\/\/localhost:8080/g, /https?:\/\/127\.0\.0\.1:8080/g];

/**
 * 打包产物里还有一批图片外链（模板自带的 logo、登录页底纹、菜单小图标），全是 http://。
 * 页面是 https，浏览器会做混合内容升级，这些图基本都会加载失败。这里把它们换成仓库内自带的本地副本。
 */
const REMOTE_MAP_FILE = path.join(__dirname, '..', 'static-assets', 'remote-map.json');

function loadRemoteMap() {
  try {
    return JSON.parse(fs.readFileSync(REMOTE_MAP_FILE, 'utf8'));
  } catch (err) {
    return {};
  }
}

function copyLocalAssets() {
  const from = path.join(__dirname, '..', 'static-assets');
  const remote = path.join(from, 'remote');
  const target = path.join(PUBLIC, 'img', 'remote');
  if (fs.existsSync(remote)) {
    fs.mkdirSync(target, { recursive: true });
    fs.readdirSync(remote).forEach((name) => {
      fs.copyFileSync(path.join(remote, name), path.join(target, name));
    });
  }
  const logo = path.join(from, 'logo.svg');
  if (fs.existsSync(logo)) {
    fs.mkdirSync(path.join(PUBLIC, 'img'), { recursive: true });
    fs.copyFileSync(logo, path.join(PUBLIC, 'img', 'logo.svg'));
  }
}

function rewriteAssets(dir, counter) {
  const remoteMap = counter.remoteMap;
  fs.readdirSync(dir, { withFileTypes: true }).forEach((entry) => {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      rewriteAssets(p, counter);
      return;
    }
    // 只处理运行时会加载的文本资源，source map 体积大且不影响执行
    if (!/\.(js|html|css)$/i.test(entry.name)) return;
    let text = fs.readFileSync(p, 'utf8');
    const before = text;
    HARDCODED.forEach((re) => {
      text = text.replace(re, '');
    });
    // 管理端配置里指向学生端首页的绝对地址，改成站点根
    text = text.replace(/\/smartcampusclassressys\/front\/dist\/index\.html/g, '/');
    Object.keys(remoteMap).forEach((url) => {
      if (text.indexOf(url) >= 0) {
        text = text.split(url).join(remoteMap[url]);
        counter.remote += 1;
      }
    });
    if (text !== before) {
      fs.writeFileSync(p, text);
      counter.files += 1;
      counter.hits += before.split('localhost:8080').length - 1;
    }
  });
}

/**
 * 托管环境的分享码网关会丢掉自定义请求头，导致 Token 传不到后端。
 * 给两个入口页注入一层 XHR 补丁，把 Token 追加成查询参数。
 */
function injectShim() {
  const shimSrc = path.join(__dirname, '..', 'static-shim', 'token-query.js');
  if (!fs.existsSync(shimSrc)) return;
  const shimDir = path.join(PUBLIC, 'shims');
  fs.mkdirSync(shimDir, { recursive: true });
  fs.copyFileSync(shimSrc, path.join(shimDir, 'token-query.js'));

  const tag = '<script src="/shims/token-query.js"></script>';
  ['index.html', 'admin/index.html'].forEach((rel) => {
    const file = path.join(PUBLIC, rel);
    if (!fs.existsSync(file)) return;
    let html = fs.readFileSync(file, 'utf8');
    if (html.indexOf('token-query.js') >= 0) return;
    html = html.replace('</head>', '  ' + tag + '\n</head>');
    fs.writeFileSync(file, html);
    console.log('[ok]   ' + rel + ' 已注入 Token 传递补丁');
  });
}

let failed = 0;
SOURCES.forEach((item) => {
  if (!fs.existsSync(item.from)) {
    console.warn('[skip] ' + item.label + ' 缺少构建产物：' + item.from);
    failed += 1;
    return;
  }
  rmDir(item.to);
  copyDir(item.from, item.to);
  console.log('[ok]   ' + item.label + ' -> ' + path.relative(ROOT, item.to));
});

if (failed) {
  console.warn('\n有 ' + failed + ' 项缺失，请先在对应目录执行 npm install && npm run build。');
  process.exit(1);
}
const counter = { files: 0, hits: 0, remote: 0, remoteMap: loadRemoteMap() };
copyLocalAssets();
rewriteAssets(PUBLIC, counter);
console.log('[ok]   接口地址改为同源相对路径，处理 ' + counter.files + ' 个文件');
console.log('[ok]   图片外链替换为本地副本 ' + counter.remote + ' 处');
injectShim();
console.log('\n前端资源已就绪，运行 node server.js 即可。');
