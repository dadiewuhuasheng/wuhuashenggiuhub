# -*- coding: utf-8 -*-
"""
把 db/boot_smartcampusclassressys.sql 里的建表结构与初始数据抽成 demo 用的 JSON 种子。

用法：
    python tools/gen_seed.py            # 在 demo/ 目录下执行
输出：
    data/base.json                      形如 {"users": [{...}], ...}
"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DEMO = os.path.dirname(HERE)
ROOT = os.path.dirname(DEMO)
SQL = os.path.join(ROOT, "db", "boot_smartcampusclassressys.sql")
OUT = os.path.join(DEMO, "data", "base.json")


def read_sql(path):
    for enc in ("utf-8", "utf-8-sig", "gbk"):
        try:
            with open(path, "r", encoding=enc) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    raise SystemExit("无法识别 SQL 文件编码")


def parse_create_tables(sql):
    """返回 {表名: [列名, ...]}，按建表顺序。"""
    schema = {}
    for m in re.finditer(r"CREATE TABLE `(\w+)`\s*\((.*?)\n\)\s*ENGINE", sql, re.S):
        table, body = m.group(1), m.group(2)
        cols = []
        for line in body.split("\n"):
            line = line.strip()
            cm = re.match(r"`(\w+)`\s+\w", line)
            if cm:
                cols.append(cm.group(1))
        schema[table] = cols
    return schema


def split_values(raw):
    """把 VALUES(...) 里的内容按顶层逗号切开。"""
    out, buf, quote, i = [], [], None, 0
    while i < len(raw):
        ch = raw[i]
        if quote:
            if ch == "\\":
                buf.append(ch)
                if i + 1 < len(raw):
                    buf.append(raw[i + 1])
                    i += 2
                    continue
            elif ch == quote:
                quote = None
            buf.append(ch)
        elif ch in ("'", '"'):
            quote = ch
            buf.append(ch)
        elif ch == ",":
            out.append("".join(buf).strip())
            buf = []
        else:
            buf.append(ch)
        i += 1
    if buf:
        out.append("".join(buf).strip())
    return out


def cast(tok):
    if tok.upper() == "NULL":
        return None
    if tok.startswith("'") and tok.endswith("'"):
        return tok[1:-1].replace("\\'", "'").replace('\\"', '"').replace("\\\\", "\\")
    if re.fullmatch(r"-?\d+", tok):
        return int(tok)
    if re.fullmatch(r"-?\d+\.\d+(e-?\d+)?", tok, re.I):
        return float(tok)
    return tok


def parse_inserts(sql, schema):
    tables = {}
    for m in re.finditer(r"INSERT INTO `(\w+)` VALUES \((.*?)\);", sql, re.S):
        table, body = m.group(1), m.group(2)
        cols = schema.get(table)
        if not cols:
            continue
        vals = split_values(body)
        if len(vals) != len(cols):
            # 列数对不上就跳过，避免把脏数据写进演示库
            print("  ! 跳过 %s 的一行（列数 %d != %d）" % (table, len(vals), len(cols)))
            continue
        row = {c: cast(v) for c, v in zip(cols, vals)}
        tables.setdefault(table, []).append(row)
    return tables


def main():
    sql = read_sql(SQL)
    schema = parse_create_tables(sql)
    tables = parse_inserts(sql, schema)
    # 补齐代码里存在、建表脚本里没写的表
    tables.setdefault("audit_log", [])
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(tables, f, ensure_ascii=False, indent=1)
    total = sum(len(v) for v in tables.values())
    print("表 %d 张，记录 %d 条 -> %s" % (len(tables), total, OUT))
    for k in sorted(tables):
        print("   %-24s %d" % (k, len(tables[k])))


if __name__ == "__main__":
    main()
