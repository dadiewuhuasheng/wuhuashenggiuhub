/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80036
 Source Host           : localhost:3306
 Source Schema         : boot_smartcampusclassressys

 Target Server Type    : MySQL
 Target Server Version : 80036
 File Encoding         : 65001

 Date: 09/09/2025 15:59:07
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for aboutus
-- ----------------------------
DROP TABLE IF EXISTS `aboutus`;
CREATE TABLE `aboutus`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '标题',
  `subtitle` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '副标题',
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '内容',
  `picture1` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '图片1',
  `picture2` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '图片2',
  `picture3` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '图片3',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '关于我们' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of aboutus
-- ----------------------------
INSERT INTO `aboutus` VALUES (1, '2026-01-18 14:16:17', '关于我校教室', 'ABOUT OUR LIBRARY', '我校教室建于1985年，现有馆藏文献320万册，设有社会科学阅览区、自然科学阅览区、电子阅览室等12个功能区域。每日开放时间为8:00-22:00（节假日另行通知），年接待读者约150万人次。\n本座位预约系统旨在优化座位资源配置，减少占座现象，为师生提供公平、便捷的座位使用服务。系统支持提前3天预约，可通过校园统一身份认证登录使用。', 'upload/aboutus_picture1.jpg', 'upload/aboutus_picture2.jpg', 'upload/aboutus_picture3.jpg');

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '用户名',
  `password` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '密码',
  `role` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT '管理员' COMMENT '角色',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '新增时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '用户表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES (1, 'admin', 'admin', '管理员', '2026-01-18 14:16:17');

-- ----------------------------
-- Table structure for chat
-- ----------------------------
DROP TABLE IF EXISTS `chat`;
CREATE TABLE `chat`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `userid` bigint(0) NOT NULL COMMENT '用户id',
  `adminid` bigint(0) NULL DEFAULT NULL COMMENT '管理员id',
  `ask` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '提问',
  `reply` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '回复',
  `isreply` int(0) NULL DEFAULT NULL COMMENT '是否回复',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 69 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '在线咨询' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of chat
-- ----------------------------
INSERT INTO `chat` VALUES (61, '2026-01-18 09:23:17', 11, 1, '座位预约后可以更改时间吗？', '可以在预约开始前2小时修改，每次预约最多修改1次', 1);
INSERT INTO `chat` VALUES (62, '2026-01-18 10:15:42', 12, 1, '电子阅览室需要单独预约吗？', '电子阅览室座位与普通座位预约流程一致，无需额外操作', 1);
INSERT INTO `chat` VALUES (63, '2026-01-18 11:08:33', 13, 1, '最多可以连续预约几天座位？', '同一座位最多连续预约3天，每天需重新签到', 1);
INSERT INTO `chat` VALUES (64, '2026-01-18 14:30:22', 14, 1, '忘记签到会有什么影响？', '15分钟内未签到系统将自动取消预约，每月累计3次将限制预约权限', 1);
INSERT INTO `chat` VALUES (65, '2026-01-18 16:45:10', 15, 1, '研讨室如何预约？', '研讨室需通过教室官网单独申请，至少提前1天，单次最长使用4小时', 1);
INSERT INTO `chat` VALUES (66, '2026-01-18 17:22:55', 16, 1, '可以帮同学代预约座位吗？', '系统实行实名预约，严禁代约，违规将暂停账号使用1周', 1);
INSERT INTO `chat` VALUES (67, '2026-01-18 18:05:18', 17, 1, '座位临时不用可以释放吗？', '可以在\"我的预约\"中点击\"释放座位\"，释放后该座位将重新开放预约', 1);
INSERT INTO `chat` VALUES (68, '2026-01-18 19:33:47', 18, 1, '预约系统每天几点更新可预约座位？', '每天0点更新未来3天的可预约座位资源', 1);

-- ----------------------------
-- Table structure for config
-- ----------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '配置参数名称',
  `value` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '配置参数值',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '配置文件' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of config
-- ----------------------------
INSERT INTO `config` VALUES (1, 'picture1', 'upload/picture1.jpg');
INSERT INTO `config` VALUES (2, 'picture2', 'upload/picture2.jpg');
INSERT INTO `config` VALUES (3, 'picture3', 'upload/picture3.jpg');

-- ----------------------------
-- Table structure for discusslibrarynotice
-- ----------------------------
DROP TABLE IF EXISTS `discusslibrarynotice`;
CREATE TABLE `discusslibrarynotice`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `refid` bigint(0) NOT NULL COMMENT '关联表id',
  `userid` bigint(0) NOT NULL COMMENT '用户id',
  `avatarurl` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '头像',
  `nickname` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '评论内容',
  `reply` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '回复内容',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '教室宣传评论表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of discusslibrarynotice
-- ----------------------------

-- ----------------------------
-- Table structure for discusslibseatinfo
-- ----------------------------
DROP TABLE IF EXISTS `discusslibseatinfo`;
CREATE TABLE `discusslibseatinfo`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `refid` bigint(0) NOT NULL COMMENT '关联表id',
  `userid` bigint(0) NOT NULL COMMENT '用户id',
  `avatarurl` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '头像',
  `nickname` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '评论内容',
  `reply` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '回复内容',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '座位信息评论表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of discusslibseatinfo
-- ----------------------------

-- ----------------------------
-- Table structure for librarynotice
-- ----------------------------
DROP TABLE IF EXISTS `librarynotice`;
CREATE TABLE `librarynotice`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `noticeno` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '教室宣传编号',
  `noticetitle` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '教室宣传标题',
  `noticetype` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '教室宣传类型',
  `picture` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '封面',
  `noticeintro` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '教室宣传简介',
  `noticecontent` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '教室宣传详情',
  `updatetime` date NULL DEFAULT NULL COMMENT '发布时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `noticeno`(`noticeno`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 39 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '教室宣传' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of librarynotice
-- ----------------------------
INSERT INTO `librarynotice` VALUES (31, '2026-01-18 14:16:17', 'LIB20250318001', '2025年春季学期教室开放安排', '开放时间调整', 'upload/librarynotice_picture1.jpg,upload/librarynotice_picture2.jpg,upload/librarynotice_picture3.jpg', '2025年春季学期教室开放时间及相关安排', '2025年春季学期教室开放时间如下：\n周一至周五：8:00-22:00\n周六至周日：9:00-21:00\n法定节假日开放时间另行通知。\n本学期将增设夜间学习区，开放至23:00，需单独预约。', '2026-01-18');
INSERT INTO `librarynotice` VALUES (32, '2026-01-18 14:16:17', 'LIB20250318002', '教室新增中文图书5000册', '资源更新', 'upload/librarynotice_picture2.jpg,upload/librarynotice_picture3.jpg,upload/librarynotice_picture4.jpg', '新增哲学、社会科学、自然科学等领域中文图书', '本次新增图书涵盖哲学、经济学、法学、教育学、文学、历史学、理学、工学、农学、医学等多个学科领域，共计5000册。\n新书已上架，可通过教室官网或预约系统查询借阅。\n借阅规则：教师可借20册，期限30天；学生可借10册，期限15天。', '2026-01-18');
INSERT INTO `librarynotice` VALUES (33, '2026-01-18 14:16:17', 'LIB20250318003', '教室\"阅读马拉松\"活动通知', '活动通知', 'upload/librarynotice_picture3.jpg,upload/librarynotice_picture4.jpg,upload/librarynotice_picture5.jpg', '为期7天的阅读马拉松活动，完成挑战可获得证书', '为培养阅读习惯，教室将于4月20日至4月26日举办\"阅读马拉松\"活动：\n1. 活动形式：连续7天，每天阅读不少于1小时\n2. 参与方式：通过教室APP报名并打卡\n3. 奖励设置：完成7天挑战可获得\"阅读达人\"证书及精美图书一本\n4. 评选优秀读后感10篇，将在教室公众号发表', '2026-01-18');
INSERT INTO `librarynotice` VALUES (34, '2026-01-18 14:16:17', 'LIB20250318004', '教室自助借还设备使用指南', '读者指南', 'upload/librarynotice_picture4.jpg,upload/librarynotice_picture5.jpg,upload/librarynotice_picture6.jpg', '详细介绍自助借还设备的使用方法及注意事项', '教室在一楼大厅和各楼层均设有自助借还设备，使用方法如下：\n1. 将校园卡放在感应区\n2. 将要借的图书封面朝上放在扫描区\n3. 确认借阅信息，点击\"确认借阅\"\n4. 借阅成功后会打印借阅凭条\n注意事项：\n- 每台设备一次最多可借10册图书\n- 借还时请确保图书条码清晰可见\n- 如有问题可咨询附近工作人员', '2026-01-18');
INSERT INTO `librarynotice` VALUES (35, '2026-01-18 14:16:17', 'LIB20250318005', '文献传递服务开通通知', '资源更新', 'upload/librarynotice_picture5.jpg,upload/librarynotice_picture6.jpg,upload/librarynotice_picture7.jpg', '教室新增文献传递服务，可获取馆外文献', '为满足师生对馆外文献的需求，教室正式开通文献传递服务：\n1. 服务范围：国内外高校教室、科研机构的文献资源\n2. 申请方式：通过教室官网\"文献传递\"栏目提交申请\n3. 收费标准：本馆读者前5篇/月免费，超出部分按成本收取\n4. 处理时间：一般情况下24-48小时内完成', '2026-01-18');
INSERT INTO `librarynotice` VALUES (36, '2026-01-18 14:16:17', 'LIB20250318006', '教室数字资源使用培训', '培训信息', 'upload/librarynotice_picture6.jpg,upload/librarynotice_picture7.jpg,upload/librarynotice_picture8.jpg', '系列培训帮助读者更好地利用数字资源', '教室将于3月至5月举办数字资源使用系列培训：\n第一期：中文数据库检索技巧（3月25日）\n第二期：外文数据库检索技巧（4月15日）\n第三期：专利文献检索与利用（5月6日）\n培训地点：教室电子阅览室\n参与方式：通过教室预约系统报名\n培训结束后将发放培训证书，可计入第二课堂学分。', '2026-01-18');

-- ----------------------------
-- Table structure for libseatinfo
-- ----------------------------
DROP TABLE IF EXISTS `libseatinfo`;
CREATE TABLE `libseatinfo`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `libseatmingcheng` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '座位名称',
  `libseattype` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '座位类型',
  `libseatpicture` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '座位封面',
  `libseataddress` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '座位地区',
  `libseatintro` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '座位简介',
  `shangyingtime` date NULL DEFAULT NULL COMMENT '上映时间',
  `thumbsupnum` int(0) NULL DEFAULT 0 COMMENT '赞',
  `crazilynum` int(0) NULL DEFAULT 0 COMMENT '踩',
  `clicktime` datetime(0) NULL DEFAULT NULL COMMENT '最近点击时间',
  `clicknum` int(0) NULL DEFAULT 0 COMMENT '点击次数',
  `price` float NOT NULL COMMENT '价格',
  `number` int(0) NULL DEFAULT NULL COMMENT '座位总数',
  `selected` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '已选座位[用,号隔开]',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 59 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '座位信息' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of libseatinfo
-- ----------------------------
INSERT INTO `libseatinfo` VALUES (51, '2026-01-18 14:16:17', '一楼A区101座', '靠窗单人座', 'upload/libseatinfo_libseatpicture1.jpg,upload/libseatinfo_libseatpicture2.jpg,upload/libseatinfo_libseatpicture3.jpg', '一楼社会科学区', '配备充电插座，采光良好，适合长时间学习', '2026-01-18', 128, 3, '2026-01-18 22:16:17', 356, 10, 20, '1,3,5,7,9');
INSERT INTO `libseatinfo` VALUES (52, '2026-01-18 14:16:17', '二楼B区205座', '普通单人座', 'upload/libseatinfo_libseatpicture2.jpg,upload/libseatinfo_libseatpicture3.jpg,upload/libseatinfo_libseatpicture4.jpg', '二楼自然科学区', '安静舒适，配备台灯，适合阅读写作', '2026-01-18', 95, 5, '2026-01-16 21:27:08', 289, 10, 20, '1,3,5,7,9');
INSERT INTO `libseatinfo` VALUES (53, '2026-01-18 14:16:17', '三楼C区312座', '双人学习座', 'upload/libseatinfo_libseatpicture3.jpg,upload/libseatinfo_libseatpicture4.jpg,upload/libseatinfo_libseatpicture5.jpg', '三楼综合阅览区', '适合小组讨论，配备共享台灯和插座', '2026-01-18', 76, 2, '2026-01-18 22:16:17', 215, 10, 20, '1,3,5,7,9');
INSERT INTO `libseatinfo` VALUES (54, '2026-01-18 14:16:17', '四楼电子阅览区408座', '电子阅览座', 'upload/libseatinfo_libseatpicture4.jpg,upload/libseatinfo_libseatpicture5.jpg,upload/libseatinfo_libseatpicture6.jpg', '四楼电子阅览区', '配备高性能电脑，可访问学术数据库', '2026-01-18', 63, 1, '2026-01-18 22:16:17', 189, 10, 20, '1,3,5,7,9');
INSERT INTO `libseatinfo` VALUES (55, '2026-01-18 14:16:17', '一楼静音区115座', '静音区座位', 'upload/libseatinfo_libseatpicture5.jpg,upload/libseatinfo_libseatpicture6.jpg,upload/libseatinfo_libseatpicture7.jpg', '一楼静音区', '全程保持绝对安静，适合深度研究学习', '2026-01-18', 112, 4, '2026-01-18 22:16:17', 320, 10, 20, '1,3,5,7,9');
INSERT INTO `libseatinfo` VALUES (56, '2026-01-18 14:16:17', '五楼研讨室502-1座', '研讨室座位', 'upload/libseatinfo_libseatpicture6.jpg,upload/libseatinfo_libseatpicture7.jpg,upload/libseatinfo_libseatpicture8.jpg', '五楼研讨区', '研讨室座位，需团队预约使用', '2026-01-18', 45, 2, '2026-01-18 22:16:17', 156, 10, 20, '1,3,5,7,9');
INSERT INTO `libseatinfo` VALUES (57, '2026-01-18 14:16:17', '一楼休闲区108座', '休闲阅读座', 'upload/libseatinfo_libseatpicture7.jpg,upload/libseatinfo_libseatpicture8.jpg,upload/libseatinfo_libseatpicture9.jpg', '一楼休闲区', '舒适沙发座，适合轻松阅读', '2026-01-18', 88, 3, '2026-01-18 22:16:17', 245, 10, 20, '1,3,5,7,9');
INSERT INTO `libseatinfo` VALUES (58, '2026-01-18 14:16:17', '三楼考研区320座', '考研专座', 'upload/libseatinfo_libseatpicture8.jpg,upload/libseatinfo_libseatpicture9.jpg,upload/libseatinfo_libseatpicture10.jpg', '三楼考研区', '为考研学生提供的固定座位区', '2026-01-18', 156, 2, '2026-01-18 22:16:17', 412, 10, 20, '1,3,5,7,9');

-- ----------------------------
-- Table structure for libseattype
-- ----------------------------
DROP TABLE IF EXISTS `libseattype`;
CREATE TABLE `libseattype`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `libseattype` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '座位类型',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 49 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '座位类型' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of libseattype
-- ----------------------------
INSERT INTO `libseattype` VALUES (41, '2026-01-18 14:16:17', '靠窗单人座');
INSERT INTO `libseattype` VALUES (42, '2026-01-18 14:16:17', '普通单人座');
INSERT INTO `libseattype` VALUES (43, '2026-01-18 14:16:17', '双人学习座');
INSERT INTO `libseattype` VALUES (44, '2026-01-18 14:16:17', '电子阅览座');
INSERT INTO `libseattype` VALUES (45, '2026-01-18 14:16:17', '静音区座位');
INSERT INTO `libseattype` VALUES (46, '2026-01-18 14:16:17', '研讨室座位');
INSERT INTO `libseattype` VALUES (47, '2026-01-18 14:16:17', '休闲阅读座');
INSERT INTO `libseattype` VALUES (48, '2026-01-18 14:16:17', '考研专座');

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '标题',
  `introduction` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '简介',
  `picture` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '图片',
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '内容',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 99 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '公告信息' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES (91, '2026-01-18 14:16:17', '教室座位预约系统升级公告', '本次系统升级将新增座位临时调换功能，优化预约提醒机制', 'upload/news_picture1.jpg', '<p>各位读者：</p><p>为提升服务质量，教室座位预约系统将于2025年3月25日00:00-06:00进行升级维护，期间系统将暂停服务，给您带来不便，敬请谅解。</p><p>本次升级内容包括：</p><p>1. 新增座位临时调换功能，允许在预约开始后2小时内进行一次座位调换</p><p>2. 优化预约提醒机制，将通过校园APP推送预约提醒</p><p>3. 增加座位使用满意度评价功能</p><p>4. 修复部分已知bug，提升系统稳定性</p><p>如有疑问，请咨询教室服务台，联系电话：020-88887777</p><p>教室</p><p>2025年3月18日</p>');
INSERT INTO `news` VALUES (92, '2026-01-18 14:16:17', '关于考研专座申请的通知', '2026届考研专座申请工作将于4月1日正式启动', 'upload/news_picture2.jpg', '<p>各位考研同学：</p><p>为保障考研同学的学习需求，教室将于2025年4月1日至4月15日开展2026届考研专座申请工作，具体安排如下：</p><p>一、申请时间：2025年4月1日08:00-4月15日17:00</p><p>二、申请方式：通过教室座位预约系统进行线上申请</p><p>三、使用期限：2025年5月1日-2026年1月15日</p><p>四、申请条件：</p><p>1. 我校在读本科生、研究生</p><p>2. 需上传本人有效学生证照片</p><p>3. 无教室违规记录</p><p>五、注意事项：</p><p>1. 考研专座实行实名申请，不得转借他人</p><p>2. 连续7天未使用将自动取消资格</p><p>3. 请保持座位区域整洁</p><p>特此通知</p><p>教室</p><p>2025年3月18日</p>');
INSERT INTO `news` VALUES (93, '2026-01-18 14:16:17', '教室新增电子资源数据库通知', '新增5个外文数据库，可通过电子阅览室访问', 'upload/news_picture3.jpg', '<p>各位读者：</p><p>为满足教学科研需求，教室近期新增5个外文数据库，具体如下：</p><p>1. Web of Science核心合集</p><p>2. IEEE Xplore Digital Library</p><p>3. Springer Nature全文期刊数据库</p><p>4. ScienceDirect期刊全文数据库</p><p>5. ProQuest学位论文全文数据库</p><p>访问方式：</p><p>1. 校园网内直接访问教室官网\"电子资源\"栏目</p><p>2. 校外可通过VPN访问</p><p>3. 电子阅览室所有电脑已预装访问客户端</p><p>使用培训：教室将于3月25日14:30在学术报告厅举办数据库使用培训，欢迎参加。</p><p>教室</p><p>2025年3月18日</p>');
INSERT INTO `news` VALUES (94, '2026-01-18 14:16:17', '关于教室清明节开放安排的通知', '清明节期间教室开放时间调整通知', 'upload/news_picture4.jpg', '<p>各位读者：</p><p>根据学校清明节放假安排，教室开放时间调整如下：</p><p>4月5日（清明节）：9:00-17:00</p><p>4月6日：正常开放（8:00-22:00）</p><p>4月7日：正常开放（8:00-22:00）</p><p>节日期间，座位预约系统将同步调整开放时间，可预约时段为开放时间内每4小时一个时段。</p><p>请各位读者合理安排学习时间，祝大家节日愉快！</p><p>教室</p><p>2025年3月18日</p>');
INSERT INTO `news` VALUES (95, '2026-01-18 14:16:17', '教室举办\"信息素养提升\"系列讲座', '系列讲座将帮助读者提升文献检索与利用能力', 'upload/news_picture5.jpg', '<p>各位读者：</p><p>为提升我校师生的信息素养和文献检索能力，教室将举办\"信息素养提升\"系列讲座，具体安排如下：</p><p>第一讲：学术文献检索技巧（3月20日14:30-16:00）</p><p>第二讲：论文写作与引文规范（3月27日14:30-16:00）</p><p>第三讲：专利文献检索与利用（4月3日14:30-16:00）</p><p>地点：教室学术报告厅</p><p>参与方式：无需预约，直接参加</p><p>讲座内容将同步上传至教室官网\"学习资源\"栏目，无法现场参加的读者可在线观看。</p><p>教室</p><p>2025年3月18日</p>');
INSERT INTO `news` VALUES (96, '2026-01-18 14:16:17', '关于开展\"世界读书日\"系列活动的通知', '4月23日世界读书日期间将举办多项读书活动', 'upload/news_picture6.jpg', '<p>各位读者：</p><p>为迎接第30个\"世界读书日\"，教室将举办系列活动，具体如下：</p><p>1. \"我最喜爱的一本书\"征文比赛（3月20日-4月15日）</p><p>2. 图书漂流活动（4月23日9:00-17:00，教室一楼大厅）</p><p>3. 专家讲座：阅读与人生（4月23日14:30，学术报告厅）</p><p>4. 电子资源免费体验周（4月20日-4月26日）</p><p>活动详情及报名方式请关注教室官网及微信公众号。</p><p>教室</p><p>2025年3月18日</p>');
INSERT INTO `news` VALUES (97, '2026-01-18 14:16:17', 'Library electronic resources update', 'New foreign language databases available for access', 'upload/news_picture7.jpg', '<p>Dear readers,</p><p>To meet the needs of teaching and research, the library has recently added 5 foreign language databases as follows:</p><p>1. Web of Science Core Collection</p><p>2. IEEE Xplore Digital Library</p><p>3. Springer Nature Full-text Journal Database</p><p>4. ScienceDirect Journal Full-text Database</p><p>5. ProQuest Dissertations & Theses Full-text Database</p><p>Access methods:</p><p>1. Direct access to the \"Electronic Resources\" section of the library website within the campus network</p><p>2. Access via VPN off-campus</p><p>3. All computers in the electronic reading room have pre-installed access clients</p><p>A training session on database usage will be held in the Academic Report Hall at 14:30 on March 25. Welcome to attend.</p><p>Library</p><p>March 18, 2025</p>');
INSERT INTO `news` VALUES (98, '2026-01-18 14:16:17', '教室静音区管理规定通知', '进一步规范静音区管理，营造良好学习环境', 'upload/news_picture8.jpg', '<p>各位读者：</p><p>为维护教室静音区的学习环境，营造安静的阅读氛围，现对静音区管理规定重申如下：</p><p>1. 静音区内必须保持绝对安静，禁止交谈、接打电话</p><p>2. 禁止携带食物和有色饮料进入静音区</p><p>3. 手机等电子设备请调至静音状态，禁止外放声音</p><p>4. 就座时请轻拿轻放，避免发出声响</p><p>5. 离开时请将个人物品带走，不得占座</p><p>违反上述规定者，将被劝离静音区，情节严重者将暂停教室使用权限。</p><p>希望各位读者自觉遵守管理规定，共同维护良好的学习环境。</p><p>教室</p><p>2025年3月18日</p>');

-- ----------------------------
-- Table structure for noticetype
-- ----------------------------
DROP TABLE IF EXISTS `noticetype`;
CREATE TABLE `noticetype`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `noticetype` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '教室宣传类型',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '教室宣传类型' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of noticetype
-- ----------------------------
INSERT INTO `noticetype` VALUES (21, '2026-01-18 14:16:17', '活动通知');
INSERT INTO `noticetype` VALUES (22, '2026-01-18 14:16:17', '资源更新');
INSERT INTO `noticetype` VALUES (23, '2026-01-18 14:16:17', '开放时间调整');
INSERT INTO `noticetype` VALUES (24, '2026-01-18 14:16:17', '系统公告');
INSERT INTO `noticetype` VALUES (25, '2026-01-18 14:16:17', '读者指南');
INSERT INTO `noticetype` VALUES (26, '2026-01-18 14:16:17', '培训信息');
INSERT INTO `noticetype` VALUES (27, '2026-01-18 14:16:17', '违规通报');
INSERT INTO `noticetype` VALUES (28, '2026-01-18 14:16:17', '学术讲座');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `orderid` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '预约编号',
  `tablename` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT 'libseatinfo' COMMENT '商品表名',
  `userid` bigint(0) NOT NULL COMMENT '用户id',
  `goodid` bigint(0) NOT NULL COMMENT '商品id',
  `goodname` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '商品名称',
  `picture` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '商品图片',
  `buynumber` int(0) NOT NULL COMMENT '购买数量',
  `price` float NOT NULL DEFAULT 0 COMMENT '价格',
  `discountprice` float NULL DEFAULT 0 COMMENT '折扣价格',
  `total` float NOT NULL DEFAULT 0 COMMENT '总价格',
  `discounttotal` float NULL DEFAULT 0 COMMENT '折扣总价格',
  `type` int(0) NULL DEFAULT 1 COMMENT '支付类型',
  `status` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '状态',
  `address` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '地址',
  `tel` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '电话',
  `consignee` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '收货人',
  `remark` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '备注',
  `logistics` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '物流',
  `goodtype` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '商品类型',
  `start_time` timestamp(0) NULL DEFAULT NULL COMMENT '开始时间',
  `end_time` timestamp(0) NULL DEFAULT NULL COMMENT '结束时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `orderid`(`orderid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '预约' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES (1, '2026-01-18 08:30:25', 'ORD20250318001', 'libseatinfo', 11, 51, '一楼A区101座', 'upload/libseatinfo_libseatpicture1.jpg', 1, 0, 0, 0, 0, 1, '已使用', NULL, '13823888881', '用户姓名1', '需要使用插座', NULL, '靠窗单人座','2026-01-18 08:30:25','2026-01-19 08:30:25');
INSERT INTO `orders` VALUES (2, '2026-01-18 09:15:42', 'ORD20250318002', 'libseatinfo', 12, 53, '三楼C区312座', 'upload/libseatinfo_libseatpicture3.jpg', 1, 0, 0, 0, 0, 1, '已预约', NULL, '13823888882', '用户姓名2', '下午小组讨论', NULL, '双人学习座','2026-01-18 08:30:25','2026-01-19 08:30:25');
INSERT INTO `orders` VALUES (3, '2026-01-18 10:22:17', 'ORD20250318003', 'libseatinfo', 13, 55, '一楼静音区115座', 'upload/libseatinfo_libseatpicture5.jpg', 1, 0, 0, 0, 0, 1, '已取消', NULL, '13823888883', '用户姓名3', '临时有事无法前往', NULL, '静音区座位','2026-01-18 08:30:25','2026-01-19 08:30:25');
INSERT INTO `orders` VALUES (4, '2026-01-18 14:50:33', 'ORD20250318004', 'libseatinfo', 14, 54, '四楼电子阅览区408座', 'upload/libseatinfo_libseatpicture4.jpg', 1, 0, 0, 0, 0, 1, '已使用', NULL, '13823888884', '用户姓名4', '需要查阅电子文献', NULL, '电子阅览座','2026-01-18 08:30:25','2026-01-19 08:30:25');
INSERT INTO `orders` VALUES (5, '2026-01-18 16:18:55', 'ORD20250318005', 'libseatinfo', 15, 58, '三楼考研区320座', 'upload/libseatinfo_libseatpicture8.jpg', 1, 0, 0, 0, 0, 1, '已预约', NULL, '13823888885', '用户姓名5', '晚上复习使用', NULL, '考研专座','2026-01-18 08:30:25','2026-01-19 08:30:25');

-- ----------------------------
-- Table structure for storeup
-- ----------------------------
DROP TABLE IF EXISTS `storeup`;
CREATE TABLE `storeup`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `userid` bigint(0) NOT NULL COMMENT '用户id',
  `refid` bigint(0) NULL DEFAULT NULL COMMENT '商品id',
  `tablename` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '表名',
  `name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '名称',
  `picture` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '图片',
  `type` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT '1' COMMENT '类型(1:收藏,21:赞,22:踩,31:竞拍参与,41:关注)',
  `inteltype` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '推荐类型',
  `remark` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '收藏表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of storeup
-- ----------------------------

-- ----------------------------
-- Table structure for systemintro
-- ----------------------------
DROP TABLE IF EXISTS `systemintro`;
CREATE TABLE `systemintro`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '标题',
  `subtitle` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '副标题',
  `content` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '内容',
  `picture1` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '图片1',
  `picture2` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '图片2',
  `picture3` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '图片3',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '关于我们' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of systemintro
-- ----------------------------
INSERT INTO `systemintro` VALUES (1, '2026-01-18 14:16:17', '教室座位预约系统', 'LIBRARY SEAT RESERVATION SYSTEM', '教室座位预约系统是为优化座位资源配置，提高座位利用率而开发的管理系统。系统支持多种类型座位的预约、使用和管理，包括普通座位、电子阅览座位、研讨室座位等。\n使用流程：1. 登录系统（校园统一身份认证）；2. 选择日期和时段；3. 选择座位类型和具体座位；4. 确认预约；5. 到馆后扫码签到；6. 使用完毕后扫码签退。\n系统规则：每人每天最多预约1个座位，预约后需在规定时间内签到，否则视为违约。累计违约3次将暂停预约权限7天。', 'upload/systemintro_picture1.jpg', 'upload/systemintro_picture2.jpg', 'upload/systemintro_picture3.jpg');

-- ----------------------------
-- Table structure for token
-- ----------------------------
DROP TABLE IF EXISTS `token`;
CREATE TABLE `token`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `userid` bigint(0) NOT NULL COMMENT '用户id',
  `username` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '用户名',
  `tablename` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '表名',
  `role` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '角色',
  `token` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '密码',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '新增时间',
  `expiratedtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '过期时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = 'token表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of token
-- ----------------------------
INSERT INTO `token` VALUES (1, 11, '1', 'users', '用户', 'k75ztyt0jjlyasi2wsdn0wj0k5p9pj2q', '2026-01-16 21:23:51', '2026-01-09 16:56:50');
INSERT INTO `token` VALUES (2, 1, 'admin', 'admin', '管理员', '3etj4vnn06tuqpr372tjfb7pvbp72t8w', '2026-01-16 21:36:09', '2026-01-16 22:50:08');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `username` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '用户账号',
  `password` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '密码',
  `nickname` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '用户姓名',
  `gender` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '性别',
  `avatar` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '头像',
  `telephone` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '用户电话',
  `role` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '角色',
  `money` float NULL DEFAULT 0 COMMENT '余额',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '用户' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (11, '2026-01-18 14:16:17', '1', '1', '用户姓名1', '男', 'upload/users_avatar1.jpg', '13823888881','学生', 200);
INSERT INTO `users` VALUES (12, '2026-01-18 14:16:17', '用户账号2', '123456', '用户姓名2', '男', 'upload/users_avatar2.jpg', '13823888882','学生', 200);
INSERT INTO `users` VALUES (13, '2026-01-18 14:16:17', '用户账号3', '123456', '用户姓名3', '男', 'upload/users_avatar3.jpg', '13823888883','学生', 200);
INSERT INTO `users` VALUES (14, '2026-01-18 14:16:17', '用户账号4', '123456', '用户姓名4', '男', 'upload/users_avatar4.jpg', '13823888884','学生', 200);
INSERT INTO `users` VALUES (15, '2026-01-18 14:16:17', '用户账号5', '123456', '用户姓名5', '男', 'upload/users_avatar5.jpg', '13823888885','学生', 200);
INSERT INTO `users` VALUES (16, '2026-01-18 14:16:17', '用户账号6', '123456', '用户姓名6', '男', 'upload/users_avatar6.jpg', '13823888886','学生', 200);
INSERT INTO `users` VALUES (17, '2026-01-18 14:16:17', '用户账号7', '123456', '用户姓名7', '男', 'upload/users_avatar7.jpg', '13823888887', '学生',200);
INSERT INTO `users` VALUES (18, '2026-01-18 14:16:17', '用户账号8', '123456', '用户姓名8', '男', 'upload/users_avatar8.jpg', '1','学生', 200);



-- ============================================================
-- 如果表已存在且缺少 role 列，执行以下语句：
-- ALTER TABLE `users` ADD COLUMN `role` varchar(100) DEFAULT NULL COMMENT '角色' AFTER `telephone`;
-- ============================================================

-- ----------------------------
-- Table structure for notification
-- ----------------------------
DROP TABLE IF EXISTS `notification`;
CREATE TABLE `notification`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` bigint(0) NULL DEFAULT NULL COMMENT '用户id',
  `message` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '通知消息',
  `type` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '通知类型',
  `related_reservation_id` bigint(0) NULL DEFAULT NULL COMMENT '关联预约ID',
  `reservation_type` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '预约类型',
  `is_read` int(0) NULL DEFAULT 0 COMMENT '是否已读',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '通知' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for classroom_reservation
-- ----------------------------
DROP TABLE IF EXISTS `classroom_reservation`;
CREATE TABLE `classroom_reservation`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `classroom_id` bigint(0) NULL DEFAULT NULL COMMENT '教室ID',
  `classroom_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '教室名称',
  `user_id` bigint(0) NULL DEFAULT NULL COMMENT '用户ID',
  `username` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `start_time` datetime(0) NULL DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime(0) NULL DEFAULT NULL COMMENT '结束时间',
  `purpose` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '使用目的',
  `status` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '状态',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '教室预约' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for address
-- ----------------------------
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address`  (
  `id` bigint(0) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` bigint(0) NULL DEFAULT NULL COMMENT '用户id',
  `address_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '地址名称',
  `consignee` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '收货人',
  `phone` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '电话',
  `province` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '省份',
  `city` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '城市',
  `district` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '区县',
  `address` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '详细地址',
  `is_default_usage` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '是否默认地址',
  `addtime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '地址' ROW_FORMAT = DYNAMIC;
SET FOREIGN_KEY_CHECKS = 1;