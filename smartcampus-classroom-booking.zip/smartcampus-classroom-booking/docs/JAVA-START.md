# 智能化校园教室预约管理系统（smartcampusclassressys）

Spring Boot 2.2.2 + MyBatis-Plus 2.3 + Shiro，JDK 8，端口 8080，context-path `/smartcampusclassressys`。

- 前台：http://localhost:8080/smartcampusclassressys/front/dist/index.html
- 后台：http://localhost:8080/smartcampusclassressys/admin/dist/index.html
- 默认账号：管理员 `admin / admin`，学生 `1 / 1`

## 一、启动方式（默认使用这种方式）

**不要用 `mvn spring-boot:run` 或 `mvn package`。**
`src/main/resources` 下有大量静态资源（`admin/`、`front/`、`static/`），Maven 的 `process-resources` 阶段复制这些文件需要十几分钟。
下面的 `javac` + `java -cp` 方式绕开资源复制：编译约 3.5 秒，启动约 3 秒。

前置条件：
- JDK 8（本机 `D:\jdk8`）。系统默认 JDK 21，不能直接用于本项目。
- Maven（仅用于解析依赖，不参与编译打包）。
- MySQL 8 已启动，且存在库 `boot_smartcampusclassressys`（见第二节）。

在 PowerShell 中，工作目录为项目根目录（`c:\Users\whs\Desktop\r9719`）：

```powershell
# 1) 导出依赖 classpath（依赖有变化时才需要重跑）
mvn -B -q dependency:build-classpath "-Dmdep.outputFile=cp.txt"

# 2) 生成源码清单（不要带 BOM，否则 javac 读不到第一个文件）
$files = (Get-ChildItem -Path src\main\java -Recurse -Filter *.java).FullName
[IO.File]::WriteAllLines("$PWD\sources.txt", $files, (New-Object System.Text.UTF8Encoding($false)))

# 3) 编译到 target\dev-classes
D:\jdk8\bin\javac -encoding UTF-8 -parameters -nowarn -cp (Get-Content cp.txt -Raw) -d target\dev-classes "@sources.txt"

# 4) 启动（classes 与 src\main\resources 直接挂在 classpath 上，静态资源零复制）
$cp = (Get-Content cp.txt -Raw).Trim()
Start-Process D:\jdk8\bin\java.exe -ArgumentList "-cp","target\dev-classes;src\main\resources;$cp","com.SpringbootSchemaApplication" -RedirectStandardOutput app.log -RedirectStandardError app.err -WindowStyle Hidden
```

也可以前台启动便于看日志：

```powershell
D:\jdk8\bin\java -cp "target\dev-classes;src\main\resources;$cp" com.SpringbootSchemaApplication
```

看到 `Started SpringbootSchemaApplication in x.xxx seconds` 即启动成功；日志在 `app.log` / `app.err`。
停止：`Get-Process java | Stop-Process -Force`。

### 三个必须注意的点

1. **必须用 JDK 8**：项目 `java.version=1.8`，Spring Boot 2.2.2 + Tomcat 9 在 JDK 21 上有兼容风险。
2. **必须带 `-parameters`**：`LibseatinfoController`、`CommonController`、`ClassroomReservationController` 中存在 `@RequestParam(required = false)` 未指定参数名，缺少该选项会报 `Name for argument not available`，导致登录等接口 500。
3. **必须带 `-encoding UTF-8`**：源码含中文注释，否则编译报不可映射字符。

### 为什么这样能跑起来

- 无 Lombok / MapStruct 等注解处理器，`javac` 可直接编译全部 185 个源文件。
- MyBatis XML 全在 `src/main/resources/mapper/`，`mybatis-plus.mapper-locations: classpath*:mapper/*.xml` 直接从源目录加载，不依赖复制。
- `com.config.InterceptorConfig` 将 `classpath:/admin/`、`classpath:/front/`、`classpath:/static/` 等注册为静态资源目录，源码目录挂在 classpath 上即可直接访问。
- `application.yml` 没有 Maven 占位符，不需要 resource filtering。
- 上传文件写入 `src/main/resources/static/upload`（`FileController` 用 `ResourceUtils.getURL("classpath:static")`），即直接落到源码目录，不存在 target 与源码不同步的问题。

产物说明：`cp.txt`、`sources.txt`、`target\dev-classes`、`app.log`、`app.err` 均为本地开发产物，不应提交。

## 二、数据库

`db/boot_smartcampusclassressys.sql`（Navicat 导出，不含建库语句，需先建库）：

```powershell
mysql -uroot -p123456 -e "CREATE DATABASE IF NOT EXISTS boot_smartcampusclassressys DEFAULT CHARACTER SET utf8mb4;"
mysql -uroot -p123456 boot_smartcampusclassressys -e "source db/boot_smartcampusclassressys.sql"
```

连接配置见 `src/main/resources/application.yml`（root / 123456，库名 `boot_smartcampusclassressys`）。

## 三、目录结构

```
src/main/java/com          185 个 Java 源文件，主类 com.SpringbootSchemaApplication
src/main/resources/admin   后台前端（Vue）
src/main/resources/front   前台前端（Vue）
src/main/resources/mapper  MyBatis XML（21 个）
src/main/resources/static  静态资源、上传目录 static/upload
db/                        数据库脚本
```
